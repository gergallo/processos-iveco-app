(function(){
"use strict";
const STALE_MIN = 75;           // follow é de hora em hora: acima disso marca como desatualizado
const RISK_MIN = 120;           // até 2h de atraso previsto = atenção; acima = crítico
const ST_ENVIAR="ENVIAR PARA A IVECO";
const STATUS_OPTS = ["EM PROGRAMAÇÃO","EM TRÂNSITO","AGUARDANDO CARREGAMENTO","AGUARDANDO DESCARGA","EM DESCARGA","ENTREGUE","EM MANUTENÇÃO","PARADO / OCORRÊNCIA","NÃO ENCONTRADO NO MAPA"];
// Betim é base/transbordo: entregue só conta quando o container chega na planta da Iveco (Sete Lagoas)
const KM_BETIM_IVECO=80;
const REGRA_BETIM=false; // regras de local de entrega/status desativadas a pedido: dados exatamente como na planilha
function viaBetim(f){ return REGRA_BETIM && !!f && /BETIM/.test(norm(f.local_entrega||"")); }
function naBetim(f){ return viaBetim(f) && !!f.chegada; }
function enviarIveco(f){ return viaBetim(f) && (f.status===ST_ENVIAR || /ENTREG/i.test(f.status||"")); }
function entregueIveco(f){ return !!(f && f.chegada) && !viaBetim(f); }
// Veículo em manutenção: reconhecido pelo status/localização do follow ou marcado na edição
const MANUT_RE=/MANUTEN|PANE|QUEBR|OFICINA|SOCORRO|BORRACHAR|PNEU|MEC[AÂ]NIC|GUINCHO|AVARIA|DEFEITO/i;
function emManut(f){ return !!(f && !f.chegada && (f.manut===true || MANUT_RE.test((f.status||"")+" "+(f.localizacao||"")))); }
function manutDesde(f){ const h=(f&&f.hist)||[]; let t=null; for(let i=h.length-1;i>=0;i--){ if(MANUT_RE.test((h[i].status||"")+" "+(h[i].loc||""))) t=h[i].t; else break; } return t||f.manutDesde||f.editadoEm||f.atualizadoEm||null; }
function manutTxt(f){ const d=manutDesde(f); return `Em manutenção${f.localizacao?` em ${lugar(f.localizacao)}`:""}${d?` desde ${fmt(d)}`:""}${f.manut_motivo?` · ${f.manut_motivo}`:""}${f.manut_lib?` · liberação prevista ${fmt(f.manut_lib)}`:""}`; }
function avisoManutCliente(fs){
  const now=new Date(); let t=`*Aviso Iveco – veículo em manutenção* (${fmt(now)})\n`;
  fs.forEach(f=>{ const irmaos=Object.values(state.follow).filter(x=>x.placa_cavalo&&x.placa_cavalo===f.placa_cavalo&&!x.chegada); const cns=irmaos.length?irmaos:[f];
    t+=`\nVeículo ${f.placa_cavalo||"—"}${f.placa_reboque?"/"+f.placa_reboque:""} – container${cns.length>1?"s":""} ${cns.map(x=>x.container).join(" e ")}\n`;
    cns.forEach(x=>{ const p=state.prog[x.container]; if(p&&p.necessidade) t+=`• ${x.container}: necessidade ${fmt(p.necessidade)}${isCrit(p)?` (${p.criticidade})`:""}\n`; });
    t+=`• Situação: em manutenção${f.localizacao?` em ${lugar(f.localizacao)}`:""}${manutDesde(f)?`, desde ${fmt(manutDesde(f))}`:""}\n`;
    if(f.manut_motivo) t+=`• Motivo: ${f.manut_motivo}\n`;
    t+= f.manut_lib ? `• Previsão de liberação: ${fmt(f.manut_lib)}\n` : `• Previsão de liberação: em avaliação\n`;
    if(f.prev_chegada) t+=`• Nova previsão de chegada: ${fmt(f.prev_chegada)}\n`; });
  return t+`\nEstamos avaliando a substituição do cavalo mecânico para minimizar o atraso e informaremos a cada atualização.`;
}

const state = { prog:{}, follow:{}, meta:{}, envios:{}, alertas:{}, rodMeta:{}, rodVer:"ativos", db:null, tab:"tab", bi:{cn:[],crit:[],dia:[],carga:["transito","porto","descarga","semveic"],sit:[],dest:[],prog:"",sel:""}, biOpen:null, biQ:"", q:"", dia:"", sit:"", periodo:"7", online:false };
const $ = s => document.querySelector(s);
/* armador pelo prefixo do container (códigos de dono registrados no BIC); container de leasing depende do cadastro manual */
const ARMADOR_PREF={MSCU:"MSC",MEDU:"MSC",MSMU:"MSC",MSDU:"MSC",MSBU:"MSC",MSNU:"MSC",
  MAEU:"MAERSK",MSKU:"MAERSK",MRKU:"MAERSK",MRSU:"MAERSK",MNBU:"MAERSK",SUDU:"MAERSK",
  HLBU:"HAPAG-LLOYD",HLXU:"HAPAG-LLOYD",HAMU:"HAPAG-LLOYD",UACU:"HAPAG-LLOYD",UETU:"HAPAG-LLOYD",UASU:"HAPAG-LLOYD",CPSU:"HAPAG-LLOYD",
  CMAU:"CMA CGM",CGMU:"CMA CGM",ECMU:"CMA CGM",APZU:"CMA CGM",APHU:"CMA CGM",APRU:"CMA CGM",
  CSNU:"COSCO",CBHU:"COSCO",CCLU:"COSCO",OOLU:"OOCL",OOCU:"OOCL",
  EGHU:"EVERGREEN",EISU:"EVERGREEN",EITU:"EVERGREEN",EMCU:"EVERGREEN",ONEU:"ONE",NYKU:"ONE",MOLU:"ONE",KKFU:"ONE",
  ZIMU:"ZIM",ZCSU:"ZIM",YMLU:"YANG MING",YMMU:"YANG MING",HDMU:"HMM",HMMU:"HMM",PCIU:"PIL"};
const ARMADORES_LISTA=["MSC","MAERSK","HAPAG-LLOYD","CMA CGM","COSCO","OOCL","EVERGREEN","ONE","ZIM","YANG MING","HMM","PIL"];
function armadorDe(cn){ const f=state.follow[cn]||{}, p=state.prog[cn]||{}; const m=(f.armador||p.armador||"").trim(); if(m) return m.toUpperCase(); return ARMADOR_PREF[String(cn||"").slice(0,4).toUpperCase()]||""; }
/* ---------- aba Tabela: controle simples estilo Excel ---------- */
const TB={dias:null, ord:{k:"prev",d:1}, q:"", proc:"", sel:new Set(), verExc:false, exc:{}, sub:null};
try{ TB.exc=JSON.parse(localStorage.getItem("iveco.tabela.exc")||"{}")||{}; }catch(e){}
function tbSub(){ if(TB.sub||!state.db) return; try{ TB.sub=state.db.collection("ocultos").onSnapshot(s=>{ const m={}; s.docs.forEach(d=>{ const x=d.data(); if(x&&!x.restaurado) m[d.id]=x; }); TB.exc=m; try{ localStorage.setItem("iveco.tabela.exc",JSON.stringify(m)); }catch(e){} renderTab(); },e=>{ console.warn("ocultos",e); }); }catch(e){ console.warn(e); TB.sub=true; } }
async function tbExcluir(cns,restaurar){ const em=iso(new Date()); const ant={...TB.exc};
  cns.forEach(cn=>{ if(restaurar) delete TB.exc[cn]; else TB.exc[cn]={em}; }); TB.exc={...TB.exc}; TB.sel.clear(); renderTab();
  try{ localStorage.setItem("iveco.tabela.exc",JSON.stringify(TB.exc)); }catch(e){}
  if(!state.db){ toast("Banco indisponível — exclusão só neste aparelho"); return; }
  try{ for(const cn of cns){ const d=state.db.doc("ocultos/"+cn); if(restaurar) await d.delete(); else await d.set({container:cn,em}); }
    toast(restaurar?cns.length+" container(s) de volta à lista":cns.length+" container(s) excluído(s) da lista · veja em Excluídos"); }
  catch(e){ console.warn(e); TB.exc=ant; renderTab(); toast("Não foi possível salvar: "+((e&&e.message)||"sem permissão de edição")); } }

try{ const t=JSON.parse(localStorage.getItem("iveco.tabela")||"null"); if(t){ TB.dias=t.dias||null; TB.ord=t.ord||TB.ord; TB.proc=t.proc||""; } }catch(e){}
function tbSalva(){ try{ localStorage.setItem("iveco.tabela",JSON.stringify({dias:TB.dias,ord:TB.ord,proc:TB.proc})); }catch(e){} }
/* Processo: carga "DESOVADO" na programação = desovado; demais (PORTO) = ovado / container cheio. Campo manual f.processo/p.processo prevalece. */
function tbProc(p,f){ const m=String((f&&f.processo)||(p&&p.processo)||"").toUpperCase(); if(/DESOV/.test(m)) return "DESOVADO"; if(/OVAD|CHEIO/.test(m)) return "OVADO";
  const c=String((p&&p.carga)||"").toUpperCase(); if(/DESOV/.test(c)) return "DESOVADO"; return p?"OVADO":""; }
function tbLinhas(){ const now=new Date(), L=[];
  biLinhas().forEach(r=>{ const f=r.f, p=r.p, d=dia((p&&p.necessidade)||(f&&f.data_prog)||"")||"";
    let prev=null, prevTxt="—", tipoPrev="";
    if(f&&f.chegada){ prev=f.chegada; prevTxt=fmt(f.chegada); tipoPrev="chegou"; }
    else if(f&&f.prev_chegada){ prev=f.prev_chegada; prevTxt=fmt(f.prev_chegada); tipoPrev="prevista"; }
    else if(f){ const q=restante(f,now); if(q&&q.eta){ prev=iso(q.eta); prevTxt="≈ "+fmt(q.eta); tipoPrev="estimada"; } }
    const st=f?(f.status||"—"):"SEM VEÍCULO";
    const proc=tbProc(p,f);
    const ref=dia((f&&f.data_prog)||"")||d, olho=!!(prev&&tipoPrev!=="chegou"&&ref&&String(prev).slice(0,16)>ref+"T23:00");
    L.push({cn:r.cn, dia:d, st, pos:f?lugar(f.localizacao):"—", posEm:f&&f.atualizadoEm?fmt(f.atualizadoEm):"", prev, prevTxt, tipoPrev, tone:r.manut?"crit":r.tone, need:r.need, olho, crit:isCrit(p)?String(p.criticidade).trim().toUpperCase():"", proc, prog:(f&&f.data_prog)||"", progTxt:f&&f.data_prog?fmt(f.data_prog):"—", placa:(f&&f.placa_cavalo)||""}); });
  return L; }
function renderTab(){
  { const tbar=document.querySelector(".toolbar"); if(tbar&&state.tab==="tab") tbar.hidden=true; }
  const el=$("#v-tab"); if(!el||el.hidden) return; tbSub();
  const L=tbLinhas(), hoje=iso(new Date()).slice(0,10), diasAll=[...new Set(L.map(r=>r.dia).filter(Boolean))].sort().reverse();
  if(TB.dias===null) TB.dias=diasAll.includes(hoje)?[hoje]:[];
  const sel=new Set(TB.dias), q=TB.q.trim().toUpperCase();
  const nExc=L.filter(r=>TB.exc[r.cn]).length; if(TB.verExc&&!nExc) TB.verExc=false;
  const vis=r=>TB.verExc?!!TB.exc[r.cn]:!TB.exc[r.cn];
  let rows=L.filter(r=>vis(r)&&(!sel.size||sel.has(r.dia))&&(!TB.proc||r.proc===TB.proc)&&(!q||(r.cn+" "+r.placa+" "+r.pos+" "+r.st+" "+r.proc+" "+r.crit+(r.crit?" CRITICO CRÍTICO":"")).toUpperCase().includes(q)));
  const K={proc:r=>r.proc, cn:r=>r.cn, dia:r=>r.dia, prog:r=>r.prog||"9999", st:r=>r.st, pos:r=>r.pos, prev:r=>r.prev||"9999"}, k=K[TB.ord.k]||K.prev;
  const fim=r=>/^(ENTREGUE|AGUARDANDO DESCARGA)$/i.test(String(r.st).trim())?1:0;
  rows.sort((a,b)=>(fim(a)-fim(b))||(k(a)<k(b)?-1:k(a)>k(b)?1:0)*TB.ord.d);
  const lbl=d=>{ const [y,m,dd]=d.split("-"); const w=["dom","seg","ter","qua","qui","sex","sáb"][new Date(d+"T12:00").getDay()]; return `${dd}/${m} ${w}`+(d===hoje?" · hoje":""); };
  const resumo=!sel.size?"Todas as datas":[...sel].sort().map(d=>d.slice(8,10)+"/"+d.slice(5,7)).join(", ");
  const th=(k,t)=>`<th data-k="${k}" class="${TB.ord.k===k?"on":""}">${t}${TB.ord.k===k?(TB.ord.d>0?" ▲":" ▼"):""}</th>`;
  const COR={crit:"var(--crit)",warn:"var(--warn)",ok:"var(--ok)",info:"var(--info)"};
  el.innerHTML=`<div class="tb-top">
      <div class="tb-dd"><button type="button" class="tb-btn" id="tb-d" aria-expanded="false"><span class="tb-l">Data (expectativa na planta)</span><b>${esc(resumo)}</b><span>▾</span></button>
        <div class="tb-pop" id="tb-pop" hidden><div class="tb-pa"><button type="button" data-a="hoje">Hoje</button><button type="button" data-a="todas">Todas</button><button type="button" data-a="limpa">Limpar</button></div>
          <div class="tb-pl">${diasAll.map(d=>`<label class="${sel.has(d)?"on":""}"><input type="checkbox" value="${d}" ${sel.has(d)?"checked":""}> ${lbl(d)} <span class="sub">${L.filter(r=>r.dia===d).length}</span></label>`).join("")||'<p class="sub">Sem datas.</p>'}</div></div></div>
      <div class="tb-seg" role="group" aria-label="Processo">${[["","Todos"],["OVADO","Ovados"],["DESOVADO","Desovados"]].map(([v,t])=>`<button type="button" data-p="${v}" class="${TB.proc===v?"on":""}">${t} <span class="sub">${L.filter(r=>vis(r)&&(!sel.size||sel.has(r.dia))&&(!v||r.proc===v)).length}</span></button>`).join("")}</div>
      <input class="tb-q" id="tb-q" type="search" placeholder="Buscar container, placa, posição…" value="${esc(TB.q)}">
      <span class="tb-n"><b>${rows.length}</b> container${rows.length===1?"":"s"}</span>
      ${TB.sel.size?`<button class="btn tb-del ${TB.verExc?"res":""}" type="button" id="tb-del">${TB.verExc?"↩ Restaurar":"🗑 Excluir da lista"} (${TB.sel.size})</button>`:""}
      ${nExc?`<button class="btn tb-exc ${TB.verExc?"on":""}" type="button" id="tb-exc">${TB.verExc?"← Voltar à lista":"Excluídos ("+nExc+")"}</button>`:""}
      <button class="btn" type="button" id="tb-xls">Exportar Excel</button></div>
    ${TB.verExc?'<div class="tb-aviso">Mostrando os containers excluídos da lista. Marque e clique em <b>Restaurar</b> para trazê-los de volta.</div>':""}
    <div class="tb-wrap"><table class="tb"><thead><tr><th class="tb-i">#</th><th class="tb-ck"><input type="checkbox" id="tb-all" aria-label="Marcar todos" ${rows.length&&rows.every(r=>TB.sel.has(r.cn))?"checked":""}></th>${th("cn","Container")}${th("proc","Processo")}${th("dia","Data")}${th("prog","Programado para")}${th("st","Status")}${th("pos","Última posição")}${th("prev","Previsão de chegada")}<th class="tb-x"></th></tr></thead>
      <tbody>${rows.map((r,i)=>`<tr class="${/MANUTEN/i.test(String(r.st))?"tb-man":/SEM VE[IÍ]CULO/i.test(String(r.st))?"tb-sv":/^(ENTREGUE|AGUARDANDO DESCARGA)$/i.test(String(r.st).trim())?"tb-ok":""}"><td class="tb-i">${i+1}</td><td class="tb-ck"><input type="checkbox" data-cn="${esc(r.cn)}" ${TB.sel.has(r.cn)?"checked":""} aria-label="Selecionar ${esc(r.cn)}"></td><td class="mono"><span class="tb-dot" style="background:${COR[r.tone]||"var(--muted)"}"></span>${esc(r.cn)}${r.crit?`<span class="tb-sir" title="Processo crítico · ${esc(r.crit)}" aria-label="Processo crítico">🚨</span>`:""}</td><td>${r.proc?`<span class="tb-pr ${r.proc==="OVADO"?"ov":"de"}">${r.proc==="OVADO"?"Ovado":"Desovado"}</span>`:"—"}</td><td>${r.dia?r.dia.slice(8,10)+"/"+r.dia.slice(5,7):"—"}</td><td>${esc(r.progTxt)}</td><td>${esc(r.st)}</td><td>${esc(r.pos)}${r.posEm?`<span class="sub"> · ${esc(r.posEm)}</span>`:""}</td><td class="${r.tipoPrev}">${esc(r.prevTxt)}${r.tipoPrev==="chegou"?' <span class="sub">(chegou)</span>':""}${r.olho?'<span class="tb-olho" title="Previsão de chegada depois das 23:00 do dia programado" aria-label="Atenção: chegada depois das 23h">⚠️</span>':""}</td><td class="tb-x"><button type="button" data-x="${esc(r.cn)}" title="${TB.verExc?"Restaurar na lista":"Excluir da lista"}">${TB.verExc?"↩":"✕"}</button></td></tr>`).join("")||`<tr><td colspan="10" class="tb-vz">${TB.verExc?"Nenhum container excluído nessas datas.":"Nenhum container nas datas escolhidas."}</td></tr>`}</tbody></table></div>`;
  const pop=el.querySelector("#tb-pop"), bt=el.querySelector("#tb-d");
  bt.onclick=e=>{ e.stopPropagation(); pop.hidden=!pop.hidden; bt.setAttribute("aria-expanded",String(!pop.hidden)); };
  pop.onclick=e=>e.stopPropagation();
  pop.querySelectorAll("input").forEach(c=>c.onchange=()=>{ const s=new Set(TB.dias); c.checked?s.add(c.value):s.delete(c.value); TB.dias=[...s]; tbSalva(); renderTab(); $("#tb-pop").hidden=false; });
  pop.querySelectorAll("[data-a]").forEach(b=>b.onclick=()=>{ const a=b.dataset.a; TB.dias=a==="hoje"?[hoje]:a==="todas"?diasAll.slice():[]; tbSalva(); renderTab(); $("#tb-pop").hidden=false; });
  const qi=el.querySelector("#tb-q"); qi.oninput=()=>{ TB.q=qi.value; const p=qi.selectionStart; renderTab(); const n=$("#tb-q"); n.focus(); n.setSelectionRange(p,p); };
  el.querySelectorAll("tbody .tb-ck input").forEach(c=>c.onchange=()=>{ c.checked?TB.sel.add(c.dataset.cn):TB.sel.delete(c.dataset.cn); renderTab(); });
  const all=el.querySelector("#tb-all"); if(all) all.onchange=()=>{ rows.forEach(r=>all.checked?TB.sel.add(r.cn):TB.sel.delete(r.cn)); renderTab(); };
  const del=el.querySelector("#tb-del"); if(del) del.onclick=()=>tbExcluir([...TB.sel],TB.verExc);
  el.querySelectorAll("[data-x]").forEach(b=>b.onclick=()=>tbExcluir([b.dataset.x],TB.verExc));
  const ex=el.querySelector("#tb-exc"); if(ex) ex.onclick=()=>{ TB.verExc=!TB.verExc; TB.sel.clear(); renderTab(); };
  el.querySelectorAll(".tb-seg [data-p]").forEach(b=>b.onclick=()=>{ TB.proc=b.dataset.p; tbSalva(); renderTab(); });
  el.querySelectorAll("th[data-k]").forEach(t=>t.onclick=()=>{ const k=t.dataset.k; TB.ord=TB.ord.k===k?{k,d:-TB.ord.d}:{k,d:1}; tbSalva(); renderTab(); });
  el.querySelector("#tb-xls").onclick=async()=>{ if(typeof XLSX==="undefined"){ toast("Excel indisponível"); return; }
    const aoa=[["Container","Crítico","Processo","Data","Programado para","Status","Última posição","Atualizado em","Previsão de chegada","Tipo","Após 23h"]].concat(rows.map(r=>[r.cn,r.crit?"🚨 "+r.crit:"",r.proc==="OVADO"?"Ovado":r.proc==="DESOVADO"?"Desovado":"",r.dia?r.dia.split("-").reverse().join("/"):"",r.prog?r.progTxt:"",r.st,r.pos,r.posEm,r.prevTxt.replace("≈ ",""),r.tipoPrev,r.olho?"⚠️ SIM":""]));
    const ws=XLSX.utils.aoa_to_sheet(aoa); ws["!cols"]=[{wch:14},{wch:20},{wch:11},{wch:11},{wch:16},{wch:24},{wch:30},{wch:13},{wch:18},{wch:10},{wch:10}]; ws["!autofilter"]={ref:"A1:K"+aoa.length};
    const wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,ws,"Controle"); const buf=XLSX.write(wb,{type:"array",bookType:"xlsx"});
    const d=new Date(), nome=`Controle_Iveco_${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}.xlsx`;
    const dl=await window.APP_SERVICOS?.use?.("downloads"); if(!dl){ toast("Download indisponível nesta visualização."); return; }
    try{ await dl.save({filename:nome,data:new Blob([buf],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"})}); toast("Planilha salva: "+nome); }catch(e){ if(e.code!=="declined") toast("Não foi possível exportar."); } };
}
document.addEventListener("click",()=>{ const p=document.getElementById("tb-pop"); if(p&&!p.hidden){ p.hidden=true; const b=document.getElementById("tb-d"); b&&b.setAttribute("aria-expanded","false"); } });
/* ---------- aba Follow cliente: resumo estilo Excel para enviar ao cliente ---------- */
const FC_COLS=[
  {k:"id",t:"ID (Nº CTRN/NºPROCESSO/NF)",w:22},
  {k:"local",t:"LOCAL DE ENTREGA",w:16},
  {k:"status",t:"STATUS GERAL",w:22},
  {k:"loc",t:"LOCALIZAÇÃO",w:30},
  {k:"inicio",t:"INICIO DE VIAGEM",w:17,dt:1},
  {k:"prev",t:"PREV. DE CHEGADA",w:17,dt:1},
  {k:"prog",t:"DATA PROGRAMADA",w:17,dt:1},
  {k:"cheg",t:"CHEGADA NO CLIENTE",w:17,dt:1},
  {k:"cav",t:"PLACA CAVALO",w:12},
  {k:"reb",t:"PLACA REBOQUE",w:12},
  {k:"mot",t:"MOTORISTA",w:28},
  {k:"marca",t:"MARCA DO VEÍCULO",w:14}];
const FC={src:"ult", ord:null, filt:{}, open:null, oq:""};
try{ const t=JSON.parse(localStorage.getItem("iveco.fc")||"null"); if(t){ FC.src=t.src||"ult"; FC.ord=t.ord||null; FC.filt=t.filt||{}; } }catch(e){}
function fcSalva(){ try{ localStorage.setItem("iveco.fc",JSON.stringify({src:FC.src,ord:FC.ord,filt:FC.filt})); }catch(e){} }
const fcDT=s=>{ if(!s) return ""; const m=String(s).match(/^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?/); return m?`${m[3]}/${m[2]}/${m[1]}${m[4]?" "+m[4]+":"+m[5]:""}`:String(s); };
function fcLinhas(){ const uf=String(state.meta.ultimoFollow||"").slice(0,16), vistos=new Set(), L=[];
  Object.values(state.follow).filter(f=>FC.src==="todos"||!uf||String(f.atualizadoEm||"").slice(0,16)>=uf)
    .sort((a,b)=>String(a.container).localeCompare(String(b.container)))
    .forEach(f=>{ const id=String(f.idOriginal||f.container||"").trim(); if(vistos.has(id)) return; vistos.add(id);
      L.push({_f:f, id, local:f.local_entrega||"", status:f.status||"", loc:f.localizacao||"", inicio:f.inicio||"", prev:f.prev_chegada||"", prog:f.data_prog||"", cheg:f.chegada||"",
        cav:f.placa_cavalo||"", reb:f.placa_reboque||"", mot:f.motorista||"", marca:f.marca||""}); });
  return L; }
const fcTxt=(r,c)=>c.dt?fcDT(r[c.k]):String(r[c.k]||"");
function fcAplica(L,exceto){ return L.filter(r=>FC_COLS.every(c=>{ if(c.k===exceto) return true; const f=FC.filt[c.k]; return !f||f.includes(fcTxt(r,c)); })); }
function renderFC(){
  { const tbar=document.querySelector(".toolbar"); if(tbar&&state.tab==="fc") tbar.hidden=true; }
  const el=$("#v-fc"); if(!el||el.hidden) return;
  const L=fcLinhas(); let rows=fcAplica(L);
  if(FC.ord){ const c=FC_COLS.find(x=>x.k===FC.ord.k); if(c){ const v=r=>c.dt?String(r[c.k]||"9999"):fcTxt(r,c).toUpperCase(); rows.sort((a,b)=>(v(a)<v(b)?-1:v(a)>v(b)?1:0)*FC.ord.d); } }
  const nF=Object.keys(FC.filt).length, uf=state.meta.ultimoFollow;
  const pop=k=>{ const c=FC_COLS.find(x=>x.k===k); const base=fcAplica(L,k), cont={}; base.forEach(r=>{ const t=fcTxt(r,c); cont[t]=(cont[t]||0)+1; });
    const vals=Object.keys(cont).sort((a,b)=>c.dt?-1*a.split(" ")[0].split("/").reverse().join("").concat(a.split(" ")[1]||"").localeCompare(b.split(" ")[0].split("/").reverse().join("").concat(b.split(" ")[1]||"")):a.localeCompare(b,"pt-BR"));
    const sel=FC.filt[k]; const q=norm(FC.oq||"");
    return `<div class="fc-pop" id="fc-pop" role="dialog" aria-label="Filtro ${esc(c.t)}">
      <button type="button" class="fc-po" data-so="1">↑ Classificar de A a Z${c.dt?" (mais antiga)":""}</button>
      <button type="button" class="fc-po" data-so="-1">↓ Classificar de Z a A${c.dt?" (mais recente)":""}</button>
      ${sel?`<button type="button" class="fc-po" data-limpa="1">✕ Limpar filtro de "${esc(c.t)}"</button>`:""}
      <input class="fc-pq" id="fc-pq" type="search" placeholder="Pesquisar" value="${esc(FC.oq||"")}">
      <div class="fc-pl"><label class="fc-all"><input type="checkbox" data-all="1" ${!sel?"checked":""}> (Selecionar tudo)</label>
      ${vals.map(v=>`<label ${q&&!norm(v||"(vazias)").includes(q)?"hidden":""}><input type="checkbox" value="${esc(v)}" ${!sel||sel.includes(v)?"checked":""}> ${v?esc(v):"<i>(Vazias)</i>"} <span class="sub">${cont[v]}</span></label>`).join("")}</div>
      <div class="fc-pb"><button type="button" class="btn primary" data-ok="1">OK</button><button type="button" class="btn" data-x="1">Cancelar</button></div></div>`; };
  el.innerHTML=`<div class="fc-top">
      <div class="tb-seg" role="group" aria-label="Base"><button type="button" data-src="ult" class="${FC.src==="ult"?"on":""}">Último follow${uf?" · "+esc(fmt(uf)):""}</button><button type="button" data-src="todos" class="${FC.src==="todos"?"on":""}">Todos os follows</button></div>
      <span class="tb-n"><b>${rows.length}</b> de ${L.length} linha${L.length===1?"":"s"}${nF?` · ${nF} filtro${nF>1?"s":""} ativo${nF>1?"s":""}`:""}</span>
      ${nF||FC.ord?`<button class="btn" type="button" id="fc-clr">Limpar filtros e ordem</button>`:""}
      <span style="flex:1"></span>
      <button class="btn" type="button" id="fc-xls">Exportar Excel</button>
      <button class="btn primary fc-copy" type="button" id="fc-copy">📋 Copiar follow</button></div>
    <div class="tb-wrap fc-wrap"><table class="tb fc" id="fc-t"><thead><tr><th class="tb-i">#</th>${FC_COLS.map(c=>`<th class="${FC.filt[c.k]?"fil":""} ${FC.ord&&FC.ord.k===c.k?"on":""}"><div class="fc-th"><span>${esc(c.t)}${FC.ord&&FC.ord.k===c.k?(FC.ord.d>0?" ▲":" ▼"):""}</span><button type="button" class="fc-fb" data-fk="${c.k}" aria-label="Filtrar e classificar ${esc(c.t)}" title="Filtrar e classificar">${FC.filt[c.k]?"⏷":"▾"}</button></div>${FC.open===c.k?pop(c.k):""}</th>`).join("")}</tr></thead>
    <tbody>${rows.map((r,i)=>`<tr class="${/ENTREG/i.test(r.status)?"tb-ok":/MANUTEN/i.test(r.status)?"tb-man":""}"><td class="tb-i">${i+1}</td>${FC_COLS.map(c=>`<td class="${c.k==="id"||c.k==="cav"||c.k==="reb"?"mono":""}">${esc(fcTxt(r,c))}</td>`).join("")}</tr>`).join("")||`<tr><td colspan="${FC_COLS.length+1}" class="tb-vz">Nenhuma linha com esses filtros.</td></tr>`}</tbody></table></div>
    <p class="sub fc-nota">Clique em ▾ no título de cada coluna para classificar ou selecionar valores, como no filtro do Excel. O botão <b>Copiar follow</b> copia só as linhas visíveis, na ordem da tela, já formatadas para colar no e-mail, no WhatsApp Web ou no Excel.</p>`;
  el.querySelectorAll("[data-src]").forEach(b=>b.onclick=()=>{ FC.src=b.dataset.src; fcSalva(); renderFC(); });
  const clr=el.querySelector("#fc-clr"); if(clr) clr.onclick=()=>{ FC.filt={}; FC.ord=null; fcSalva(); renderFC(); };
  el.querySelectorAll(".fc-fb").forEach(b=>b.onclick=e=>{ e.stopPropagation(); FC.open=FC.open===b.dataset.fk?null:b.dataset.fk; FC.oq=""; renderFC(); });
  const p=el.querySelector("#fc-pop");
  if(p){ const k=FC.open; p.onclick=e=>e.stopPropagation();
    { const fb=el.querySelector(`.fc-fb[data-fk="${k}"]`).getBoundingClientRect(), W=290; p.style.top=Math.min(fb.bottom+4, innerHeight-60)+"px"; p.style.left=Math.max(8,Math.min(fb.right-W, innerWidth-W-8))+"px"; }
    p.querySelectorAll("[data-so]").forEach(b=>b.onclick=()=>{ FC.ord={k,d:+b.dataset.so}; FC.open=null; fcSalva(); renderFC(); });
    const lp=p.querySelector("[data-limpa]"); if(lp) lp.onclick=()=>{ delete FC.filt[k]; FC.open=null; fcSalva(); renderFC(); };
    const all=p.querySelector("[data-all]"), cks=[...p.querySelectorAll('.fc-pl input:not([data-all])')];
    all.onchange=()=>cks.forEach(c=>{ if(!c.closest("label").hidden) c.checked=all.checked; });
    cks.forEach(c=>c.onchange=()=>{ all.checked=cks.every(x=>x.checked); });
    const pq=p.querySelector("#fc-pq"); pq.oninput=()=>{ FC.oq=pq.value; const q=norm(pq.value); cks.forEach(c=>{ const l=c.closest("label"); l.hidden=!!q&&!norm(c.value||"(vazias)").includes(q); }); };
    setTimeout(()=>pq.focus(),0);
    p.querySelector("[data-ok]").onclick=()=>{ const vis=cks.filter(c=>!c.closest("label").hidden), marc=vis.filter(c=>c.checked).map(c=>c.value);
      if(FC.oq&&vis.length<cks.length) FC.filt[k]=marc; else if(cks.every(c=>c.checked)) delete FC.filt[k]; else FC.filt[k]=cks.filter(c=>c.checked).map(c=>c.value);
      FC.open=null; fcSalva(); renderFC(); };
    p.querySelector("[data-x]").onclick=()=>{ FC.open=null; renderFC(); }; }
  el.querySelector("#fc-copy").onclick=()=>fcCopiar(rows);
  el.querySelector("#fc-xls").onclick=async()=>{ if(typeof XLSX==="undefined"){ toast("Excel indisponível"); return; }
    const aoa=[FC_COLS.map(c=>c.t)].concat(rows.map(r=>FC_COLS.map(c=>fcTxt(r,c))));
    const ws=XLSX.utils.aoa_to_sheet(aoa); ws["!cols"]=FC_COLS.map(c=>({wch:c.w})); ws["!autofilter"]={ref:"A1:"+String.fromCharCode(64+FC_COLS.length)+aoa.length};
    const wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,ws,"Follow"); const buf=XLSX.write(wb,{type:"array",bookType:"xlsx"});
    const d=new Date(), nome=`Follow_Iveco_${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}.xlsx`;
    const dl=await window.APP_SERVICOS?.use?.("downloads"); if(!dl){ toast("Download indisponível nesta visualização."); return; }
    try{ await dl.save({filename:nome,data:new Blob([buf],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"})}); toast("Planilha salva: "+nome); }catch(e){ if(e.code!=="declined") toast("Não foi possível exportar."); } };
}
async function fcCopiar(rows){
  if(!rows.length){ toast("Nenhuma linha para copiar"); return; }
  /* versão para o corpo do e-mail: fonte 9pt em cada célula (Outlook respeita <span>), sem quebra nas colunas curtas, centralizado */
  const H={id:"ID<br>(Nº CTRN/<br>NºPROCESSO/NF)",local:"LOCAL DE<br>ENTREGA",status:"STATUS<br>GERAL",loc:"LOCALIZAÇÃO",inicio:"INICIO DE<br>VIAGEM",prev:"PREV. DE<br>CHEGADA",prog:"DATA<br>PROGRAMADA",cheg:"CHEGADA NO<br>CLIENTE",cav:"PLACA<br>CAVALO",reb:"PLACA<br>REBOQUE",mot:"MOTORISTA",marca:"MARCA DO<br>VEÍCULO"};
  const WR={loc:135,mot:130,id:100,status:100};
  const curto=(r,c)=>{ const v=fcTxt(r,c).replace(/^\(vazio\)$/i,""); return c.dt?v.replace(/^(\d{2}\/\d{2})\/\d{4}/,"$1"):c.k==="id"?v.replace(/\s*\/\s*/g," / "):v; };
  const corSt=s=>/MANUTEN|OCORR|PARADO/i.test(s)?"#C00000":/ENTREG/i.test(s)?"#2E7D32":/DESCARGA/i.test(s)?"#B26A00":/TR[AÂ]NSITO/i.test(s)?"#1F4E78":"#404040";
  const F=(t,cor,b)=>`<span style="font-family:Calibri,Arial,sans-serif;font-size:9pt;color:${cor||"#262626"};${b?"font-weight:bold;":""}">${t}</span>`;
  const th=c=>`<th align="center" valign="middle" style="background:#1F4E78;border:1px solid #8EA9C1;padding:3px 4px;text-align:center;vertical-align:middle;white-space:nowrap">${F(H[c.k],"#FFFFFF",1)}</th>`;
  const td=(r,i,c)=>{ const v=curto(r,c), wrap=WR[c.k]; const st=c.k==="status";
    return `<td align="center" valign="middle"${wrap?` width="${wrap}"`:""} style="border:1px solid #BFCCD8;padding:2px 4px;text-align:center;vertical-align:middle;${wrap?`width:${wrap}px;`:"white-space:nowrap;"}background:${i%2?"#EEF3F8":"#FFFFFF"}">${F(esc(v)||"&nbsp;",st?corSt(v):c.k==="id"?"#000000":null,st||c.k==="id")}</td>`; };
  const html=`<table cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse;mso-table-lspace:0;mso-table-rspace:0"><thead><tr>${FC_COLS.map(th).join("")}</tr></thead><tbody>${rows.map((r,i)=>`<tr>${FC_COLS.map(c=>td(r,i,c)).join("")}</tr>`).join("")}</tbody></table>`;
  const txt=[FC_COLS.map(c=>c.t).join("\t")].concat(rows.map(r=>FC_COLS.map(c=>fcTxt(r,c)).join("\t"))).join("\n");
  let ok=false;
  try{ if(navigator.clipboard&&window.ClipboardItem){ await navigator.clipboard.write([new ClipboardItem({"text/html":new Blob([html],{type:"text/html"}),"text/plain":new Blob([txt],{type:"text/plain"})})]); ok=true; } }catch(e){}
  if(!ok){ try{ const d=document.createElement("div"); d.style.cssText="position:fixed;left:-9999px;top:0"; d.innerHTML=html; document.body.appendChild(d);
      const s=getSelection(), rg=document.createRange(); rg.selectNodeContents(d); s.removeAllRanges(); s.addRange(rg); ok=document.execCommand("copy"); s.removeAllRanges(); d.remove(); }catch(e){} }
  if(!ok){ try{ await navigator.clipboard.writeText(txt); ok=true; }catch(e){} }
  toast(ok?`Follow copiado · ${rows.length} linha${rows.length>1?"s":""}. Cole no e-mail (Ctrl+V)`:"Não foi possível copiar — use Exportar Excel");
}
document.addEventListener("click",()=>{ if(FC.open){ FC.open=null; renderFC(); } });
/* ---------- Painel 3D animado ---------- */
const A3={ok:false, loading:null, scene:null, renderer:null, camera:null, controls:null, clock:null, raf:0, vis:false, objs:[], pick:[], anims:[], sig:"",
  curve:null, curveB:null, logoTex:null, logoSrc:null, sound:false, audio:null, tour:false, tourI:0, labels:true, hid:new Set(), sel:null, hover:null, audioNodes:null};
window.__A3=A3; A3.distLb=115; A3.__pose=(a,s)=>a3Pose(a,s);
const A3_COR={crit:0xC0392B,warn:0xE08A12,ok:0x1C9F56,info:0x4755A0,desc:0x1E8FA8,patio:0x2C6E9E,done:0x7A8793,manut:0xC0392B};
function a3Script(src){ return new Promise((ok,er)=>{ const s=document.createElement("script"); s.src=src; s.onload=ok; s.onerror=()=>er(new Error("falha ao carregar "+src)); document.head.appendChild(s); }); }
function a3Load(){
  if(window.THREE&&THREE.OrbitControls) return Promise.resolve();
  if(A3.loading) return A3.loading;
  A3.loading=Promise.reject(new Error("motor 3D não encontrado na página"));
  A3.loading.catch(()=>{ A3.loading=null; });
  return A3.loading;
}
/* texturas desenhadas em canvas */
function a3Tex(w,h,fn){ const c=document.createElement("canvas"); c.width=w; c.height=h; fn(c.getContext("2d"),w,h); const t=new THREE.CanvasTexture(c); t.anisotropy=4; return t; }
function a3Sprite(txt,{cor="#13202A",fundo="rgba(255,255,255,.92)",tam=34,borda=null,escala=1}={}){
  const pad=18, c=document.createElement("canvas"), x=c.getContext("2d"); x.font=`700 ${tam}px Arial`; const w=Math.ceil(x.measureText(txt).width)+pad*2, h=tam+pad*1.2;
  c.width=w; c.height=h; x.font=`700 ${tam}px Arial`;
  x.fillStyle=fundo; const r=h/2; x.beginPath(); x.moveTo(r,0); x.lineTo(w-r,0); x.arc(w-r,r,r,-Math.PI/2,Math.PI/2); x.lineTo(r,h); x.arc(r,r,r,Math.PI/2,Math.PI*1.5); x.fill();
  if(borda){ x.lineWidth=5; x.strokeStyle=borda; x.stroke(); }
  x.fillStyle=cor; x.textBaseline="middle"; x.fillText(txt,pad,h/2+2);
  const t=new THREE.CanvasTexture(c); t.anisotropy=4; const m=new THREE.SpriteMaterial({map:t,depthTest:false,transparent:true,sizeAttenuation:false}); const s=new THREE.Sprite(m);
  const k=.026*escala; s.scale.set(w/h*k,k,1); s.renderOrder=10; return s;
}
function a3Emoji(e,tam=3){ const t=a3Tex(128,128,(x)=>{ x.font="104px 'Segoe UI Emoji','Apple Color Emoji','Noto Color Emoji',sans-serif"; x.textAlign="center"; x.textBaseline="middle"; x.fillText(e,64,70); });
  const s=new THREE.Sprite(new THREE.SpriteMaterial({map:t,transparent:true,depthTest:false})); s.scale.set(tam,tam,1); s.renderOrder=11; return s; }
function a3Hash(s){ let h=0; for(const c of String(s)) h=(h*31+c.charCodeAt(0))|0; return Math.abs(h); }
const A3_CNT=[0xB8322A,0x1D5E9E,0x2E8B57,0xD98E04,0x6B4FA0,0x8A5A2B,0x0E7C86,0xC04A7A,0x5B6770];
function a3TexContainer(cor){ return a3Tex(256,128,(x,w,h)=>{ const c="#"+cor.toString(16).padStart(6,"0"); x.fillStyle=c; x.fillRect(0,0,w,h);
  for(let i=0;i<w;i+=10){ x.fillStyle="rgba(0,0,0,.16)"; x.fillRect(i,0,4,h); x.fillStyle="rgba(255,255,255,.08)"; x.fillRect(i+5,0,2,h); }
  x.fillStyle="rgba(0,0,0,.25)"; x.fillRect(0,0,w,6); x.fillRect(0,h-6,w,6); }); }
const A3_LOGO="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAbgAAACgCAYAAAB+OHnxAADukklEQVR42uz9d5QkV3reCf/uvRGRvryvau8d0AAaZgyGwMxwSGKGTiRmSXFFJ1L89hytpCMdfVqeo1WjtVpxVxKlpQzttxRFI5IASXFmSMxwODNozGAs0HDt0N6W6/LpM8y93x8RkZVVlVWV1d3AAMPOc6IzKztNZMSN+9z3eZ/3eQX3bvdu7+xNGGNWPPnMM8+IZ555pv73c889J55++mkjhNAb+fBXXnnFLiSTCaamkqlUKmnbYo8QtgAfAM8zSkqTNMYkA1TalqTApIKAtBBkhSBhjMmATAmBDSYJ2MaIBGhLCGEZgwVCCYEyIAVGghDGGAFCrL2H4Y8XQmpttJFCBMYYLQQBCN8Y44PwwXhCUNMYVyKrxpgqUAFRFsJUjBElKSkLQQUoaa2rxkjXsiwvCAJfSn+yhuMF5bIrc7JqiqaSz+fdp556qraR43n06FF54MABAfD000+b6FzF52zFiRRCmHtD/N7tXTPZ3DsE925vE4CJCKQ4fvy4mJqaMk8//bTe6AR49OhR+SM/8iPtWuuOarXaZdt2B9AhIQXsklJmA60TQMZARkJGG5MB0gKy2Vx2n5ASGr7VYMCAMQaDwZilf694vOy+8TOWQBdmgxeeYOmdWPFYCLHisRDR342PI1yVQuJ6LpVy+RaIGoKyEKKENkUjRCV8rMsGCsqyakEQFJDyivD9agALyph5o9Sc7/tz5XJ5/sknn6xudAAYY+Tx48flE088wfHjx3niiSfiRYq5B4D3bvcA7t7tPXELIxYEII4fPy4AnnjiCb1W1GUM4sKF847rurbneZZxnF5ZqfRrKQcsIQaMlD1ovU1Z1oNaa4wxCcAxxiSFEAkgASSklDKXy2FZFlprtNYYrdHG1P/WWuO6rr8kYjSLUGSMEcaY8CKIAMIYI2KwaASX+FpZ9lwdWJY/Xv/gLQXEeB8b9tXEf9cBON756EDGr5RCmsYrWYBQlqWkEAgpkVKilESI8HG4CaRUBL5PsVQiCAK01q4QogbUDKYqEDXAlVIGRms3MOYFS8pJjJkwUk/gmclUW9ucNztbTvX1lbZu3eoJIYJ1xowCJMDx48dNBH73gO/e7R7A3bt9W8ArpqPqlFQ0wa86IZ0/f75Na93tum6XlDIlhBiUUm7Vvt8fGDMspezHmB4gK5XaJqUMUVKIhk0CBm1MCFwReMUgFjF9PmAQoiEWEhhMDDVCSimXfm742SKKemzbXnIZGOLvM2gdxBN//b5xM8YQaA0RqNbBaClQLafwlkRjUsb70gA+SqKkQkiJavK3kDI8BxgQgiAI95Po+40xaGO0iY5XGJAuhqAmfJuJI21AIYQQQlAHRRHvm6gDd/gb448Jz42lFK7r3jJaXzBCzAghxoBxYNJxnEK1Wi1blnXG9/2FmZmZmSeffNJvYdwBiOVUaLQf94Dw3u0ewN27bTwKO3HihHzooYcMoNfLfV25ciWZz+e3WJa1SQgxDHRLyWalrJ2+5/cZTA/QBSKVTqecVCqF53kEgSbQATrQaKPxPQ9j4rk2BghhFif9EJBs21oyXk08fuvvCyfgRqDyPY9azaVWrVKtVqnVatF9Fdd1qVarXL50KXyfWPzgEEx1uI9BQKCj++g5o4MQAE0IhMZojDYNAGcwZilpGUeJS+jGaItBRYhFQAvBTkXgFj2Ooi4pZZ2i9H2fvv5+evt6sSyLZCKJbduk0mkcxyGRSJBKpXBsB9uxlwAWiHrgGn1gCIgRAOqG32SMRhsjYvpWRCsSAShlYds2SkmUUigV7qNlWZTLZYrF4k0QC0IwA8waQymdTopKpfIVIdQJKeX4rl27xteL/o4ePSqfeeYZ2TAEzL3o797tHsDduzUFtGiKarqiPnXqlNPe3r7FsqxEtVrNep63UwixC613IMQWqcRu3w+SQsikFMKxLAvHcVCWCoHMD/ADHxMCQYBBgxHGIBpoQGFZlliMUASWZSMAz/OizcXzfeZmZvEDHyEEnudTLpcoFUuUSkXK5TJzc3O88frrSyQeZhld2WyrVCpxNNiIRIuAJBqBoOG+gdZsfLzehWWacLZm+eP6cxFQLv87zv+J8Dc6joNtOyFYSrnqZoyhu6eH7q5ubMcmk8mQyWRIZ7JkM1lSqRRd3V0kk0lAYNsWtmWj4nOr4nNkhec1OoZ+EBitg3Cdog1CYBDChAGmkI7jKKUUyorAL4pWFxYW8AO/jKFm27br+d4UiK8ZYa7bjn0hcIPTiURiHqhUq9XS7t27mwpkXnjhBeuJJ54AiOnOe5Hevds9gPtOPafGGJ577jn59NNP07DCbXrBP/vss+qRRx7ZDAwRBNss297m+n4fmG3GmO/r6OiQvu8vCi9iCmwlXWcQ0QQThSpCCDAIqaRQSkXRikRIgTEGz/PI5/MUCwWKxSLVapXp6WmKxQLVai16vkC5XOats2epVCoopVieN6sLLKRsTgmucS+VWnERmKX/tLZw2PB7YqHIRs+uWPGemB5tpEbXu28E1vh4BkFAR2cniWQSKSTpTJpMJkMqlSKdTjMwMMjwyAi+70eRYZpsNkMulyOdyZBMJqOcaEwlx+PDaIwx2ujo6+rhrR1Hq0ou5ggRYFkWhUJhzhgqwphphBgzcFUYM2GEOK21ngFu1Gq16wcPHnTXifpETHU+88wz9yK+ewB37/Yei8rk8ePHZW9vrzxw4IDfjF40xoiJiYl0uVweFkLsNSY4YIx4n5RyKAiCHiHoSiZTubZcDjeKnkqlEsaYIKQCF6MLHUVg4cSkUEoJIRepr8APIhoyzFsVCgVu3brFwvwc8wvz5BcWCALNxMQ401NTuK5HtVrBdT0K+Tye56IsFVJ2ETAmEoklABbvywaO0Tt7Tt4lF9xGhC8iyucZs5hjC8FT4/s+jhPSnbVaDcuycBIJkokkyWSCbDbL1m3bMMaQyWTp7Oyks6uLrq5u2trbSCVTDYIXVY8qBcL4vo/nuQTxQim6WZYllZQoy8KyQhrUsizm5ufwPb8ipZwGpoC81rqitf4jKeWp7u7uS52dna4QotJkIIgXjh9XTzzxBM8995w5ffq0OXbsmL43i9wDuHu3dwe9WD93kQx/hfT+7NmzOSnljnQ6PVgplbYi5QFj9E4p5C6p5CYdaNt2bBKJBEYbPN/D9318P9AQAVq4yYjGjHIrVnQf0l3lcplqpUKxWMTzfUqlEmOjo8zMTDM9Nc3s7CxSCubn55m6dQspBUGgo1yZQWuzhFYTQqCskMJaHnE05tfeCSBa70JZjwQTt/l9RrT23JrfdwdYvhwQGyPeOFqP6c7lgpv4+UZaVCkFQjAwMEB3dzdtbW309vXR0dFBrq0dAbS3t9PT20sqlSaRcMBAoDW+55lAByYIdMRE1PNullJKWFZMoSowUCwW0Vr7BuM6jiM8r/ZXaPF1pDwTBEHRcZyzO3bsmGx2XT333HPy9OnTprG2716kdw/g7t3evghAEF54IiqwXZVaOXfu3PYgCA5blvUBEwR9GrNNII709vYmarUaQaQGjLcof2IAbTARmyhEpOATjfVWUkk812N2dpbZmRnm5uaYX5hjcnyCfKFAMZ9ndnaWaq1GtVqhWChgWVa0WhfhD4knumjIiWUS+8boaq1Iy7Q4kOsSCrP+q1vJ1hhhYu4VhEGHPwstFwEoBqH6/SpX15L9NCCMqO+nNPFz0RZpX4Ru+C2iRbAWqwOjWXaw1ow2zUoADEUmounzy89jfB+rUGNgNNGCxfN9+vv72bJ1K5lMlpGREbq6ukhnMvT29tLd00M6nQk/P35/yJOjtTbaaKMDHYtuVD3fiCHhJLDsMPrTgWYhP38SxAUhGEfLV6QlzwM3du3adWO1BeXx48dVLpcTDz30ULBR04F7t3sAd++2MkKTkZpxxQX1yiuvtPf09KTL5fxupaz3a22+XymrU2vdro3p7+3pkSHd41GuVNBB4MdqjqjmKxKWSCxLYVlWfdXtui6e51GtVMhHoHXj+jVee+1VAj+g2qBEjDfLUkgZfk49ElOqLle/HYrQrDJI6zULJsxBSbP4eiPi+xiIwv/0pan/f4BBSwikwZfgK4MWBk8ZAkn9/wIBxZTG1MFLQGOduKxL9xZBRIqosisGweU7Lht+wOL/RTnKRbAXdY1LBGjRYsCE32v5glQlCq01SC2QASgNVgDKi+59cGrguCCCxWNVB81lIFr/vwZgrh9T2QCCYukJ2oiUQyyuapYeBhEqQV3Xxff9OhVp2w6pdIpUMlkXuTzw4IMMDQ3R1d1NOp0hnU6RTKZCJsIYfN8nCAJ8349zxVpKaYQQRkhJMpGwEokEQgiKxSJB4BeAgpRyIQhM2RjzO1i8UivV3rJtu7w8txfX8D333HP6dkwL7t3uAdzfmONujKEx+d3sYjl16tRmrXWvEOKwbduHfc/7nmQqtcv3PJRloaTEAIHv4/k+RmsvjvwAKaSsFydbSoXvUQrXrTE3N8fC/AL5Qp6bN24wMz3NzPQ0165do1gshMAX0U8sU+fFYLZSwHD7/Fg4/4v6RBtN7xgMgTD40RYIgycNFRUqyrUATxk8qfGFwZUGX2q0hEIivF+CkHJxoo1BqR5SyuhxPaSKnLdEIyote49qeFwHMbH0O2OAW/Kahn2pfxcN+8TS75bL/l7xPQ37IMEpQ7ICvh2ClDAh8MWbUwMrAsR03pCshBJEpaPNC19nR/cyCDcjo00s3dacWcz64BdvpqGmcJH+1MDSurwgCNixYwdbtmyjf3CA/v4Bcrkc7e3ttHe0k0ymwEC1Wg3VvOHgDEwU/QHKsiwRXxOxyEYbg+e61xDiPPA6QXAmlc26lUrlpYMHD15vtihtsJm7p+C8B3B/c6OzBrrDbwZoZ86cGdRaP6m1/l4pRJc2Zo+AHifhdKSSKUqlEp7nxRNBZMZh0FqLKN8hGqOyeKKo1WpMTkwwNjbK/Pw8165dZWZ6moWFBYrFIuVSCSuqY7Isu/7+ZgKFjVCIogG4Vn+PIcDgCh1uMtw8GYJZyQpCcJMNAKcM2tKLE34zIYWQK4GnDhpNwK0BZMRygBENl4pgsYxcNgATTYCm8fuaAVxDVLOY8Yz46fhzTcP3mMWIasn7xDJAjfdNieYnpXE/JFBbBC+pw8cxENquqQOcMpAsQroIdg2SVYNTDR9LvbRIcUk02BgViqWR4GpwsJo4Jh5/YblIKIbyfZ9cNkeuLQK49vZQCSolj73v/QwNDZPL5ZYAKWCiiM/E+V0RFbvbti1sy8J2nHpEOTk5eVHAm1Kpquf7f5lMJl/cvXv32PLr2BgjTpw4YT300EP6mWeeuSdguQdw39mgFsn1V9Sbfe1rp7qylu7Qjj4s4B84tr3b9Twb6Olob0drQ7VWjWkXDWhjjBJCiFiqr5TCtm0cx8HzPCqVCvPz85RLJebm57h08SJvvvEGWgd1WjEUk/goFVKLsaKtsQRgo1Ti4lwZQpkwDZFXdG8weGhK0qcqNVURUJMheFlI8tLDlyGNaGTDZB/O9su+TIZBlhRNqT/q9KFYGTEtj9ZYFk2tAMOl4LY0UmoCLMvBTMp1wG15NLkaSK7yPYLVAXR5HYJpcsE3gqZpRq8u23wgCKlNFUD3pMGzw7fYHiTKkKwYUhVI5cMIUeql0WMMpoFaGg0u0hut056NEd3i5keiJEF7ezuO4zA4OERffz9DQ0Ns2rwZ27Jpa2+no7ODhJPA94NQbOV56CAwQkgjpNDxIjKZTNrJZBKlVCieEmLOQBljPi3g9arnvWyMuf7oo4/ONO7jCy+8YAE88cQTwT1K8x7AvdfzZ6sqG40x6vXXX/9IOp2+v1Ip7QgC85gUoi+ZTA42RltR/sAH0FrHNlORCkTEsnyUZZHPLzA5McnY6E1GR0eZnZ3hwoULLMzP1QumxTIrqEYni7UAzawySOpUYj1vI/DRVKXGJcAVGl9oisLHFZqy8KlJTYBGE9KHS6g1lkdWi6AiRJNJWorFyVCtouKoA4ZYGqkgVqcmESsjG9YAONkEFJcDnJLNoyZWAcrVAG6t71kL4MRtXt5mlYnBLEZizQF16XNWOQRBy4NEBRKVkAq1fHCqkF0wYa4wei7k+BZBL/678X41AGxW52gMdbCLo7R4zPu+z46dO9m9eze5bI6+gQEG+gfo6QvVnL7n1R13outTEzr8GCGwlWWFBetRHZ/Rhkq1+qYQvGKMPiOl9c1azTn76KP7Z5rMFfUlxT3hyj2Ae9fTjk888QTLI7QXXnjBGhho6yuVgk8mUqnvr1WqOeD+/v5+p1KpUKvV4oS4NsbUrQW11gghhLIUCScBUE+el0olpqemuHjxAufPncN1Xebn55mdnsbz/Xo0FxdDb4xaNNH8JaLgSTS6V6Gj/9fCUBI+ZeFTkh4L0kNjcIXBJwS30MLCLJuZGiagRtHCEtAQKyfuFXznstesoN5Ek2isGZUnmue6lgPO8rybaBGUmu3nit8kFiPVVSPAtb6nWWR3B8B2xxfEsoCxMSpt/J0KcMM8oeUZLA8yC5CsQrIE6aIhVQojQhlFizISxJhIELSRqK8Z3SmEwHXdurilra2Njo4OsrkcbW1t7D9wkE2bN9HT04vj2ChlxQaeYflCEOaApZR1n8xEwpGJRFjsPjs7WwSuJ5OJW5VK5bQQ6vcLhcLry7szGGPUiRMn5EOXL2vxyU9q7uXv7gHctzlKq4tDGvl1AZz4xjf2q1TqcK1W2ysEP2hb9h6tdSKdSeP7PtVqFR1oVwghDUZGllUiXhlblkUymcRow0J+gfHxMRbm55kYn+D6jet1IUjkkl/3/bNtezFBv2hE3BLFGFOLVjRb+MJQE0FELWpKwqcgPGoyjMYEUJQ+QVySJMzSREv9c0UDdLJ0UhesDkBSrAIGq+TQlo/kRhqyFWHJamIOWCrkWJErWy/qkk0iquY5v1UBbr3vaRrZfRsBbrVJxqwEQSPAqGX7Hk3v9bIIDV3ThkzekCqEABhGgmC7DVFfE9BrhQyMxVJAXX0ZF7rHxgLpdJpdu3axactWtu/YQTKZoKO9k2wuh9YBbs3FD/y424MWQmhjjLEsy44XnL7vU6lUKsaYM8B5hTieaWu7WCwWLx45cuT68uhuibH5PVrzHsC9nbejR4/KJ554Qk5NTZlPfvKTS8xgv/nNbw4IIT7qOM773Gp1ECGe7Orq6qhWq/iejx/SIwaDRoSUY8garlQkBkHA1K1bnDp1kumpKWZnZzl37izVarUu/IgLZxsVZ2tFZ2ZFOkWsOPEumpoImFAVAmFw0ZSlTy2iGgMRsLJYSjQdQGb9GWV1NeHyKIsmALc8h9ZS9NYkmlovemsEt2bAoppEayt+k2ydmlwreluNmlxOwb5LwW1DEV+ziFxGaBWto1TJkMlDogrts6EaNFUOI75kNSybQKysTVw32ovKF5Z2TlikMwHa29pJppIMDA7R3t7O5i1b2L5tOz29PUipYluy8D7wjQ5XsEYIIZRSMs55K6VIpVJMTU1dQogXHMsq+q772YceffQLyylL8+yz6nhvr7iXw7sHcG8H9WgaHc5ff/31jBBipFqtfhit9yPERyzL2tfW1obrupTLZYKo9swYIxsFIbHdlG071GphPVmlUmFyYoJvfesb3Lx5k8D3mZqawvM8bNsmmUwiYjn+OmC2HGBkFJlJIyKxh8YTBlcElEXAlKxSkh46EoK40m8y04iNAdh64LZatFGftNcBt+VRGDSh65pRfKsIS5ZTfMvfj7h9YclykGWd6E2sIXJpGt3d5bzbu3WCiuwI6o1m4zoSSSR4CVWeVg0s3yA09E4K2uchWxBhXWC0SR3VO6qGIW7WnwTrFnQ6NEmI1ZvZbJb29g4cx2bX7j3s2rWL4U2byKTSJJJhVwc3MgzXgSYCOxNOC8Y4jmOl0+nQfmxurqq1PmPgG1rrF9vb27+ZTqcnt23bVm1Me9xu4+B7AHePehTPPPMMx44dW2JM/MILL3TYtv0hW9m7fO3/WCadPuJ5HkrKsGbG89Bae1JKobVWdZv8yAlEWQrHSRAEPlcuX2Zq6hbTU1Ncu3GdG9euUSmXIbJBWkE3rmNPtVL0FgIaQFX6VERQz5ctSJdZ5a4KVYKl+u27evWsCW6tUJOi+YS//PXN8lWiBWqyGWhsJPe2GmC3Sk02jQA3QE1+h4JbfSCahu7p2lC3Dl/WNLb+uuiyccqGZEWQLkNbAWwvfJwrCBwvEoXGSs6WhnFDI9xlys2Y6mxra4uUmlvp7e1leHiYvr4+kuk0bqRibhC8aCFEYIwhpjQhzLnbtk2lXP6yk0z+Wa1WO+W67jeffPLJYuPuHD16tLH+7h7g3QO4paD23HPPSYDl1ONLL31+SOvkj2Uy6cfL5fJwIpF4OJvJUigWcF23Pv9HK7HQIcQQSu9tCxAhP++6TE5M8MbrrzM7O8P1a9eZnJwgkUjUZfrLHfDXphtDSGsUgcQCEF9oCtKnIFwWpEdVBFSEjyeDhqhsZUuXd+SqWEvl97YJS9agJpsBSKvU5O3UvN2OsGRVCvRdJix5u28N0dtSoGv42ywFvhWdHWKKU4JVMuQKAtsVSA1Dk5JcCRxfLKnfW17Evhp8LBewaK2jUpyw9+HQ0DB9fb1kc20cuu9+Nm/ZTDqdjvoCCoLAj23MjBQyLhQXBiMSiQS5XI6ZmRmklN80Rr8ZBOb5crn85e/93u+dbfzee9HdPYBbAmyNA+FrX/taCtydQaA+ZIz+Odu2NoPoymQycZNMbYwJhBAqzn7E1KNUioTjoCyLYqEQejXOzfHyt77JlctXAEM+n0frgGQyhWXbdU+99WrOGnNoCoEyAh+DJ8K8WVUE3FJVplTIYvjCoIky9EYsg8Fvozxrvdxbq8KS1QCuqbAkjsJuU1iyfH8U6wtLWgG4VoUlqwHce0RYcpcu1oa2pg3ebLrh/5cDnVkGjAZEw2MjzOJ4MAZZi+rzAuibkXTmBdmKxApC0LMCgRahtVurApbG+rzYAs8YTTabw0kk2L59O7t276G/vz/y2kxj23ad+mwAznjesdLptJBSUigUvUTCXnBd74yU/Lox8lXP8y7FndKbzW/3AO5vAKAtb4thjBEvvvjiY8AhpdQnLUt9xLbtOoXg+74BgobpUsRO6bG7vuM4FAoFrl29yuTEBFevXuH8W+eoVCt1f0YhwgaRjaC4Hpg1QpM0gpoIKEiP+SgyKwiPvPLCHqJNTqdYlYh8F4FboxpyPWEJy2ysWIMSbCpcYZ2i7uaOJe9YUXdTWpXWa96+06O3RnAzy2hLszzKaxL16aWAKfTiZxixLDLEYFUFqRq0lyRJV5CqCnryCscPD7pu8DiNxcNrRXj1HF5kOB0LWASwfccO+gcG2LZ9O4NDwwwMDIQuLb6PjhSdkWuRjgRpKhaaOY4TtbTi08aYr0spjz/++OPfaGX+uwdw731gkydOnFBHjhzxGsN427YP+r77P1mW/RHf93c7jtNu2zblcllH4BP7Ny4RiNiOg5QS3/Mol8tcv3Y1pB5nZpidnWVhfh5lWXV5sdmAKEQAVqRUDERoXVWWAXOyxpSq4hE6f/jL6MZ3jGK8E3BbLdoQrPR6vBvCksYISIoWwI21/SZvV1jCKvTimo4la0SJkrtf0P1uj970GtRk42PdcEEtj/qWR4CNlWaxeCsuT4hebwRLw0EXcmWJZQzZsqR/3iJbU5FvZ3gdBlGXibrVGq1RmnGEl0gm6Ozsor29nT1797Jnz166urux7VBBHTsQseh3GT8WmUxGOI7N3Nz8vJTyvNbmC5Zl/fmpU4nXf+EXFue/V155xS4UCubJJ58M+BtSb/eddGXUDYyfeeYZYrntqVPPOjMz/YeBDwWB/xO2bR8UQli2bYd1aVprE8p51XJAUkqRSCRwazWmp6cZHx/j4vnzvPXWW9RqNVzXJfKuw7KsloUh8XwlI9qxJjQL0sUlYFa5TFiVemF1WN0aXjkyMh/mvTI61xJb3M3cm1gD9N4LRd23Iyz5TqYmoXnurZXobS2AW05jGrOEymx8jYiAT5gwxx22ZDCgBSIqPu8oSQbnLRKBJFOVJH2JjIrRQ3u61hSasajM9z18z48W04qhoUF27d3L1q3b6O3ppaOrE4yhWq0uXzgHgFZK2clkEs/zCIIgCAJ92hjzP2zb/obruq999KMfnWwMAGjQEtwDuHfp7ejRo/LAgQNiuVDki1/84v1CmB8RQj6mtfnutrYc5XIltu4xUUGmjAaXAJY65gNT01NcvnSJK5evcPPGDaZuTWJFYCaEQMSr9nWox7iYunF+Kke046ysURYB06qyJHe2/AS950bgusISmpslr0YxNgO3VWX+LQpLWqEm1dtgprz8+MDK2jpY20z5Ox3clgPWatHbarm3ZhTnGtHbUhq0QY0ZmzvrhoWlWfGAbEnSUVZ0VhSOL2mvKmwd5u/CUGsxoSDWAbvGbgqu65JMJhkZ2URPbw9bt21nz969pNMZjFl8XRzdSSm1MUZKKUVsFJ1KpZiZmX4zkUh8pVarvdre3vl7jcxWzG4dP35cf6fRmO/ZK+TZZ59Vvb29Ik6uAuL5558fdhznB43RPy+E3JTLZbu01hSLxXi4StEQ32utEYDtOChLUa1UKRYLXLl0mbNnzjA+MUaxUMR1a8QWPK2JQ0wUpYURmhZQEwEumhlVi/JpLq7Q6KiQWjRUon5HLKc2UtT9dign1xOWtKKcvBNhCc2oUloXliynSP+mRG8tC0uWvXY1cGMtGtMsBc1VwG2tHGBkx4yREWAGAhVAIhC0VxS9JZucJ3EChROE5zMUg5kldnir3aSUaK3xPA+3ViOVTtPb28uWbdvYtGkzmzZtIpVO09bWRhAE9ehOCAkYI4TQWmuTTCatbDbD/PwClmVdqNWqZ7Xm3wRBcPKpp57KN9KY30nNXd9LV0hc97Gk5uP5558fsSzrcSHM92ttPpZMJruBmLP26+vjKKfWOHDiupNbk5PcvHmDK5cucfHiRcrl8hKBSEwhtCoQUdHsWsILwUy4XLdKaLFSFBJn0r6jOAKxRp1Wy8IS7m5R93dit4DvRIBrtSxgvdxbIyA2Rm+NoKWbRInx87rhyl43igwFI+goxSEaI0QBRtNVtump2uRcizbfIhWo0GRBmBVzyGrRXex4FE9rUko8z2PHzp0cfuBBMpkMO3ftQkqJ67rL0yU6ojKtZDIp4jkyCIJzwItBoI+3t4u/ev/76+UH4ujRo7EloXmvrrvf9VdI7CrSmBg1xsjPf/7579Fa/JgQ4rFEIrFbKUWlUgmtsSJmsFEoAixRNpZKJS5dvMilixeZnJxg6tYtpFQ4jh2tfhriMbN2lCYbJpoKPrdEmWlRpSh8SsJbdIn9m3BrVVjSLAq5U3BbQUOKFsAt+o+1/CbvCUveueitVWGJWUYVajYmLDHLPos1orflCs0Vj1fm8YQBoxu+K2qhLnxJu2eRDCS9boKBWhLLyMX6O8LoLl7+Nr+8xJIEiO+HwrdsNseOnTvYtn0HO3ftIpfL1d/ne148KTaClbBtW8R1uQsL869Zln3O8/xff+qpp15snIOjHnf+ey1fJ969Y70ObHUPqc985jO7Egn7bwdB8HPG0J/JZGzP83BdN4hAbAkFGQNbIpnEaE0hn+fWrVtcu3KV0bGbTMe2WJaNZdsRmJk1vYpNRC3YQiIRVI1PCY8ZKsxQYY4aFTwWs2+i3pn6bwzArSZjv9ct4L3dLeDbEb2tJiyBFsQkGxCWNIvqWgHa1YC5LoAxi6rKICpLEFHUFwhsLWj3HDb7WTq1QxKLhFFhhw6CVYFueXSnpCTQAZVKlUQigZNw2LplK3v27aO7u5uOzs4VkV1D42QN6GQyaScSCUqlUtX3g9OWZf2m7/vHP/7xj59vTA29l2rs3lVXSjPByNGjR62HHn3ow8qITxrDD2Sz2d641YzW2ifuzNVgPhxHaUpZdYusW5OTXL16hampKWwrbH2hlEKKqNknpmkQvsR1X4RKRo1hXBeYC0JAm9RFdL1k7juYerwTgHuvdQuQTezClnznvW4Bdz16a5Z7axY1LQetwKwNkrpJ9LYCKKPng2XU5BIgXf6ZpjmgxvtkTNPIT8Q1eHqp9UpK23TpJJ3GIUeSTSKHjPotmohJWmxq1Xw2l0Kija73sYtbAe3cvYvevj6Gh0bI5rJL6vEagDLQWhullKUshWM7lEolLYT4HWP0G5lM9beffPKTxYYAQkbve9fm68S7Y2wb+dxzz1mf/OQnY7NEPve5z+30Pe9fKaV2er53MJPJJGrVGr7v64YorV4MZoxBSIFthcXaruty6dJFLl+6xNTULarVKslkAqWsxRq1NUDNYMI2MhFd6RtNwdQY9fOUtMsVPY8xHouC/3uNnO6oW4Dk7lty3Y6wpFkj09tSTnKvW8DdALdmwo/VirpbigCb0aAN4GbMKvvVLDpcZb+DZZ+7Yp8Bo5eAtNDxIluD1ghj0U2CNA4HrD7SwsYWCokgQBMYvXp0Jxafj1WZ1WoVKSX79u8n19bO0OAgnZ1dJBKLPSfjmt8IfsGEdXa5XE4goFatnvRc74v4/m++/MYb52LFZdy1/N1YXye+jaBW760WH6hPfepT29KJxIOlcvkTTiLxty3LcoBYGeQbY5SUcolYxBhT93V0XZfZmRkuXrzIlcuXQvls4NeLJU08iFalH8N/FRJbKGrGZz6ocCsocsNbYDoo1vnxxrq0e8ZvrN8t4NshLPl2dQtoRi/e6xawMWpyNUrwdoq6WxGWrJV7W4uabBYJLgdi3RhhsrREIX5j9LwwIqy9MwHokBWSRmKh2Gv10KFS9FlZMjIBGFwT1NMma93i+U9HpQVSSDo7uyIHlSHa2tqwLKtuFbZsrvaFECaZTNrRfFwS8E0jxO95nvfVH/3RH73QyMItFwL+jQK4ZjTkpz71qfuM1j8mpfyf29vbN5XLZVzXxRgTxBGeqC8tTP2ExZZZhUKB8bExJibHGbs5ShAEoUKysW+aaVZ2uQhOIf0YRmKzfpkb7iyTXp4Jv4inXRCSe80XbgfcuHNhCaI5nbeWsESsQwdupJHp7QhLWgW3ZhGk+JvULWAVYUkjcKxb87ZKPVszavJ2ygJaFJYsybvBKtHbcnBb9p5GZaaJ0hz1XF74I3vtDjpkkuFEJ1ucTiyhooW2wY8UnWLF9G6Wjp+oObLnuqQzGQYGB9m8eQv9/f3Ytr2kFi+OBKPuB0gppWVZOIkExUJh3LKsv6zWai+Mjo7+6T/8h/+wFgcwzz33nPzkt7lLuXjnxnGoxIkLDJ999tlsJpF4pOK6/4vjOE+mUqnuSrWCW3N9GVrsy2YxllJW3cT01uQk58+fx3NdiqUiOtDYjr2kGWjzSC3ks6UQ2NHgKGuP69VZxtwFxtx5ykE1HG3C+pslErmb1OS9bgGtUZP3hCWrR02rCkuW0Y4bsORaAUDNIr0ldOIa0dt6ANcsemvqvtL4GXrZb42FKiL66gBMgFAOHSrF1kQ3WxJd5KwEWZUkMBpXB/WF+9qXrkTrsPTAcRzS6TRDQ8MMDQ+TSaexHDtcP+hgOVxoMFopy8pmMxQKRXQQvKHRv+c43n/7gR/4iek4ODl+/LhsFAt+JwHcitq1P/3TP+0DHgbzr1PJ5H2L5saBB0YJISSmkTIMb6HBKOTzeWampxm9eZPZuVmkCOuQlFIhEJl6lcAqsVqYiLWFwtU+o7V5xqpzXK5OM++VFlN7Ue7tHrDdAcDd6xbQhHrkXreApjmuDXYLCFaLkprRmHcQvTXN262Ve7s70duK719yWYRQp+OcXfRXzsrwQHaEgUQ7fYl2JFDT/pI5rGlkF/WujMUp8eOuzi727N1LKpMhk07XI7p4d4QIA0EwgRDCdhwHY8D13Eu2tD7tubU//dEf+7GvLk9LvZP05dt21Rw9etQ6duxYHbX/7M/+bJ8Q4n/3fe8ghoOO44harWbqc81yF1IDQkqkCKOn+bl5JifGmZqaolQqYVkKKVXTLNrSBWJUAydU/bPmvBLj1XnOFye5UZ1DBzUQVr1tPbcZUy8mduNDaxquY7Pmfq52WsLGqQ2fZxZzhe/6bgGyNWGJEDKqE2qWe5PRpG+aRG8N7xOy4TVy6etlw9+Ej816wpKmObENCEtWpTgbxsh7pFuAebs+1JjbF5YsAY1mgMk6wpLF54XeoLCEJmCpTdPmrIsTkYgEJA3X8PIItLFurlkEuMpMYRoPauCRddroS2QYSfVwIDeMI8PFf2A0OlKMN4/sVva2s20b27bp7eujt6+PXC6HkirM5ekl12z4S4wRlmWJdDpNIZ8vO4nEi7Va9Ssg/02clnrhhResJ554IngngE68DcAmn3jiiXpI+uyzz+7BmH+XSDgfchynzXXdKL+GFmIpDRmf9NgPslZzWViY5+bNG+TzBXQQhBX9SsU6n7UoUQAcGVKaC16ZWbfI+cIE54vj1LQP2gdpIYWoA+HtAppu4MjDCydoWPFHnFVUOyeEaACu5dd8OAC1aeDd460+qYf3AhmuoqLjZr4d4LZW7m2FGfJqnbq5vaLuRvEKzcCCNYq6xd3tFtAseltTWGKWlim8G+lJs3zN37y74G2Nu29Dt4DVhSW6tRzg8vdh1heWLIkCG/ZXrPZbV4kAW7zJSDUZzm2KdjvDpnQ3u7ODDKTaSSkHDLjar+fW1kktLdE9dHd3Mzw8TDaXxbGderlB4+dEtXWBENLKZjO4rketVr1mKes/+Fp/+pOf/OQVIQT/4l/8C/l2e1/etSvn2WefVY3CkT987g8/llSJn3Rd9wcSyUTOdV2CIPCjaV0uHpEGVaIQSCWplCvMzc0xdesWhUK+bmwcRmArQ/blF5pAYEcT0o3yDHmvwonZy4wVp6KJSkbRWuu5NdGwXlosL9CLCWHLJquSpFSCnJ2ky8kiRAiwtrSwpcIRFkpKVCT3lcsixhjYAqPxdICnfVztU9M+vtHUApe5WglXexS8apgnrAOprIcF8aE1xrz9AHe73QIiilFJRUraaGGWYNAigMnFM7skQmrRb7KpajL0BvXR69ei3Y2at2XKSIkgpa13KTW5CF86at3kCx16LS41wYheHu2wYQkErjvyghajprejW0ADwFpGkjIWAXrpz1sOPqxR1K2XlQWsBnANn+9pHzfwlu6z1s1/621M6iJetMeLbgRDqS525gbYlu1jINWBQODpoH62xFqL2BjsdKgj7+jooK2tne6ebtLpdF2huWQURECHQFrKkolEgkqlctMPgn9/7ty5/3Ts2DH/6NGjEuDtAro7vnqMMeKZZ56xjx075h49etQ6ePDgxwPP/V8R4vFcW5tTKBTA1Ini5sdQyrANRK3G5MQEC/k8tWp1SbS27ioDsGXYCNANfC4XJrlWnOLMwg2qgYc25raKr+NIS+vFKMqSNmnl0JXI0ptoYyjdSbudxpE2CWmRkBYZlUCbRVluDF71ovJ1vzMGwNCDTgqJbwIqgYtvNJXApRLUmKwsMO+WGK/MM+MW8bSP0X40aVr1ws9vKzXZpFuAkBJjfAadLn6o6wEqxkOJJhyluIPRK5amYw0CZWBWl/lz/zRGGowlMHEk2CzXdze6BUQAJhAY4dPppfnk3B5cEYQ55DV/y7cP4GIHfC00rtBM2eVwUhQBJelRsDzmrSrztht2vZZB1FZGgJGrl9HcbreAVUFt48ISYQQm8GnTKT6u9pIRNlqIZY1LTet87Vrva/hqiaDs1/jc1BvMuoXw+qxHkWIlKN6VST5WYwYgJGnLYTjTw+HOrWxr68eWCmMMXovCFIRABwFBEJBKpWhvb6d/oJ9UMhXidMS0LTsExhijHdtWkQfwq+VK9eiP//iP/0VMW74dQhTrTunIqIrd/f3f//0P2Jb1/2DMkWQqRbVaZWFu3keIUDjS5OSHCh5NrVJmdmaamdnZusN/XIC4nhoypiGlEMzWilxYmOC16UuMl+cWZ7c4otkAtEXZUIwOMEFA0k7T5WTYmunjge5tOCL8zshiDm3CmruwZwGUjItSKtzqJQ0WjmPXJ3ghljUtjaS7AJ7r4kXFl6EQx4uoB4MMNO0qSZeVZjjZhRCh24EEbpRmeCs/ylR1gfHKPDqogp2IotV3SVZXxEX2goczW+my0uEiJAje9q9XyqJLpTng9vJmMIqFQ6DCSqLwZIrb+9JWgdiAHUCvl6YmfALfjxZfdykBJlp5cq0PlSveFRHqjMhUOFlGixgjwihPR1He6cwM406J6USFGbuGVh5ghWAiGoCHJhP4EuEFK4GNVSjGZu9fTaTRJLe3R3SzXXRRNR7aC5ofKrFRMFllzBuDVJKhTAcPlDfzpeIbSOkQN9IxjePvLrIv9QhNhtN92a9xYf4GF/LjDGe62dM2yO6OYQbSHaH9YOA1Fn03Bw4V6h90oJmdnSW/sEBvbx9d3d0kEg5BoJdF+0YIhPI8T7uup9Pp1IMCPvVnf/Zn/7ZUKv3nJ5988ubbYQMm7gTcjh07pv/rf/2vHY5j/QMp1DHHsahWayaqlwjnf7MyGRofuFq1yszMDJVKpe6Q3RInjMGSoc2WAK4Vpnht6jKX8uPMVvPRUkndlmBksW4udBToSOY40LGZHbkBehNZHGFTC1yMDhO26UyaVCpNIpEglU6Ry7WRcJywCWrUO85SCoTAtiwSyeRifm1ZvrAxovVcl5obfo/nufhe2NG3WqtRrVbJ5/O4bg3P9SiVSgSBj5IWSklSlkM18LhUmORGcZpXpy/jBTVQYURnuEOJylp1Wi0IS8JjrOmxcvzMwAcJTEAmm6Wrs2vZfonb3rXV0OXW1C1wNde9Wf609BquBUJJjA1GCYySd79bgFx0lTDao7ea5mfn78eVAYODwyQSTsstmFoMwFoGtLW+Nh6nWmsCHYRj0PPwXI+a6+K7XnSaw99no7CFYt6qMe6UuJyc50oyz4JTjY6Rihw71qEmWxGWsAo1WY/m1vGb1AYnkPy0c4R2EjipJD09PW/D+Fv8WqUUU9NT1MpVin6FP7z0FRbcMkrJcHcFGCnWFZbcnYiOBucUn7ZkO3s6R9iW62NP5zAp5RAYja+DcDptYeHn+z6pVJL2jk7a29uxLGuxji5eK4g4uDaBEEK0t7fLUql0wXe9f/UTP/mTv9ss3fWOA1yskPzt3/7tXbZl/WUmm9lVLpXQxmiBkGuyWkLguh6zs7NUKxWCIEDK1pz2A6OxpSKhbIpelSsL43xr8gKXF8apuuXwAhLWhqO1JeAWhG4zXcl2jvTsYG/HMG1WCs/38I3Gsi062jro7eulu6eHdDqNpSyUFbqpKKXqRZKNWwxkS1pYLFvVmoa5KPbTXPJYLHYuiHKaYfsMz2N+YYG52Vmmp6cplooIA9lECiEls26RUzPXeHH0FEHggmWHFOHdALflua4WirolAh24fKT7Ph7r3EHVc3n00cfo7u4mWCeKMy1M4KbJG4wx2I7DmZMnuXT5MrlEij+efZkLego74RDYAmNLjCVbz71tsFuAEALje/RX0vz0wv1U8Xn8Q48zMDCA7/sraZ3Vcs1rsRotrPxbzc3GYzUew1rr2AMWrTWlYpFypUKxUKBcLpMv5MNFma9JYSNtxYxd5owzw7nkLFNOGSM0QtggGkzN3+FuAUKDCTweUJt5KrGfil/lwP4DbN22bYU/410df7bN1atXOXXyJOlEki9ee41vTZ7Hsm20BC0aIt136FbP1+nQOUUom/5MJ+8f3MeOtgF60+0YY6gGHpZYe86IbcG0DshksnR0dJBMJVc/bgJ0oINEwlEg8Dzvr6q12t//+Z//+Yu/8Ru/Yf/CL/yC904DnDj6wlF17Mlj/u/93u/8gJLWH0kpU67necYYS6wRfsUtkgqFPPmFAsboJZP42lQkKCFJ2wmmK3lOTV3hpbGzTBZuRZOQQErVRI7f+orGYCDw6U13caR3Owe7tpKxE1RqVZxkkrZcjp6eHgYGBmlvb1/Sar5x00ZHNM4qC2fR4oSz7LeYBprFYOqLgsZjCFAqlZi6dYuZmRnm5ucol0ukrARSWVxaGOfc3E1OTV+j7FeQlh2SI2KDAHcH3QLi6K1DZfjJTY+Txaa9q4MHHzrS2lho8n+tvl4qRalQ4GtffQmJ5Lo7zZ/OnsCkLHRCoR2JsRuL0+9utwAhBcYNAe5nSoepBC4f/OAHGRoawvP9Favk1dI6a9rN3UWAW8EsNOxf47kykfK5Wq0yNjpKoVhgoZCnML+A1ALHdphWJW6oBU4kxpmwyqBACIURvOPdAoQG5Qf8VO59bJLt4Fg88uijJBKJdRsa38n4E0LgeR5f/+pLuFWXea/EH576EjWhMUqilUDfLk1+F6K6uho8LuqWkg8PH+Dhof2M5Hoo1MpLSqlWAzmIWgUB2VyW9o72cEGtzWrznxZCkEqlpOfWLldr3j/62Z/92c88/fTT6rnnngveSYAD4Ld/+7d/IeHYzwghBlzXDYQQqhXar1gsUiqWwsm5Bf5QG42SCltZTBRneW3yEm9OXmR0YRyk00BD3j7hJqI8G8bwgaGDPD60n5yVpOxVsWybzZu3sHXLFjKZHAnHwQ/8JRHau2HVHWWQ6qczpgZK5RJTU1NcOH+eSqVC0knQls5yfuYmnzr/NcaL00jHifw1RQuijTXEFi36TQokJnD5QM8+Pj7wIPlaiUMHD7F582YW+9Pytkww8bF55eWXuXH9OulUiv8+9hKjooBI2wRJhbYlWGJj1ORq4LYMIIUUmJrHYCXN33WPUPSrfOiDjzM0NNw0grsboNT06rgLYGmauDHE1nlSSsrlMgvz81y/fo1bk7ewEEhlUZU+L8ubvGaPM29VkMIJxT5RTrapanJ54TcbpCYbIj1pBNqvcMjZyo+1HyFfKbJ792727N6D63ktpUjudPyde+stTp06RTaT4fPnvslrty5jJR0CBVpGoqdvY+ljXRkgBKZWoiPbzUe2PsTjmw8iCUV8OjKjXxNZIm2C4zi0tbXVLcDWOFaB49jKcRKUK+Vf+Mmf/OnfvFNvy1YPo3j22Wfl9u3b5Zuvvfb90lLPOo6jXNdbUcvW7Cu0DqhUKriuu6HEaELZ1AKPl66f5HOXT1CqFsEYlJWoFyzeyU0KifZdUnaS79/xGA/27aDqhoqwkaEh9u7dS66tLRRxLHXbXn1QrzZ5mI2D1+2C5fIGr7VajampKU6++QblaoXOXDsFr8Ifn3yBiwtjWLYTSubXSiKsBXAtdguIFzpp5fDzOz5Kj8ripBM8+uhjWMu7PLwNiwFjDMqymJud5Utf+GvSqTQn89f57OwbWLkUfkqGUZwjWwO4jXQLAIQSmIrLUCXDL+hHybtlPvShJxgeHn5XUpS3A5aNNVNKKYIgYHZ2lksXLzI9PQ3GkHHS3BBzfJozjIkFhKVAyAYhyrLc293sFoABX/O32x/hcHIEVxkePvIwuWyufg7e1vGnFMVikeMvfAmJYLI4xx+9/gV0QkUAJ9GKd41zjRQKrT3QPrt7t/GJXY+yuaMfJSRe4C+qgNeYMrQOI/x0Oh1FyatPiMYYLaU0yWRSVcqVYz/50z99LJ43bgfkVCsv+o3f+A37p37qp/xHH330e9Lp9KeDIDC+H5j1IjeAIAgol+Ncm4qKuEW9mHvpphAyrI2yLZsb+Wl+982/5qVLJ/CMQUgLqdRtFWU3pSX9Gn3ZLn7+8MfZ372ZYq1Cd083Rx46woEDB7FtZwkF07jFLeTX2pa/Jqzna7JF9X9rfpZc//viLVZvxhOrZVl0dXUzNDhIpVKhWAppywP927gyM8ZccQZlhTY7S/qgtZx7azF6EwJ0wIH2TTw5cIiq77J923YGBgbROmjt94kWjo1Y4/8QJBJJZmamKcwX6Mp0cK04Sd7UULYCS2CUiq4Mcfe6BYhQNYzn0+YneFhtoRq4bNu+nY6OjohCvTvnfyNj9Xb/b7XXKKlQkXMGJgS6XDbHyMhm2tvbqFarzJfy9NntHJKDJLTFNX8GbTTSiEjNShOVpVmZCFshp19FZRm9ToQadoatTj7eeT++DhgaGGTb9h34vl+PPt/O8QeQSWeplEuMjY3S19HDdH6e8YWpMMKJ1KnvFoAzmLCMSyhmSvN8/dobTFVL7O3bSkcqi6sDVDR3N5vXhYjmdSHwPB+tQ5BfPbYSQmsjPM8jmUo9ceLllwfvP3z4r5588sng2WefVc8999yGJn+rhdWIEEJ4v/6f/tMRJcSve56rg8AXQgipWyiv0jp09hfCWf+1JrSQsaTiT0+9yPGLr1DyaohEGmMWm/7d+apEoH2PBwb38kN7PkCbnaLkVnjkyMNs3roF27LxfG8RKJosOFZb3S6P2hrzc5ZlLfZqEovWW3HyPo4Ql1C4d2HVjYFA+7R1tPPBxx/nzOnTXLp0CUcp/t4jP8CfnHqB18fPoxJJgpgnX55rWlNYssrrl0UycTnpR4cOE2DIpDNs3rIFIcCyrQYz2beRztWaZCrD9q3bmZiYoMfOsS83wsTCWfBDmkxogzFyqbvKnXQLYClYCiGwrFDRqkQICEZG7IC4+1FXy69pZYzfxrmJ/WG3bNnKwMAgV65c5uKliyS04uOJgwx6bTxXexVX6TDKlY0g17BjzWy9aBbRNSkib3AKeV/7TrJ2krJw2bR5Exjzjo0/rTWWpdi2dTsXL11CYtg/uJXz09cxvo68dQVam9UXm+80yJmGMgNlceLmWW7OjfPD932YD2w5RLFWCUumWgDluOxJNgq4TDNm0Zhyuawtpf7e7l07H/6N3/iNH/rkJz95faN5uTUB7tlnn1VCiOB3fud37sOYv5BS9tdqNS2EkK2c6Lj2y7LWliOLqEbEUgqtDX/w+hf46zNfBctCWtZdLVSWQqK9KvcP7uGnD38PxhjKtQoHDxxk34H9dWWik3AazAvMxi5ms5hDdBwHx0kghKBYKIRqTN+LEq6iHnF1dXUhpCTwfWrVWlhT15gnbJLzaNawdTXgVah6U9j9+w8iELx1/i06s+18Yv8HuTQ9Rt6tIG0rrsppWqC98nFjkqm5sKT+G3yXvZ1bGG7vpVatsm37djLZDEEQYAnrnRFRGAVotm7fztlzZymWytzXuY3XC1eZ9zyEpxCWAa0x8UJDiKZAtfYxofkxQdRzVYLwPlwALp0glp/bOz3/S643s3i+9BqNM+9WPi/+HD/wsWyLg4cOkcvlePmVV1jwyjyc3MacX+IzlRNYySyBNJjGRZNZH4zXTAPUr2NNl8rxUMd2fK3p7Q2V0OEpemfGnyJUWQ9vGmFwcIDRm6Ns6x2mP9vJaHkWYTnhZPkuNNeOx5u0HCaLc/zGtz6FZSk+uO0wNS+cs6SULcz14adpvaZTizA6ELUg8HOJ3AO2Zf2n//bf/tvP/tRP/dRMXKJ2RwBnjBHHjx8Xxhjxm7/1m/+6LZfrz+fzrhTS0Y1V98sOQVxQbFs2SklYx20mVu5IYyh5NT51+iX++sxLSCcZUfB3ryZEEApKEnaaJ7c9QMJ2WCgXuP/wA9x36BCe54UUi1K3vZLVWi8WeCvFtatXuXDhPHOzc4yPjeL5YT2b0eGKPW4N393bQyaTpauzk33799PV3Y0f+AR+QOAHiMbVnFn9QlyyX2bl5GiMQVqC+w7fjxAhyPV1dPGj9z3B77z8PCJMhyyq2+Q6wpJmk/2yE7wospS8b2AfaTss4t80MlLPvTVy+RtWsW1w0jXGkM1l2blzFydeeYX+tj72ZIf4ZukKMqnRgcRYrJxomgLbOjZfTXKYQggsFdI2lm1hJ5w6Vd3snK2Wz72d83+nEdntR3CL++J5Htu2byedTvPGG28wXy7y3e0HGfcXeKV0ESuVQQuiXBRLo7eN1rwRRm8ha1PjQ30P0p1qI18psXXLFhzHCa+vZZZUb+f4Q4ULi/sPH2ZsdIyUleCBzXsZO/0SUhuMFiBNyMq+C4FOG420E2jt85+/9j944+Y5fvKRT5BNpKn5LkqtD3LxsXRdt96w1TStqjfWQn7BT6fTP1Aul//kV3/1V//W5OTkQqsgtyrARZ22/V/91V/92Uw69d2FfN4X4Bij11wuaTTJRJJEMrnuamdxDg3tpD7zxtf53KkXUU4qEpHc5ZsA43n82JHvZd/ANkrlItu3buehBx/E98LO361OAs2e01qTSCRwXZdrV6/yF5/5NNeuXqNSLhFoTcJxsCy7XvgtpazTkxfOn8MAjuPwwpe+xLbt29i3/wD7Dxygrb2NUql028C7/LmYCj3y8BEQhosXL/HBnQ8wVynyP177PHauHV9H/oPrKaXWO8GEvc+1X2NT+xAP9O+g5rsM9PfT0dkJBhzbaaqqbTlCuY1JVweavXv38dZbb1F1q3xg8CCvn7uG72mkrcFSaHn7v7np8w1AqKywdtK2LGzLjkxUFsGy2Tm73XG5FiW5lhCqpbHUQmTZ9FoJNENDw2QyGb7xjW+QLxT52f4naJtO8kLxLCoRzh9GsjZVZ9aJ3iKrVhN4dNidHOnaidaanp5u+vv7sSLzg3d6/BkMA/2DDPQPsLAwz8GRHXzj8klmvBJCqrD7gOJde9NGh+bxQvCVt75BRfv8wyf/Nmk7had9VNRnc71LxXasUKNRF1k15Sutcqnkp1KpJ6qVyq8cO3bsJ5999lnF6sVYjWuJ5t/94osv8mu/9mtbpeCLWhtLay2X13ytqAHTBikVbW250FR4nU1ESWkh4Je++Pt86ezXEU7ybSnkl0Ji3CoPbDrAj973BLVahb6+Pp788Efq9JBSkRlyFH3JaIujusatUcyhrNC2K5lMks/n+Y//4d/zmU9/irm5eWzLIpVOk0gmCTB1A2U38HADn8AESEuSzmRob29HSYkOAsbHJ3j1xMtcu3KFbdt30Nfbhw70kkR4nNBv3Jo9L5Vcse8xTTY8PMLU9DRzc7MMdfdxauwKxUoRpazFXMiq8vcWugXIxdX09259iMN9O3G1z979+2jvaA8HobXy2C7f58Vz0vC8XPZcw9/x1uw5qcLfn0ql8P2AGzeu0dPWxWRlnpuVWeyEhVYCYwlQsnEQ3V6n7oYyATyfDp3i8fQeKrUKu3ftobu7OzwOy85tM/FG4/Nrnf8V4ojG37/8uYa/hRLN39P42sbj28J5W/FcdE600WSzWXp7+8gXC8znF3ikczeBH3CucB3bshsbGjTPva0qLFmM6iRgghrv79zHxwYepOCV2Ll9JwODgyHj8m0Yf1JKbNtGSsXlK5fp6ejCC3zeGr+CnXAaSgW+vSUD69OWYCcy3Jy+ySvXTvPE3ofpzrbjBh5WZFO42ialxLIsbGVRrVVDypLm2AJI13WDZDJ5+Ls/9jHxMz/zMy8cPXpUvvjiixsDuKgpnXjxxRfNx7/v+/6r7Tj7XNfVENpurbUJIcLq9WSyropcaxNC0p7J8Xsvf5YvngxpSQzc7Q5UoXpPk7FT/ML7fpiuVA4rYfPIo4+RyWQwRtcnfSKwW7I1UT4uV5JZtk2tVuO3fuPXeeuts3R1dWE7NuMzk1y8foXrk2NcHb/BtcmbXJu4yY3JMa7fGuXGrTFGpyYYm55gfOYWt+ZmcRI23R1ddHV2MTl1i9dOnKDmVjlw4GA0EVp1j8s1gbfxueWTYGRinc1mqVWrXLpymc19Q5SqFd4avYyyrMWLrFm/svUamca93qQEAjqSbfzcoY9jjKG7q4v9+/eHXR9su/lksdZvWee5ll6jJLZjk06nuXzlMkk7QcKxOTN7NXQzsQRGRb9RitYbmTbtrBCCo5ACXI9Ok+a7Mnsp1yrs2bOX7p4eECKM6hr8S+USUFi68Frv/DuOg23Z2FZoFxc/ti0bS1mhhVz8vO1g2xaOHeaLk4kEtmXXzb5DStVqulhaayG11vloFHDlcjk2jYwwPj5BuVpmV/sIp+auseCXwt5jdZATzR1L1hCWiFjgJRx+fPPjdNhpMrks9913P1LIuvvQOz7+or9zbTnGxkZxXY+u9k7eGr1M2XeRKiyCN++BZrfaaJSdYL4wyxtjl9jWu4nhzj4CrVHKWgcHZDhWbZtyuRyd1thAYym+ACIItLaUevJjH/3o1/7ZL/7ipaNHj1ovvviibpmifO655+SxY8eC//Sf/p8flkr9kOvWTNyJdZ3MKl09PXR1dRIs6w+02kHJJtL85Zsv8SffeP7toyWj3Jv2auwc3Mnm7n4W8nn27dvHyMgwpVJpiVVYq2NpuUOBY1v8ybN/zsk332BkeISxqXFefetk3c9NSAlKIhI2CpZY8rjGUPMqzFVLWFIxNn+Lrmw7j+w/zPDQMIVigZe+/BWGhoZ53/s/0JSu3BCFEv9t2/i+z6H77mdsdJTJ6Sk+euh9fPXCG0zV8khlEyCaiyhWdfdoFGOEm/E8PrLzMD25dhZKBXbs3EUqlcbzvUVxg2nWX2xtiigeLUYve2+DbNzETurGNK3Z6u3tZeuWLVy9epW93VvYPjnA6co4TjIdGjpI0xDJsnZR96qCnKX/F6sow4t/6ULpTtVuYZ3fDL/z2/8v5VI5GtvLOrg1dGS2bZtkMkU6nSbblqOnu4et27aTyWTIZrNkMhksy6JULocu/C3U6rVCry6enbB7dDaX48EHH+D4i8dJixQ/selD/MdLf4ErApQtCZCLZtgb6h0sIPA42L6DA91bqNSqbBnZRC7Xhuu5DV273tnxBxDogO7uHnbv3sM3v/VNto1s4eDILl48fwLbsQmMeedM0u/wFugAmcxweeIq/8fzv8n/+SP/gP2DW6jUai1ZMSZTSYIgYGZmBinFajk8EQSBAGMsx/l///Nv/ecP//2f//sX18rHLQc4+clPfjL4r//hP3TULOf/Cq3FNIBcj2e2HZvunu5whbLGa2PS1FYWN+du8X9/9r+C7bytB98YjVAOj205QNpJ4KXToT2S50ddwQUbjRobE6W2bXP9+nW++tJX6OntpVApcuHmVaqeh50MaYjQeT00UzUrBAhhyCPj/qZopkoLfObrX+Tw7gO87+BD1Ko1Pvf882zbto3+gQGq1RpSrt+Vt06NrZYEjzwajzzyCJ/+1KdIKJtDQzv54vmXEY6NEFH362ZAtyof3PhdAVk7w4d3PITB0NnZyeDgQF01G2f57kRL1JKEvslrgiAgkUxy/333c3P0Jklp81Dfbi5cnQBXIywZ0pStN2Bv7f8jYFFWTCUuanZWe1urh8dSEs/1OHv6DNVaFduy1gRQrU1DP7CoH2EQ0Nvbx+DQECMjm7jvvvvZf/AgSllUKuV1neaXH2vdSsG6MWzespUd23Zw+doVDvfs4HuKD/Dn49/EFkk0ejGibqVbQFzUHUpFeWrkCI5lYyRs2jSCIZTrfzvHn47qa++7/zDnzr1FsVzige37efnKKVzPRwpFINlwR4NvWySnA6xUhvniHP/607/Bv/+J/y9DHb1UPRcl5brHqX+gH89zmZ+fX0uoIj0v0MlkcpNfcX/z6Wef/e5nnn5aHzt2bN2piKNHjwKQh79lWfbuSqVqtNYyCDTrbb29faHxsGXV25w321R07zgO/+WF5xBaRyDz9qxTYuVk0kmwb3AbVd+jo6ODwcGhutGzvI0iWiEWN6Uszp09iw402UyWt65e4tbcNFbKwZPgW+BbEt+ReI7AtyWes7j5tsS3Rbg5gsBWmKSFSic4cfE0n/vmcTK5LEZrPvfZz4ZqTyVXAV4TrfkathWx/uLzQkDge7S3t9PWlsPzPB7f9xC2kYhAI2P7uFhR2MyxhOYRi5Rh3vPhkQMMtfVQ9Vy2bdsWtUIyiz3vNrCF8uJgyRb2RRX1rel7o5xv42ZFEeyWbdsZGRxmoVTgkaH99Ntt6JqP9DUiMCtp89XKANZqdtq4RhAC21ZYlopWq0vHU7zRsG3kGCklybXlQs9UR+FJja9MNA4XN21LOrq76Orppqunm+7eXvr6+hkeGkEJyY3r1zn+wpf4rd/8df7t//1/8bnP/iVaB6RSyfoxb+VYr0ZPxjSpZVmoqOvGI489RjaVYa6c5+ObHmW7049XdVEBCB2mGlbk25avAEycMg3NHPa2b+W+3u14OmB4aJi2trb6edj4+GPF+ANzW+NPRQu87u5udu/eS7lSZtfgZnb3b0V7HtIYpDZRboj3xM0PAqSTYnRmjH/67K/gaZ9MMlUvh1lv27R5M7bt4HnBqlhjjJHlclknEqknP3Dz5j8QQphIdLJ2Du7FF180R4++YCUS43+htU5rbeRaa4fYwiqXy7F58+YV7vfNNgOknAR/+vIX+KOv/gXCst/WAy4QEAT0Zbv4iceeolarMdA/wNDQUL3VuliuE2hho2HAW5bFmVOnuTl6k7a2Nl47dxKPgMCSaFsSKEnggLYE2pLoKDKIN62i/1OhTY+WAh3RYsq2mZybpiPbxqFd+5mYnKS9vZ3Nm7cs5uMsK8yRRHy3FeVd4sVG+LeNZTuLg8mxcRy7ngPLZrPoIODqtat0tnVwYfQatwpzSDsUmyzJR63TLSCMGiXGBDgqyc8+9BQjuT6cpMOu3XuwLKshCoi7kLPOFr7Gsiza2tpIpdKkUilSqWTd3V7cxmQVnz/Hsblw8QKdbe0gBK/fuoCddELzZWu1376GsGR5Xk5Qz8F1iSzf2/MQpWqZbdt30NHRXj8ed7IR1dWVSiW+8Y2vhx6u+Wlev36GicIsNxduMZqPtyluLkxyeeYmF6dvcHH6BldnRpkozLBQLVLVHql0iu7OLlJOktmZWU6efJObozcYGR4hm83Vj+Gqk/qSjhjrn1+tDalUilwuy+joTbLJDH7gc3LqEtJWURNW0bx0YJmwJF5A4Xn8+K4P81DfbmraY/fuPaTTmfp42ej4k1LS1tYejb8kqXQ6ql8Nbmv8yciGqrunm7Onz5BJpcmk0rx88STKssIOA1J8m7q7335EK+0k83OTjJUW+Mi+R5bQ82sdDztqMTY7O7teMGy01oFlWY989KMf/cLP/dzPjT399NPqzJkzpilFGffg6ep67fswolvrIDI3X5ualEqG1KQV+s6tZxhrK8V8qcAffevz4TmLpPJvH8KFRbtd6Vx9Mu/s7KhTdyv217T+sY0su+XYpFNpstkswrFwawGWHTbTDJRAW+FANWtZ8RiDMGHPLDRopZGBQKYTnLh8mvcffpiOjg4uXLjAzl27qVWrYddwHbcwMVGfOh22kNdB9P8hADQ+Z6LXxxdZIpmkXK4gpKQjm+Pg1l2cGbuAk06gtVlsWinWL+qOa9+M53FoZA+PbNlPoVxi86bNtLWFdk2r5RDXzC8pi6lbU3zj658m0EG0Apc8+tj76B8YwHXdJTmnlpY/Ubf2TZu30t/fT61a5dFNB/ira99ivuYhHYkJTAjwy7nDtcBttXMsQBLWPtq2HYpJGiKJtdRqLf2iiGFIOA5SSJxkAt8SyES4eKoXUMuVn1kzPoUgz1h+HjOnSdyy6E63saVzmG29I/T19nLj+g1+7Vf/C0899Qkef+IJqpVyC7nD1iZmpQxB4LNpy2auXLvG3NQUHxg5xAs3XuVGZQErncCI+IoTK4UlUHcsCQ0dKmxuH+G7tz5Eya/S39dPV1dXvVZ1w5O2VJTKZf7qs5+l5tZQMpzz9uzdy959+8LrRIgNjb/4szOZLNt37uDGjesc2LqLPYPbODN5BSuTCucCGf3E9wbGoXWASmX561dfZGvPMD//oR+i7FZR6+TjfN+np7uHQr7AxPg4lm2tQm0K6fu+zmTS3a5X+5fPPvvs3wKCZ599VjR6VsYAJ06fPm0APC/4u9lMxq5UKj7rOJ1orUmn03R1da3Py9dzBBZ/9M3Pc/PWKNjO2wtuLCqv0k4K27YQMlQ8CimRzQJUsUFLJBNGpZs3bUYpRSqd4sOPfYg/efF5Cn6FRDKNsBVGQiCjCWaZyGTxq0XkmRd2ijWBwqhQiXSrNM+50St81/2PMTk1ybN//IeUy2WqlQq1Wg3P85b07yKW2BKrkcyS5xGgpMKybVKpFNlMlnQ2QzqTJp3OsKVvCEuFFjRieU+YNYq64wlfo0Fa/ODBD5JMJPHQ9A/043te00FuWjjeqVSKv/rc83zm039Orq0NJSW1ao2JiQl+5u/+XEj5GIMQstVpa8k4PnToPr7y5S8z0jXCo0MH+Mz1b5DMRgCvI5ATq4tHmoP9sscmBBc7YWPZ1oro504gwhCqBqWUJJOpsIg8n8A4Ep1UaJvQnUWJsJB9lZMgjUAEhkBrRt0FJifynJ6+woGB7Rwc2oXxA57/y89QKhX56Me+Z92F7UYmfGMMlrTZuX0HX5+aZDDby0N9e7h+6UVkwomy5aJxhbmyl1yUd0fDk8P3MdDezXRxnuGhoTAXpPWGepwvGX+ffZ4/+P3fJZlMoJSN57lseX0r//Sf/SK5XA7P9zc8/owBx0mwZ+8+bty8QS6V4fEDD3Fm9BJSG7QgTODL9xDCxTlGO8HvfOlZHtyyh0e2Hajbeq3FChoMg0ODzM/PUqu5q4wtA2CVSiVt2/ZT4+M3f+gf/sN//OzRo0eXrHAtgKeffloeO3Ys+JVf+ZWHBHyoVqtprY1av3UEdHR04jjOuu0+4pxMsVrmj1/+a3S9xcvbHS/HcVZY7yIbaNTYNul2Vpt1Z8XILXvPvn0ceeRhxkbH+K5H3s/uXbt59svPc+L6W+ggQGTSYU2VkpEQTNQtyhonp0ZjWCFB61CEUKn4nBu/xo98+ONYSlEoFlFCYgmFpSw8t7a0ac6Svk2iIZgI5eqe5+F5LpZlk0gksBOJ0B9RSkq1CkPd/fS2dzNVzSOtBLqhKc96M3Boy+Wzs3sT37XrCK7v0dfdQ1uurYEaav2oa61JJZPcvHGD8+feYmh4hFQyGTnmWFy7eoVbExNs3rIF13VbH1fRfqiIRRgaHqGtox23VuP9W+7jpfFTFCpu+PvthrSmaGGnxerjJlTdOuHxjor+m6pMbgMk4rKWRDJBMpHESSbRtsAkFUECjCWjrdn3xQINE+JHYFDaxngBBdfjq6OnuDQ7xt953/fjux7Hj79AR0cnj3/Xd1EoFOqlJ6sqsjagyBsaGaHzXCeFSpEPb3+IL994nflyDRlHccsXG8vq44wOyCZyfN+ux6hqj472Drp7uuum3hsZf8YYbMtiYX6ek2++QWdnF7lcDgMkHIdiscjY6Cj7DxwI58ENjj8B+L7HppERhgaHmJ2b45G9h/mrV1/i6sIEVjoVmrW8t/AtnNukwHMDfuvLf862niGyyfRiz8zVzn8QkEwm6R8Y4uqVy5FGY635wQjX9f/50aNHnz927FhpBUW5f//+MHqr1Z5qa2/rzOfznhDCXq+zrWUp+vr7Vp20lu90V66d//C5P6BanEPaybvqMbneynChXKwP7CDqOyZaNAhd/0SGDibf932f4LPP/wULCwvs2bKDZ/7uP+by5E2+duF1vnz+NaZKC7helcWmMAaUBTIEXhlFICGFaEID3kDgY7BSCS5P3eQPv/BpRGCoVSr4NRev5uJ5XthLTYcwpLWJFrN6MYrTZomE2fN8al4tdHGQAqHCe5REOIqq8ClVyiglovMkl2pNl7XCaaTmpBQEbpWfeOh7yCSSzHku/YODISW8qpvwWrRbmFt66+wZZmdn6erq4tTFs+QrJT72viepVqtcuHiezVu3rP0dq01qQqB9n66ODrZu2cLZt95iZ/8wB3u28dL0GZyUjQwEWpklFN/awpJmIpxF8U2c/2y9TKA1D8S4RjOZSpJJZbCTCbQj0WlJkAr73ZlE1BKoWRgTRUFChwCnfQ2eRHoWtmczUVzg8xe+wQ8dehIpBMdf+BKbt2xheHg4XFxscPGyIgIVIjTETiTYNLKJ115/jZ1DmznYtY0vj5/EcmyEkBhhFjuux/vNorhEezW+Z8fjbO8YolgrMdgzFEZWcuOH12BIJpNcunSBickJ2tvauDx6jWtjN/mBjz6F4zi8/vqr7N2/ryVJfNPxpzWJZJJdu3bxlZe+wkC6n0f33Me1r48jGvLL70WQU4kUr575Fr/VPcg///6fY6FSQK0BWkKISMnbw/T0LQr54iqK8fB0e57np1PpQ8Lwz4D//ejRo9axY8f8GODEsWPH9C//8i+ndOD/cLFYNMagzDrgo7Wmu7u73gV3vR9pWRbThXleuvgGQRCgHN5BZZBgvpCnXK1gjKFQLCCjXlW3/YnLuhv7fmgk+30f/wQvfeXLLOTzZLNZHt1zP0d2H+LvPPmDSCF55coZXr36FtdmxpgrFZgp5clXimi3hnarIeDZCYQKCyERBo1GJmxmKnmefel5hKuRnkYGBhlEKisaV3gmWtCK5vU9dUFDeDGGllyghYmELoLAkai0E+6PWEdYUv+/UEWma1WGezZxZPM+KrUKbe3ttGXbokhSbpiDs4Si5rq8dfYsqVQK1/e4OH6dmu9S9qr0dHVx9eq1UMG1AUXuknErJRrD3n37uXjxItVqhY9seZBXbp3D9wKELxGWwZhVHCZazE0uibSE2MBs1SJoRwpMywqVyspRBLYIKcq0hU5GdGVCrZzsG/qvCR1SfMI30XgL0DWNlbD4xvRZOq6184l9j3PpyhUuXbrAtu3bcN1aVNi/xnFuIa+NDHtI9vf3g9bMF/PsbB/iqzdPIjwdCUsjkIMl5QKCECxsK81T2x+rl8F0dnVFx3vj408agR8EnDl9Gq/mks3muHlrnLGZCSZmpti7fTdTU9PMTM/Q3dtL4HstO+vXv0NJXM9lx86dvPHG60zPzvDonjCKK3oeQipEQ0HHe+mmjUYm0nz+za/y/Yc/xIHh7ZTd6pq95OLyq5GRTZw+eQqBWsPMG+F5HtroH/t3/+7f/co/+Sf/ZAaQx44d01acOwuC2mFbJR7wwq62a5q/CSHRfkBnV2ekftLrJMgNaSfBV86/xtWxK8hkmkC/U9FbyPUVyyVOXbvAzp5hJicn0UGAsuJM+8YrjpZftPHvTyQSfPfHvoebN28wdesW+XKRarVKKpnCcWw+euBRvufQ++uigjOjl7kyNcpUcZ75cp4rt8Y4P3mNyYUZgkohXKVGMnItQ+82ZQmUDyrQIZ3UcCxNA+1hRPOrd0UavMExwchQEBNYAt8Kc4ZmSePONSbv6P+NDnhi50MMtnUzk19gZPNmbMdedYW/Hg1uWYqJiQkuXbpIe3s7lyeuU/ZrCCW4NjXKvh17mM/Pc/3qNXbu2o3nbfx7pAyp5u7uHjZv3sLVK1fY27uV3e3DnKqMopIKHciGrHUzgGdpnlKsP4MKaCkHdycpaGyBscNmrjqp0ClFkLSaANyiIlFEeUeCsEGodCXS1eiqJu108sXR19g3uJPNwyNcOH+Bh448QiaTwQ+C259+o4VWnETp6umht6+P/NwCB/q3Y70Bxg1b6oi6YGbpYJZCEFTLfGjb+znYu5VCpcTw0BCpVBLfv70FrWVZVKsVTp48SUdHB4Vyken8HMpxuDB6mYcPP0ShUODatasMjYxQ3lAervGiNFi2zaH77uelr7zI8NAm3rfvAf7ytS+TdDJ4uqHO/T0WxQnLppCf5U9e+SJ7h7auO9aFEARak8tmaWtrY2FhAWWpVaZno9xaTdu2vdN13R8QQvz20aNHBYD1zDPPCADt6x/RUocSBGPk2uGjTzIdChOWRzOr5d7KtRqfP/UNPK+KUjmiSsx3JAWnlKJSKvH65bPcP7KLm5NjTE5OMrJpBN/zb2tiWX1VGqoWt27dyqZNmymXS9SqVWbn5yjk85Sr1TDJHZVMbO0eZM/AFixlkbQdZkt5xuanyFeKXJ4a5cbMBOfHrnJx9BrVagWvUqPk15AGlDE4KiwFiNtPNK5yjGgBsEXDa0UYzcVqOy1lXfm5Ku3WEN0JKdCBR1u2m0/s/yDVWo1sNktPdw+e722Ivmk8npZl8eYbr+MHPolkkuvT42F9F5orM6MIW5FIJLl58wb79u/Hc92Vxe0t8lJCCPYdOMClSxcgCHhq5/t54+U/wPGTBIEO1aSmmbsLq7fRWWN8tSoy2QizIJa15zFShmUoTgPIJWVzE+MGwYaIEj/C15iEQXsa6WiwNUFg842JU+w//AOMTYxx+tQpHn3ssTpg307+sPHAhayPzeDAEGM3x+joamco2c2N2lxd2YowYV5bL8Y1WgfYVorv3f5ImJ+2Fd3dPXUrwdu5zqWUXLx4kempKXp7+zh74xKeDpC2YmzmFsVahc7OTsbHxqiUyw1iJ7Gh8RenELZu3carJ16hVq3wwf1H+PKpV6j5OozOJVHk+h6L4nQAyTSff/Mlnn74o+wZ2IK7TqRrtMZ2HHp6e1jILzT6Uq6yFjYYwf9y9OjR3z927JgLCOuZZ54xx44dMwj5fUIIYdbhEwQC3/Pp7e0jlU6tq4I0xuAom+sz47xw+puQyBCY4B09uPGq540rb5F/+MNgDKdOnWRwYOC2J5XV3xcKOjwvzPNlMllyuTY6u7pDqb4xlMtlarUqpVKJSrVKtVqlUisxV1oAYxjIdbG5q59DI7vQkdVXzXNJ2DbfPPcGXz39KmevXqBWrTI1N8tsfh4Z17dFdYWmwZ5pdQM0saxgO3SmDaM4iVFh/ZtZrSVOYz1SjF1+wAf2HGRX3yZmCwtsHRzAdmw8z2cD5hcr6N/Tp0+RTqYpVIqMz09jnJCGu5GfZiI/w77h7UxNTTE3O0s2l2tJ9LT8/2Puv6+3n82btzIxNsbOzmF2tQ1zqXQL20nj6cV+VncyyZgGSvFuWnXVi41bcV8Rq1wsURhl4lBBCYwNwjFga3zLR5gEZ8tjVIVPVzS5rwbSt/u7LMuiu6eHSq1CJ53s693MlasTJNJOuNhQMrLJirSVQqDdGnv6dvPhLYeZK+fp6+mrGxiskcdZdfwZY0gkE5x4+VuRKEhybWIUY0uUY3OrMMf1qVH2bn+CyalbzM7MMDg0jOvWNjyHxOMvk8mwffsOzpw+xfbBER7Yvo8vv3WCRHs2BGrTXIX9br8JIXBrFZ771l9z7If/P9R8b90rSGtNV1cXN2/epFqtrjWWlFtzUZY6krKsI8DXQg9SIcwv/dIvbdWB3+37PjrQazKUgQjBKZPNoFQLtW+EKrUvn38NdIBQCvMOV+UHRmMnk1wYvcJXz5zgg3se5Mb164yNj7N9+3Yqlcpt1cWsdzJNQw1aHMkCtLW1IUR7vXt3rVYLpf6uS7lSwfc9FhYWqLkufiQgsZQi8DUf3H+Ex/c/zFR+lprncuPWOKevnuOtm1e4emuU61NjIcgqiVIylPpH+2tWm8waT58Mac46uKmoZkrKBoFJQ2TSKKzQBqlsnj78EVzfJ+HY9PX1N7Sp31g0FRb+JnnzjTeZmpyku7OL166epaxrqFQCkVDMVwqcmbzCAzsPMj07w+hYqGYLHU7kOudQN/3OdDrJrt27uXbtKj1WL48O7uPKpQnwDTLQkZ2aWhrVNuuNt0b0ttSy8+5FcFKqpe1f7nRlCNEYWPTkNMJCBYa8V+OVW+f48NBh8sU8CwsLtLe3R+4eYs3j3ArIGBMKL2zbhkAz3N6HcX1EYJABmCCm68ziNWng49seCY1+pWJoaBhjiMzdNybiCelxi9mZGS5fvkw2m2V0aoKFShFhq7C+1ZG8cfksH37kcaSUTE5OMDQ8FEXmGx9/xoTz5e49e7hw8Twm0Hxg/0O8cukUnu+DsKL0g3nPFH4vYWGl4svnX+PK9CjDnX14gb+qKCxOf6XSabq6u7l5/cZ6LJAGIbWUPwN87Zlnngnb2GrtvV9K1ef7fqhLWKu4W4e+k5lMBt2ySENwevQS3z6/mchiR8KzX/4sB0Z2opTk+Atfwq3V2LN3H7VadWMKqBYG11qviUEvtgtLpzPIbJYuEWYgXNclCMIC7mKxSKlUpFarkc/n8XyPXDJNNpFiU88AHzz4EPlyiXylQLla4YtvfIMXTn+LqcIc+WIepEBaNpYMW5QsUUIun5ARdff7WIptRBP/zGWPpZDoaokP7XmMvX1bKVfKDA8Pk0qlWhTziKYTgBCKc+feolqtogVcnxolkCBtiW9Boi3LN6+d4hMPPUEmnWZ0dJS9e/dFbinrTaiiaS6uVnPZvXsPJ998k7mFOT6w6T6+eOM1pqolRCKFsEP6JOwOy9oNX9eL4BB3Pwcn3obLJ65vFAJhBCpl4VaqXK3coiPTznwpz8z0FD09PbiuXjK5GyM2eFTiBaShrS1HW66NSqVCf6aLnEqFoh9bhfnBuGsFgO+xqX2IJ7Ycpua5tLe3hw49Lai8mx00rQPS6TQvHn+Bubk5tmzaxInzJ6n4NZxkGl8anHSSN66fZzo/R3dbO1euXubAwUM4jtMCu9V8/Hm+z/DwMJtGNnP16hUe2nWArb3DvHXrGpal8N9rSbj4eBqDchwKc5N8+rUX+adP/RTT+bn6InytQKGrq4ubN26s22MuXDSY7/qlX/qlzl/8xV+ck9GqYYttWUJrrY02wuhIVr58i4xYlbLIZrPrdg0wGCypuJWf5czY5W/bSTECAhEmcCfzM/zBlz5Fd1c3szMzvPClL+K6NZJRg9aN2jzdaa5kUf4bNj71/TBiU0qRSCRIp9P09fWxbdt29uzZy8MPP8KB/QcZGBqivb0DH03ZrWG0pjPdxo6BLfzcx57mD//JL/Nrv/AMP/bE97N9ZBt2wsH1yvgKjK0wjkLbIrIPE4uPHYG2w5yNUSLsi6aa5eCW0ZvGYEvJDx58nKSyEVLQ3z9wB7ZTkEwmmZ2Z5szpU3R2dDKTn2NsfhormSCwJYGjUFmb6+Uprs9Pks1kmRgfp5DPI4Ta8DlY6ueo2LFjJ+VqmZ5EOw/37UbXglBVGEQyeszqwpJ1cm+ixf24re3tus5iKzYVjhEcya2ggC81trTIF/JNa5Za3/dFH04pFVobcrk2Ojo7KZaKpO0EHU4a7fmIgPA8xH1UhMB4Lp/Y8Rh96Q7cwKO/r79O/d7OZlkW5XKZUydPhnVwpSI3pydRlkUgDYEVHoeK8fnqmRMkEg6FfJH5+fmWF8DNtrARsuHQofswxuC5Lk8d+S4IdPSbo6DV8N67mZANevPmRW4tzIYG2Kyvws/lcvXFsjHN8UlrLUIWMthqfP9h4syJCcyDQkjCEqw1mppGH5RKpeqAsOaOaYNj2VyZGiVfKYFU38YgThBIcJIJvnn+Tf70+F/S09NDoVDgD37/d7l54wbJZLKeJ7vrk84623Iz5/jExhRnvF8AnZ2d7Ni+g/vuv5/D9x/m4MFD7N69h0wuS8WtUCwVKZSKbO0Z4J/+wM/wKz/9v/HL//M/4Xsf/giZZBrtVtDaR1oWxLk2KTBKhlSkih8vN+SLl5liZfRWq7BjYCeHhnYxV1ygt7ePtra2OoV9O5tSivPnznHz5k1SqRTXpsYo+1WEIwlsCBKSwFaIlM1nz30tbDGiA65dC1e6MS28umH26t/t+z679+whm8lSKBX4yLYjZIwNro/wIoCL26SsFd2um4O7+2PpbaWuTJSjVQISNrf8BW6UbpF0kpQrlTo11+pxXtO31hgcx6GzqxPX80jaCdJWEu0F0SIjPA/SgPZcenL9fHjLYWqeRy6Xo6ur+7avZWMMiUSCW5OTXL16mfb2dq5PjDKdn0UlbLQErQRaSoSl+Pr517FsG8u2eevsGSzLuu3xJ+vGA8MMDQ0xn8/zwI79bO4aCE2YNcjYteU9BnJahyUDZ66c4cLkdZJ2Ykm7odUATilFe1s7gR9EPvFNmqIahA60n0ymbAMfBJD/6l/9q0Eh5R7P95ECtZ7LsJCCXC7bUm2LNppUIsHXL52kMj+NZa+P1m/LTVJvHmiURNgWf/KVv+L4a1+nt6eH69eu83u/+9+4cvkyyWQycrtnwx0GNjKBrhcNru1mrvE8L/JetMhmMgwODnJg/0GOHHmEI0ceZmRkE9K2mVmYJyNtHtqyn3/+gz/Pn/yv/5af+NAP05vpICjMY/xlHPhGmJyGlkEIxfftfYzOZBYjYKB/4I4m8PgiP3XyTRKOQ4Dh/OiVMHqTAuNIjBPmQETS4uzsdcaKM6SSKa5du1ZXv93uChrCRpz79u9nvjDPQLqT9w3sxy2VsTT1lXSr1m7vFJ0YO+S/XeBWp7YlCFtRxqNsfJJOgkKh0DSffSdjACCdyoS964QkqRyMp8MFRt2mS4Dv8aGR+9jTtZmSW6G/tx/HcW4b4KQM27WcOnWSQqGAZVncmBzFCIEWom6IHkiQjsXowjSvXT5DR7aNickJ5ufn66bit8MgxCKbww88SKlUREnJBw8cwau6WFELILFK7vBdHsCFYhO3yuvXz9U9ZdcDONu26ejsbMkJX4QtlQ4fPXpUSiFEu5KyP3bSsJS17pbJZFuSwUqpKNeq3MrPhr5T385zIUKCO5BgLEEql+G5L3+Wr558hT07d1OtVvjd//bb/PXn/4qx0dG6y8Rq0tTbicpW21ZrJ7K8A3Cz94TtVmLqOOzknM3l2LFjB48+/Cj3HbqP7t5etDCUSkVSdoJ/+vGf4v/39/4lf+fDn6QtkcXUqlF7libU2hpF3SFjKTCBx0BnHx/b9xiFSomO9g56e3vrpra3A/JKKebmZjl79gy5XI6ZwhzTpfnQ19MGY8uwtssWyKTNgl/m1bFzdLd1Mr8wx+jo6LoT3HoXlRCC3bv3kEgk8Gs+j4/cR1rbkdBBRxOsWMV3sjWQkeL2zv9ai6q3L4JbjBiMCIuTS8YjH5RIOomIYvdXdBW501s6nUIDCZUga6cwflCPoIUGHfgkEm386J7volAtk0ml6e/vD6OFFheaK+cuSRD4vHbiBG25NgqVMjcmx7ASFjoW3CgwKgS4ilvlK2dOkEolqVYqjI7ejMp3uK3xFysq+/sH6Ovrp5gv8Mju+xjs6MWtuWHJ4HuRoowXxJbDa9fOhUrKFsaI1ppkKkUqla7Pf6vgkzDaIJTcadv2oEwYsyWZTHZrowMppGxl0s6151r6EbZSTOXnuDE7Aba9auPDdwLdGhuOBhICJRAJmz/5yvM898XP0NXdg2Mn+fP/8Wf82q/9F770hb+mWCzU2868ndTl7eTsmgFp4+cZYwgiN4hDh+7noQePsP/AQYQQjE6Nk7OT/G+f+Fn+zf/0j9jevwVTraCQi9Hceo4csmEe930+se8D9GY78AOfoaGhegTVKtA3TuYxwL355puUymVSqTQnr5wLc4GWRNtR/tAO2xFhK3yleW38Aq7x8D2PsdHRO6aMPc+ju6eHXTv3MDU3zbb2Qfa0b6ZWqqB8EIGOasVo7mpyFyO4jUc+4m7PSkva0hgpEEqh8aloH8ey0DogCPw7oiVXi2S0DrCVRdJyQm9XE/Y9DMUlLo8N7GVv9yaqvkt//wCJZPK2Fpnx35ZlcfXqFW7evE4mk+Ha+A3Kfi2sKZSgFQRSoCMTdWHbnL55iYmFaZKJJDdv3MR13ZYXeM22IAjI5XLs3r2HfKnApp4BHtpxAO16SEPYK06/9wBOGwNKcXrsMvPl0LZrLWYvVlMmEwlSyWQ4P8hVj6sKgiBIJVM7lVK7pLHtHUopJSIT3vW2uNZq3fxbtBOFaolbhXlY50e8UyBnZCh79pUBR6EtxWdfeZE/f/GzjM3eYu/uvaAN/+PP/pR/+cxRvvLlLzMzM13vU/R2uE28HWDZmEsKAh8n4TAyMsIHPvABdu/agxGGizevsH9wG7/3C/+av/PBHySoVaKW4qsWpS21m4pWVtl0O9+79zFqrks2m6Gnp/eOVvAxPXnyjdexlaJULTM6ewtjLwpiYsNgbQkCJVCpFOfnrnF1fpLutk6u37hGuVzGduwNTXTNIqIDBw+gbIUK4PGRQyQDhfECpB/l4YxpSVjSHNfEXR0Dbyu3tPw3SAE6wDU+ygoXsHG+5G5Q+jFFmUgmQQg8zw3LP/Ti/hgDEskndr4PN/CxLMXw8PCSxehGr8X4vS9/65sEgcayLC6PXceoMP8ctrySizWjGOxkghtT45wfu0ZneyfjE2MUigVs+/bHn1IKrTX79u0n19bGQn6BJ+9/jLZEBu36i+D2XozkhKBYLXFu4iqWXJ/di3OiiWQiMqdaA6eEMJZt2QpGpDBia9jXTQkpJGttGEgkE60NGhMqKOfLBQr5GaSyWvake9soShE2rdRKoi2Fbxm0o0jksnzr4kn+7MvP84WXv4KrfYZHNqGk5Pd+93f4D7/87/jjP/zvvPbqqw1dwGWdwmwUgLzT4pRWaVKtdST4kOzcuZP3v++DbBrZxEJhgXK5xD/46I/z4499HOEbHGEtbUOyXFgi46cUVIp8fP8H2NY9SLFcYnh4BNu27yi5b1kWN65f5+rVq3S0d3JjZpwFt4i07Shik/XmscYCY4Fl2yy4RU5NXSaVTjEzM8P4+NgSv7vbOXa+7zM0NMymoU3M5Od4qH8PI8ludNVHBqEfaCg2MbeFF1LcfYAT4i7Petos8Xusg0u4xMEIgx2JeuIeg3dDaBUDnGM79cWU0dGSQBuUCW25Dvft4+GhPVRqFUaGR3Ac57b3IV5glYpFzp19i3Q6za3ZaWbyc0hlRS4/MnT8QYQ5OSki82f4+luvE6DxXY/x0dG7kodua29j9+49LBQW2No3zH1bdhH4sdjkvdXxe8kkEmguTN6oO7+sB3CWY5FMpUIR0xqbkDKsBJBys5SWHA7d2iWyhS2RTNYn9laWqOMLM3jV8sa92d4mkNNR/sBI0CqspfKUwc6kKPhVvvjqS/zxFz7NN948wdjsLUaGRzCB5otf+Gt+6zd/nf/j2DP80R/+dy6cP0epVAJEvc2M53lUq1VcN3T493y/7vQfb0EQrNgalZLLVZNN1UK3KZyIV8laa5LJJA888CCHDz9IoVhgan6Gf/TdP8EP3f9duIUFZNSbLloirzivQoS2XKl0B0/ufIggCEhl0vT09Db0yjNLQFK0cLHHt/PnzzE/N4/l2Fy7NYZnghDY7DBiM1bksCElWkoCpZHpFF++/joFr0IykeTq1av1CWs1h43WxAaGA4cO4bouCWHx5MgDBFU3VFP65o4k23Gt1N06/+FxvouFAqs70oXHNKqZlNJaVfRwp4AddtkIS2mEMUhtwhyUDnsVPrXjEdqdDEhBd3dPfYzfzviLI9CzZ88wOjZKV2cXN26NU6yVkbYKBSYqakDaIF4LjEElkpy4fIZCpURbWxvnzp/D9/1VxU4bEdrcf/9hlLKoVCt84rEPI32QpnHsvbcQTgpAB0wsTCOFbGnvjQ6jOMtWYdeMVTBKKSmEFNhK7bOEEO3N+6I140FNPeRuBU0Co8PyAGW9e05AbFYqQy9I3eC+byVsbMtizi3xpde/Rmc6x/T8LDtGttI3MIAlFQvz8xz/0hd44YtfYGTTJg4cPMSWLVvJZjOMjGwinc7gRbVszQo9xZJ+dKx43OzvtZ673ffGYoCRkREc2+blV17m1swU//i7/w4CyZ+/8QLSUmi1nKJsoCcDj4Mj+zk4uIOFUpGhoWEspSiXy01/X7PfvpwaUpaiWCzw6olX6GhvI18pcmNmDCuVCGvz4l5mSoRmu1FkqRWohM2VwiTnZm5woGMzN27eoFwuk06nl0TYS5LdLdLHW7ZuZWBggIWFPEcG9/IX177BVLWKSEhEYMJ9ug3xpOeHatjl4ozbOf9aGxzHJgjuZrfFpbm3JZdxDCCm0VNTtkxPt8roLDbqXXQrEUDNrbFjcCvfte0B8uUi7e3t2LZNqVS6rfEX3/u+x6snToAxlKsVrk3cRFqKQIgI1GJvOlHv3gEglKBYqfCVMyf4+IMf4tbULSYnJhgeGWlKmbb6+7XWtLXl2LfvAKdPnmS4t5/7tu7mtRvncLKZJSz5e6b+W4T09qXJUUIFf2vdF0Lxn1o3E2AMCCn7LSFld9S2Y02LrvDk6Hoeav1IIjwxc6WF0KXevIsObNRoVMdrXQUIg++DlgYlLaSlyPsVXnzzW7xy7iSDHT1sHdrEpr5BBgYGcT2P2ZkZPvf8X0ZKrzSDg0Ps3r2Hjq5Otm7bSm9P36KSK6IbdFSouES0ImV0wjY+wa313HrgF8p1Xbp7ejhy5BFeeeWbTM9P84tP/TRe4PHpV/4Ku6MTL+aFxLJEsbT40fufxFEK17Lo7e2hXC5HZQPN9sNE8cVKQYaIBrCTSHBr8haXLl6kv3+Ac2OXWaiVcNJZPCuM3Iwd0sxGxobBURsbFVKX3xo7y8OD+5jLz3Ph/HkO3XdfVFIh1z0ezZ6PL6xDh+7jrz7/ObZ1buXJTYf571e/RCqbQAcaoWXzLtnr3HzPvyOAWxluGVzPvTsLymXCkmVfE/khipAWiqNdHTrlNLqHrFUK09p+aAIdMh2hejJczSPhu7c/TG+6nZniAl2dXQQRS3K74892HGZmZnjr7Fm6OrvIV0qMz05ipxJ4kqg8YGkEhxYN/ekM37rwBk9/4HtBCC5dusRQ1CvvTsafZVns3beXU6fexJE279/3ECevXwjt8epuQ+8hE2YDSEnNdynWyjiWvX5Xmhjg1No5O2OMiKb5NktKkRRRH6/1AE5KgdWiZ6NAoI0hXy29a1cQRphQ6otEC4MROnLPD+dNqRQJO4PnBVydHuPG1BgpK0lXWwcjfQN0d3TR39NLwnKouS43blznypXLofTbDgsTu3t62LljFyNbNpHNZEmmUjiOQyqVQimF54UikCAIFpOnNORSGi7A+hJtiYXkGiAmaFrjtvQ5gVurkctmOPLQw3zr5W8yPnOLn37fJ3j96hluFKdQqRSBMQ0TRFh3tHdgO49tOUCpWiGXzSKEoFarRftgmuyTWLpPYul4CRt2Sr7x9a8hI1XbWzcuYyWcRccVKyxCD09Qw2fIsFs1tuSN6ctMVeZxbIerVy+ze88ePNddIQARYpUO6MsmR2MMnu8zNLKJ7q4e8sU8D/bt5vM3Xgm7TDup0AQhANTGJhjf9/DqABfth2GFaKXV848B33W5KyvKxrzbkr9ZrD+LvBNjBxI/8Bt+j2h5odXsb6M1TiKBW/OihaGuC9WCIKC7rZO/dd93UaiVyaRSpNIpKtVKNL5ub/wh4PSpk8zNzTA8NMKFCycJCDtTByICNiTEtFpE0oQqbYN0bK5MjXHq2nmG23u5efM601NTJJOp0EaqWWS5zvgDcF2X9vYOBoeGmJme5siug3zu1WEuzY5iRx2/eU+ZMIdtzCpejUK1TG+uE41eE38gHGtqnRRZ6D0qMcokLKUsFbpsq3UBLqSQWl+mGmMo16rRCXsXcsSRY3q8EhMiajAqNVKCDEAH4cpU2QnwDZXA4+bcJKMzE1hC0ZFtY7Cnj6STYPPgJtpyWXQQ4NgJ8vk8M7OznD51Cs/zaG/voLu7m0w2Q09PD319A3R0dNDb10dHZydKybCWKPBX5Fvi9i/LAUu0AnBi5eJj+WtczyWdSbN58xZOnznNUG8/33Pg/fzWS3+GcMySZp9CSHTg8SOHniRtJ5n3CuRyOWrV2qo1g+sCcGQ6XCwWeeP118imMyyUC0wUZhDJ0NjW2Apjy5CeVGJJ2YJRkkAbrESC6cI8J29d4onhw9yanWH05g16entXtEZa3lZmabu7pfChjSGdSbNl61befPMNNvUNsL9jKy/lz2J5CbAFQolQabcBjtL3fWq1Wt2vc63j08r5N8bg+t6dU5SmlesbEBIrum6klOggwK3Vwr5wdxiRxgueSrUS0v3xJCcEFbfKD+w+Qi6RoeJW6e7qwq2560aKax3fuNnU66+eIJ3KUPVcLt64inLsqC9idB6s5kBiBNi2zcJCnq+de52fefKHuDE2ytj4GNu3bQ/7IcrbH3/JZJJdO3cxPj5Gf6qP9++5nytfHQ0tvKS4i7T0O3fzfZ+aV6u3D1vvF0jLakmUEjb9ZcASQiRDa521CdyQooyKu0WrF4CmVKu8i8PmyEBWhksfIUOVvNAyGtAaoww6kOggakUShA4OYYGpYbqcZ/LiNBLJqcvnyaUypBMJBnr66enoor2tnY72DrTRBL7P3NwsExPjnD51CgEkUynSmQwdHZ30dPewactmdu3ajWVZOI5Tl/qH4buMIryNr4ZbeU3RKzLQP8D42BhTszN836EP8sJbr3BpYRwpHbQwCBTaq7C1bxvv33aIqueSSiSjBHh13X0Qy8oMaFitp1Ipzpw5TT6fZ6B/gK+ePYFHgHASkT9mWKSvYyCRYqk0X4XnxhUer05d5EOb7set1RifmKCzs4tarbZCVbkukMR3Bgr5PLt37+att87iVmt8dNODvPLmBfyaj3Si8oXAtBzFGcD1fKq1WujrusbxaVzdi3VAwXO9Oy/JWZFvWxnRxYbTCWWHXZulxA8Cam4tHK+rUe4tMQshDamkpFAs4DcYdvs6oDvdxcf2PYZAoKSFsmxqrtvUgKKV8YcxKGVxfewq169fJ5vLcm1ylJJbgYRFENGSgQqdTFZ0zIwCACMAR/HGlbeYfbRA0nEYHb1ZLzxv/I0bHX+lwGdoeJj2tnZm5+d44v7HeP7Vr5D3K6AshDD1xsXvBYYSIfCjdmAt5eAwSARSKPSadXOIkNZ1BiwhxGB0sMW6qauNHjchSDkJ3vUKn3iSjaiIuPEnMuw3JZRBByCC0L0hVnApLRBaYCfSCB1Gd+X8LBK4NjWOJSS2tOhs76C7o4vezm662zuRlqKruxslJY5tU65UGL15g5vXr/HaaycwxtDd08OevXvZtWsPnZ2dZLJZarXQVFlI2RKgiSaT43qTpZSSnu4eZufmyKTSPHXoA/zHL/wB0nEwEgQGPI/v3n2EkfY+xuen6O7ownPdVTn01VfQosGrOYwAzr31FlIKqr7LjZlxtBKIqKDb2CpscBkVzy5t2xMn5A1WOs3JqYtMlufoyLZx8+ZNhoeGsSwL3/irr6CbdOAWjcXtUQ5geHCI69evs7NnhANtm3m1ejV0uLAMqLjwW7SyvMJzXWrVal2QtNrxYRmdtdr5DwHGvbNLzqwjLIGo8atGKIuUcvCjcx/4AbVqjcaeJCvG6HqTebzw1BplWZSKRdCacq1CuVrFd13et/1+9g/uoFQtk81kCfyQGr3d8ae1JtvWxptvvkmtVqOnu4crY9fxTYBUTl0tKtTiomqFS5uEQBucZIpLE9e5dmuM/UNbmZgYZ2F+nnQ6G1pT3eb4M1pj2w7bt+3g1ddOMNw+wofve4xnv/o8CacNP1JVvqeaDbSoDK7TyJHCaN1IT0qCIChaUoqrUsqDQRCYtUBuSZ7OtIbQEoFVN1gW726gi/gBIyIFDhBEvmYySmgLFbtWG4QWmMguKIj+FpaFtE19lRsEhsAEjM7f4ubMBMYPe1SlEwnasjkyqQzdHZ1kUxm627uwEgmSiQQSQSFf4MvHj/PKt75FT28vAwMDPPrY+0mn09TiSEmKtSnKViK4JpNoti2HbdsUS0XuH9nFYK6XSTePJRO4tRo9HQP80MEPMV/OY1sWQgpqbm3VHqBLV82iae7Dtm1u3LjBjRvX6WhrZ2xuiluFOcha+ELjS42vNFqKcKWBWMkTCYOPRlmSmfwsb05d5mObH2Ts1iSTtybp6eldomwVTUBjrcVATKkMj2ziyrWriMDw4U0PcuLkJUTaIH0NQbjCR61BuETXg4k+z/XcRYBrcnw2QlHqIMCr1W7/WjMNzix6pbCExryTDshaKdqdsKGoZVkYoFKtLlmRr4zgVhd6NP6/1hrbcigVi/Vu9VWvRiaT47vvez921LlAcOfjDwHzs7NcuXQp7GKRn2NsZhIjJT4BHgIfQaDD4m583fS7jDZ4RmC0z4unX+bAph34XsDkrVsMDVpLBDC3Nf6CgN6+fpLJFNVKhQ8eeIjPn/gyZd9HChUyT/GBEO/u6dZEQKSk2pCiNrQnXPM1RikpAh1csoSQUkgZWt+sp6LcSL+0iDfOV8vv3hzcGjtviJo8mlChJGTUSVeLsLAyKrLEgAzC54QhBDodUp5Shc9Jwkgv7k1UCXyK89OY2Vvo65dIWDapRArbsujI5Ng2soWtI1tIZ9NIA7MzM1y/do2rV69y6NB97DtwYEVutNWLeb2Vcxja27S3tYUdFjJphtt6GB+dRiYc8H0+sOUQQ+19TOdnSUQehIEfAOtPMM3FBGF5wOjoTfL5BbKDQ9ycHkc6imwmi5dRBFmLIK3QSRtji0VZvlza3FMojVIG3a54eewsjw8fxLZsJicmQjfyBqpr43RuuMpOZzL09vQyv7DAga4t7G/bxKnyGE4yg/ajhVCLs4vve3iet2ZJSavPAwQ6wPW927/cltf0mcbnG6M5A4Ema6XoSGTwdICyLHzPx/PcVVmG1ibzSKSmNcqyKZVLYWNg3yNfLrBvZAeP7j5MvlLEUhaGkJa97fFnNMlkiqtXrjA+PkZfbx/nr1/G9X1yuTY8G5yEJLAl2pJhsTfNo3Shwzo9oxKcu3mJilcjnU5z8+YNujq7Vr1WW12Mxo4em0Y2cfHSBfr7B3hgx35eOPsKSTsbLr7Ve0RRaQy2skhYkWdsC2+ps0RrMSShcQnaoC2lpGtZagX/33RAWFYYJLYYVkohSNkJ3rO3+AKI4n6DQMT5OhPl64wI6czouRj0wjqxiMbQJhT8RRZDUimko0IwFECgKQU18KvMlwpcuzWG9fo3GezpZ7hvkM2DI/T19fH/b+9PoyS50vNM8Ln32ubu4bFnRO4rkAkgsRZ2FFAAiCqKVaJIDiVALVHizLRGUp/T0uj0LOqW5gfAH+qWTs+c6TM9pEixORqJlDSNpCiRRRaLVahKoFBVAKqQWBNAIhckkHtm7OG7md1754eZeVh4uHtErkABYefECY8Idw83s3vve7/3e7/3azVbHDz4fSqVCg8+/AhRlKrl+u2WV7mv3XI4Jq1HC+OQITXIhtIwRBqrDZ4K+Pq+h6i16giS3VcURpf1PzoBVogkYj1x/BiFoIgVggdu+xJfe+RJSoNlSuUyfjFApRECeRKh21un/bKajQbNVkwQBMzNzVKr15YlqC9nM7C0ATC4ns/k5CQXpy6ySU3w8ORtHDl+ChEahCuwOhHCrGXGGq2Jo46ayR7RWr/P1pm4t1cKbmv5fTq+rdEMBSU2FkaoVSo4ODTDJjqO+5errGXjlSqKF+Znmbo0heM4NMMW9bDJX33060mEaJPnXu34s9YSyYjz589hjMZg2bVtB3fecScD5WT8FYtFHNdJSwE6xmDX8Wfb5R++57FYWWR2bpZyudyVjl7z+MNijWFoeAilHNCGR2+7j58cf48w1ghXLm1SPus0pbV4jkPB89AmVcj2j8yWGWj3e57jKLBMO1KKBSmdJQFJX14T4tgQhuGaPr+SisB1c1f7xkZxUkikvEZ32XbmIPJfFmto17iR7kaEzna9S+AnrEC3o73kjYUUyOSGINP3ii2cmj7PibOfUP5wgO0bN/PI3Q+wedNmDh9+B2MMd919DzJVH11LgLPWIkmcWay2bBwYRVlJq9Hk8VvvY8/YFsIoSnJIcXTZ/6Nz8iqlqC5WOPXJJ5TLZTzXZWRklKGhQYYGhykPDiYWcZc5Y/WAplqrsbAwR61eZerSJSYmJol13O6k3bk6Cbovhu0FRliiRszQ8AiDA4NcmJ/i8S138Z0zr3OmvoD0i1g3obLXIjaJjSGMorQTcf/FrS8A5gOrSF/ZXOuWe+u06Eof29QW6KbBTYx5A8ybecqOQxSGaZ5JXHEk2t74SJHkKFtNfNfjXHWaydEJHrrtS0mUmu7oV2u5str4k1IyNzfHe+++S6GQMCnjwyMMDw8xODTM4NAQpWIJ1cEWrIVOq9frLCwsADAzNUWpWCKKou6F8GsYfwiIoohCscjw8DCzC3PcsesWbt60nXfOnsBxkv5qWojPOMAJsAbPcfGVm1DMa8irJddOrnK/sUoqoaWZcYQQizKx6loV861NWkg0Go014YGnHArK/3TYSSGSxp5ruHBXswNJq8ZBSGRhII3SEkBrR3tp3sLYzDdOtMEMKxAmB5ZpMauwIF0XP/Boxpojpz/i0sIs33j0q2yc3MSRD95HOYr9t9/Rn3ZbY5lAJw2AEFhtqNVruNLBQ6Kt5Cs778IRilYUJtx5bFdftETH7j+Xg8h2ZZemLrHvllsolQbwAx/fDwgCH5U2MW22WitzNx2R9orbo5N83EB5MO0QnfTRyzdhvZLNQJYznJiY4KOTH7FBjnP/+F5On3sFGVqMYxEqFSqtsmmM45goDnP2Zh3XJ3PJWANgJC+3RDq6/Cm3rJDbrvq3RMLvcO/4XqpRE2ET1/8ojFawO73GRL/FHAuO61CpJB2yR4dGmD4zyyO338tAoUStXkuocfTVjT8sUkjm5ufYtn0HhUIhGX9BQMEP8IKApeL5Xu8vel9TISiVSm0ZfK1Wa3fMuJrNqDWWyYlJ5mZnMEbz1bse4fDp4wht2wIY+zMQxRWdpPyq1qil3eBtX4BLCubFqhGcUgpl9BlHCjWllEJrswbMSBajKAxXvXLWWqQDZb94wyM3QdK+/t6b7uKWzbvRRl+/G21BCUmtVec/HzqIcGR7tytSIBMWUAZhRfq7BBSz9kEJoNn0Sy4BXtaxWEqUEzBdW+BPf/hd/sbXf5WJyY18fPIkW7dtp1AotCOvqykTyP8cxXHqpRniCknYarF/663cMr6Dheoinu+jUtDodu/XTBeli/zGTZvalkb512ePu9aJrXZ+AhzHxXU9BgaSHob5neLVLDCxjhkeGcE5pZhbmOPhyf28cO4t6q0Y6TlYnXRGZ5W6OJ1SlN1o07V+rmWbE2uJo6g9BtdcLrAWetLmc02GAVXgyU13Um820+hGtIFg1Xu0ysbLkozlqalL1Ov1pGRGKZ740iMYY3pa4V3J+AMYHh7m3vvvT8ZfB5Bf8fhL2QnHSUyCk/tjMLG5erbFJiVGhWKR+fl57ti5jx1jm/hk8SJSeiBtCv2fTYSzWFAOu8e2ELYS714p9KoZI6PNqu2ghMA4jitjHX3oKCXOOY5DrLVdCwUkBERRvKbw3BWKQa8IVt9QnYkQYOOY27fs4Z/+0v+BWMfX7UZbDK5yma0u8OMP32ZqYQbhJK2BjMwvCLINZpnlgLBpDi6lLmlHcSBsCogmATpjLMrxuVRb4Mfvvs5f+7lfJI5j5ufmKBQK7ajkWnRskFISthLT6DiKkgXMSu7ZeBOuVNSbDQrFYruhaOf/7Pdzr79Za5Pc0Rpcxa/dOLmMBaZLxCGlZGh4iIsXLjIxPsED4/v4zsxbBEEZ4xmETuulOoQqFovWBmN0u/eY7VhQ13K+3XIWJo4xaVSsM8p8dVTsXhZgctFb9tgk1L+JGjw2eQ/EhmbaxTuOoq650W7rihCrMAskJR9zc7MolTRO3r55K7u37KRSqyCEaHcN+KKOP6WScqPjx44xVB7ka/d8md/+9r+n4PuE7ZIB+5msi8uK+IeDAVphiyiK19yJXiln1VXZdR3iljrlKOl84rkeYRjZtV6HKFo9B6etwUUy4AZI5d7QVjk2uQq8feoY5+an2gatPWmLfm8kcjeky6Y2M6EOXJev3/EI/+aF51GlcmJtJdojMylMtiltleUYUqWxlalhfy6nh5FJHs8YsAKjwWig4PLx9HlaOqJYLNBo1PF9v514Xctk7vdzNvDCMKTRaDBYKFGpVhj2iuyf2MVcZYHywACFQgHPTQGO5XLyzqjhaj/TjXivy13Asrq9ocERzp+/QKvR4P7xvfxo6j2iUCeF345N3LzVSuoqTqlS13HxgyApmr4G10NKiZPWJJrUv/GaRW42Bbe4xUSwgV/f8WTipRlHDPgDiVBgrfNc0DOnmpUiCak5l7accR2HW/beRrPZRMea8kA5cQXpHG9fkPGHTaLKYrFEUCgwOz/H3o072DIyyYXmArLgLe1VPqM0pRWSrYPjNJqNJC++BgBaTWCCxTiu69TrjZOOtccclP0giqNQKulYa9fwTywmNsvyPr0WgKZtUvYKlMtjLNQWEErdEKCz1oJUfHLpLNMLs2woj+L5HuWBctedssWumNTZ7jj/N5tvbJnzC5xfWCCOYn7hjkf49hsvM704m+aO7DJA6/DiwWZyYysSOiGjKZFgkr2+sIlrihUGZKLM1E7STblQcHFcD9/z24a3/c6r58+5hSHz/5uKIprNOq0o4tLcFLuHN2FMIjAqFQfwXQ/X99qbh/x79Z3Idm2frVeEcrXnd60WK2MNWBgcGmRkeITp6Sl2j29kf3k7P6l/hF8oI2OLUTahKjtpxDhGxxrHcfA9bwmIruL6ZLmHMHVG0Vonn7MvkPWI3jqFJSYRHmE1ygr+4c6vs9kd4UJlmlKhSBAEywr9+wHramuAMQalFNPT00xPTVEslhCuw5bJLdTqNQZKJQqFwrJz+yKOP2sshUKBsbFxPvn4JJs3buKOHbdw/vCPkV7ijSmk+MwVaAkE1mjGysNsKY+nDjRm1c+pHAdH9m+tY601fuBLrc37uO5Zx3pqKgr1tOu4m2OtjVje/avHm0SEq0hzLRarLb5wGA0GWKjOIlA37GILBAu1RU5cOM1oUKYahWzetHlJz9llcLX593SyL+Pic4/z0Y7jOFQrFS5cusiGwRF+5Z4n+J2/+PdJAbRgbQaoebcC0iJGmdKWpLk4mRhmah0RDBTZtnEzF6cuUSoU8HyvXfTddVfYZyImejjRnszGaApBgXqtTthssVCr0Gw0uHlsO1GrhTM0xEC5jO/7eEGi2OpcDLotvD0XiB6fibZ+p/d7Xe75JVG4uGaLlU3tnbZs3cqlSxcJG00eGN3LO6c+QTcjhOOCKxIKUC5X7mWd1h3HIfCDNiBczfXJAM71PKyxxFq378+qYZrtUdRNyiogMSYCrfk7W/4S9w/s4WJllpJfYmR4pO9ivubFO/2mjSYIAo59eIQ4TtIht+27tW0BNjw8guu6KwHuCzb+svfYsWMH58+eZWFhkYduvpNXj71FNY6SJtN8BsUmSY0Ju0Y2Ia1InHfWcDiuh+xTFG7TBIDreEgVHn/mmWdCxzTMlOe6nziOs1nHsWUNfeHA5lzjex8tLIFMAO6k1gjnxiXipJCYsMlPjr7DQ7tuZ2Z+hlq9zsTERFum2w3g1vK7/GMhBJs2b+HipYtMz87wwO7bOXrHIxx8/yc4xQLGXoErYOaqkt02lTisCCvRJuSefXfgyMR0dOu27Xiuh5Py0l3PYZUJmF8gEYlbwtmzp3Edj+mFWVQsGC4O0EwdzUulhBZZRq2tshno9/hKrvsVnV+Pha/XQtf+WdB278hMeTG0/RI3Tm5keHiEqZkZbh/byVZ3lI9bc4jAQcQ29c1celNrLVEUE0cGz/MoFottRuRqrk8GcM3UnFjHCcBJIdMeEKLdDFUgcp26lzoDkG+gaVN/RauxccTmYJJfHb2fp0Zupxo20FHMyOaRJBdrbNfr0xUU+lxrayxFr8jFCxc4feoUUii8YkDgBzTrDSYmJxkaHl7OIK1hM/q5HX/W4joukxs38tFHH7FxfJL9m3fz6qn3E8/cvJ3dZ+SQCHQcsX9sJzYyNOPVsCRhFsvlgVWpOymlU1lcDIW1fwHg/Nqv/drcgQPPHy8UgoejKDSsovsSQuC6LlEU9uxUmw+jA0+xeWCMQ1Ld0DxcJrD+6fF3OXXPeRwrOHP2NFu3bkl2fzk65XIGc7eJUCqV2L//Dl5+6SVKAwP8X/7y/w6B4Pvv/gBZHkIhMFw50GUJ+bhe45E7HuavPfyXaLQa+K7Pxk2bllGTq01W+kSpxlo81+XEieOcPnWK4ZERLl08z4DjI2yS1N8wMUGhWKRQKuGnIpPLoVuuywKzxvPrtfBdyefLP5ZKctttt/H9771As9nkgaGbOXnpRzgFH+uaxHnFyHYUZ61FxxHa6KR1UrHYbi9ztQDnOE4CcNag087g2mqE1WgrMRYMEmt1bltvUmAzHcISAVYyKsvcM7SD/2LiEbb7Y1yqzzNQLLF159Zlhctr+qz9FnORAJzruHzw/ntUq1WGh0eY2DCBEEmvuY0bN1JMr9eV0H2fu/GXduHYvXsPH3/8MY1mjUf23cNPP34foZNbKCQrejR+asGbEBijGSgNsXlghCgOieNoVdl/oVDAdV36p9GEdV1XhGE0Z+EdACdJ3KlPpFRIqcRaOnt7nsBx3K69vzpzDQ1CJovDOF5AbK6fmnHl/wbXCzh94Swvvfsa37jrKxz54AN2bNvB3n37aDabbYBebYKuZdLs3LmThfk5Dh06RLPZ4L966hm2jU1y4I3vUa9VwPORrru0UV613UO73BUTh2AM+7bezN/5yv8G3/FYmJ/n4YceplwuL5vsq07Ars9J6cmUjvng/ffTNhYh5y+eY+fwZlpxxPj4OCMjwwS+TzE34K52gbma637VC4wQSfSRRRv5SMQk2+SlIuxej2HT5i2Mj29gcX6e28rb2DQzzMVWHeH7ScdvybKMf6w1Rmtcz6VQKLRZhau9Vo7j4AcFMBajY8BSdAMcJ8B1XIxSGBSaLFmfjDNXSMqyAAY8oRiXA2xWw+wPtrAnmKAgPWxkOF2/wMaJjezavZtSsZgIS0z/67OWBTxZ+Aye73HuzFneefstfD9AeQ4jo2O0Gg02b9nC5s2babVay8beF338WWspThbZuXMnxz78kC1jk9y+ZQ9vnD2GVyq2G6/zGRCcCARGR9y86WY2+IPUWo1VPpJAa834+AaUclZdN5VyrKPMd3/lV3/1nLVWOgCO43y7Uqn8N67rllYzXc6KXF3XYWFhfsVA6+Sm61ozWRgicDyqrRAhnKtv5bEWoUn6P5Tj8J03fsg9228BAx9++CH7brmFIAguKwHeb6Bn0eC9993P2Ng4r776CtMz0/zSPU9w88btfP/oId678DEX5y4kbvhSpbt5wXJPnaXCcWtNMoAtbB/fwlP7HuDRPXdR9gLmF+e4/7772bFzZ2JI67pXCXBJTmh4ZIT//B//kJd/8CJbt2zj1MVzuFoiHUGhELBz1y4KxQLlwTKlYjGxzrpCgOtV73bVC8xlvtdaQGW1v2eR7y1pFLepNMjd5Z382cJbBIGHcS1CGdooZxPw0VrjuUnzW8dxrh3A+T5CJG1l9o7vYO+WPRQHB3CLQbtsIekMkYCbQlJQHjucsbQ206Yd7y3amMRfUkaMjo2xe+wmtm3fnvR+M2sHsL6fPRsLIlnMvvMX3yYKIwqFIqXBMuVCiUarwc5dO9ekGP4ijj/f87j11tv48MMPEcbypZ238d6Z42AMMumhk7aY+XQRLhMA7ipPoCzUw1ZSQ9nn+Y6j2g2i+4mXjDFCKSVwnG8KIeyzzz4rHADXdV/XQpz3PO+mMAz7XoVsEpVKA0xNTRFFUd8Tiokpq4Ddgxt599LxG3Z9rUhuqOO5nJ67wBvH3+X+3Xdw+PC77Ny1kzvvvKvta5YfNPIyDKW7HXv37WPjpk384KWDfHLqFLtGNvNfP7GbS5VZTkyd5e1zxzk+fZap2jyRjrECtDFIsdQZIHA9NpZH2T48yU0btnDftlsYLQxSbzVoNOrcd9/93LZ/f2KldQ0moDGGUqnExfPn+P4LLxAUCrTiiFPnT7OlPAFINm/azPj4BoKgQLFYTBaaNapiu30m1acz/LVcYExXh45kiGfFwtdi9y+lZP/+23n7rbdYWJxnf3kHr1WOM9cKkX6QdPs2ieTAktxzYw2u5+F5HiptAXS1AOe6Lp7n0ag3kI5iZGiYAb9M2Ruk4AQrOgK0X2sss/FiouRN+w46ymFgIOlVuH3HDkZHR/F9n2azecX0fj+wKZZKfOfb3+a9w+8yNjbOYqvGfTt2UW/WGR/fwNat25BS4vt+383oWsZT1hrq0xh/7WYNqbPOWjfS/R5bY7h57z527tzJR8ePs3N8E5uGJzhdnUYpf0lR+SniWyKC0wwGZXaXJ6k2G4lGoQdoCSGIooiR0U3tWt8+98z6vi+01ueV570M8Nxzz1nHWiuFEK1vfetb35NK7lGOWm20IKRgcGgQpRSNRqMvKFgsQlr2DE7yzqXj3DDRamoYYgDX9fjT11/ilsmdGB3z//v3/47B8hA7d+0kiqJli+2aexP1CHK11gwODvLUV3+eo0eP8sH773Ph0iWKQcD9W2/l3m23EBtNbBIBgKMU5xdnKHkBA34hcQMXImnNLhQKaLSaNOKQicmN3H///QyPjGCtbRe6rhaBrjZpsoXx3/3bf8ulqYts37aDI2dOYMKYgu/hug67du/C8zw8x02UTJdxrfLjI9u1vnHodV7/yU8olIqYzEXnMjVISzmczvPrPXYh8ziM2X3THh77yuNXvRvPNgmTGzdy++138ML3vsPW0mZu9id5rfUxMjIIV2Ldpc8bxzopzk/PYdX6njUu5EIIhoeHePDhh4l1okb0PA8v8PEcdxl7IhCJ+lZIPNfDDxKxUlAoUCqWGB0dxU2b7iZuR8lnLqSuHNcK4LI588f/+T/xu//qX7J54yYuzU8zvmUTA8UB6rUae/fubUeNl3ud8uMv29SeOH6MF777XYrF4uq1gtd4/EGiFB0b38Av/tIvJxH9GuogVxt/fuDzwIMPcuzoUTzhcPf2vZw5PAXGfEbKBRKH+jtGdzLilmhGrb7+sploanR0FMdx2vnGHuub9QNftFrN3//6179+PlmihXWyDYWU8k+VUn9fa73qALLWMjAwQLFUYmFhYdUW4kbEbA1GKHlFanHzxoTJItmtGGFxXMV8vcof/+T7/OI9j1Ov1/nXv/e7/KP/5v/EyOhoYhOTToK1Tp5e55s22sP3fe666y727NnDmdOn+eijj1hcXKBarSYRjEx27NrETBaGEpOISLd3fbFNqMfC4BA7btrNTXtuYnRsrCc11C8C7XVO1tqk2Nh1+Ys//xYvv/wyW7Zs5tL8DB+d+YS9EzuwQjAxOcnIyCiu66Jcp00prHVhyO/2lVLUajV+73d/l7fefINisdj2hezsb2d7bFxYLZ1gV51mtJpNbrn1Vp766leXvVNf55A+9LW1SffpR778ZV597RXmKgs8OLiXty+cImppcCXCk0luzCbehkmpgFlGc1+LY2CgzN/8W3/7mlNLUspldPiV0PtdF2bf54MP3uff/8HvUy6VibTmxKXTPPLoY0RhyNDwMJs2b06L1y//OnUqprXWfPNP/oQ/+Df/X0bHx5Kmxlm/y/xmbPU99BWNP0gMkweHBnn0scfYsGGiK115udfXWssdd9zJ5s1buHjhPLdvuYkfH3+bubiJkJJ2K09548M4kW4IPCdgb3kj9WYDbU3fexbHMZOTk4yOjKCNSUCu+/kbx3FkGEZzSrm/D/D888/LZ555RmevsEqpl7XWJ1zX3bOWPJyUkuHhYc6cOtUzxGzvVoCS9Lh5cBNvTR1FOv7y0P16R3FCoDyXn544zIAb8Ngt93Lyk5P89m//Fv/gH/4jgiBA6xgh5BVNmp7nne52b7n1Vnbv2UOz2SSKIs6fO0ej2aRerxFHceKVicB1HDzfp1QqUggKjI6NUSqVKBaL7fdbrcB+raCTLS6u6/JHf3iA3/6Xv8WmjZuoNOq8cuRNhoMBysUSrueyc+dOBoeG8by0HCHNlVzutcoA7vy5c3x04gSbNm1K2bLk9zLr1H2Z0fTlHo5ywFimp6d5//B7y/rrrfWe99pJDg0Ncd+X7uO73/0LJjdsZI87wXvNiyhfYXSuGW4cp4XY9pqfq81FBB17Puhl6tPlfC6Xrl/t+nSbH67rcuL4cf7Hf/4/0Gw2GRsZ4yfH32bPTTexY9M2pmamuOOuOwmCgFardUUphPz48zyPc2fP8dprr7Jl21YcJ6mnU0ohpUIq2b327DIDldUiSiUljUaD1159lV/8K7/UjiyvdvwBPPTww/zB7/9bNhY3ctfWvbxw7HVcp5DkXT8lE2YhBDaO2D+6i03+EGEcpgXCtmeAgrVs3bYtSYX036jbQqFgra3/cGRk9ENrrRIiMbZ00l2DEEIsvPDCd75VLpf/4cLCgpZSOqtNoo0bN3Ls6FHqtVrfm2OswVEeu4obeFd+hLlBsbJN6SgjLVKBU/B46f3X2TQ0zu6t2/nwgw/47d/6Tf7xf/dPElf3XCR3rY44jonCEKkUxWKxvTFYa+NDm/aVWuuisZbnZHlUIQR/9s1v8ge//28ZHh5GKsXbRz+gFbfYMrILBGwY28COHbsIfB8/8LuKIS5r4bWWg99/Ic3DOXxw5jgztQWUo5Lxnq3CfTz5+v6u798Tpd7GwXHu3LKPMIp45ZUfc9vttxOGYd+8YLf70m0BFULwyJe/zIsvHqTZbHBHYRsfVs4jIpN0XtC2HUVonVhp2WsYwfWXW699jFwt6PYb3xkAO47D6U8+4b/7x/9XKpVFhoeGOXL2BLONCr90061UK1UGB4fYtWt3Wyl8NZ8py7e++cYhpqemGBke5uPzpzk7dX6p1+B17oRtrWWgUOKuvbfhOC5vvfkGv/D1r7fH5rUYf7ffcTsbN26kslDh1k27+MnH79HQOumoIfNZwBtzSBIDiaI/wJeGdxLFEbHVfenJOI7ZvGULExMTbWebXtSklFI2m02hlPMv7rvvvujZZ59tL+IOYA8cOKAA7XnOH8dx/Pc8z3OtXR3nS6USGzZs4P1Ll/B9v+cktVhCQrY4g0wWxjhXn0JKF3O9WeFUaCKlQEsQjkQVPP7TT17gF+78Mrs2beHY8aP88//+n/F3//5/xdjYGM1ms31Br9WuWqRCls7anctd0Nbyefq9ZzaBgiBgdmaG3/6t3+R733uB0dFRNJYfH/4pl+rzbB3dSLkwgOO67L5pD6OjowSFAp7no5RzVabO1hgO/fR1fN+jGtaZqs1hlSCWGqsEVqYLjFgDLyTy7iC2C8B19lVLOrSfCWfYGdcZLBY5evQoc3NzDAwMsBZ6frVrboxhaHiYW/ffxhs/PcT2sXG2izE+aszhBg5RmoeIorhdp2avkHq70g3OWv/PtaJM8+1ptNZth/3jx4/xf/8X/5y52VkmNkxwfn6KDy9+wr7dN7Fz4zYqtQp37/0Sw8PD1Ov1vi4WlzOHXnvtFQLfI4wizs1cQmPRJsakaY3ruiwJQb06x3ytwu5N2zmdpi/27k1Kl1bbZK12n+I4plgsce999/FHf/Qf2bZ5K7dt3MUrp94jcEoYY9PzvHEgZ9No7O7yNgatT7VRQ4r+ykkL7N69G8/zVhhzdD69UCjIer3xR08++eSP0mDN5AGOp59+2lhrxSuvvPLjMGy9ViqVvtJsNjV9ir6zKOCmm2/mo48+olGvp3ZSvUsGfOFyS2GSc83ZG1Iq0L5/MpFFG2uRjqQVxbzwzis8sOt29kxu441Dh/i//ZP/lr/1t36dhx55BBA0m40rGmxXAljiGhZg9hKZGGMICgWkELz15pv8z//T/5NPPvmYDeMbaIQt3jn5AZWojhcEbBnagOM4jIyMsu+WW5PC7rQRpHLkFS0yxhgKhQKvvfoKFy9epFQscWzqFFqB8BTGFQnAOQKb65rcNypb9nfRNWLrjO6kFTSiFlO6wo7RzVy8eIGjRz/kwQcfWlUwtVaAC4KA++9/gLfefBMVWvZ5m/ikNQuhAZmYU8dxjIl1H0XCtbv/VxqZXWuA06noJQxDXvjud/hf/tXvsFhZZHxsjAuL03x48STSU9x7690YndDWN998M61WK/3c5qqui+u6fHzyI4588AGBX2C6Mk9kY3AkJt1YZd/tdVr8pRDENuZCZZZ9O25iemaGY0ePsnfvvive5HSOP601d919Ny+99CKVSoW9G7bzzrnjhHGMkOqG05TWaEa8MrcXNlNt1Velb6MoYu8tt7B561Zsn9zbEn6KuufxbG5VsMsATghhrbXqkUceafzwhy/9B2PMV1J1Zd+LGkcRGzduZHJignfefptSqYTuJfkEQkK2ijIjTom5qJq4E9wAlDMi6U1nEMTG4PoerTDmlWNvE8cR+7fvZXpmin/xz/97fvEXf4lf+dVfZXLjRhqNRpprsl0aZIo1/e8bfXSa3WZtRaSUnD1zlj888L/yx//5j/C9gMHBIWYqcxw/9wlV3QTfYbhUZqg0iHAc9t9+O+NjYwSFANdzyRS2S++91sVFtCfeD1/+Aa2wRWmgxFyzQuwIpC8xnsQ6IvmedU7uBmCiC8B1Xu5cF4dOsBPWYiKPs2aOO1Xi3HH86FHuvffeZTTP1dBxrVaLW265ld07d3HixHH2DW3iUOskU60Q4QLCEMdRYpibClSuGVtwnTdLV/MeQRBw/Pgxfvs3f5PXXnuFocEhxkbGODt/iWNTpwitZtOmTezatJNqrcYtt+xlfHycOI6gi8/q2k9VtPPhr7/+OtVqlaGhYaYWZ9AkTjRGglE5gBPXazUCIT3OVWdo6JCRoSHefedtHvvK4ysMq690/IVhi40bN7H/tv28/PLLbB4dY8vgOB8tXkQ4CuSNQ7ek75/goeJO4jAksqY3OZNG+EEQcPfddyelFH3mo7U2HBsb82Zmpn//K1958vDzzz+v6CiAcXJvrgHm5yv/6+Cg/d+7rnd/HMeGfubLQmC0Yc9Ne3j//fcJwzCRo/aZGArJvcEWfqxP0rAx192dMnMIQCSD14HYWpSr0Fbzk4/eY75S4a5d+9jguvz5t7/FT19/jS996V5+5Vf/KhOTk4lxbRzRarbasmql5Kqb77WO07UN6LXl1rKvIAja0vNDr/+U73z72xw+/C7nzp1lZHgUCxw79zHT1bkkigoctICtw5MUCwUGBge5ee9eigMDidel4yCExBh7RXfM81zOnz/Hhx8eoVQoMVtfZDFuIAsuuqAwgcJ4AuMpjCOWB2VCLAc40RnBiZWkfy8q04DSHmfrNaq02DA2ztvvvM1TX/saY2Pjq9Eha7p/2fV/6JEvc+TDDxmKBbc6G5lunUw6RUhDFEftHFzS1mY1elTccIC7mvfKFI++7+O4LkZr/uybf8Jv/r//Z+r1OpMbJqg067xz6kPmmhXwJKGJuefmOygol2oUsu/W29JF7+roW5EOpsriIm8ceh2AVhSy0KiBI9EKtCMwKvmyQlxXgJMWFpotzi1Oc8fmmzj58UlmZ2bYtn1b27Ltau6TEEkU9NRXv8arr7xCHMfcufkmPp6/mHSFMMn5WXl9cU4iMCbk1uIWJmWJZhz2JGNsG5xD7rv/PoaGhvrORWut8X3fq1arH0eR/h+sTchlIYTtCnDpi4QQYu7ll1/+0yAIHqhWq2a1C9tqtdi95yZ27NrJkfffx/f9vgAXA2M2oCwD6noeiXsD6MqUc1Yp0KXxuUAhgA8unaQZtdi1YTNjo6MszC/yzT/5Ez744AOefOop9u7dx9DQMNu2JQOw2WwSx3ppjyL6T6y1TcBV4avje3bPln7nui5BkNQoXbxwnp/85DVee/VVXvnRj9BxTCGtbbo4N825uSnqcTPZ0bmKljSMDQyxZWQSoSR79uxh8+YtSX2U7+M47lWJS5Ry+fDIEc6eOcvY6Bgnpy7Qkhrlu+hAoosKU3DakdxKAEt3nUJ0B7h89NYpg845+QtrsZFFey5H9SW2lMaYmp3mww+P8PDDj6Q0mLhsYOk8ms0md951F5OTk8xOz3BbaQtv1E6zKCKsY4nCDOA0Om1o228cdMzbqwTCa7Gq2dz4W36vhRDtDdbs7Cxvv/UWf/HtP+fVV36E7/qMjIxwqTLLmflLLIZ1HN+jITWT4xvZu3kXi9VFduzaxeZNmwjD8KojSa0TI4MjH3zAsWNHGRwoc7EyQz1qInwHrZIWVNqVCcBdx4JokfZ8BJcPp09z945bkVLxxqFDbNm65ZqNvyiKGBsf49bb9vPWm2+wbXiSjaURzrXmEcpJm6FeP5Yp2UtqhlWZfXKcVhSiexG/1iLTNk/7br2F++5/YFWgT6O9ehhG//ipp5765Nlnn5W/8Ru/sQKvOsjN50S6+/qDZrP5D5VSY3Ec9y0ZEFIQa80TTzzJxydOrKnw20GyX44zr2uEmLSdxPWO4kTaZVskdlkYNMk2xhEeH8+dZ6Yyx4aBYXZPbGNoeIjzZ8/xr/7lv6RQCJjcuJG77/kSO3fuZv/+/WzesiXtAJyclTGZvdZSFJX/3ZXujLMFQ4ikjiVzYMiis+xnYwxnz5zh/fff48Tx47zz9lscP3YMKSWlgQGsNTSiFh+fPst0dR7pKPAcjJtMbhzFztHNlApF3ILPnXfeSbFUxHVcHNdBStElB7L282g06hz66etgLZGJmWkuIj03ATRfYQoqieR8mXRPyMQmdjlArQCzFeDWjbJcAkVhwUYWIeFo7RL36V14jsu7b7/Dgw8+vDxasGSr0SobFNnlviW5uK88/gT/5l//f9hYmGSv3MBPWh8jMURpHVzS0uZGi0wu772W6qzSGWxte9xlbIZI+xE6jiKKY9544xDvvv02r736Kh988B5SSIaHRwjjkCPnP2K6tgCuQhY8Yk8Sotm7bRcj/gAz1QVu3nszvu+l4pJeed+1q0GttRx+9x3mZmaZ3LiRSwtzGJmqrJVAOxLtSIxzIwDOIlCcr80xXZ2j4Pm88cbrfOWJJ9KSJd1u+npl42+pldf9Dz7A64d+imMF+yd3cfb46yjXTUyYRdqA+RqbMGc1b0Xhcb+zCTe2NGn2bXAb1mqMT2zgqa9+DSllX4Cz1pqBgQFZrdYOPvHEEwc6hSU9AU6I3zAHDx50Hn/88ZMvvvj9/2lsbPyfzc/PR4Dbd4cUxwwNDXHPl+7lhe9+h2Kp1FfyGqEZJWCXHOWImb6RCSoQSQNKk4hXsUJihcERHrUwpDpzjqnFOcZKg2wemWBkdBQTa86eOcuR9z+gWBpgaHiQwcFBdmzfyS233cbg4CC7du2iWCzhuE5SEK0cXNdBKgcv7V5gc+ar3SZsXm2WB684jgmjCKM1cRzTqNcJo4gzp09z/vw5jh45wocfHmFxcYG5uXnqtSrl8iCDQ0MYY5hemGW6Mk89bBBZg/JdjCLZsbqS2IWBoMie0S0gBXt27mL37j04SuH5flI3ZnvM1jUcrusyOzPL22+9QbGU0JMLYQ3KPrEniX2FDpyEpvQl1pHLASwfiUlW/m0ZbSlW5umy52VWkKFBCljUIafiGfY4oxw7dozz588zOTm5NLnE5YF4Z95Ra8vtt9/Bpi2bqc1XuCmY4L3GGbSIaImQOIqStjlpTVxmXH4Vl/raL1ZCtEtDHEclTSdTT8CkrjNkcbFBs9nkvcOHefedtzl29CgXL55nbmaOICgwPDRMbAzn56Y4V5miaSJk4GIcgfYkkSMoFcrcMrGL2coCGyY2cOsttyZ2Y0L2ZsTXPP4cqtUKr7zyY4rFIvVWk9nKPFI5aJmBm8A4YByRSOmvl/O+Tfo8OkhaOuK9Cyf5ys47mZ6Z4fixY9zzpXtptZorc89XkJeJooi9+/ax9+a9HD96lB0jm5goDXEprCB9L2m4fJ3ScUJY7hKTDBmPJlHfkgAALwj4S1//y5RKA33rHY0x1nUd0Ww2PzTG/BNrl2zMVwU4gCeeeEJba+Wbb775u3Nzc3/T9/39rVbLiFWqoGOtuf+BBzhy5AM+PnmyXTbQG+Ra7KDIgixxSTbQ4sYUx7V3Zkpg0r2GsJIIgyMclKOohxHN+WkuzE0xNjDCUGGAkfIwGyYnEFZQr9SYnZ7h449O8uLB7xPHMUGhQLlcThz3x8YYLJeTIu1SicnJyaQRpeOiHCctKl2KwmSqPjXWYowmjjVxHBFGEVYbpqanmZ2ZptFosrgwz9T0FKdOfkKz1UwKU9OWOoHnUyqW8AsBi7UK5y5MsVCvEJoYKwXClQjlEqt0IrsS6ylaSnP/2A4G/BJaGO68+26ks1TQ3avbglwxaO2KyZKl7A799CfMzMwwOjrKpflZcFIq0hFYVybf85EbHTSk7IzKujyWrAS8TGwi2xwl1hEIR6BdON6YYq/cwEK1yruH32VycjI3wa589gsBzWaDickJbr/9Dr75J3/Mti1b2cIwC80GkQ2JTIjrqHZHCClF2+H/SllFcY1XK20MszMzaK2pVirMzM7QbDSZunSRo0ePsrCwwCcffcT5C+dBCoRNfEYLQYGxDRtoRi3OLlzi/MI0odUIRyICN6EEPYl1JS1luGViOxsKQ9SbDfbt3Uesdbv+sxclv5bxlwCcx+lTpzl25AjFUomLCzOEOgLHxUib1l+Sy71dTwFGuomRAi0sZxeniI0mbIW8d/hd7rrnbsJWEyGvXsFtjKFcLnPnXXfz3nuHGXGG2Tm8ialzC0jPYmxagH0NzyyjJu+Ixhm3LgvUutynpUMpxfz8PH/9b/xN9uzZ047Ye52SUkoYY4Ux5u8/8cQT76ZF3eayyPiMz3zppZe+5DjqkLXWpEjZlwbwPI9LFy/y27/1m+3C2b7WM+kO8S01zSVZQ6Kuf21cLnEgddotW1uUtkhtkXHyXaWPiTQm1gSuz4AXUAwKlPwC5eIAjkx2soHnJ7LvNMLKWqHEUYS2Bq0Nnuumbh0SRymEWAK4rGo/k/PHcdz+iqJk9+O4DlJIHDehDH3XBSFoRiFKSlpRSCNsUWvVqTbq1KMmCIFwJCiJlcnONAE2gXXS6M0B1/d5ZvODDAUDxMawefMmdKyJdVKkHoYRYdhKIo1YtzspizWMKGvBcRzmZmepVKo4nstPLxyh5sWYAZeo7BKXXXTRwQTJgrcEVGI5xSjXkHfrlpvrzNvFFhUabC1kuKr4ZX0bflPiFFzGhkZoNBuEYdg+31Xl6Z1JfgTKUSilKBZLzM/NMre4wFh5hI/MNG/XP+Eb3u3EaG7ZdytDw0PEUXbPoxX1kpc1JcS1mR5JMXpMo95gdm62DXBzc3PUazWiMEyiOcfBcz1cz0MbgzaayGpqYYOFRoVa1KBpYpTngJIYVyRjMB1/2pPEyvK39jzJ9tIGWlHI+Ph4YnDQahGGIWHYIgqj9j0xJk7UdWvcCEihqFYrXLp0ifLAAG+dPMJ0q4L1FJEniV2J8QTaTejK6943zVqkARkZnMjyi3seZGMhiXInJjfQSh2PwjRPa42+zPGXAIdKO0vEsWZ6ehrf9zBS8Ifvv0RdavAUWnJNzjlr7WXR3GUm2BoX0/RT7xc4ymFhYYF777uP/+Jv/tpa3JF0sVhUtVr9/3HhwoX/9umnn7b9wK3vdEjLBMzBgwf/2dDQ4D+t1Wp96+KyHUOxWOTQ66/zp9/8k8Qhvc/8tICL5JKt8Up8hlgYblxxRsKFY0Fai0iBTRqLjElBziC0QBmL1QarDWiLEuBKB4HAUy4DhSKBmxgRu8pFCCgWignXLlLJu7HpwmHa3/vuwkWSH8jCTisS/8JWFGIttKIm9VaTWrNBbHTa2kRjRGqx5KgklyBtkjhPFWLGkVhFkvvyHFoy5uGRvTw+dltKWVjqjQZh2KLVatFqNmm1WjSbzZQmjfvbrHX5k1SCQqHEyOAwpyuXeGf+JLboEpccorKDHnAxRZV8JleuVEfKVYQlsgtduQwYO/5mLDI0OE1DXGnyc41d3KU3MVdboFarEUYRrVYGclGqHF2LAGjpDmbFzJ7nMVAqUxoo4ToerufyWvUYt+lJUCJdyFpEUUwYJtc5WhG52H77tLXfiMvEyywv6LleOw/seS5CJffIWIu2BmEFs40F5psVWnGIFhZtNUZIpCMTpaIkKQNxZApuAjxFXUbcObyLv7rxwYQxsJp6vUaz1SJstWi2mjRbTVrNZDxGUYjR+rK3wb4fMDQ0TKVZ49BH7xEqk2zwUoDTnkwoSimv/xJkk421YyCqN7lnbDdPbL+LWr1GpbJIGIa0wuT8oyjqWXpFR8PYPOApJVGOS+B5BIUiAwMDeL5POSjx4idv8fbsSaTvJQpSJa7Kn1KkwObicIeaYAeDGLFKDGuh1Wry+JNP8uhjj6GU0y/vZoUQulAoOI1G418/+uhj/+WycLjP0a+Czv7O7/yOWy6X/1mlUr2zWCz8YrPZjPu9Rqb+anfdfTeVSoXXXn0VL400eveMg52UcLTPT5unqMZNhFDXX1kp8rrEhCrTwmCNwEqD0QIbS4SyGC0QSiKtRJpkgWwZizCWlm5SXWwkZ2KStIBM3dddmezilZCJz50QSVscsWTsLDquRQaAWY2UTjsPaKOJYo22Ork2WRgvSR4LEK6TWpPlgE2mgObIBOSc5dFboIr4yuNI9WwCXLEFrdFhhIli4igpSI5NhEFjpF1mHNIpIOq2dZJSUombRNVZztamk7IEV2JdAekCaJVYvn0SXereuu1YO2vkughLVrw+3bUaR4CrONacwovAEmOcGKMjtKPRNlnwrkg5KsFIi1GaVrTIXKWO8h1U7DIki1yqzyOVTEy3veSeKeniOwIZO1e9gPbcytq1rd8WmzT3NgZtDbHR1KI6NCyx1YRxRCMOk7GJSa63FOAlLaSFVAkNLARGkY69BNysk+R/cRRWJBZSHyyeoalDRGwh1ugwxoQxOozQUYSOkzmg0ViZRm+2z/jrOPVG1CJenOXCwjQRGqTCpA5HViapCyvEjdlfp+PSYFGuw+nKFIcvnsC1ApMyRrFO5psWYNXlxicWKwzGxtjY0mpoFsM6ylG4nkegXGS6VgmT3DYjriy2kKkq3ZMOdwZbuNXdQNxn7c4a20opuff++3ni554ijqI1iEpKTrVa/c9xbP6PaUmAWC16W5XQePrpp9WBAwf0t7/97dFyeeAtz/O2NRqNVfNxWV7pBy+9xJEPPsBx3RS1e7ucFKTLyeYM3519j9DGSKFujCFzO/GbTH5p0qhOp9SlsYiUypQGhDEJyKW7MEFO+ptGhe3OvTYTlGSLjl2zc4XICynSxSNpb5KbiJnjgkr/lUgVYCpxbrGOxMp0h5bW+9BeZCRGkRRKaIvVMU5kkU2LCjWqpVFRcg2kTsiHZeNWXMbIEhnICqzvoAsKXZDokks04CTRm68SwJNipbBEdBGM9BWWiOXUZbe8nQYZamQ9xl3UyEqIrMY4VY1sxMiWRsTJeLhimboQSVSsknyjTqNUmdKXIk5ocBFaVCtGtJJNkzXmGo/vPuBne7/IkLiuaLvUADXLV7WND6RsX+OktirNYymRjDeZbF60Elg33XA5YFQqyRdgtUZGBhlZZNPgtAyqEeOEBhFapDEIs9yRbWk+rcxvrTzf9HNLsFKilSB2k7IA7aXfM/WkvHEMkkzTIk5kkKFBRemXTtacZN5xhYXCdumepA4tVgni1ExBuzIti8juxeULa6QQSf0mlq+N3cHNhUmaJupbyJ0xA3fdcw8PPvhguwykj/rXlMtlWa0u/gdQf//RRx+tpKrJNV2VvlvFAwcO6GeffVb+wi/8wuzLL7/8TBhGf+G67mAURX1BLhMlPPaVrzA2Nsabb7yR9pHrjYsay03eRhzH5TtT79KImwjlXpU9z2UtROmAMCSJci1IpPHGIJUFI5JJZmRiBJCB3TJwS7+yyWZE1wEq8hUotst6I/KfixyYLS0iWSSSJcZtqjA0Kll4TFq4mgBesqhYJdqLbQaCsUmCQIUCYxGuScFZYoUGYzBGpJsAu1LZ2IlqXSImm0aZxhEYX6ILEpOVBLgClFjKry2LzrpQk92iuV7gJkTv10ibWLi5El0woBXCgBZJNI8rEbFJ6tOuUDPeFi9k1z1Q4ApiBaEySGnJttKK5GdhLMJcxappuz0WvUFheQ/YvCPzkpRDphupjr2HSXuMtUFNJhsKLdJNl0oViRmYpTR5JvBK9G9JNCa0QkqLVDahQL3USEFYrJFYY5c2ovlzWQHgedZKJKmB3DjSMoskM8WkSP9+g5uBLgOfZEMgSLtpxBYpTTsXfWX6u6XzydYHo1JR17JzvYpifh0xWRjlsdG9bCuM0jQxAX5PcNNao43hgfvu486776bZbPbrg2gB6zhKVquVF6V0/8EjjzxSefbZZ+VaIrfLOrvnn39ePfPMM/rgwR/8tWLR+wOttR/HsRZCqLUITz46cYJDhw4lkV0f1Y5NQ90LzXm+efqnTNVmwfGS11h7Yxr25RaBLFKTNqMfcwtQGq0lz7FL9S12+aIhSCK9bv9D9NQhZQ+TDtDtHXIa0djMDoEkQsvAzToCk03WDMREGkGoDACzOrMUjwxp3tEi43QnGVtElHzPzrtNbfXyf8wDXAfIZTt64ySWXDqQmEChg9TBxFdYryN6ywCqn7CkX9G36EFT5mrcRGwQLYNqaWQ9idxU3SCbGhlqRGxAX+kCsxzgkKkNWRpVWyWScaFtEinGGhFdBcB1W/i7RW+242+pu8uyv2d1o3khqcieJnKqwxQIU6/XZMMlMdnmIc8mZM8T6XMz8wVjkdogQ5tEcJFBtkwSXYcmYVJMW/nSEcXZ3tFp7lztMto4jSYdkRZ4g1EqibRvFEXZRohk/VCxRehkvsmUMZHaIPXVANzSZjlbNzIrMqNSQU0KdlolTMNqEZxITS1M2t7r1pGtfGPzPfjSJTS9KcasM3epWOS2/fvZsWsXpo+gxFprpZR6YGDAWVxcPFit1r7+jW98o5Xh0OWLX1Zl8Kw4cOCAfOaZZ/SLL77wNdcNnnccZ7jZbBq5Bndax3E4c+YM777zTrtNRj+60hWKug555fwH/Oj8B0RxCMpJk5k3sC9ttrC33QeSySbsEmiJLJrDLH9u7jXL8h75NFW/XEluMW4vILlF32T0XdapV2WLSaJCbE/Y9LU2e67MCS9SQM4WEaFNAnIxCXWmk9xKe8HtxdOLHD0kVxocI2UCtJnXpJdQdcaXWC/JB1pXLNGxnfTilSgnZQ/AzU9CbRCRRbU0orW0sIpWAvQiNulCebU79XSD4smlRTSNioQxyViKQWjb3kxc9kpmuyhPbJeorRsILHutaA9Oa5dfX5vfnIo8e7B0vdvRnBDLc1syATRrxfJIMVUri9gklG0GcOnPIs11r/j8phPc7MrI1XYEeWm0ZGVCn2aRtZZrW+CvS2ok3WAKbRCaRL1t0rFg7FVQlB1aA7G0yUjENEsAZ9obXrEKHWlAR5QLQ/zirvvZO7S5vWZ3V7QmDFgcx0xMTHDbbbcxNDJCq9ns29tNKSWCIKDZbP4nY+zfeeyxx+Yuh5ZcM0WZQ2AL6Kefflo98cRXv/uDH/zgVxyHPywUCuPNZnPVSC6KIrZu3dpubthoNNocflf3eyyD3gDf2PMg+yd28b1P3uTY3Dm0iRHKyY3j699uJ9mJ29RUIEer5OhHYW22Yi2jUES2/e3V06+THlq2WC9J3Je1kMlJ322bpkxBJKWIsmgtv9Dkc3mdJsRWpj4vIi0nUGAdC/nb2g1k6AZmXUCH9PNIgfUE1lHggHVlrvZNrKQn6SMs6VoPt8pnWzlrk8/lJrsHrRLAJUiiWeJrOL7EUvQtLEvRkVXkBUpX9L7dACAPBF3BrOO5y4DRpsKwDqp5WeS3BFZ5usu2I7scNdjemGa8nG2Xxiwb/2m0mxhug1C2e9SZMirLfmly4NZ57jkANOlGz+Tux6fgiZ4bo7Y9fxMATuphpRFc88aZ7RzpUhSNWE0HkDgYmSjE8wrctWkvj225nU2lEULTuxtGRkn6xSLjGza0W9+sAm7GcRyplLNYrzd++/z58//0mWee0ZdLS152BJd/ftYK/Ac/+P6Dnlf4T57nbarVaiZF2L5dwB3HIQxDTp06xcLCAjqO20V9vYAuUB5NHXJs7iz/6YMfcW7ufDoYJEKoJGS29saOS5vLpXWCWm7SilUS+cL2ZiiXorWO4me5VBvWpopkB8CJJVBZyjmxUlqfCWtyApksQiWVf6+Q4vfqt9ZL8JGLopJ2OBKrJDgZXZpSeEr2ph4vR1giezyfHjvUVEwkdKIglWkpiDBJ6cg1X2DIaZvbLbbFEv12JWPR9gA4a5dHcYaVUY/t8h7L3mop4rIdKGfbG8AMpFKAYymPl3RzzQFZ+3H6/3QavaTq5CWaNhe5ZXPKdDuv3N87z6fzOghSCp8l2rRtOvwpoVyW3khp2LaArVtq41r8u5Q5sB0bYJubQ4naWxLrGHSE55e4Z+MeHt9xFzuGJpLOMCZeGbWlqvCsnndgYIDt27czNDxMFEU9xSTWWiOltL7vq1ardaHZbP36V7/61e/CUk321ewrL/vIuNDvfOebN5dKo/9nKcXfM8ZYrbXtF81Za9tJxWq1ysLCAgsLC0mDUdm9dY61FikErnKotBq8efYob104znsXT9IMm2AMwvUS+tIaLJ/i0ZH47gdwomO33N29I82ndVv8s4VFAkKuzFd1Rl2dkVXOwFikC5gQaaKlcyDKjNLMUX/tkxRLi6DqkPbL5T8nkaVMeqJlwC3pyL3lBSdrpCaFWCUv12cBS2oyUqp5Kb+aiIiuwwIjsvxrWtyf2bNdkWeSXUlDtqOXjkV+WSTXCRR2ZVRnyEU3Sw3ErFka0DavWuxGF9qOz2G6gJHOAVlqutB5T9rXJalbyEVsXQDPZs/pcp4it7EQuY99o3NvXTYoYtmmt2PjfM3HX446b/9OtNdmHbUgbOCXR7lvyz6e3HMPu0c2o0RiL5ZM95XF5Vlneiklw8PDbQenfo2ErbXWdV0RBAH1eu2Pof73vvzlv3QpxRhzlQTtld/WfMLv5Zdf/C8LhYHfEwJqtdoS5d0nopNSorWmUqlQq9Vo1BvL3Pfzr7QpHelIlbiHWMuRSx/zydxFfvTxYY5d/Bh0BK4HaVTXKyr8zB29wK1NKXY+R6ykBLv2P1sJlMv+R5627Ob5mAEbdEjtRffPLjsFId0iKdn7XOn4X5dT1N2Zt+MyAO6azYhPZ/ffNWIxnVFbBwDkc1jd8nCmIzoyOYDqpDwBdAdw9QRS2mKRniBsukde7c9kzMrorTNCtH2oyvVjGY2Y1aVhDUQR6Ijtm/dw+4bt3L3tVu7dfDMtkxSbZ+4xQnRJd9qkQW2pVKJcHqBQLLb9d7u0k7IktlvKGINS6kOtzf+i1PnffOSRZxpXIia5LtM5X3D3/e9//8Eg8P5rz/N/LQxDmZ5cnHqF9fw/SqnETDgMCcOQKIz6FoVnE8J3PJQQzNQrfDx3nhc+eI13zp1gen46Q1CU47YLpn8mAU6KLnRcR2SVRVDdejuJXtFbJ7jRXV4vuoAGojst2E/wkQfZfgDXtW7tciy56G+2/Hk6+kVg+b+ZLhTmCkDoBpgd7286npM91l3yd1cKbrYfzdgD3Jadq+19ruvH0hRK00I6iiAOwfUZKAzw9dseZt/kNvZN7GTryATNsEUj7eHWr0uFlBLP8/B8r9201RrTa97FQggn7exu41j/XhiGz331q189m2HKlYhJrut+NY+4P/3pT59oNhv/WyHE3y4Wiyrtnaah3SFcdFKQWWF41tZCa932JevB2SYlqBZc5eBKRWw0c/VFXvrwTT68+DEvfvBT6pUFcF2k6yUgZy2fqeEu+kQbogPkukVvy57XA9z6goRYHhHRLf9Fb/FG3gpr1R5tcvXI6kqLukW3SHOV3NvPPMD1AJ1ulGBPOq8LmHRGb/mIznYBw260Yye4dHvOMlGI7QLEXc6pU1xiugBmL1HNFxzUkvyYSHxkW3UQkpGhcW7duoef3/8Q9++4jbJfwHVcQh3RisLEEL5rKyjbXpsz4/h8EXePiM0KISiXy7JWq2ljzLeFkP+vRx999DsZhjz99NPmWoLbNSVk8h/wW9/6ll8sFp9SSj0uBH+3WCyMRFHcTjQCq4pS8r2o8he0F9hJkdyMwPWotRocPnuCHx97m++9/xrnL54G1wWhkMpJ+GdjPv2x36tOq2vk1UVFmKcx6UNNdm0GmrPG6gYy+QixH7j1irpWRIDi8sCtFzXZz7HkaqjJzwO49YrOulGTdERNeXozD262S7TVC9yWRVs5ADNdRCD5PJq2y1/fmWPLcm+2D3VquzznCxy9ZTXHxtjErNka0DFescxDu/Zzx7a93L/7du7afjNRHBPpOLEBbNOQoieodfYJ7MHumVT56DhO0kIsikJA/IcwjP7d448//mfZc69WSHJDMw6dH/ZHP/reDiEKX4vj+NeF4BFAOo4j4jg26QXqC3TZhczatvQDvOxvQgiKfgFrDRcWZjh85jjfef813jl9lGp1Pknq+gVk2g3gU4nrLoea7ObIIcVKgISVOTyxRmqSPvRgL2oyE5b0zbuthZq8xt0CPs/gBr2jlG7Rm2UVyvAyore1ApzpAOJeKkfLcmqxG624WvSWpy+70bRfUGDTOoYoBOVSKpTYtWELT+67j/t33sbG4XEGgxKRjqmFjcQftwPU8uCVRWpKqVUb6trEekq7rusGQUCr1SQM4yNSym8LIX7vy1/+8uEsIHrvvffs9QK26wZwGY/64osvqieeeMLk6xd++MOXftlaeSvYv14oFO4GCMMQrbVJ83msBnY6bUljjOlLY2pjECLJ1WUdr0/PXeSbb/+Ao+dPcvj8x9hGFfwiQqmuN/ZTATgpuizcfaK3fgDXL/cmu9GkfUClX+7tagHuWncL+LxHb71yVF2Bg5UCks5IrlveLP+cT0NYsiwaND3Ow/YWlnxB6EmRY1WstRBHoGNKg6PcPLGNB3ft5+E9d7JtZLJt7h7GEXG6PnZSkNn6l/WrdNL+lf1UkOlVF1JK4fs+QRAwNzd3FsQhY8yfKaUOPPbYY3PZaw4ePOg8+eST8Q2jZ6/n8eyzz0qA5557zgohrLVWvvrqq9uNMQ+B+XvG2JsKhWBb1tl4rfRlBnRRFBGFUVunKvILY1YMniqxHOkw4BeYrS9y+OwJ3j59hB+efJdz0+eXFkPloKTEWHv9wK5fndaahSWsdA3JL+ydhZySyxSW5F//KQhLVlCcXJ6whM8hwPXKg11rYQmsrrLMlQusC0tuPKhlVKHWMegYsDhegb2T23lgx218afst7BrfTDko0QhbxEa3NwQr1sjUni3r3u66Lo7jtHNrPdZBba0VSinpui4ArVYrEsK+YC3/UQj1w0cfffTDfNDz3HPPiQwHbty1uoFHp/zzW9/6ll8oDN3suvrvW8uvAFtc1xPGaLTWqyowM4mr0SbpWdZqJg0500TnCgoTizYGRypKfoFIx8zXKxy5+DEvn3iHw+eOM1ObT0J7x0UqJ51L9vqB2wo6cLXcm+jus7gCgFYTluSBq0sEJS8j99bXK1JcH2FJT3D8nIJbZwR2OdQktnuRdD9qsitQXoawpFfuLf98bXsLS/LgtS4saa93gsTBnzhRQPrlETYUB7lr2z6e3Hsf20c2UvJ8hBA0ohbG2KRTPKJnpJb1LfQDvx259VjzTJoCMkHgOyBoNBoVz/PORlH8b4wx/65UKl247777omy9f/rppwHMjQS1Tw3gsv+ZeluKPNgdPHhwp5Tyy8Djrqv+erFYGqzX60lH2yUVjux147Ob1m7OGYZEUURWyNwO5dOozliTdMpOIzYlJOcXZ3jn3AkOnT7CkYufMLc4nVwipVLnFLGMkrFXCnC9ZOyyT35srcKSbtRkJ7ithZq8amHJGlSTay3qXheWrI1WtPQo6rZreJwH0T7Rm6aDluwBtLojwjNdPndn9NUt99ZpQ2a75N4snzuAW1I+pk5N1oKJQWuC0hC7xzazY2SS+3fcxj1b9+KkSvKsq7qFdm4t29xna5+SCuUogkKA53p4XtLQ1tLFzSbJqVkhhPI8r01XNpvNd7Q2zxtjfvDEE0+8nH/NwYMHnc701Kd6HT+9DWmSd8uMnNPfyZdeeukux3G+YYz+u47jbJdSCiEErVYrTEHO6bfLARL6Moyo12s0Gs20RCArOhQ5K7yl/m2Ocii4PvWoycXKHO9f+IjXT33Ih1OnWKwvJJNNCFBOu/3PZUV316Sou6MIG268sETmgbJHVCrl6tTk9ewW8HkEN+hR1H0FwpI88FwPYQldwOhaCUs6n/M5EpaIPKjpOAFw5RD4AbdO7OTOTXu4Y/MexgeGmSiPJI1no9Yy96FOBXrSR1Lg+z6u51EsFJFKtk3vu6xhGQltPM/zgiBgcXExBvsCcN4Y/thxnFe+/OUvX8qt4yIFwive+1+Pw/mUb2abrHj22Wfl/v37hRBCA28Cbx4+fPh/XFxc/LkoCh8F8asTExtubTSaVKvVtgIzfR/RGXo7joPjOBSKBaIool6rU6/X0wZ7Bms6+9NZ4lhTbzaQQjJZHGZy95d4bNfdXKrM8caZIxyfPsOxqdPMNWsIAVHYQjppjd3VaDHXYvi6mnHwlWxZxBW8vj2U+zz3WrmGXKvz/DxQk93AbUVnALrbZtlVHtMjmoPl9nOmC4D0EnZ0A7eukSjdOyB0fr5eANirk8LPWKTWBqQ49Wx0PcbKo2we2sAD227l7i03M1wo4ykHIQShjrm0MJv6Ri5fQJJ+nBbHcfG8pPi6UCy0I7Xsf5lcY12bCB9s6hksi8WidF2X2dnZE2A/AftHruv//kMPPbSYj9SmpqZsumbbz+z1/WzN5WW7gfZF+853fri5XBZ/I47ju3zf/9tKOcRxnCkqdQpsslvOLm9J02w2icKQxcVFms1mCk4pjdm++bnEKwIlJa5ykAhOL05xavYCpxcv8fKJt5hanF7yghQyZx7dAXn9cm/XSliyovCZ5V6Rku6WXKsVdV+JsKTzfenyv/tFgV3b3XwBi7rXKiyxPYCjK215hcISSw/JPz2EIvbKhSXQhda0K+viukWAn2lAE+11xVqTNHQ2FqwGx2NjeZR9G7Zz16Y9bBueZPvwBNZCZBLluMkJRZbWK7PERllLsVRioFQiKBTwfX+ZiUYP+lEqpYRSCsdxqNVq54TgT8Ee9f3i8w888MDp/OtulMT/cwlwnUcW2eXzdT/60Y9uB/OIMeYfSal2+L5fSnlhtNZt2WpXsJMS0rq6VqtFrVajWq0SR1FSdmCT50i5pB7Kmq1aLL5yUVLRiJpUwgbT1Xn+7MirfDT1CQ1riVq1ZHVWDlImrVBMt0jtRghLujmd9DImXgGel5F7u9bCkl7nkqdIVwPQz1P0tlpR92p+k/SgHdda1A39ywIuR1iyWlmAuRJq8rOfdxNpZwVrU9/HOKlRGymPsHtkM1uHxrl1YjtbBicoeT4FNyDSMaGOMljMieYScNQ6kfo7jkNQKDAwMEAQBHie15V+zEVpVgiB67rK8zwSt6l4EeyfO476o1Yr/vGTTz55Zul1B50DB6bstTA/Xge4PkD3V/7KX1GZQic7fvjDH95trf7brus+FobRXsdxhrKq+SiKbQcvLZYNOJZKDlrNJouVCpVKhVarRRSGSKlWqDGzjgVSSBwpUVKijaUZhxydPs0b549yav4iM/UqtcZCSgR7IOVSWivtL7cUva1RWHKlNW9ryb2tVvN2NUXdVyIsgWvTLeBn/TCr2Vextm4Bl2vJlQegbtFbHiT7dQu4ktzbWoQl/ejMz8SiuiTuEAisDkEoPNdnpFBmU2mYvRu2c9PYVnYOT6CkgtRKSxudMzYWy8L5zOwiCAKCQgHXdRkbG8P3/fZ6lndpsksIZ5VSUimF53nZBv+steanwAthGL/w1FNPLZP1Hzp0yPnmN7+pfxYitc9NJiOjMJ977jnyF/5b3/rWYLFY3KeU+MtCqG8YozeXSqUtYRgmoX0yMHQ/GlNKSRiGSWRXrVGpLNJqJT+312aZrM6WJW/LbHflSQdHKabri8w1Krw39TEfz1/k6OwZ6s1aujjb5arMzqaLaxWW9IqYejmd9KUm1ygs6Sf4gMsTlvSNAFk3U4b+3QI6KcDL7RbQDTyuxJKrqxlzj8/dacl1TaK3z0buTbQVi4lCO1F32iR9gWXHyEa+tHkfe0Y2M1IYYPPgOAJoxTGx0e10RraWZJSjyW0AHEcxODjI4NAQhUKBQqGAkBKTKM07IzWT9llzs9q2er0+D5yUUhyNY/NNpdTr3WrVAH7jN37janvZrwPc9YrsDh48POC68zeB+WVj7INKqZ+z1vqFQoFms5nl7FYAXb5fnQBirYmjiPn5earVKrVaLXt9Wy6bf4usONxRClc6gKWlY+Yai5xenOKtiyf5ZOEs83GT2KSdRQUIqRKgy3rD0SWHtt4tYL1bwHq3gM9UUXfWOsZYC0YnX0LguAFlL2Db0AS3jm3nptEtjBbLBI6PIySx0YQ6TqdNxxpiDMYalExMjINCwMBAmaHBwXbEppTC2KT+l2XUZaJ8FEI4maNIpVKJ4jh6RSnnHWvj7zpO8OJDDz1YybrNPfvss/KJJ56QTzzxhP60atXWAW6Nkd2BAwfk008/Y4RY2nk8//zzA5OTk1+WUt4E9q8C9xSLxeEoComTovC203UWI3Uai2YDqNFsMjszQ71Wp1arJaKVVhMh5Iq6FZs2MRQiEakIEkqzGjY4Pn+OhbDOkfkznFy8QCVuJDUujpelD5EibQiadU7+IncL6AmOX8Dc289Ct4B8P7o1dwswy6PTXtHbp1DULfLzot3ZPI3QTCIOGSuUGQ3K7BnZzNbyBNuHJhgNBjCp8MNYg07FIO01JV0n8h66hUKBgfIAw8PDeJ7HwMDAsnxaLq+W32ZIpZTICrar1WoLeBfEj7XW36vX6y9+4xvfWOxYLxVLQr7PrfXL55LbyerrSHvVZb9//fU/KdbrwzuFEF8D+w8cx9kJOElPOk0cR33r7DLT0UyNGYYhFy5cYPrSVDuXZ61FKpVIdzObm3abnqTrgacSa5tq2GAxbnChNsvbsyc5PHcag0XbGNAgFEiFVAn111ZmrqVbwFqKutfSLWA1F//1bgE3Dtx+lroFdHMs6UlNsoZuATe2kemS2jErtE7FISRzcSgos7E0ytbyGLsGNzI5MMKAV2DQK2CsJUzd+bPBKjtq0zK3Jc/3KRYKBIUCo6OjFEtFfN9vrzP5pqFZJxZACyGU7/syE4lEUdQE+0Nj+I9KqVddt3H6wQe/NpNbEyVLjajhC9JI6HNfTZRFdgB5Jebzzz/vbd06eXsci6+D+IpS4r7h4eHRVFmZ7UFFpwl03uIm+1lrTbVSYXp6mkq1SqvZpNVqYYxpe7plszmZt8l7KClxhEQgiK2hFjdZCOt8uHiO9xdOUTcRi3GTVlxPQUClYhWx1HJ+vVvA5+9Y7xbwqXQLEPkoLcujAY7j4SmHTQNjbC9vYEt5jJ2Dk5S8AFc6SVsam9gAZqDWST2mPru4rovreXiuy8joKCMjI5RKpWUWWRmo5QDJpiAnfN8XpVKJarVKGIbvlkql6Wq19j0hxO8/+uijZ5Zv6F9377333oy2/EL2Dvoilcv2FKg8//xhb2Ji+i6l1FfB3ON5/tOu6y7rWqC1zpaCFbm7jHKQUhLHMZXFRer1OguLi8xMT1Ov1dsgJ4RIC8xzdl82C7iS/J8rE459Pqoz3apwrjnHR/WLXGotMh1WkpoZKZciuBQchBQJ6C3L3+XArScdeAXCkjw1eSXCEugucvkimynD2lWTndQkHdSg6UFNdqMSO6lDWFkW0Bdkc2un7ujrplnFjosOuy27OkDSAYZXEZ1lea9Uw598ScmgP8CQV2Tn4CS7hjYy4AVsKo5QdH1ik9GNtl1C1LYDzEVp7cbMxjI6NsrI6CjDw8P4vt8GtSxKW3odVghMusSobIPsOA6NRgNj7Mu+778Sho23Qf153qU/i9QOHDggflbq1NYB7gZEd/nIzlorX3755Vtc192idfRr1vILwLDv+75SKhOZRIDsFKpkVELW5VZrTbPZpFFvMDc3S7VapVpJxCoiRwvKlOJL6i7BpNJiJZIIzxGKqm7RNCFTrUU+bs5wsjHFhXCOCEtk4yx7iJBu6haezJQ2pbneLeBnYEBy7boFdM3Jsbaibs1yB5PPgbBE5DxptdHJJtGYtijEUw5bSmNsLA6zozzBxuIIvnIpuokwxFhLZDTGmnb6IcvNWWtSoEpEakopCoWAkdFRhoaGKZVKFIoFXM9Lm5AadKay7IiLlVIqCAIAGo2GNcaeE4JXQfzQWvt9KeXJRx99tJK9MHMTuR7dsNcB7nMGdLt375addXYHDx50pJRfUUo8Zi1PgbhjcHBwOKmzi4jjOC01ERZsfhluR3UZf26xNGp1ZmZmiOOY6elp5ufniaIIYwxZ24mOz5YYpAqJRCCFbJuiLpoGU2GFi9EidRtyvDnFuXgOiEA6ab5ApE4rS4JMREdpwmq5t/VuAZ9u7m29W0D3DcAqC5rNX1ebdrU2hiAYZDwoU1IeZb/I7aPbGQ0GGfKKbWGYSeedyWrKchFaFnGZtB+lH/j4fsDQ0BCDQ0OUy2WGhoZwHKfN2qSRWvvs0zVBSCmFUqpdx1atViuO4xzWOj5srTjYbDZf+vmf//lz+XN8/vnn1YYNG8TnVfm4DnA3iMbs7F30/PPPe5s2bbrDGPOwlOKrwG1KqZuzkgGtdVpcTkLEW1QiDlluhJolkBuNBs1Gg0ajwcULFzhz9mx7QmYlA+2yhXaS2WJzlKYSAoUktJqGjTgbzbFgmlzSVS7ECyzYJlXb7BBzyFwRaQp2mVrzWnYLWBeWXB649YxyrkBY0glYneDWK9JbS83bMpFJF+DNPscVNTK1KwGwi7Aki55EXnzV/jw2N8AMRbfE1tIoE8EQI36JDcEQY8EAJSfAlYpWZoOVmjgk8y13allOLJ3Hg8PDYC2Dg4OMjowwODREEAQUi0WkUmitl/k8GmOsEMIIIRSwzBOy2WxGIE4IIQ4B3zLGHP/kk0/e+/Vf//Vax5rEp9FPbR3gvhigJ1988UWZ70L7/PPPqx07dgxHUfQgmIet5ZeFEBullBtKpVLWtifzelu2zGc+l0oqROpwEsdxu9XP4sIily5dYn5uLmnoGkXEOkaIxDklL3CxZMXmAonAF4kjQmjjFPRCpk2N82aRGVNjxtZZpElDhGmiRaYRnkwXDAGqIxZd7xZwY3JvsN4toEdRt7Bi2blZUorPmjS8kiipKCiPzcURio7PxmCYjYVhhrwinnLxpIObtpXJ8mhgkzKfdkstgY5jtNbtWtcgCFCOolQaYNPmTYyPj7eVjlmUluXqcxFa2krSWqWUEwQB9XrdJjSkPGuMPWEt35ZS/oVS6sRDDz1UyQed69TjOsB9alQmLFdkZseLL754q+epB7TmESF42Pf9O3zfp9VqtQUrNvHgMdgkS5btQzM6M7srUkrq9Trz8/PUqjWmp6ZYWFigVqvRaDSSAKdLsfkS4EEapyEzqTKCGhEVmpyxC8zaOjVi5qhTERFNIqyKk/KEvNFy5tKQ2owhZIf7yiq5tytRTnY1W/4CRm+dgpJuNlamD8W5ltxbHlTMFRR1L+v9llGTWYTX+Z7Zl1kBvmLFOacmwiZF2DYACnzHx5cuw16BTcEow16RkhMw7pcZdIuo1A0k2wJmlGO7Di2fAsgpF40xDKdU48TEBH4QMDw8TLk8gOslnUNsej7GGps+TjwesVJKKaSQOK6DoxyCIGB2brZmjP0WmO+BrBhjDj7++OPnO4fBOqitA9xn6tpZazPaIL9rA+CFF16Y9DzvJlepx4y1D1hrH5dSDjuOIz3Pa0dmNjmMQCSykKTzIJalhLUQYlmENzc3x+LCAqdPn253RMjtHtsil3yTw0x1nJScS1wkEkmTiBohTWKqRFwQi5wTVT6RcyAEMSYFnJROkkvRnhRZuUJWn3cZysl+3QLWhSWf/24BaVQmUgrfmjQaMwmwYTSgABjxygTCxROK8aDMpD/MuF/GlYqSE1BQLjIVgmir0TZHY7ad+2070spq0DL6v1QqtSX7Q0NDDAwMUCoWcRwntcJKm4hmqQaLQWCstUpKKVzXJfG/jQjDEKytAC8LIX7kBcGxMAyPPPzww+/lJfzPPvuszNaNLHXBF6Q2bR3gfkaPzPZmamrKdkZ4P/zhD8vA3cDPSSkfw9rd1tqtSkq3UCwShmEW5ZmO+yLyFmJ5ejKOY5rNJjMzM0l0V60yOztLo9GgVqu1gS4DyizCSzQJth3VZV8i9diMMWgsDRExIxrMUOeUWqApIhrSUJcRLaFBpoytkIBqJ+GXmSln9XorKM71bgE9o65OWu9ntFuAWAGkoh2FWZMTfthkx+MKRVF4FKWLg2CjP8KmwgjjbplBr9AWWanUqihxCLGkTWQQOdf9fGSmtcZ1XaSU+L7PwMAAo6OjyfexMcrlMkqp9nzJXpO+x7KNqxDCOo6jCoUCjUaDKIpCIcRZa+0pIeUPtNavNJvNn3zta0tF1p2pjnVxyDrAfS7Abv/+/aIX3fDyyy9vl1LeKoTYKYT4Vav1diHllmKxWM7ozDavn2wdTWdZQr7+TkpJFEU0m00WFhaYn5ujVq9TrVSoVqssLi6uELssozfF0sLaTuDnAdAKYmFYFC0WRYu6iJiVTeZVgwUZ8YmzAEJ39LdLF7V8vZ2gnXe0HQBm14UlvZ1COsGtJ215mcKS1cCtBzUpshuWoxattVidE3vkRSPkoj2tcVXAFm+YkvSYdIcoOwGBcBl0Cslj5SbMRAZgmRvQMi/yJVVjvjWMMQbf9/F9n0KhwNDQEOMbNuAHAQOlEuVyGdd1l9GS6esy2z6TzhXlOI7I+84qpahWqyeU47yhtf6OMeZUq9X68KmnnvqkX0pjnXZcB7gvDOjB8hzewYMHgyGlyg2ldrpSPqKt/arjOPfHcVxylBqQaTK71WoRax1KIWSqrJIisTlYBlpZ8jsMk1KGKAyp1evMz80xNz/P4sICCwsLaK0Th4V0J5ynbYQUS/RmulsWCFT6JW2yX46EJkSzIEO0MNRFzLxqMqeazKsml9wGsbDEwqClwcp0ay9Mrm4hKWdIcFC2ac92lnK9W8AN7RYgVgBccrvygGna3pEmeQObAiUgUShgkxpKlb6SIREw4hQZVkWK0sMTDiXl40mFg2qbFuvUjT+rBc3EH1lUlkVW2QZQSkkQBDiOw8joKEEQMDI8zPiGDe3fZ00/M6VzDhDzXoxWSulkdKPrujQaDVqNxsdWynclVA28bK091Gq1Tr344ouXlptFPK8A0gLrz7W/4zrArR9rWNvadIXJc/M50HOKxeLtWuuHhBBjwtpHpFJfGR8fH0gbFLY7G5C2fcosfTJZsZRJwCekTMybcw1cG6nTysLCAnEUMTMz0+5ynuX7Msomfa/2iLHL+NO067kV+SAQm25WNZa6jFiUIQtOSFVGNFTEtNugKTVNGdNQmkgaYqVB5RhaIcDKFQC3lkH7mV9dbnC3ANGLBs35RNr2380SnYjNyfVTWhGBawM8JAXhEgiXAi7jskQgHAakz6AMGJJFitLtcA7JmsqAzkdmbZKxPT9W0IzKcSgPDOB5HsVSCcdxKAQB27ZvZ3BwkCAIOno3JiCW83O0S+SHIDMozhz6FxYWQuAM1p7wfX86iqIfhXH8Qr6lzLJb+Pzz6sWkHq3rHF4/1gFu/WBlnUvG9XcC3oDvf2lgcPCmxVptu7X2HgF/2fO8Ur59jzGGOJE5WyGEzsCUjg7neWoTIAxDGmlNXhSGbV/NyuJi4rVZrRJFUXvhyFOc7YiPDnMGu0QlSStQWZ7ECrSwNGVEQ2oaMiYShoaMmfda1GVE1Y2pOCFngurKRq89ISz3pLTOQVrRd/TbVSDxugGlWZuwRPQUlogO5WEvGjMXbeWVj20Vo+gQlgg2iAFia7DGEOBSxKWExwAeReFSEC5lEeALRZACXCBcZJrDNdmXte0+Z9kmRcCyjVZn1+kM/LK6skKhwODgYOqyX6ZcLuN7HoViEc/zAMhT+iyPX2W20ctybBmFKYSg1WpdQIiTwHtSyjel1u/EQpx96KGHTvaao7mPyDrluA5w68dVUprPPfecOHDgwIqyBGutePPNN8fjOJ40xnzJWnuPFOJ2pdQtcRyPOo5TLJVKaK3bAhZrbZxxgrkJuwLwsq7AcUphGmOoLC6yuLjI6TNnqFYqCCDMavTiOFGPpZFe/msJKGxunU4W5iy3lwlcRLpGa2HQwqYgmAhZQqmpK01NRdRURF3F1J2YC34tbYKVPD/OvVYLk5Q9rFitRBeUEx2otjaAvGbgBl1r3syKKM922Fnlips7C7CtBSNxjIu0oJA4Nom2pZVIA55VbBZlAutQEh4lXIYpEAg3JY9lSkun31OTAJNKOxKRR/7uihTL0tZRWX7LWmwKQlntWCb8GB0bo1AooKRkcHCQ8uDgsojMcRzyZgp5itJaa6WU7bYxjuMIIQRZeY4QIhOCLBhjPhZCHDbWvudKedjx/Tfr9XrlkUceaXTe2ddff92pVCp2XRCyDnDrxw2K8pJ+d08LEnfwrpTIK6+8MimlvF0Ysx0h7hZK3Wa03i2k3Dw0OBhk1GbHDjohu5JFVCSpCdGmODMAzItSojCkVqtRTevyFubn2xFgo9Eg7cqA1nqZG4tMbcNWeGB2DEiRAk8CMDZHbuWel9KjFkuoNC2haUpNS2laMvk6H9SXnKOEaecDI2GIpel4nACjYel77IZ9wPEKuclutWpt4FsuCHG0hzQZKAmUBcdIHCtxjEi+W4mbfTeyrWe11hJYh022jGMlgXUIcPBQeDg4mTlwe9uRYavtGuUue16XSH1FzzJrKZRKyBRwCsUixSBgbHw8oRcLBYqlEqVSqW1VRUeElwk/8u76yT4qGZuZGbHrujQSen0GaCghTmqt/9wKMS2EuBCG4dFeVGP6v9Qyhn0d1NYBbv34dO9dthBktXidXRIAvnX0qD+xuDiptR6V1t6JEHdY+DtSysBaq4QQXpaIz+jNLGoD4qxNRwdFI/IRn5QSISVxWgeUiVsajQb1ep1atUq1WqXRaDA/P0+r1covYMsoqhX0p8z8N3NLrM3HhcvBTlra0aBA4KZSzQQzDFosjxC1SEoisgjQCJsydwnANZXGiiRfZNLnZc/RIi0eFrSjmHZN4IqJlm4UTFqAn4J3prmRVqYAlvwuE/EExmmfk0zPT6Y5T0X6mjQyk0Kmr88ZAWOJRPvTpdfBtlnO/JZBiKWIq6szfo5OTDYtEimXhE2Dg4NJfqxYpDQwQKlUYnh4uA1Anu/ju27boCCxx1qK7DpEH5kLkJdFcBmYpb0YLRAKIQ4bIY47cDrS+jXHcQ4DUaVSufjkk09Wu9CMWd0qvdIB68c6wK0fn/FIb8OGDQIgby+WHQcPHgw2bNjgVCqVba4rb7eWfdbaL0upxo0x48CEEKJYLpcRQrQpTiBToS0DUWts6nKUeLLka/byIJap4DJVZ71ep16r0ag3MNbQarWYnZ3DaN2mPqMoalNN+bKI/M9J/Xk+UWdXRB15mMkDYhu17fIYsV2uZ8Vy5jL//p2s5lVMuhXRaUc0lf9/NneG7ceZk9WKtVp0pDDTLvEmH2kl76G1btOCOo4RaZuWTIjhOA7KcZJeZmOjBH5AqVSkWCpRLBTxfC/5Xx33Px+NdeTcrMgZfTuOIzMgy4QfMzOzVggza4yYFoJppWTLGP0XUopDjhN8eOedd57Pcs1d5kIm5GrL/9dXiHWAWz8+Z4AHiAMHDoinn356FfrFikOH3thuTLgLnCFr7X4p5S3Wmp1gd1orrBBMDgwM+HEcLTOjzeVGbKbmTNdfkTmnZwC4QqCS0p55QGu1WkRhSKsVUq1WUmCMaIUtms0WYdgibIXEUQRCtOlQ0am47LAyWzn6l2jSFRAj1jZp2ga9a78nS5Enq4CkZSVUd6EH25+j8/90NAVNOs5LSsUSUkk8z8N1XPwgwHEUY2NjFIslrLUoJZPmnJ6H7/tJBOZ5beDKqRzzwJX5hNs0IiNlCsRStJ9ayOWAMG0tdQk4B+aMtfJja+0ZIcQHUsZnKpXWqSeffHJ6tXG+bDCvR2brALd+CdbB78CBA2LDhg2iW7QHcPjw4YFWqzVYr9edgYHCLULIO7XWN1trdwIRsN11vZuiKPI8z1MZqDiOQxRF7dqjRNlJDG3KM8v3iTwY5UsbsgUwX/ie/8qiw1azRaOZKECjMCl4j3VMpVJh6tIUSqm2OTUWjEm6Nvei4DofL+GJRXS0F8rMsvOF9H0uOsp1ltlHLeHU8tdnrvaZCfZavrLXaa2ZmJhgaHgIlXoiJkDl4fl+29FeqYRqVMrBUQkVLFViXGxzkZ6xBmusMcZ0qggt4GSCorwjSNb+KSs90Vq3hKBpLQ3P82wYhi9LKd7R2h4RQpy21p4PgqAahmG1s21VFpEB8sCBA/a9996z687668c6wK0flw14gHjxxRfFE088YXvRP/njtdde2+h5co+1bNKa3UIIRwi2ep53RxiGo9YyLgQDrusWy+VyG/Syr4z+ZElMQGddX7qAtyPC9oIulsyq81FKt8dZtJnlGdtfKR267DNpjdFJC5XEJDs1/k3DE5GLAIUgrSeM21ThiomW6703PDyElKqNbMv6lsk0h9a2WBNI5aCkQjmKfD6q8ytTGuZnt8jVFIrl18EuAXn2z9tjIP+4TT27buIuks+9ep7H/PwCYJsk5pFzwJy1LEopLmmtp4TgfSHUjBDihOuaM60Wp7oBWCeYHTp0SFUqFTs1NWXXO1SvH+sAt35cL9Djueeea4+VLDmfLX692LWjR7/lVyqTY0qpUSHEQBzHG1xX3RzHZou1ZrsQYtJau9X3/V0ZvdgtGskLUfL2SqlRNSkItxm6PCWa/577zFZkXGknjZkDgk6wyBcpZz37bFoILbL2QXaVCj1B242+DdBCLs8edtCOdESSuWvRdUOQnWP+d/m/pUAksyh5WU6TJIfW+b/CMDTW2neFEGWgBuKSEJxzXed8qxW96zj2E4AoYt513blCobC4d+/exbWOrUwktS78WD/WAW79+ExTnQAvvvii6bfjTo2pvXK57ANDQoiStXajEGJLCnybpJTjxpiSEKIKGAHfsNYGQAD4rusKKQW+H+C6LrGOsWapRipXK5VQbGkEluV8jDG6k1LsrA/s9bsOKlHQNavW83rZjp/z79V1YU/bseQmrrBSSiezsOoU4eRrGjtrE7OifWNMbK1tCSEajuO0ojg+jTEfAINIuYAx01aIC0qpc8BZz/NOtFqthuu68alTp6JvfOMbrbVGYZnQg/Xc2PqxDnDrx+cN+J5++mkADhw4cEXGsydef31oXohhpdSo1noUGAaGJDhWiI2u626KoqgkrC0AQ1gxgKQEFAUULAQC4abulnVgeGhoyM9yZ0tthfrk4LpQnp2titZydFKJIsdhZo876w87HzuOw+LCwqKFEGsDCzFChAJaQM1aWxdCVIUQNQtVYW3VWFsXUjattScULMTWVq21c0qpWWPMnLV2/r777qtfzT1O728GZD2j+/Vj/VgHuPXjcz32OsEio0GzOqVc9HJZuZeDJ08Gw/Pzgeu6gRDCj6LIt9a6jrWOllIShlgpN3ietzW2umC1LRsoSSl9Ye2AAV9AgBAFwAN8rPUQwsFaFyFU0vcca40Zdlx3ZxzHVojVXaFTyvUI1jaFENYKobE2FhBbISIgFtY2jbWhhaaSsmqtbVqoSahbYxpSyqryvLrW+rSUcgFAa62llLEQIqrX660oilqjo6MNrXXr9ttvDy8HsFJDAZu7L8to6Y4odh3A1o/P7PH/B1fSl3/NoYJAAAAAAElFTkSuQmCC"; // logotipo SADA enviado pelo usuário
function a3TexPorta(){ // porta da cabine: logotipo da SADA (ou outro enviado pelo botão)
  return a3Tex(512,334,(x,w,h)=>{ x.clearRect(0,0,w,h);
    if(A3.logoImg){ const im=A3.logoImg, r=Math.min((w-16)/im.width,(h-16)/im.height); const iw=im.width*r, ih=im.height*r; x.drawImage(im,(w-iw)/2,(h-ih)/2,iw,ih); }
    else { x.fillStyle="#0B4F8A"; x.font="bold 140px Arial"; x.textAlign="center"; x.textBaseline="middle"; x.fillText("SADA",w/2,h/2); } });
}
/* ---------- geometria arredondada ---------- */
const A3_GEO={};
function a3RGeo(w,h,d,r,s=2){ r=Math.max(.001,Math.min(r,w/2-.001,h/2-.001,d/2-.001)); const key=[w,h,d,r,s].map(x=>x.toFixed(3)).join("|"); if(A3_GEO[key]) return A3_GEO[key];
  const n=2*s+1, g=new THREE.BoxGeometry(1,1,1,n,n,n), P=g.attributes.position, N=g.attributes.normal, sz=[w,h,d];
  const map=(v,size)=>{ const i=Math.round((v+.5)*n); if(i<=s) return -size/2+r*(i/s); if(i>=n-s) return size/2-r*((n-i)/s); return 0; };
  const p=new THREE.Vector3(), q=new THREE.Vector3(), UV=g.attributes.uv, fc=(n+1)*(n+1), eixos=[[d,h],[d,h],[w,d],[w,d],[w,h],[w,h]];
  const fr=(t,size)=>{ const i=Math.round(t*n); const c=i<=s?-size/2+r*(i/s):i>=n-s?size/2-r*((n-i)/s):0; return c/size+.5; };
  for(let i=0;i<UV.count;i++){ const f=Math.min(5,Math.floor(i/fc)), [su,sv]=eixos[f]; UV.setXY(i,fr(UV.getX(i),su),fr(UV.getY(i),sv)); }
  for(let i=0;i<P.count;i++){ p.set(map(P.getX(i),w),map(P.getY(i),h),map(P.getZ(i),d));
    q.set(Math.max(-w/2+r,Math.min(w/2-r,p.x)),Math.max(-h/2+r,Math.min(h/2-r,p.y)),Math.max(-d/2+r,Math.min(d/2-r,p.z)));
    p.sub(q); const l=p.length(); if(l>1e-6){ p.multiplyScalar(1/l); N.setXYZ(i,p.x,p.y,p.z); p.multiplyScalar(r); } p.add(q); P.setXYZ(i,p.x,p.y,p.z); }
  return (A3_GEO[key]=g); }
/* ---------- modelos ---------- */
function a3Mat(c,o={}){ return new THREE.MeshStandardMaterial(Object.assign({color:c,roughness:.55,metalness:.15},o)); }
function a3Box(w,h,d,m,r=0){ const b=new THREE.Mesh(r?a3RGeo(w,h,d,r):new THREE.BoxGeometry(w,h,d),m); b.castShadow=true; b.receiveShadow=true; return b; }
const A3_RODA={};
function a3Wheels(g,zs,w=2.5,R=.55){ if(!A3_RODA[R]){ A3_RODA[R]={pneu:new THREE.CylinderGeometry(R,R,.46,26), flanco:new THREE.TorusGeometry(R*.82,.1,8,26), aro:new THREE.CylinderGeometry(R*.52,R*.52,.48,18), cubo:new THREE.CylinderGeometry(R*.18,R*.18,.52,10)}; }
  const G=A3_RODA[R], mp=A3.mPneu||(A3.mPneu=a3Mat(0x1b1f22,{roughness:.92,metalness:0})), ma=A3.mAro||(A3.mAro=a3Mat(0xC5CCD2,{metalness:.85,roughness:.25})), mc=A3.mCubo||(A3.mCubo=a3Mat(0x60686e,{metalness:.7})); const ws=[];
  zs.forEach(z=>[-1,1].forEach(sd=>{ const wh=new THREE.Group(); const t=new THREE.Mesh(G.pneu,mp); t.rotation.z=Math.PI/2; t.castShadow=true; wh.add(t);
    [-1,1].forEach(f=>{ const fl=new THREE.Mesh(G.flanco,mp); fl.rotation.y=Math.PI/2; fl.position.x=f*.2; wh.add(fl); });
    const a=new THREE.Mesh(G.aro,ma); a.rotation.z=Math.PI/2; wh.add(a); const c=new THREE.Mesh(G.cubo,mc); c.rotation.z=Math.PI/2; wh.add(c);
    wh.position.set(sd*w/2,R,z); g.add(wh); ws.push(wh); })); return ws; }
function a3TexBadge(){ return A3.badgeTex||(A3.badgeTex=a3Tex(256,96,(x,w,h)=>{ x.fillStyle="#E9EEF2"; x.beginPath(); x.ellipse(w/2,h/2,w/2-4,h/2-4,0,0,Math.PI*2); x.fill(); x.strokeStyle="#0B3A66"; x.lineWidth=5; x.stroke(); x.fillStyle="#0B3A66"; x.font="bold 58px Arial"; x.textAlign="center"; x.textBaseline="middle"; x.fillText("SADA",w/2,h/2+3); })); }
/* cavalo mecânico cara-chata 6x4 (frente em z=+1.33, eixo dianteiro z=0.2, origem no chão) */
function a3Cab(g,rigido){
  const azul=A3.mAzul||(A3.mAzul=a3Mat(0x2196F0,{metalness:.35,roughness:.22,emissive:0x0a3a66,emissiveIntensity:.3})), preto=A3.mPreto||(A3.mPreto=a3Mat(0x15191c,{roughness:.6})),
    verm=A3.mVerm||(A3.mVerm=a3Mat(0xD42A26,{metalness:.3,roughness:.3})), cromo=A3.mCromo||(A3.mCromo=a3Mat(0xC8CFD4,{metalness:.9,roughness:.18})), cinza=A3.mCinza||(A3.mCinza=a3Mat(0x2B3136)),
    vidro=A3.mVidro||(A3.mVidro=a3Mat(0x0E2536,{metalness:.9,roughness:.06}));
  const add=(o,x,y,z)=>{ o.position.set(x,y,z); g.add(o); return o; };
  add(a3Box(1.1,.35,rigido?9.4:7.2,cinza),0,.95,rigido?-3.3:-2.25);
  add(a3Box(2.5,2.1,2.3,azul,.22),0,2.4,.18);                                              // cabine
  add(a3Box(2.46,1.0,2.2,azul,.3),0,3.84,.12);                                             // teto alto
  const def=add(a3Box(2.3,.45,1.5,azul,.2),0,4.44,-.12); def.rotation.x=.12;
  const pb=add(a3Box(2.2,1.0,.08,vidro,.04),0,2.92,1.3); pb.rotation.x=-.08;               // para-brisa
  add(a3Box(2.44,.2,.34,preto,.08),0,3.45,1.33);                                           // pala de sol
  add(a3Box(2.54,.17,2.34,verm,.08),0,2.3,.18);                                            // faixa vermelha
  add(a3Box(1.8,.95,.08,preto,.04),0,1.72,1.33);                                           // grade
  for(let i=0;i<4;i++) add(a3Box(1.66,.05,.04,cromo),0,1.4+i*.22,1.38);
  const bd=new THREE.Mesh(new THREE.PlaneGeometry(.66,.24),new THREE.MeshStandardMaterial({map:A3.portaTex,transparent:true})); add(bd,0,2.3,1.358);
  [-1,1].forEach(sd=>{
    add(a3Box(.55,.17,.06,a3Mat(0xffffff,{emissive:0xfff2c0,emissiveIntensity:.9}),.04),sd*.86,1.26,1.35);
    add(a3Box(.12,.75,.12,preto,.05),sd*1.38,2.85,1.02); add(a3Box(.22,.06,.06,preto),sd*1.3,3.15,1.02);
    add(a3Box(.1,.55,1.1,azul,.04),sd*1.26,1.1,-.1);
    const tq=new THREE.Mesh(new THREE.CylinderGeometry(.33,.33,1.25,20),cromo); tq.rotation.x=Math.PI/2; tq.castShadow=true; add(tq,sd*1.02,1.0,-1.45);
    const pt=new THREE.Mesh(new THREE.PlaneGeometry(1.05,.69),new THREE.MeshStandardMaterial({map:A3.portaTex,roughness:.35,metalness:.2,transparent:true})); pt.rotation.y=sd*Math.PI/2; add(pt,sd*1.263,1.82,.3);
    add(a3Box(.05,.85,1.85,vidro,.02),sd*1.257,2.9,.25);
  });
  add(a3Box(2.54,.46,.34,azul,.12),0,1.0,1.2); add(a3Box(2.3,.12,.34,preto,.04),0,.76,1.22);
  if(!rigido){ add(a3Box(1.3,.14,1.3,a3Mat(0x1a1d20,{metalness:.6}),.05),0,1.2,-4.25); add(a3Box(2.55,.1,2.6,preto,.04),0,1.3,-4.25); }
  return a3Wheels(g,rigido?[.2,-5.3,-6.6]:[.2,-3.6,-4.9]);
}
function a3NumFmt(n){ const s=String(n||"").toUpperCase().replace(/\s/g,""); const m=s.match(/^([A-Z]{4})(\d{6})(\d)$/); return m?{dono:m[1],ser:m[2],dv:m[3]}:(s?{dono:"",ser:s,dv:""}:null); }
function a3PintaNum(x,N,px,py,tam,alinha){ // escreve "ABCU 123456 [7]" com o dígito verificador em caixa
  x.font=`700 ${tam}px Arial`; x.textBaseline="middle"; const t1=(N.dono?N.dono+" ":"")+N.ser, w1=x.measureText(t1).width, wd=N.dv?x.measureText(N.dv).width+tam*.5:0, W=w1+(N.dv?tam*.35+wd:0);
  let x0=alinha==="right"?px-W:alinha==="center"?px-W/2:px; x.fillStyle="rgba(0,0,0,.35)"; x.fillText(t1,x0+2,py+2); x.fillStyle="#fff"; x.fillText(t1,x0,py);
  if(N.dv){ const bx=x0+w1+tam*.35; x.lineWidth=Math.max(2,tam*.08); x.strokeStyle="#fff"; x.strokeRect(bx,py-tam*.55,wd,tam*1.1); x.fillText(N.dv,bx+tam*.25,py); } }
function a3TexCnt(cor,len,num,parte,arm){ const k=[cor,len,num,parte,arm||""].join("|"); A3.texCnt=A3.texCnt||{}; if(A3.texCnt[k]) return A3.texCnt[k]; const hex="#"+cor.toString(16).padStart(6,"0"), N=a3NumFmt(num);
  let t;
  if(parte==="lado"){ const H=256, W=Math.min(2048,Math.round(H*len/2.6)); t=a3Tex(W,H,(x)=>{ x.fillStyle=hex; x.fillRect(0,0,W,H); const p=W/len*.28;
      for(let i=0;i<W;i+=p){ x.fillStyle="rgba(0,0,0,.18)"; x.fillRect(i,10,p*.42,H-20); x.fillStyle="rgba(255,255,255,.09)"; x.fillRect(i+p*.5,10,p*.15,H-20); }
      x.fillStyle="rgba(0,0,0,.28)"; x.fillRect(0,0,W,10); x.fillRect(0,H-10,W,10); x.fillRect(0,0,12,H); x.fillRect(W-12,0,12,H);
      if(arm){ const t=arm.toUpperCase(); let fs=Math.min(150,H*.58); x.font=`900 ${fs}px Arial`; while(x.measureText(t).width>W*.8&&fs>40){ fs-=6; x.font=`900 ${fs}px Arial`; }
        x.textAlign="center"; x.textBaseline="middle"; x.fillStyle="rgba(0,0,0,.3)"; x.fillText(t,W/2+3,H/2+5); x.fillStyle="#fff"; x.fillText(t,W/2,H/2+2); x.textAlign="left"; }
      else if(N) a3PintaNum(x,N,W-34,52,46,"right"); }); }
  else if(parte==="teto"){ const W=256, H=Math.min(2048,Math.round(W*len/2.45)); t=a3Tex(W,H,(x)=>{ x.fillStyle=hex; x.fillRect(0,0,W,H); x.fillStyle="rgba(255,255,255,.07)"; for(let i=0;i<H;i+=24) x.fillRect(0,i,W,8);
      if(N){ x.save(); x.translate(W/2,H/2); x.rotate(-Math.PI/2); a3PintaNum(x,N,0,0,Math.min(62,H/((N.ser.length+6)*.9)),"center"); x.restore(); } }); }
  else { t=a3Tex(256,110,(x,W,H)=>{ if(N) a3PintaNum(x,N,W/2,H/2,34,"center"); }); }
  return (A3.texCnt[k]=t); }
function a3Container(corHex,len=12,num="",arm=""){ const g=new THREE.Group();
  const lado=new THREE.MeshStandardMaterial({map:a3TexCnt(corHex,len,num,"lado",arm),roughness:.55,metalness:.25}), teto=new THREE.MeshStandardMaterial({map:a3TexCnt(corHex,len,num,"teto"),roughness:.55,metalness:.25}), liso=a3Mat(corHex,{roughness:.55,metalness:.25});
  const b=new THREE.Mesh(a3RGeo(2.45,2.6,len,.06),[lado,lado,teto,liso,liso,liso]); b.castShadow=true; b.receiveShadow=true; b.position.y=1.3; g.add(b);
  const pm=a3Mat(corHex,{roughness:.5,metalness:.3}); const portas=[];
  [-1,1].forEach(sd=>{ const piv=new THREE.Group(); piv.position.set(sd*1.22,1.3,-len/2-.02); const d=a3Box(1.2,2.5,.08,pm,.03); d.position.x=-sd*.6; piv.add(d);
    [-.3,.3].forEach(xx=>{ const bar=a3Box(.06,2.4,.06,a3Mat(0x9aa3a8,{metalness:.8})); bar.position.set(-sd*.6+xx*sd,0,-.06); piv.add(bar); });
    if(num&&sd===-1){ const pl=new THREE.Mesh(new THREE.PlaneGeometry(1.1,.47),new THREE.MeshBasicMaterial({map:a3TexCnt(corHex,len,num,"porta"),transparent:true})); pl.rotation.y=Math.PI; pl.position.set(.6,.85,-.1); piv.add(pl); }
    g.add(piv); portas.push({piv,sd}); });
  g.userData.portas=portas; return g; }
/* semirreboque esqueleto em coordenadas do reboque: origem = pino-rei no chão; z0 = frente */
function a3Esqueleto(g,z0,len,nEixos=3){ const cz=A3.mChassi||(A3.mChassi=a3Mat(0x2E3439,{metalness:.45,roughness:.45})), add=(o,x,y,z)=>{ o.position.set(x,y,z); g.add(o); return o; };
  [-1,1].forEach(sd=>add(a3Box(.24,.42,len,cz,.05),sd*.5,1.38,z0-len/2));
  for(let z=0;z<=len;z+=1.55) add(a3Box(2.44,.14,.14,cz),0,1.5,z0-z);
  add(a3Box(2.44,.3,.3,cz,.06),0,1.45,z0-.1); add(a3Box(2.44,.3,.3,cz,.06),0,1.45,z0-len+.1);
  [-1,1].forEach(sd=>{ add(a3Box(.14,.8,.14,cz),sd*.85,.85,z0-2.4); add(a3Box(.35,.06,.35,cz),sd*.85,.45,z0-2.4); });
  add(a3Box(2.4,.18,.12,cz),0,.9,z0-len+.02);
  [-1,1].forEach(sd=>add(a3Box(.3,.14,.05,new THREE.MeshBasicMaterial({color:0xff2a1a})),sd*.95,.9,z0-len-.05));
  const zs=[]; for(let i=0;i<nEixos;i++) zs.push(z0-len+1.1+i*1.2);
  add(a3Box(2.55,.08,nEixos*1.2+.4,A3.mPreto,.03),0,1.25,z0-len+1.1+(nEixos-1)*.6);
  return a3Wheels(g,zs);
}
/* veículo articulado: cavalo + reboques (cada reboque gira no pino-rei e segue a pista) */
function a3Veiculo(v){
  const tipo=v.tipo, cn=i=>A3_CNT[a3Hash(v.cns[i]||v.cns[0]+"#"+i)%A3_CNT.length], t40=!/20/.test(String(v.tam||""));
  const T=new THREE.Group(); let ws=[], conts=[], rebs=[], wb=4.45;
  const reb=()=>{ const r=new THREE.Group(); return r; };
  if(tipo==="truck"){ ws=a3Cab(T,true); const b=a3Box(2.5,2.7,6.6,a3Mat(0xEDEFF1,{roughness:.6}),.12); b.position.set(0,2.8,-4.6); T.add(b); wb=6.15; }
  else { ws=a3Cab(T);
    if(tipo==="bitrem"&&t40){ /* bitrem 9 eixos: duas carretas de 3 eixos, cada uma com um container de 40' */
      const r1=reb(); ws=ws.concat(a3Esqueleto(r1,.85,12.6,3)); const c1=a3Container(cn(0),12.1,v.cns[0],armadorDe(v.cns[0])); c1.position.set(0,1.57,-5.45); r1.add(c1);
      const H=12.6; const ext=a3Box(1.1,.3,1.05,A3.mChassi,.05); ext.position.set(0,1.3,-12.1); r1.add(ext);
      const qr=a3Box(1.2,.14,1.2,a3Mat(0x1a1d20,{metalness:.6}),.05); qr.position.set(0,1.22,-H); r1.add(qr);
      const r2=reb(); ws=ws.concat(a3Esqueleto(r2,.85,12.6,3)); const c2=a3Container(cn(1),12.1,v.cns[1],armadorDe(v.cns[1])); c2.position.set(0,1.57,-5.45); r2.add(c2);
      rebs=[{obj:r1,D:9.45,H},{obj:r2,D:9.45,H:0}]; conts=[c1,c2]; }
    else if(tipo==="bitrem"||tipo==="rodotrem"){
      const r1=reb(); ws=ws.concat(a3Esqueleto(r1,.85,7.6,2)); const c1=a3Container(cn(0),6.05,v.cns[0],armadorDe(v.cns[0])); c1.position.set(0,1.57,-2.95); r1.add(c1);
      const H=tipo==="rodotrem"?9.0:7.4; const ext=a3Box(1.1,.3,H-6.2,A3.mChassi,.05); ext.position.set(0,1.3,-6.75-(H-6.75)/2); r1.add(ext);
      const qr=a3Box(1.2,.14,1.2,a3Mat(0x1a1d20,{metalness:.6}),.05); qr.position.set(0,1.22,-H); r1.add(qr);
      const r2=reb(); ws=ws.concat(a3Esqueleto(r2,.85,7.6,2)); const c2=a3Container(cn(1),6.05,v.cns[1],armadorDe(v.cns[1])); c2.position.set(0,1.57,-2.95); r2.add(c2);
      if(tipo==="rodotrem"){ const d=a3Box(.9,.25,2,A3.mChassi,.05); d.position.set(0,1.0,1.35); r2.add(d); ws=ws.concat(a3Wheels(r2,[.95])); }
      rebs=[{obj:r1,D:5.05,H},{obj:r2,D:5.05,H:0}]; conts=[c1,c2]; }
    else if(tipo==="sider"){ const r1=reb(); ws=ws.concat(a3Esqueleto(r1,.85,12.6,3));
      const b=a3Box(2.5,2.8,12.4,a3Mat(0x1C80D4,{roughness:.8}),.1); b.position.set(0,3.0,-5.45); r1.add(b);
      for(let i=0;i<=12;i+=1.55){ const f=a3Box(2.54,2.8,.07,a3Mat(0xDDE3E8,{metalness:.5})); f.position.set(0,3.0,.75-i); r1.add(f); }
      const fx=a3Box(2.55,.28,12.4,a3Mat(0xD42A26),.05); fx.position.set(0,2.2,-5.45); r1.add(fx); rebs=[{obj:r1,D:9.45,H:0}]; }
    else { const r1=reb(); ws=ws.concat(a3Esqueleto(r1,.85,12.6,3));
      if(v.cns.length>=2){ conts=[0,1].map(i=>{ const c=a3Container(cn(i),6.05,v.cns[i],armadorDe(v.cns[i])); c.position.set(0,1.57,i?-8.6:-2.4); r1.add(c); return c; }); }
      else { const c=a3Container(cn(0),t40?12.1:6.05,v.cns[0],armadorDe(v.cns[0])); c.position.set(0,1.57,t40?-5.45:-2.45); r1.add(c); conts=[c]; } rebs=[{obj:r1,D:9.45,H:0}]; } }
  return {T,rebs,ws,conts,wb};
}
/* sinalizações sobre o veículo */
function a3Sirene(){ const g=new THREE.Group(); const base=new THREE.Mesh(new THREE.CylinderGeometry(.55,.65,.35,24),a3Mat(0x2b2f33)); g.add(base);
  const cup=new THREE.Mesh(new THREE.SphereGeometry(.6,24,14,0,Math.PI*2,0,Math.PI/2),new THREE.MeshStandardMaterial({color:0xff2a1a,emissive:0xff1a0a,emissiveIntensity:1.2,transparent:true,opacity:.85})); cup.position.y=.17; g.add(cup);
  const rot=new THREE.Group(); rot.position.y=.45; [0xff2020,0x2060ff].forEach((c,i)=>{ const p=new THREE.Mesh(a3RGeo(.9,.3,.14,.06),new THREE.MeshBasicMaterial({color:c})); p.rotation.y=i*Math.PI/2; rot.add(p); }); g.add(rot);
  const cone=new THREE.Mesh(new THREE.ConeGeometry(1.1,4,20,1,true),new THREE.MeshBasicMaterial({color:0xff3020,transparent:true,opacity:.14,side:THREE.DoubleSide,depthWrite:false})); cone.rotation.z=Math.PI/2; cone.position.x=2; const cg=new THREE.Group(); cg.add(cone); cg.position.y=.4; g.add(cg);
  g.userData={rot,cg,cup}; return g; }
function a3Exclam(){ const g=new THREE.Group(), m=new THREE.MeshStandardMaterial({color:0xF2A11A,emissive:0xE08A12,emissiveIntensity:.6,roughness:.3});
  const bar=new THREE.Mesh(THREE.CapsuleGeometry?new THREE.CapsuleGeometry(.28,1.3,6,14):new THREE.CylinderGeometry(.32,.2,1.8,20),m); bar.position.y=1.5; g.add(bar); const dot=new THREE.Mesh(new THREE.SphereGeometry(.3,18,12),m); dot.position.y=.2; g.add(dot);
  const ring=new THREE.Mesh(new THREE.TorusGeometry(1.4,.08,10,48),new THREE.MeshBasicMaterial({color:0xF2A11A,transparent:true,opacity:.7})); ring.rotation.x=Math.PI/2; ring.position.y=-.4; g.add(ring); g.userData={ring}; return g; }
function a3Joinha(){ const g=new THREE.Group(); const s=a3Emoji("👍",3.2); g.add(s); const ring=new THREE.Mesh(new THREE.TorusGeometry(1.5,.08,10,48),new THREE.MeshBasicMaterial({color:0x1C9F56,transparent:true,opacity:.8})); ring.rotation.x=Math.PI/2; ring.position.y=-1.6; g.add(ring); g.userData={s,ring}; return g; }
/* socorro e obras */
function a3Carro(tipo){ const g=new THREE.Group(); const corpo={amb:0xF7F7F7,pol:0x1E2A38,bomb:0xC8281E}[tipo], len=tipo==="bomb"?6:4.2;
  const b=a3Box(2,1.6,len,a3Mat(corpo,{metalness:.3,roughness:.35}),.3); b.position.y=1.25; g.add(b);
  if(tipo==="amb"){ const f=a3Box(2.03,.3,len-.3,a3Mat(0xD6281E),.1); f.position.y=1.3; g.add(f); const cr=a3Emoji("✚",1.4); cr.material.depthTest=true; cr.position.set(0,2.4,-1); g.add(cr); }
  if(tipo==="pol"){ const f=a3Box(2.03,.5,len*.6,a3Mat(0xFFFFFF),.1); f.position.set(0,1.25,.2); g.add(f); }
  if(tipo==="bomb"){ const e=a3Box(.5,.2,5,a3Mat(0xC9CED3,{metalness:.7}),.06); e.position.set(0,2.3,-.3); e.rotation.x=-.12; g.add(e); }
  const vd=a3Box(1.8,.6,.1,A3.mVidro||a3Mat(0x14324a,{metalness:.8}),.05); vd.position.set(0,1.65,len/2-.02); g.add(vd);
  a3Wheels(g,[len/2-.9,-len/2+.9],2,.45);
  const bar=new THREE.Group(); bar.position.y=2.15; const l1=new THREE.Mesh(a3RGeo(.6,.25,.35,.08),new THREE.MeshBasicMaterial({color:0xff2020})), l2=new THREE.Mesh(a3RGeo(.6,.25,.35,.08),new THREE.MeshBasicMaterial({color:tipo==="bomb"?0xff2020:0x2060ff}));
  l1.position.x=-.35; l2.position.x=.35; bar.add(l1,l2); g.add(bar); g.userData={l1,l2}; return g; }
function a3Trabalhador(){ const g=new THREE.Group(); const colete=a3Mat(0xFF7A00,{emissive:0x552200,emissiveIntensity:.3}), pele=a3Mat(0xC98B62), calca=a3Mat(0x2B4C7E);
  [-.22,.22].forEach(x=>{ const p=new THREE.Mesh(new THREE.CylinderGeometry(.16,.14,1,12),calca); p.position.set(x,.5,0); g.add(p); });
  const tr=new THREE.Mesh(new THREE.CylinderGeometry(.42,.36,1.1,16),colete); tr.position.y=1.5; tr.castShadow=true; g.add(tr);
  const fx=a3Box(.86,.1,.1,a3Mat(0xE8F0F4,{emissive:0x999999})); fx.position.set(0,1.45,.38); g.add(fx);
  const cab=new THREE.Mesh(new THREE.SphereGeometry(.3,18,14),pele); cab.position.y=2.35; g.add(cab);
  const cap=new THREE.Mesh(new THREE.SphereGeometry(.34,18,10,0,Math.PI*2,0,Math.PI/2),a3Mat(0xFFD21A,{roughness:.3})); cap.position.y=2.42; g.add(cap);
  const braco=new THREE.Group(); braco.position.set(.45,1.9,0); const ba=new THREE.Mesh(new THREE.CylinderGeometry(.12,.1,.9,10),colete); ba.position.y=-.4; braco.add(ba);
  const cabo=new THREE.Mesh(new THREE.CylinderGeometry(.05,.05,1.5,8),a3Mat(0x8B5A2B)); cabo.position.set(0,-.9,.5); cabo.rotation.x=Math.PI/2.4; braco.add(cabo);
  const pa=a3Box(.35,.05,.4,a3Mat(0x9aa3a8,{metalness:.8}),.02); pa.position.set(0,-1.2,1.15); braco.add(pa); g.add(braco); g.userData={braco}; return g; }
function a3Cone(){ const g=new THREE.Group(); const c=new THREE.Mesh(new THREE.ConeGeometry(.35,1,18),a3Mat(0xFF6A00)); c.position.y=.5; c.castShadow=true; g.add(c); const f=new THREE.Mesh(new THREE.CylinderGeometry(.24,.28,.14,18),a3Mat(0xffffff)); f.position.y=.55; g.add(f); return g; }

/* ---------- relevo real (SRTM, NASA — amostras via OpenTopoData) ---------- */
const A3_DEM={"lat0":-23.1,"dlat":0.1,"lon0":-44.8,"dlon":0.05,"rows":[[1384,566,6,0,0,0,0,0,0,0,0,0,108,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],[1451,1132,1159,1016,248,8,409,170,0,185,1,0,267,570,187,73,0,0,0,0,0,0,0,0,4,4,3,6,12,11,251,0,0,0,0,0,0,0,0,0,0],[1207,1389,1351,1119,1064,1318,1167,945,307,133,7,759,1186,998,233,589,616,476,425,3,2,8,6,21,20,29,237,173,185,47,38,26,33,0,14,115,136,91,120,18,11],[1255,1608,1473,1790,1421,1179,1258,1242,1571,1131,1077,1003,595,689,591,463,512,432,504,841,26,16,13,14,32,135,911,313,45,6,3,7,34,0,0,14,12,36,76,49,68],[847,984,806,1129,1479,1186,898,855,855,586,606,628,736,712,434,493,411,616,423,163,62,116,34,30,40,65,109,51,55,97,4,39,11,7,0,0,5,3,5,9,26],[625,619,614,616,548,484,624,575,537,563,418,483,455,600,476,414,642,496,455,433,586,363,51,69,429,536,1138,325,23,103,23,389,18,14,16,18,14,15,5,32,22],[652,614,571,514,445,411,427,447,510,519,554,549,456,482,378,419,378,453,488,464,401,515,486,577,623,353,207,751,823,919,1147,736,869,932,1381,1454,386,123,34,35,172],[2344,1354,1721,2139,1928,999,544,485,530,439,388,409,460,470,520,534,550,532,514,531,519,353,468,464,547,573,637,622,660,943,797,1262,1550,871,746,1078,928,979,944,855,814],[1335,2033,1394,1943,1384,1090,1007,1645,797,943,706,774,701,800,676,839,698,546,549,651,644,569,489,450,322,449,368,484,433,594,700,625,590,719,901,958,1158,820,952,878,1076],[1876,2078,1444,1234,1391,1566,1212,1348,1364,1312,1187,873,739,748,705,666,629,636,808,624,546,510,523,634,564,710,467,439,365,377,331,472,534,341,610,595,719,787,770,881,1105],[1294,1444,1371,1505,1142,1445,1480,1553,1206,1188,1392,1274,1303,794,736,644,760,726,531,436,601,489,474,568,407,460,500,507,650,442,465,438,331,280,373,351,538,555,690,732,769],[1147,1268,1582,1407,1043,1254,1091,1121,1156,1115,1130,1156,1399,1301,1108,1014,1176,1000,917,854,828,640,854,888,855,710,533,657,542,370,508,506,355,308,555,422,403,322,433,578,500],[1100,1158,1234,1170,1144,961,993,1130,1061,1242,1127,1121,1143,1106,1319,1015,900,824,1074,973,1061,1099,878,919,904,705,575,548,571,541,613,626,553,558,542,530,569,342,751,385,337],[1133,1076,1123,1064,1096,987,983,1045,991,981,1048,1224,1143,1158,1049,1218,1064,928,815,844,761,721,713,894,765,828,669,763,892,825,642,558,671,717,542,568,624,681,724,793,646],[1012,1046,1080,1057,1003,972,1039,1027,953,950,990,1058,1150,1135,1136,1109,1126,1170,1509,1036,894,843,750,826,836,797,712,720,808,824,866,807,770,767,601,621,597,650,666,656,544],[1021,1061,1105,1507,1426,1029,988,999,920,1003,1064,1014,1094,1148,1018,1136,1101,1104,1194,872,866,809,898,864,813,761,709,732,798,772,695,447,740,756,375,390,325,645,360,265,328],[965,945,950,1075,1164,986,1027,913,922,991,978,934,1011,974,1045,1092,1104,1097,1136,1185,1159,1136,871,769,846,854,829,771,753,556,414,494,473,444,452,532,375,371,300,321,303],[943,1050,1068,1004,1019,1000,911,951,945,972,1014,1021,1028,1066,1205,1103,1055,1126,1147,1131,1160,1188,1145,930,915,987,890,783,654,857,522,534,526,488,447,441,461,972,679,535,311],[950,884,943,973,941,938,971,976,1009,1012,1022,1038,1034,1038,991,1024,1015,1055,1108,1098,1081,1056,1139,1161,1207,1184,719,757,586,602,567,547,493,483,416,377,344,360,341,360,457],[849,879,868,901,1010,941,961,961,1044,991,1041,1019,990,1017,934,974,978,973,1080,1046,1083,1129,1212,1109,1211,906,887,715,813,624,581,751,569,523,580,387,409,401,339,377,330],[838,1040,853,868,918,866,874,866,877,931,1009,890,1050,985,973,962,990,1060,1077,1020,1102,1165,1150,1180,966,844,831,783,804,790,840,788,687,816,777,786,469,371,327,419,350],[905,917,987,962,932,986,963,1048,1071,1043,919,1022,991,1042,991,1051,1044,1058,1087,1104,1211,1133,1107,1115,762,753,781,749,735,812,789,818,804,900,763,768,787,499,388,345,361],[927,1009,1074,977,1042,1027,1059,942,1037,1069,943,1002,1010,1055,1040,992,983,1102,1071,1055,1032,773,788,761,775,797,775,692,681,768,808,770,717,729,668,758,778,809,746,572,398],[1056,1048,1060,1056,1070,1084,1170,1204,1053,1241,1153,1058,979,1025,952,965,924,1023,980,975,1108,990,813,807,745,723,754,778,807,785,821,765,649,772,698,753,712,703,807,737,752],[1011,1008,1073,1056,1110,1060,1050,1044,1012,1102,1068,1108,1036,971,914,943,954,944,891,985,995,1019,1028,747,788,688,805,832,665,757,657,600,752,701,674,810,619,701,678,708,791],[990,1033,857,945,832,908,904,978,930,1043,1174,1162,1124,1045,906,903,926,937,939,1016,948,1013,1041,1181,1321,1307,802,891,795,719,822,684,670,771,686,640,668,696,638,735,797],[982,914,946,817,888,793,784,808,1029,1120,1040,945,1006,1054,1004,994,849,1094,981,914,980,993,1046,1317,1036,1053,1013,1092,752,736,671,660,674,715,693,661,567,559,613,538,553],[861,902,892,781,834,910,955,1016,1003,907,978,1000,966,986,964,858,880,1030,1328,1132,1115,1087,1174,1285,1219,1236,1112,849,1059,773,686,664,566,610,588,611,514,489,442,556,499],[764,796,811,804,917,969,1064,1061,918,883,895,909,924,838,782,832,1009,1415,1239,1049,868,1064,958,1110,1051,1164,967,868,900,749,718,539,529,579,591,437,619,502,375,485,584],[765,801,795,883,1112,1075,1048,929,979,1103,818,974,888,780,834,968,896,1350,1268,1348,892,837,1007,1095,1476,1650,1134,941,827,843,786,820,782,660,600,616,683,670,485,339,428],[731,801,780,805,864,832,999,832,900,902,975,880,872,1149,1159,897,1169,1476,1192,1077,781,1119,1388,1200,859,1487,1350,1861,731,808,784,794,770,763,636,622,680,638,583,401,292],[743,780,769,760,818,988,937,853,789,762,861,751,828,874,814,949,1001,1034,1071,838,942,1108,1037,1110,994,1012,822,836,721,722,683,637,758,838,707,815,834,758,776,665,394],[728,791,737,853,922,867,924,816,832,708,865,863,911,861,873,880,853,912,806,865,814,972,992,999,1091,1084,1184,806,743,744,883,917,838,653,720,712,758,707,874,836,593],[752,775,712,784,868,799,999,742,717,749,755,898,858,913,889,808,816,775,885,742,859,819,1020,1102,938,1018,720,720,649,657,884,716,878,887,684,675,622,793,863,762,682],[791,930,861,962,807,745,745,758,804,800,800,875,888,930,776,787,761,745,684,726,677,747,756,889,1024,908,704,715,662,733,917,813,814,836,768,593,622,459,647,532,728],[724,923,762,802,802,696,720,837,733,776,879,842,863,927,827,780,777,732,718,781,736,701,774,1062,1021,1111,728,649,661,696,954,1030,840,867,981,947,966,1013,761,483,309],[660,697,808,804,742,760,724,707,739,753,769,825,815,863,814,742,696,717,706,693,736,728,721,1030,1422,1465,1554,907,652,615,661,730,813,642,726,1033,914,975,767,954,975],[782,710,752,734,731,704,758,696,861,818,1008,905,707,718,768,759,680,726,699,788,756,798,847,869,1076,1326,1499,1135,668,648,690,679,676,819,606,815,615,941,856,1088,1015],[704,704,669,793,673,689,733,764,777,753,819,724,736,670,678,752,669,687,680,798,910,800,810,848,1097,1253,1339,991,918,764,700,644,522,670,604,655,506,706,841,902,629],[749,720,673,727,704,748,777,728,764,862,861,725,661,682,670,634,681,723,749,878,781,746,724,1117,1141,1340,1314,1145,815,597,580,887,756,623,709,563,669,510,430,627,416]]};
const A3_ALT={rio:8,caxias:4,serra:456,petropolis:821,areal:283,simao:495,matias:484,jf:708,sdumont:844,barbacena:1165,carandai:1108,lafaiete:997,congonhas:906,novalima:1034,bh:904,neves:803,sete:765,betim:837}; // altitude (m) de cada ponto da rota, SRTM
const A3_S=175, A3_K=Math.cos(21*Math.PI/180), A3_HM=.026; // escala horizontal (unid./grau) e vertical (unid./metro)
function a3XZ(ll){ return new THREE.Vector3((ll[1]+43.7)*A3_K*A3_S, 0, (ll[0]+21.2)*A3_S); }
function a3Grid(){ if(A3.grid) return A3.grid; const R=A3_DEM.rows, nr=R.length, nc=R[0].length, G=[];
  for(let i=0;i<nr;i++){ G.push([]); for(let j=0;j<nc;j++){ const v=R[i][j]; if(v<=0){ G[i].push(-9); continue; }
    let s=0,w=0; for(let a=-1;a<=1;a++) for(let b=-1;b<=1;b++){ const x=(R[i+a]||[])[j+b]; if(x==null||x<=0) continue; const k=(a||b)?(a&&b?1:2):4; s+=x*k; w+=k; } G[i].push(s/w); } }
  return (A3.grid={G,nr,nc}); }
function a3DemM(lat,lon){ const {G,nr,nc}=a3Grid(); let fi=(lat-A3_DEM.lat0)/A3_DEM.dlat, fj=(lon-A3_DEM.lon0)/A3_DEM.dlon; fi=Math.max(0,Math.min(nr-1.001,fi)); fj=Math.max(0,Math.min(nc-1.001,fj));
  const i=Math.floor(fi), j=Math.floor(fj), a=fi-i, b=fj-j, s=t=>t*t*(3-2*t), A=s(a), B=s(b);
  return (G[i][j]*(1-B)+G[i][j+1]*B)*(1-A)+(G[i+1][j]*(1-B)+G[i+1][j+1]*B)*A; }
function a3Ruido(x,z){ const h=(i,j)=>{ const s=Math.sin(i*127.1+j*311.7)*43758.5453; return s-Math.floor(s); }, n=(x,z)=>{ const i=Math.floor(x), j=Math.floor(z), a=x-i, b=z-j, u=a*a*(3-2*a), v=b*b*(3-2*b);
  return (h(i,j)*(1-u)+h(i+1,j)*u)*(1-v)+(h(i,j+1)*(1-u)+h(i+1,j+1)*u)*v; }; return n(x/9,z/9)*.6+n(x/3.5,z/3.5)*.3+n(x/1.4,z/1.4)*.1-.5; }
function a3DemY(x,z){ const m=a3DemM(z/A3_S-21.2, x/(A3_K*A3_S)-43.7); return (m>12? m+a3Ruido(x,z)*70 : m)*A3_HM; }
const A3_BORDA=700*A3_HM;
function a3Sm(t0,t1,x){ const t=Math.max(0,Math.min(1,(x-t0)/(t1-t0))); return t*t*(3-2*t); }
/* perfil da rodovia: relevo suavizado ao longo do traçado + altitude real de cada cidade */
function a3Perfil(cv,ids){ const L=cv.getLength(), N=Math.ceil(L/1.5), raw=new Float32Array(N+1), xs=new Float32Array(N+1), zs=new Float32Array(N+1);
  for(let i=0;i<=N;i++){ const p=cv.getPointAt(i/N); xs[i]=p.x; zs[i]=p.z; raw[i]=Math.max(.3,a3DemY(p.x,p.z)); }
  const media=(src,w)=>{ const o=new Float32Array(src.length); for(let i=0;i<src.length;i++){ let s=0,c=0; for(let k=-w;k<=w;k++){ const j=Math.max(0,Math.min(src.length-1,i+k)); s+=src[j]; c++; } o[i]=s/c; } return o; };
  let sm=media(media(media(raw,12),12),12);
  const marcas=ids.filter(id=>NO[id]&&A3_ALT[id]!=null).map(id=>{ const p=a3XZ(NO[id].ll); let bi=0,bd=1e9; for(let i=0;i<=N;i++){ const d=(xs[i]-p.x)**2+(zs[i]-p.z)**2; if(d<bd){ bd=d; bi=i; } } return {i:bi,d:A3_ALT[id]*A3_HM-sm[bi]}; }).sort((a,b)=>a.i-b.i);
  const cor=new Float32Array(N+1); for(let i=0;i<=N;i++){ let v; if(!marcas.length) v=0; else if(i<=marcas[0].i) v=marcas[0].d; else if(i>=marcas[marcas.length-1].i) v=marcas[marcas.length-1].d;
    else { for(let k=0;k<marcas.length-1;k++){ const A=marcas[k],B=marcas[k+1]; if(i>=A.i&&i<=B.i){ const f=(i-A.i)/Math.max(1,B.i-A.i); v=A.d+(B.d-A.d)*(f*f*(3-2*f)); break; } } } cor[i]=v; }
  let hs=new Float32Array(N+1); for(let i=0;i<=N;i++) hs[i]=Math.max(.35,sm[i]+cor[i]); hs=media(hs,4);
  cv.userData={N,L,hs,xs,zs}; }
function a3RoadY(cv,u){ const {N,hs}=cv.userData, f=Math.max(0,Math.min(1,u))*N, i=Math.min(N-1,Math.floor(f)), a=f-i; return hs[i]*(1-a)+hs[i+1]*a; }
function a3IndexaEstradas(){ const H=new Map(), C=12; [A3.curve,A3.curveB,...(A3.acessos||[])].filter(Boolean).forEach(cv=>{ const {N,hs,xs,zs}=cv.userData; for(let i=0;i<=N;i++){ const k=Math.floor(xs[i]/C)+","+Math.floor(zs[i]/C); if(!H.has(k)) H.set(k,[]); H.get(k).push(xs[i],zs[i],hs[i]); } }); A3.rhash={H,C}; }
function a3PertoRoad(x,z,max){ const {H,C}=A3.rhash, ci=Math.floor(x/C), cj=Math.floor(z/C), rr=Math.ceil(max/C); let bd=max*max, by=null;
  for(let a=-rr;a<=rr;a++) for(let b=-rr;b<=rr;b++){ const L=H.get((ci+a)+","+(cj+b)); if(!L) continue; for(let k=0;k<L.length;k+=3){ const d=(L[k]-x)**2+(L[k+1]-z)**2; if(d<bd){ bd=d; by=L[k+2]; } } }
  return by==null?null:{d:Math.sqrt(bd),y:by}; }
function a3PertoEstrada(p,dist){ return !!a3PertoRoad(p.x,p.z,dist); }
function a3Chao(x,z){ let y=a3DemY(x,z);
  (A3.pads||[]).forEach(p=>{ const d=Math.hypot(x-p.x,z-p.z); if(d<p.r+26) y=p.y+(y-p.y)*a3Sm(p.r,p.r+26,d); });
  const r=a3PertoRoad(x,z,42); if(r) y=(r.y-.3)+(y-(r.y-.3))*a3Sm(9,42,r.d); return y; }
/* ---------- cenário ---------- */
function a3Montar(el){
  const W=el.clientWidth, H=el.clientHeight, CEU=0xCFE6F3;
  const sc=new THREE.Scene(); sc.fog=new THREE.Fog(CEU,900,2600);
  const cam=new THREE.PerspectiveCamera(42,W/H,.5,5000);
  const rd=new THREE.WebGLRenderer({antialias:true}); rd.setPixelRatio(Math.min(window.devicePixelRatio||1,2)); rd.setSize(W,H); rd.shadowMap.enabled=true; rd.shadowMap.type=THREE.PCFSoftShadowMap;
  el.appendChild(rd.domElement);
  // céu em degradê
  const ceu=new THREE.Mesh(new THREE.SphereGeometry(3000,32,16),new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,fog:false,uniforms:{a:{value:new THREE.Color(0x6FAEE0)},b:{value:new THREE.Color(CEU)}},
    vertexShader:"varying vec3 p; void main(){ p=normalize(position); gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }",
    fragmentShader:"uniform vec3 a; uniform vec3 b; varying vec3 p; void main(){ float t=smoothstep(-0.05,0.5,p.y); vec3 c=mix(b,a,t); c=mix(vec3(0.93,0.95,0.96),c,smoothstep(-0.35,0.0,p.y)); gl_FragColor=vec4(c,1.0); }"})); ceu.renderOrder=-1; sc.add(ceu); A3.ceu=ceu;
  sc.add(new THREE.HemisphereLight(0xE3F1FF,0x3d5a30,.6)); const sol=new THREE.DirectionalLight(0xFFF0D6,1.05); sol.castShadow=true;
  sol.shadow.mapSize.set(2048,2048); sol.shadow.bias=-0.0004; sol.shadow.normalBias=.4; Object.assign(sol.shadow.camera,{left:-110,right:110,top:110,bottom:-110,near:1,far:900}); sc.add(sol); sc.add(sol.target); A3.sol=sol;
  const ctl=new THREE.OrbitControls(cam,rd.domElement); ctl.enableDamping=true; ctl.dampingFactor=.08; ctl.maxPolarAngle=Math.PI/2.08; ctl.minDistance=10; ctl.maxDistance=1300;
  Object.assign(A3,{scene:sc,camera:cam,renderer:rd,controls:ctl,clock:new THREE.Clock()});
  // traçado da rodovia (curvas suaves) e perfil de altitude
  const pts=LINHA_SETE.filter(id=>NO[id]&&NO[id].ll).map(id=>a3XZ(NO[id].ll));
  A3.curve=new THREE.CatmullRomCurve3(pts,false,"centripetal"); A3.curve.arcLengthDivisions=3000; A3.curve.updateArcLengths();
  const bh=NO.bh, bt=NO.betim; if(bh&&bt){ const pb=a3XZ(bh.ll); let bi=0,bd=1e9; for(let i=0;i<=1500;i++){ const q=A3.curve.getPointAt(i/1500), d=(q.x-pb.x)**2+(q.z-pb.z)**2; if(d<bd){ bd=d; bi=i; } }
    const LA=A3.curve.getLength(), u0=Math.max(0,bi/1500-30/LA); A3.sB0=u0*LA;
    const t0=A3.curve.getTangentAt(u0), p0=A3.curve.getPointAt(u0), p1=p0.clone().addScaledVector(t0,8), pe=a3XZ(bt.ll), pm=p1.clone().lerp(pe,.45).addScaledVector(t0,6);
    A3.curveB=new THREE.CatmullRomCurve3([p0,p1,pm,pe],false,"centripetal"); A3.curveB.arcLengthDivisions=600; A3.curveB.updateArcLengths(); }
  a3Perfil(A3.curve,LINHA_SETE); if(A3.curveB) a3Perfil(A3.curveB,["bh","betim"]); A3.acessos=[];
  { const pb=a3XZ(NO.bh.ll); let bi=0,bd=1e9; for(let i=0;i<=3000;i++){ const q=A3.curve.getPointAt(i/3000), d=(q.x-pb.x)**2+(q.z-pb.z)**2; if(d<bd){ bd=d; bi=i; } } A3.sBH=bi/3000*A3.curve.userData.L; }
  // áreas planas: porto e plantas
  const rio=a3XZ(NO.rio.ll); A3.portoC=new THREE.Vector3(rio.x-26,.6,rio.z-4); A3.pads=[{x:A3.portoC.x,z:A3.portoC.z,r:58,y:.6}];
  A3.plantas={}; a3PlantaPos(A3.curve,"Iveco 7 Lagoas",1.4); if(A3.curveB) a3PlantaPos(A3.curveB,"Sada Betim",1.15); a3IndexaEstradas();
  a3Terreno(sc); [A3.curve,A3.curveB,...A3.acessos].filter(Boolean).forEach(cv=>a3Estrada(sc,cv));
  a3Paisagem(sc); a3Cidades(sc); a3Porto(sc); Object.keys(A3.plantas).forEach(k=>a3Planta(sc,k)); a3Nuvens(sc);
  a3VisaoGeral();
  // interação
  const ray=new THREE.Raycaster(), mouse=new THREE.Vector2();
  const pick=ev=>{ const r=rd.domElement.getBoundingClientRect(); mouse.x=((ev.clientX-r.left)/r.width)*2-1; mouse.y=-((ev.clientY-r.top)/r.height)*2+1; ray.setFromCamera(mouse,cam);
    const hit=ray.intersectObjects(A3.pick,true)[0]; let o=hit&&hit.object; while(o&&!o.userData.v) o=o.parent; return o||null; };
  let down=null; rd.domElement.addEventListener("pointerdown",e=>{ down=[e.clientX,e.clientY]; });
  rd.domElement.addEventListener("pointerup",e=>{ if(!down||Math.hypot(e.clientX-down[0],e.clientY-down[1])>6) return; const o=pick(e); a3Selecionar(o?o.userData.v:null, o&&(o.userData.trator||o)); });
  rd.domElement.addEventListener("pointerleave",()=>{ const t=document.getElementById("a3-tip"); t&&(t.hidden=true); });
  rd.domElement.addEventListener("pointermove",e=>{ const o=pick(e); rd.domElement.style.cursor=o?"pointer":"grab"; const tip=document.getElementById("a3-tip");
    if(o&&tip){ const v=o.userData.v; tip.innerHTML=`<b>${esc(v.placa||v.cns[0])}</b> · ${esc(v.cns.join(" + "))}<br><span>${esc(v.sitTxt)}</span>${v.f&&v.f.localizacao?`<br><span>📍 Follow: ${esc(lugar(v.f.localizacao))}</span>`:""}`; tip.hidden=false; const r=el.getBoundingClientRect(); tip.style.left=(e.clientX-r.left+14)+"px"; tip.style.top=(e.clientY-r.top+14)+"px"; } else if(tip) tip.hidden=true; });
  new ResizeObserver(()=>{ const w=el.clientWidth,h=el.clientHeight; if(!w||!h) return; cam.aspect=w/h; cam.updateProjectionMatrix(); rd.setSize(w,h); }).observe(el);
  A3.ok=true;
}
function a3VisaoGeral(){ const bx=new THREE.Box3(); [A3.curve,A3.curveB].filter(Boolean).forEach(cv=>cv.getSpacedPoints(60).forEach(p=>bx.expandByPoint(p)));
  Object.values(A3.plantas||{}).forEach(pl=>bx.expandByPoint(pl.c)); const c=bx.getCenter(new THREE.Vector3()), sz=bx.getSize(new THREE.Vector3()), R=Math.max(sz.x,sz.z);
  const asp=A3.camera.aspect||1.6, d=R*(asp<1?1.6:1.1); c.z+=R*.08; c.y=8; A3.controls.target.copy(c); A3.camera.position.set(c.x+d*.3,d*.72,c.z+d*.55); A3.controls.update(); }
/* malha do terreno com cores por altitude e declividade */
function a3Terreno(sc){ const x0=-240,x1=210,z0=-365,z1=420; A3.tbounds={x0,x1,z0,z1};
  const nx=176, nz=306, geo=new THREE.PlaneGeometry(x1-x0,z1-z0,nx,nz); geo.rotateX(-Math.PI/2); geo.translate((x0+x1)/2,0,(z0+z1)/2);
  const P=geo.attributes.position, cor=new Float32Array(P.count*3);
  for(let i=0;i<P.count;i++){ const x=P.getX(i), z=P.getZ(i); P.setY(i,a3Chao(x,z)); }
  geo.computeVertexNormals(); const Nn=geo.attributes.normal, c=new THREE.Color();
  const C={areia:new THREE.Color(0xD8C9A0),baixa:new THREE.Color(0x5B9B43),media:new THREE.Color(0x4C8A3B),alta:new THREE.Color(0x7C9A4E),topo:new THREE.Color(0x8E8A6E),mata:new THREE.Color(0x2E5E2B),terra:new THREE.Color(0xA08C70)};
  for(let i=0;i<P.count;i++){ const x=P.getX(i), z=P.getZ(i), y=P.getY(i), m=y/A3_HM, ny=Nn.getY(i);
    if(m<4) c.copy(C.areia); else if(m<450) c.copy(C.baixa).lerp(C.media,a3Sm(150,450,m)); else if(m<1050) c.copy(C.media).lerp(C.alta,a3Sm(700,1050,m)); else c.copy(C.alta).lerp(C.topo,a3Sm(1150,1600,m));
    c.lerp(C.mata,a3Sm(.96,.8,ny)*.8);
    const r=a3PertoRoad(x,z,11); if(r) c.lerp(C.terra,a3Sm(11,7,r.d)*.7);
    c.offsetHSL(0,0,a3Ruido(x*2.3,z*2.3)*.12);
    cor[i*3]=c.r; cor[i*3+1]=c.g; cor[i*3+2]=c.b; }
  geo.setAttribute("color",new THREE.BufferAttribute(cor,3));
  const m=new THREE.Mesh(geo,new THREE.MeshStandardMaterial({vertexColors:true,roughness:.95,metalness:0})); m.receiveShadow=true; sc.add(m); A3.terreno=m;
  // laterais do bloco (maquete): camadas de solo e, onde é mar, água
  const BASE=-16, pos=[], col=[], idx=[], terra1=new THREE.Color(0x6B4A2E), terra2=new THREE.Color(0x3B2A1C), mar1=new THREE.Color(0x2C7DB6), mar2=new THREE.Color(0x173F63);
  const borda=(pts)=>{ const o=pos.length/3; pts.forEach(([x,z])=>{ const y=a3Chao(x,z), mar=y<0, top=Math.max(y,-.04); pos.push(x,top,z, x,BASE,z); const c1=mar?mar1:terra1, c2=mar?mar2:terra2; col.push(c1.r,c1.g,c1.b,c2.r,c2.g,c2.b); });
    for(let i=0;i<pts.length-1;i++){ const a=o+i*2; idx.push(a,a+1,a+2, a+1,a+3,a+2); } };
  const lado=(xa,za,xb,zb,n)=>{ const p=[]; for(let i=0;i<=n;i++){ const t=i/n; p.push([xa+(xb-xa)*t,za+(zb-za)*t]); } borda(p); };
  lado(x0,z0,x1,z0,nx); lado(x1,z0,x1,z1,nz); lado(x1,z1,x0,z1,nx); lado(x0,z1,x0,z0,nz);
  const sg=new THREE.BufferGeometry(); sg.setAttribute("position",new THREE.Float32BufferAttribute(pos,3)); sg.setAttribute("color",new THREE.Float32BufferAttribute(col,3)); sg.setIndex(idx); sg.computeVertexNormals();
  sc.add(new THREE.Mesh(sg,new THREE.MeshStandardMaterial({vertexColors:true,roughness:.9,side:THREE.DoubleSide})));
  const fundo=a3Box(x1-x0,.6,z1-z0,a3Mat(0x2A1E14,{roughness:1})); fundo.position.set((x0+x1)/2,BASE-.3,(z0+z1)/2); fundo.castShadow=false; sc.add(fundo);
  A3.agua=new THREE.Mesh(new THREE.PlaneGeometry(x1-x0,z1-z0),new THREE.MeshStandardMaterial({color:0x2C7DB6,roughness:.12,metalness:.25,transparent:true,opacity:.93})); A3.agua.rotation.x=-Math.PI/2; A3.agua.position.set((x0+x1)/2,-.04,(z0+z1)/2); A3.agua.receiveShadow=true; sc.add(A3.agua);
  // sombra suave sob a maquete
  const sh=new THREE.Mesh(new THREE.PlaneGeometry(1,1),new THREE.MeshBasicMaterial({map:a3Tex(256,256,(x,w,h)=>{ const g=x.createRadialGradient(w/2,h/2,10,w/2,h/2,w/2); g.addColorStop(0,"rgba(40,60,80,.45)"); g.addColorStop(1,"rgba(40,60,80,0)"); x.fillStyle=g; x.fillRect(0,0,w,h); }),transparent:true,depthWrite:false}));
  sh.rotation.x=-Math.PI/2; sh.scale.set((x1-x0)*1.5,(z1-z0)*1.4,1); sh.position.set((x0+x1)/2,BASE-22,(z0+z1)/2); sc.add(sh);
}
/* rodovia texturizada: asfalto, faixa amarela tracejada, bordas brancas e acostamento */
function a3TexPista(){ return A3.texPista||(A3.texPista=(()=>{ const t=a3Tex(256,1024,(x,w,h)=>{ x.fillStyle="#474C52"; x.fillRect(0,0,w,h);
    for(let i=0;i<5000;i++){ const g=60+Math.random()*40|0; x.fillStyle=`rgba(${g},${g+3},${g+6},.35)`; x.fillRect(Math.random()*w,Math.random()*h,2,2); }
    x.fillStyle="#EDEDE8"; x.fillRect(w*.045,0,w*.025,h); x.fillRect(w*.93,0,w*.025,h);
    x.fillStyle="#F2C230"; for(let y=0;y<h;y+=h/2){ x.fillRect(w*.49,y+h*.06,w*.022,h*.24); } });
  t.wrapS=THREE.ClampToEdgeWrapping; t.wrapT=THREE.RepeatWrapping; t.anisotropy=8; return t; })()); }
function a3Estrada(sc,cv){ const {N,L,hs,xs,zs}=cv.userData;
  const faixa=(Lw,dy,mat,uv)=>{ const pos=new Float32Array((N+1)*6), uvs=new Float32Array((N+1)*4), idx=[];
    for(let i=0;i<=N;i++){ const tg=cv.getTangentAt(i/N), nx=-tg.z, nz=tg.x, y=hs[i]+dy;
      pos.set([xs[i]-nx*Lw,y,zs[i]-nz*Lw, xs[i]+nx*Lw,y,zs[i]+nz*Lw],i*6); const v=i*L/N/20; uvs.set([0,v,1,v],i*4);
      if(i<N){ const a=i*2; idx.push(a,a+2,a+1, a+1,a+2,a+3); } }
    const g=new THREE.BufferGeometry(); g.setAttribute("position",new THREE.BufferAttribute(pos,3)); g.setAttribute("uv",new THREE.BufferAttribute(uvs,2)); g.setIndex(idx); g.computeVertexNormals();
    const m=new THREE.Mesh(g,mat); m.receiveShadow=true; sc.add(m); return m; };
  faixa(7.2,.02,new THREE.MeshStandardMaterial({color:0x9C9486,roughness:1,side:THREE.DoubleSide,polygonOffset:true,polygonOffsetFactor:-1}));
  faixa(5.2,.14,new THREE.MeshStandardMaterial({map:a3TexPista(),roughness:.85,side:THREE.DoubleSide,polygonOffset:true,polygonOffsetFactor:-2}));
  // defensas metálicas nos trechos de serra
  const post=new THREE.CylinderGeometry(.08,.08,.9,6), mp=a3Mat(0xB9C0C6,{metalness:.8,roughness:.3}), trilho=[];
  for(let i=4;i<N-4;i+=3){ const dy=Math.abs(hs[i+3]-hs[i-3]); if(dy<.55) continue; const tg=cv.getTangentAt(i/N), nx=-tg.z, nz=tg.x; [-1,1].forEach(sd=>trilho.push([xs[i]+nx*6.4*sd,hs[i]+.5,zs[i]+nz*6.4*sd])); }
  if(trilho.length){ const im=new THREE.InstancedMesh(post,mp,trilho.length), M=new THREE.Matrix4(); trilho.forEach((p,i)=>{ M.makeTranslation(p[0],p[1],p[2]); im.setMatrixAt(i,M); }); sc.add(im); }
}
function a3Rnd(seed){ let s=seed; return ()=>{ s=(s*16807)%2147483647; return (s-1)/2147483646; }; }
/* vegetação realista: espécies da região (Mata Atlântica, ipês floridos, araucárias nas serras, eucaliptais em MG, palmeiras no litoral) */
function a3Merge(partes){ const P=[],N=[],C=[], c=new THREE.Color(), v=new THREE.Vector3(), nrm=new THREE.Vector3();
  partes.forEach(pt=>{ const g=pt.geo.index?pt.geo.toNonIndexed():pt.geo, pos=g.attributes.position, nor=g.attributes.normal, M=pt.m||new THREE.Matrix4(), NM=new THREE.Matrix3().getNormalMatrix(M);
    for(let i=0;i<pos.count;i++){ v.fromBufferAttribute(pos,i); const loc=v.clone(); v.applyMatrix4(M); P.push(v.x,v.y,v.z);
      if(pt.esfera){ nrm.copy(loc).normalize().applyMatrix3(NM).normalize(); } else { nrm.fromBufferAttribute(nor,i).applyMatrix3(NM).normalize(); } N.push(nrm.x,nrm.y,nrm.z);
      pt.cor(c,loc,v); C.push(c.r,c.g,c.b); } });
  const g=new THREE.BufferGeometry(); g.setAttribute("position",new THREE.Float32BufferAttribute(P,3)); g.setAttribute("normal",new THREE.Float32BufferAttribute(N,3)); g.setAttribute("color",new THREE.Float32BufferAttribute(C,3)); return g; }
function a3Copa(r,seed,det=1){ const g=new THREE.IcosahedronGeometry(r,det), p=g.attributes.position, v=new THREE.Vector3();
  for(let i=0;i<p.count;i++){ v.fromBufferAttribute(p,i); const n=a3Ruido(v.x*1.7+seed*13,v.z*1.7+v.y*1.3+seed*7); v.multiplyScalar(1+n*.55); p.setXYZ(i,v.x,v.y,v.z); } return g; }
function a3CorFolha(base,var_=.08){ const b=new THREE.Color(base); return (c,loc)=>{ c.copy(b); const k=a3Sm(-1.2,1.6,loc.y); c.offsetHSL((a3Ruido(loc.x*3,loc.z*3))*.03, 0, -.12+k*.2+a3Ruido(loc.x*5+3,loc.y*5)*var_); }; }
function a3CorTronco(base){ const b=new THREE.Color(base); return (c,loc)=>{ c.copy(b).offsetHSL(0,0,a3Ruido(loc.y*4,loc.x*9)*.1); }; }
function a3Especies(){ if(A3.especies) return A3.especies; const M=(x,y,z,rx=0,ry=0,rz=0,sx=1,sy=1,sz=1)=>new THREE.Matrix4().compose(new THREE.Vector3(x,y,z),new THREE.Quaternion().setFromEuler(new THREE.Euler(rx,ry,rz)),new THREE.Vector3(sx,sy,sz));
  const tronco=(r0,r1,h)=>new THREE.CylinderGeometry(r1,r0,h,9,3), E={};
  // folhosa da Mata Atlântica (copa irregular em vários volumes)
  E.folhosa=[0,1,2].map(sd=>{ const parts=[{geo:tronco(.42,.22,6),m:M(0,3,0),cor:a3CorTronco(0x5E4632)},{geo:tronco(.2,.1,3.2),m:M(.8,5.6,0,0,0,-.7),cor:a3CorTronco(0x5E4632)},{geo:tronco(.18,.1,3),m:M(-.7,5.9,.3,.3,0,.7),cor:a3CorTronco(0x5E4632)}];
    const r=a3Rnd(31+sd), base=[0x2F6B2E,0x3A7A32,0x2B5F2A][sd];
    for(let i=0;i<5;i++){ const a=r()*Math.PI*2, d=i?1.4+r()*.9:0, rr=i?1.9+r()*.8:2.7; parts.push({geo:a3Copa(rr,sd*5+i),m:M(Math.cos(a)*d,7.2+(i?r()*1.6-.4:1.2),Math.sin(a)*d),cor:a3CorFolha(base),esfera:true}); }
    return a3Merge(parts); });
  // ipê (copa larga) — amarelo, roxo e verde
  const ipe=(cor)=>{ const parts=[{geo:tronco(.36,.2,5.2),m:M(0,2.6,0),cor:a3CorTronco(0x6A5140)}]; const r=a3Rnd(77);
    for(let i=0;i<6;i++){ const a=i/6*Math.PI*2, d=i?2.1:0; parts.push({geo:a3Copa(1.9,40+i),m:M(Math.cos(a)*d*(i?1:0),6.2+r()*.8,Math.sin(a)*d*(i?1:0),0,0,0,1,.62,1),cor:a3CorFolha(cor,.05),esfera:true}); }
    return a3Merge(parts); };
  E.ipeAmarelo=ipe(0xF2C31B); E.ipeRoxo=ipe(0xC5569E);
  // eucalipto: tronco alto e claro, copa estreita
  E.eucalipto=a3Merge([{geo:tronco(.3,.14,17),m:M(0,8.5,0),cor:a3CorTronco(0xCBC2B0)}].concat([0,1,2].map(i=>({geo:a3Copa(1.4,60+i),m:M((i-1)*.35,13.5+i*2.1,(i%2)*.3,0,0,0,.8,1.7,.8),cor:a3CorFolha(0x5E7F4A,.06),esfera:true}))));
  // araucária: fuste reto e copa em forma de taça
  const ar=[{geo:tronco(.42,.3,15),m:M(0,7.5,0),cor:a3CorTronco(0x4A3A2E)}];
  for(let k=0;k<2;k++) for(let i=0;i<8;i++){ const a=i/8*Math.PI*2+k*.4, L=k?3.2:4.4, ang=k?.55:.75, y=k?15.8:14.6;
    ar.push({geo:tronco(.12,.07,L),m:new THREE.Matrix4().makeTranslation(Math.cos(a)*L/2*Math.sin(ang),y+L/2*Math.cos(ang),Math.sin(a)*L/2*Math.sin(ang)).multiply(new THREE.Matrix4().makeRotationY(-a)).multiply(new THREE.Matrix4().makeRotationZ(-ang)),cor:a3CorTronco(0x4A3A2E)});
    ar.push({geo:a3Copa(1.1,90+i+k*8),m:M(Math.cos(a)*L*Math.sin(ang),y+L*Math.cos(ang)+.3,Math.sin(a)*L*Math.sin(ang),0,0,0,1.5,.45,1.5),cor:a3CorFolha(0x234F2A,.05),esfera:true}); }
  E.araucaria=a3Merge(ar);
  // palmeira (litoral)
  const pa=[]; for(let i=0;i<5;i++) pa.push({geo:tronco(.28-.02*i,.26-.02*i,2.4),m:M(i*.12,1.2+i*2.3,0,0,0,-.04*i),cor:a3CorTronco(0x8B7355)});
  for(let i=0;i<9;i++){ const a=i/9*Math.PI*2; const fr=new THREE.ConeGeometry(.5,5.2,4,1); pa.push({geo:fr,m:new THREE.Matrix4().makeTranslation(.6,12,0).multiply(new THREE.Matrix4().makeRotationY(a)).multiply(new THREE.Matrix4().makeRotationZ(-1.95)).multiply(new THREE.Matrix4().makeTranslation(0,2.5,0)).multiply(new THREE.Matrix4().makeScale(1,1,.18)),cor:a3CorFolha(0x3F8A36,.05)}); }
  E.palmeira=a3Merge(pa);
  // arbusto
  E.arbusto=a3Merge([0,1,2].map(i=>({geo:a3Copa(1.1,120+i),m:M((i-1)*.9,1.0,(i%2)*.6,0,0,0,1,.8,1),cor:a3CorFolha(0x3F7A33),esfera:true})));
  return (A3.especies=E); }
function a3MatArvore(){ if(A3.mArv) return A3.mArv; const m=new THREE.MeshStandardMaterial({vertexColors:true,roughness:.85,metalness:0}); A3.uVento=A3.uVento||{value:0};
  m.onBeforeCompile=sh=>{ sh.uniforms.uT=A3.uVento; sh.vertexShader="uniform float uT;\n"+sh.vertexShader.replace("#include <begin_vertex>",
    "#include <begin_vertex>\n#ifdef USE_INSTANCING\n vec4 wp=instanceMatrix*vec4(0.,0.,0.,1.);\n float hh=max(0.,position.y-2.5);\n transformed.x+=sin(uT*1.4+wp.x*.21+wp.z*.13)*.018*hh*hh*.12+sin(uT*3.1+wp.z)*.01*hh;\n transformed.z+=cos(uT*1.1+wp.z*.19)*.014*hh*hh*.12;\n#endif"); };
  return (A3.mArv=m); }
function a3Paisagem(sc){ const r=a3Rnd(7), B=A3.tbounds, E=a3Especies(), L={}; Object.keys(E).forEach(k=>L[k]=[]);
  const livre=(x,z,dr)=>!a3PertoRoad(x,z,dr)&&!(A3.pads||[]).some(p=>Math.hypot(x-p.x,z-p.z)<p.r+8);
  const incl=(x,z)=>Math.hypot(a3DemY(x+3,z)-a3DemY(x-3,z),a3DemY(x,z+3)-a3DemY(x,z-3))/6;
  for(let i=0;i<7000&&L.folhosa.length+L.araucaria.length+L.palmeira.length+L.ipeAmarelo.length<2300;i++){ const x=B.x0+4+r()*(B.x1-B.x0-8), z=B.z0+4+r()*(B.z1-B.z0-8), m=a3DemY(x,z)/A3_HM; if(m<8) continue;
    if(!livre(x,z,15)) continue; const s=incl(x,z); if(r()>.28+Math.min(.68,s*2)) continue; const y=a3Chao(x,z); let esp;
    const q=r(); if(m<70&&z<-200) esp=q<.45?"palmeira":"folhosa"; else if(m>950&&q<.2) esp="araucaria"; else if(q<.045) esp="ipeAmarelo"; else if(q<.07) esp="ipeRoxo"; else esp="folhosa";
    L[esp].push({x,y,z,s:.75+r()*.55,v:(r()*3)|0}); }
  // eucaliptais em talhões (planalto mineiro)
  for(let k=0,f=0;k<400&&f<16;k++){ const cx=B.x0+30+r()*(B.x1-B.x0-60), cz=-120+r()*(B.z1+100), m=a3DemY(cx,cz)/A3_HM; if(m<700||incl(cx,cz)>.12||!livre(cx,cz,40)) continue; f++;
    const ang=r()*Math.PI, ca=Math.cos(ang), sa=Math.sin(ang), nx=6+(r()*5|0), nz=4+(r()*4|0);
    for(let a=0;a<nx;a++) for(let b=0;b<nz;b++){ const lx=(a-nx/2)*4.6, lz=(b-nz/2)*4.6, x=cx+lx*ca-lz*sa, z=cz+lx*sa+lz*ca; if(!livre(x,z,14)) continue; L.eucalipto.push({x,y:a3Chao(x,z),z,s:.85+r()*.3,v:0}); } }
  for(let i=0;i<2500&&L.arbusto.length<900;i++){ const x=B.x0+4+r()*(B.x1-B.x0-8), z=B.z0+4+r()*(B.z1-B.z0-8); if(a3DemY(x,z)<8*A3_HM||!livre(x,z,11)) continue; L.arbusto.push({x,y:a3Chao(x,z),z,s:.7+r()*.8,v:0}); }
  const mat=a3MatArvore(), Mx=new THREE.Matrix4(), q=new THREE.Quaternion(), e=new THREE.Euler(), pv=new THREE.Vector3(), sv=new THREE.Vector3();
  const inst=(geo,lst)=>{ if(!lst.length) return; const im=new THREE.InstancedMesh(geo,mat,lst.length); im.castShadow=true; im.receiveShadow=true;
    lst.forEach((o,i)=>{ q.setFromEuler(e.set((r()-.5)*.06,r()*Math.PI*2,(r()-.5)*.06)); Mx.compose(pv.set(o.x,o.y-.2,o.z),q,sv.set(o.s,o.s*(.9+r()*.25),o.s)); im.setMatrixAt(i,Mx); }); sc.add(im); };
  [0,1,2].forEach(v=>inst(E.folhosa[v],L.folhosa.filter(o=>o.v===v)));
  ["ipeAmarelo","ipeRoxo","eucalipto","araucaria","palmeira","arbusto"].forEach(k=>inst(E[k],L[k]));
}
function a3Nuvens(sc){ const r=a3Rnd(21), m=new THREE.MeshStandardMaterial({color:0xffffff,roughness:1,transparent:true,opacity:.78,emissive:0xffffff,emissiveIntensity:.3,depthWrite:false}), geo=new THREE.SphereGeometry(1,16,12); A3.nuvens=[];
  for(let i=0;i<11;i++){ const g=new THREE.Group(); for(let k=0;k<5;k++){ const s=new THREE.Mesh(geo,m); const e=9+r()*10; s.scale.set(e*1.4,e*.6,e); s.position.set((k-2)*11+r()*6,r()*4,r()*8-4); g.add(s); }
    g.position.set(-240+r()*450,110+r()*40,-360+r()*780); sc.add(g); A3.nuvens.push(g); } }
function a3Cidades(sc){ const r=a3Rnd(11), cores=[0xEDE5D6,0xD9E4EC,0xF3DCC8,0xDDE8D4,0xE8D9E6]; const telh=a3Mat(0xB5543A,{roughness:.8});
  LINHA_SETE.concat(["betim","esmeraldas","pleopoldo","matozinhos"]).forEach(id=>{ const n=NO[id]; if(!n||!n.ll||id==="rio"||id==="sete"||id==="betim") return; const p=a3XZ(n.ll);
  const grande=["petropolis","jf","barbacena","lafaiete","bh"].includes(id), qt=grande?14:7;
  for(let i=0;i<qt;i++){ const h=2+r()*(grande?9:5), x=p.x+18+(r()-.5)*(grande?30:16), z=p.z+4+(r()-.5)*(grande?30:16); if(a3PertoRoad(x,z,12)||(A3.pads||[]).some(p=>Math.hypot(x-p.x,z-p.z)<p.r+6)) continue; const y=a3Chao(x,z);
    const b=a3Box(3+r()*2.5,h,3+r()*2.5,a3Mat(cores[i%5],{roughness:.7}),.25); b.position.set(x,y+h/2,z); b.rotation.y=r()*1.5; sc.add(b);
    if(h<5){ const t=new THREE.Mesh(new THREE.ConeGeometry(2.6,1.4,4),telh); t.position.set(x,y+h+.7,z); t.rotation.y=b.rotation.y+Math.PI/4; t.castShadow=true; sc.add(t); } }
  const lb=a3Sprite(n.n,{tam:28,escala:grande?1.1:.85}); lb.position.set(p.x+16,a3Chao(p.x+16,p.z)+13,p.z+2); sc.add(lb); if(!grande) (A3.cidLb=A3.cidLb||[]).push(lb); }); }
/* empilhadeira de containers (reach stacker) em operação no pátio */
function a3Stacker(g){ const S=new THREE.Group(), red=a3Mat(0xD3302B,{metalness:.35,roughness:.3}), blk=a3Mat(0x23272A,{metalness:.5,roughness:.35}), wht=a3Mat(0xF2F2F2,{roughness:.4}), vid=A3.mVidro||a3Mat(0x0E2536,{metalness:.9,roughness:.06});
  const add=(o,x,y,z,p=S)=>{ o.position.set(x,y,z); p.add(o); return o; };
  add(a3Box(3.0,1.3,7.2,red,.25),0,1.55,0);                                 // chassi
  add(a3Box(3.05,.18,7.0,wht,.05),0,1.25,0);                                 // faixa branca
  add(a3Box(3.1,1.7,1.4,red,.3),0,2.0,-3.6);                                 // contrapeso
  for(let i=0;i<4;i++){ const f=a3Box(3.12,.12,.5,wht,.03); f.position.set(0,1.4+i*.35,-4.02); f.rotation.x=.9; S.add(f); }
  add(a3Box(1.5,2.1,1.9,red,.25),-.7,3.1,.4); add(a3Box(1.52,1.2,1.7,vid,.12),-.7,3.4,.6); add(a3Box(1.6,.2,2.0,red,.08),-.7,4.2,.4); // cabine
  const gir=add(new THREE.Mesh(new THREE.CylinderGeometry(.16,.16,.25,14),new THREE.MeshStandardMaterial({color:0xFF9A1A,emissive:0xFF7A00,emissiveIntensity:1})),-.7,4.4,.4);
  a3Wheels(S,[2.3],2.7,.95); a3Wheels(S,[-2.5],2.6,.8);
  // lança telescópica (gira em torno do pino traseiro)
  const piv=add(new THREE.Group(),.55,3.2,-2.9); const b1=a3Box(.95,.95,7.6,blk,.12); b1.position.z=3.8; piv.add(b1);
  const inner=a3Box(.72,.72,6.4,blk,.1); piv.add(inner);
  const plaq=new THREE.Mesh(new THREE.PlaneGeometry(1.7,.62),new THREE.MeshStandardMaterial({map:A3.portaTex,transparent:true})); plaq.rotation.y=-Math.PI/2; plaq.position.set(-.49,0,4.2); piv.add(plaq);
  const cil=new THREE.Mesh(new THREE.CylinderGeometry(.2,.2,1,14),a3Mat(0xB9C0C6,{metalness:.9,roughness:.2})); cil.castShadow=true; S.add(cil);
  // spreader (garra) pendurado na ponta
  const sp=new THREE.Group(); S.add(sp); const rot=a3Box(.9,.45,.9,a3Mat(0xF2B21A,{metalness:.3}),.12); rot.position.y=-.25; sp.add(rot);
  const bar=a3Box(6.2,.45,.55,a3Mat(0x2F3438,{metalness:.5}),.08); bar.position.y=-.65; sp.add(bar); [-1,1].forEach(s=>{ const t=a3Box(.35,.3,2.3,a3Mat(0xF2B21A),.06); t.position.set(s*2.95,-.65,0); sp.add(t); });
  const carga=a3Container(0xB93A32,5.6,""); carga.rotation.y=Math.PI/2; S.add(carga); // o container viaja no referencial da máquina
  g.add(S); const solto=a3Container(0xB93A32,5.6,""); g.add(solto);
  return {S,piv,inner,cil,sp,carga,solto,gir,rodas:S.children.filter(o=>o.isGroup&&o!==piv&&o!==sp&&o.children.length===5)}; }
const A3_ST_K=[ // t, px, yaw(0 = virada para a pilha), lx (alcance), ly (altura da ponta)
  [0,7.5,Math.PI,5.5,6],[2,7.5,Math.PI,5.5,3.2],[3,7.5,Math.PI,5,5.5],[6,9.5,Math.PI,4.5,5],[9,9.5,0,4.5,5],[13,12,0,6,11.8],[15,12,0,6,11.0],[17,10,0,5,7],[20,10,Math.PI,5,6],[24,7.5,Math.PI,5.5,6]];
function a3StackerPasso(st,tt){ const ph=tt%48, t=ph<24?ph:48-ph; let k=0; while(k<A3_ST_K.length-2&&A3_ST_K[k+1][0]<=t) k++;
  const A=A3_ST_K[k], B=A3_ST_K[k+1], f0=(t-A[0])/(B[0]-A[0]), f=f0*f0*(3-2*f0), L=(i)=>A[i]+(B[i]-A[i])*f;
  const px=L(1), yaw=L(2), lx=L(3), ly=L(4), Z=-7.5, Y=.4;
  st.S.position.set(px,Y,Z); st.S.rotation.y=yaw+Math.PI/2;
  const dz=lx-(-2.9), dy=ly-3.2, th=Math.atan2(dy,dz), Lb=Math.hypot(dz,dy); st.piv.rotation.x=-th; st.inner.position.z=Lb-3.2;
  st.sp.position.set(.55,ly,lx); // ponta da lança no referencial da máquina
  const a=new THREE.Vector3(.55,1.9,.9), b=new THREE.Vector3(.55,3.2+Math.sin(th)*3.6,-2.9+Math.cos(th)*3.6); st.cil.position.copy(a).add(b).multiplyScalar(.5); st.cil.scale.y=a.distanceTo(b); st.cil.lookAt(st.S.localToWorld(b.clone())); st.cil.rotateX(Math.PI/2);
  const leva=t>2&&t<15; st.carga.visible=leva; st.solto.visible=!leva;
  if(leva) st.carga.position.set(.55,ly-3.2,lx); else { st.solto.position.set(t<=2?2:18,t<=2?.4:8.2,Z); st.solto.rotation.y=0; }
  const v=Math.abs(px-(st.px0==null?px:st.px0)); st.px0=px; st.rodas.forEach(w=>w.rotation.x+=v/.9);
  st.gir.material.emissiveIntensity=.4+Math.abs(Math.sin(tt*6))*1.2; }
function a3Porto(sc){ const r=a3Rnd(3), c=A3.portoC, g=new THREE.Group(); g.position.copy(c); sc.add(g);
  const cais=a3Box(70,.6,40,a3Mat(0xB9BEC2,{roughness:.9}),.3); cais.position.set(32,.1,-4); g.add(cais);
  for(let i=0;i<3;i++){ const gu=new THREE.Group(); const m=a3Mat(0xE0A020,{metalness:.4,roughness:.4}); [-3,3].forEach(x=>{ const pe=a3Box(.8,18,.8,m,.2); pe.position.set(x,9,0); gu.add(pe); }); const topo=a3Box(8,1.2,22,m,.3); topo.position.set(0,18,6); gu.add(topo);
    const cab=a3Box(1.5,1.2,1.5,a3Mat(0x2b2f33),.2); cab.position.set(0,16.6,12); gu.add(cab); gu.position.set(56,.4,-18+i*14); gu.rotation.y=Math.PI/2; g.add(gu); }
  for(let i=0;i<42;i++){ const ct=a3Container(A3_CNT[i%A3_CNT.length],5.6); ct.position.set(18+(i%7)*3.1,.4+Math.floor(i/14)*2.6,-14+Math.floor((i%14)/7)*6.5); g.add(ct); }
  const lb=a3Sprite("Sada Caju - RJ",{tam:34,escala:1.3,cor:"#0B3A5C"}); lb.position.set(c.x+30,32,c.z); sc.add(lb);
  A3.portoPos=new THREE.Vector3(c.x-22,c.y,c.z+14); A3.stacker=a3Stacker(g); }
/* áreas urbanas (centro de cada cidade) — pátios não podem invadir */
function a3AreasUrbanas(){ if(A3.urb) return A3.urb; const grandes=["petropolis","jf","barbacena","lafaiete","bh"];
  return (A3.urb=LINHA_SETE.concat(["betim","esmeraldas","pleopoldo","matozinhos"]).filter(id=>NO[id]&&NO[id].ll&&id!=="rio"&&id!=="sete"&&id!=="betim").map(id=>{ const p=a3XZ(NO[id].ll); return {id,x:p.x+18,z:p.z+4,r:grandes.includes(id)?24:14}; })); }
function a3PlantaGeo(esc){ const L=24.6/esc, r0=L+3, r1=2*L+6, zEnd=3*L+8; return {L,r0,r1,zEnd,zMin:-17,zMax:zEnd+9}; }
function a3PlantaPos(cv,nome,esc){ const end=cv.getPointAt(1), tg=cv.getTangentAt(1), rot=Math.atan2(-tg.x,-tg.z), y=a3RoadY(cv,1), U=a3AreasUrbanas(), G=a3PlantaGeo(esc);
  const fwd=new THREE.Vector3(Math.sin(rot),0,Math.cos(rot)), cz=(G.zMin+G.zMax)/2, R=Math.hypot(30,(G.zMax-G.zMin)/2)*esc; let D=G.zMax*esc+6, pos, c;
  for(let k=0;k<60;k++){ pos=new THREE.Vector3(end.x+tg.x*D,y,end.z+tg.z*D); c=pos.clone().addScaledVector(fwd,cz*esc);
    if(U.every(u=>Math.hypot(c.x-u.x,c.z-u.z)>R+u.r+6)) break; D+=4; }
  const frente=D-G.zMax*esc; // da ponta da rodovia até a portaria
  if(frente>1){ const a=end.clone(), b=new THREE.Vector3(end.x+tg.x*(frente+2),0,end.z+tg.z*(frente+2)), m=a.clone().lerp(b,.5); a.y=b.y=m.y=0;
    const ac=new THREE.CatmullRomCurve3([a,m,b]); ac.arcLengthDivisions=200; ac.updateArcLengths(); const L=ac.getLength(), N=Math.max(4,Math.ceil(L/1.5)), hs=new Float32Array(N+1), xs=new Float32Array(N+1), zs=new Float32Array(N+1);
    for(let i=0;i<=N;i++){ const q=ac.getPointAt(i/N); xs[i]=q.x; zs[i]=q.z; hs[i]=y; } ac.userData={N,L,hs,xs,zs}; A3.acessos.push(ac); }
  A3.plantas[nome]={pos,rot,esc,fwd,c,y,G}; A3.pads.push({x:c.x,z:c.z,r:R,y}); }
/* textura listrada vermelho/branco da cancela */
function a3TexCancela(){ return A3.texCanc||(A3.texCanc=a3Tex(256,32,(x,w,h)=>{ for(let i=0;i<8;i++){ x.fillStyle=i%2?"#FFFFFF":"#D6281E"; x.fillRect(i*w/8,0,w/8,h); } })); }
function a3Vigilante(){ const g=new THREE.Group(); const farda=a3Mat(0x1E2A44,{roughness:.7}), pele=a3Mat(0xC98B62), preto=a3Mat(0x15191c);
  [-.2,.2].forEach(x=>{ const p=new THREE.Mesh(new THREE.CylinderGeometry(.15,.14,1,10),farda); p.position.set(x,.5,0); g.add(p); const b=a3Box(.24,.14,.4,preto,.05); b.position.set(x,.07,.06); g.add(b); });
  const tr=new THREE.Mesh(new THREE.CylinderGeometry(.4,.34,1.1,14),farda); tr.position.y=1.52; tr.castShadow=true; g.add(tr);
  const cint=new THREE.Mesh(new THREE.CylinderGeometry(.36,.36,.12,14),preto); cint.position.y=1.02; g.add(cint);
  const dist=a3Box(.26,.16,.04,a3Mat(0xE0B040,{metalness:.8}),.02); dist.position.set(.18,1.75,.37); g.add(dist);
  const cab=new THREE.Mesh(new THREE.SphereGeometry(.28,16,12),pele); cab.position.y=2.35; g.add(cab);
  const bone=new THREE.Mesh(new THREE.CylinderGeometry(.3,.3,.18,16),preto); bone.position.y=2.55; g.add(bone); const aba=a3Box(.36,.04,.3,preto,.02); aba.position.set(0,2.49,.3); g.add(aba);
  const bE=new THREE.Mesh(new THREE.CylinderGeometry(.11,.09,.95,10),farda); bE.position.set(-.48,1.55,0); g.add(bE);
  const braco=new THREE.Group(); braco.position.set(.46,2,0); const bD=new THREE.Mesh(new THREE.CylinderGeometry(.11,.09,.95,10),farda); bD.position.y=-.45; braco.add(bD); const mao=new THREE.Mesh(new THREE.SphereGeometry(.1,10,8),pele); mao.position.y=-.95; braco.add(mao); g.add(braco);
  g.userData.braco=braco; return g; }
/* portaria: guarita, cobertura, cancelas de entrada e saída, vigilantes, lombadas, placas e alambrado */
function a3Portaria(g,z,nome,xMin,xMax,zFundo){ const cinza=a3Mat(0xD7DBDE,{roughness:.6}), vid=A3.mVidro||a3Mat(0x0E2536,{metalness:.9,roughness:.06}), met=a3Mat(0x8A949C,{metalness:.7,roughness:.3}), amar=a3Mat(0xF2C230), preto=a3Mat(0x1d2124);
  const add=(o,x,y,zz)=>{ o.position.set(x,y,zz); g.add(o); return o; };
  // piso da portaria (continuação do pátio) e ilha central
  add(a3Box(22,.3,9,a3Mat(0x9EA4A9,{roughness:.9}),.1),0,.15,z+4.2);
  add(a3Box(3.2,.35,8,a3Mat(0xC9CDD0),.12),0,.3,z+4.2);
  for(let k=0;k<6;k++){ const f=a3Box(.5,.36,.2,k%2?amar:preto); f.position.set(0,.31,z+.4+k*1.5); g.add(f); } // zebrado da ilha
  // guarita
  add(a3Box(2.6,2.4,3.2,cinza,.12),0,1.7,z+4.2);
  add(a3Box(2.66,1.0,2.6,vid,.05),0,2.1,z+4.2);
  add(a3Box(3.6,.28,4.4,a3Mat(0x1F4E8C,{roughness:.5}),.1),0,3.05,z+4.2);
  const pl=new THREE.Mesh(new THREE.PlaneGeometry(2.6,.55),new THREE.MeshBasicMaterial({map:a3Tex(256,56,(x,w,h)=>{ x.fillStyle="#1F4E8C"; x.fillRect(0,0,w,h); x.fillStyle="#fff"; x.font="bold 34px Arial"; x.textAlign="center"; x.textBaseline="middle"; x.fillText("PORTARIA",w/2,h/2+2); })}));
  pl.position.set(0,3.45,z+6.45); g.add(pl); const pl2=pl.clone(); pl2.rotation.y=Math.PI; pl2.position.z=z+1.95; g.add(pl2);
  // cobertura sobre as duas faixas
  add(a3Box(20,.35,7,a3Mat(0xE9ECEE,{metalness:.3,roughness:.4}),.12),0,5.3,z+4.2);
  [-9.5,9.5].forEach(x=>[z+1.2,z+7.2].forEach(zz=>add(new THREE.Mesh(new THREE.CylinderGeometry(.18,.18,5.2,12),met),x,2.7,zz)));
  const faixaCob=new THREE.Mesh(new THREE.PlaneGeometry(12,1),new THREE.MeshBasicMaterial({map:a3Tex(512,44,(x,w,h)=>{ x.fillStyle="#0B3A66"; x.fillRect(0,0,w,h); x.fillStyle="#fff"; x.font="bold 30px Arial"; x.textAlign="center"; x.textBaseline="middle"; x.fillText(nome.toUpperCase()+" · ENTRADA E SAÍDA DE VEÍCULOS",w/2,h/2+2); })}));
  faixaCob.position.set(0,5.3,z+7.72); g.add(faixaCob);
  // cancelas (entrada à direita de quem chega, saída à esquerda)
  const canc=[]; [[1,"ent"],[-1,"sai"]].forEach(([s,tp])=>{ const px=s*1.9, zz=tp==="ent"?z+7.4:z+1.0;
    add(a3Box(.55,1.2,.55,a3Mat(0xF2C230),.1),px,.9,zz);
    const piv=new THREE.Group(); piv.position.set(px,1.35,zz); g.add(piv);
    const braco=new THREE.Mesh(new THREE.BoxGeometry(6.4,.16,.16),new THREE.MeshStandardMaterial({map:a3TexCancela(),roughness:.4})); braco.position.x=s*3.3; braco.castShadow=true; piv.add(braco);
    const luz=new THREE.Mesh(new THREE.SphereGeometry(.12,10,8),new THREE.MeshBasicMaterial({color:0xff2a1a})); luz.position.set(px,1.62,zz); g.add(luz);
    canc.push({piv,s,luz,fase:tp==="ent"?0:7});
    // lombada e faixa de parada
    for(let k=0;k<8;k++){ const f=a3Box(.75,.12,.9,k%2?amar:preto,.05); f.position.set(s*(2.3+k*.75),.36,tp==="ent"?z+11:z-2.6); g.add(f); }
    const pare=a3Box(6.5,.02,.35,new THREE.MeshBasicMaterial({color:0xffffff})); pare.position.set(s*5.4,.32,tp==="ent"?z+8.3:z+.1); g.add(pare); });
  // placa PARE e iluminação
  const poste=add(new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,2.4,8),met),10.6,1.35,z+9.6);
  const pare=new THREE.Mesh(new THREE.CircleGeometry(.6,8),new THREE.MeshBasicMaterial({map:a3Tex(128,128,(x,w,h)=>{ x.fillStyle="#C8281E"; x.beginPath(); for(let i=0;i<8;i++){ const a=Math.PI/8+i*Math.PI/4; x.lineTo(w/2+Math.cos(a)*62,h/2+Math.sin(a)*62); } x.fill(); x.fillStyle="#fff"; x.font="bold 38px Arial"; x.textAlign="center"; x.textBaseline="middle"; x.fillText("PARE",w/2,h/2+2); }),side:THREE.DoubleSide}));
  pare.position.set(10.6,2.7,z+9.7); g.add(pare);
  [[-11,z+8],[11,z+.5]].forEach(([x,zz])=>{ add(new THREE.Mesh(new THREE.CylinderGeometry(.1,.14,7,8),met),x,3.5,zz); add(a3Box(1.2,.2,.5,a3Mat(0xFFF6C8,{emissive:0xFFE9A0,emissiveIntensity:.8}),.05),x+(x<0?.6:-.6),7,zz); });
  // vigilantes
  const v1=a3Vigilante(); v1.position.set(.9,.46,z+8.55); v1.rotation.y=Math.PI*.25; g.add(v1);
  const v2=a3Vigilante(); v2.position.set(-1.3,.3,z+5.6); v2.rotation.y=-Math.PI/2; g.add(v2);
  // alambrado em volta do pátio, com abertura na portaria
  const tela=new THREE.MeshStandardMaterial({map:(()=>{ const t=a3Tex(64,64,(x,w,h)=>{ x.strokeStyle="rgba(170,180,188,.95)"; x.lineWidth=3; x.beginPath(); x.moveTo(0,0); x.lineTo(w,h); x.moveTo(w,0); x.lineTo(0,h); x.stroke(); x.fillStyle="rgba(120,130,140,.9)"; x.fillRect(0,0,w,4); }); t.wrapS=t.wrapT=THREE.RepeatWrapping; return t; })(),transparent:true,side:THREE.DoubleSide,depthWrite:false,alphaTest:.05});
  const muro=(xa,za,xb,zb)=>{ const L=Math.hypot(xb-xa,zb-za); if(L<.5) return; const m=new THREE.Mesh(new THREE.PlaneGeometry(L,2.2),tela.clone()); m.material.map=tela.map.clone(); m.material.map.needsUpdate=true; m.material.map.repeat.set(L/1.2,2); m.position.set((xa+xb)/2,1.25,(za+zb)/2); m.rotation.y=-Math.atan2(zb-za,xb-xa); g.add(m);
    for(let s=0;s<=L;s+=3.5){ const t=s/L; add(new THREE.Mesh(new THREE.CylinderGeometry(.06,.06,2.4,6),met),xa+(xb-xa)*t,1.2,za+(zb-za)*t); } };
  muro(xMin,zFundo,xMin,z); muro(xMax,zFundo,xMax,z); muro(xMin,z,-10.5,z); muro(10.5,z,xMax,z);
  return {canc,vig:[v1,v2]}; }
function a3Planta(sc,nome){ const P=A3.plantas[nome], esc=P.esc, G=P.G, g=new THREE.Group(); g.position.copy(P.pos); g.rotation.y=P.rot; g.scale.setScalar(esc); sc.add(g); g.updateMatrixWorld(true); P.g=g;
  const zA=-2, zB=G.zEnd; const pat=a3Box(52,.3,zB-zA,a3Mat(0xAEB4B9,{roughness:.9}),.12); pat.position.set(0,.15,(zA+zB)/2); g.add(pat);
  const bm=new THREE.MeshBasicMaterial({color:0xffffff}), am=new THREE.MeshBasicMaterial({color:0xF2C230});
  for(let i=0;i<9;i++){ const f=a3Box(.12,.02,G.L,am); f.position.set(-21.6+i*5.4,.32,G.L/2); g.add(f); } // baias das docas
  const faixaP=a3Box(48,.02,.18,am); faixaP.position.set(0,.32,G.L+1.2); g.add(faixaP);
  [G.r0,G.r1].forEach(zr=>{ for(let i=0;i<10;i++){ const f=a3Box(.12,.02,G.L,bm); f.position.set(-24.3+i*5.4,.32,zr+G.L/2); g.add(f); } }); // vagas do pátio
  const tx=a3Sprite("PÁTIO",{tam:22,escala:.6,cor:"#fff",fundo:"rgba(60,70,80,.75)"}); tx.position.set(23,3,G.r0+G.L/2); g.add(tx);
  const gal=a3Box(40,9,16,a3Mat(0xE8ECEF,{roughness:.6}),.4); gal.position.set(0,4.5,-8); g.add(gal);
  const tet=new THREE.Mesh(new THREE.CylinderGeometry(9,9,41,40,1,true,.55,Math.PI-1.1),a3Mat(0x7A8792,{metalness:.5,roughness:.35,side:THREE.DoubleSide})); tet.rotation.z=Math.PI/2; tet.position.set(0,4.3,-8); tet.castShadow=true; g.add(tet);
  for(let i=0;i<8;i++){ const d=a3Box(3.6,4.4,.2,a3Mat(0x2F3A44),.08); d.position.set(-18.9+i*5.4,2.2,.05); g.add(d); }
  const faixa=a3Box(40.2,1.2,.1,a3Mat(0x1F4E8C),.05); faixa.position.set(0,7.6,.05); g.add(faixa);
  const port=a3Portaria(g,G.zEnd,nome,-26,26,0); A3.portarias=A3.portarias||[]; A3.portarias.push(port);
  const lb=a3Sprite(nome,{tam:34,escala:1.3,cor:"#0B5B35"}); lb.position.copy(g.localToWorld(new THREE.Vector3(0,20,-8))); sc.add(lb); }
function a3PortariaPasso(dt,tt){ (A3.portarias||[]).forEach(P=>{ P.canc.forEach(c=>{ const T=(tt+c.fase)%14, up=T<1.5?T/1.5:T<5?1:T<6.5?1-(T-5)/1.5:0, e=up*up*(3-2*up);
      c.piv.rotation.z=c.s*e*1.45; c.luz.material.color.setHex(e>.9?0x2ECC40:(Math.floor(tt*3)%2?0xff2a1a:0x551010)); });
    P.vig.forEach((v,i)=>{ const b=v.userData.braco; const T=(tt+i*4)%14; b.rotation.x=T<5? -1.2-Math.sin(tt*6)*.35 : -.05; b.rotation.z=T<5? .2:0; }); }); }
/* ---------- veículos a partir do follow ---------- */
function a3Tipo(p){ const t=String((p&&p.tipo_veiculo)||"").toUpperCase(); return /BITREM/.test(t)?"bitrem":/RODO/.test(t)?"rodotrem":/SIDER/.test(t)?"sider":/TRUCK/.test(t)?"truck":"carreta"; }
function a3Dados(){
  const sel=A3.selCn&&A3.selCn.size?A3.selCn:null, hoje=iso(new Date()).slice(0,10);
  const base=biLinhas(), emOp=new Set(biFiltra(base).map(r=>r.cn)); const rows=sel? base.filter(r=>sel.has(r.cn)) : biFiltra(base,"carga").filter(r=>emOp.has(r.cn)||(r.carga==="entregue"&&r.f&&r.f.chegada&&dia(r.f.chegada)===hoje));
  const RK={crit:0,warn:1,ok:2,info:3}, porPl={}, sv=[];
  rows.forEach(r=>{ if(!r.f){ sv.push(r); return; } const k=r.placa||r.cn; (porPl[k]=porPl[k]||[]).push(r); });
  const vs=Object.entries(porPl).map(([pl,rs])=>{ const r0=rs.slice().sort((a,b)=>RK[a.tone]-RK[b.tone])[0], f=r0.f, q=f.chegada?null:restante(f,new Date());
    const emDoca=rs.some(r=>r.carga==="descarga"&&/EM DESCARGA|DESCARREGANDO|DESOVANDO/i.test((r.f&&r.f.status)||""));
    const est = r0.manut?"manut" : rs.every(r=>r.carga==="entregue")?"done" : emDoca?"desc" : rs.some(r=>r.carga==="descarga")?"patio" : r0.tone;
    const mov = !r0.manut && (r0.carga==="transito");
    const sitTxt = r0.tone==="info"&&!r0.manut&&est==="info"?"Sem necessidade informada":r0.manut?"Em manutenção":est==="done"?"Entregue hoje · no pátio da "+(r0.dest==="Betim"?"Sada Betim":"Iveco 7 Lagoas"):est==="desc"?"Descarregando na doca · "+(r0.dest==="Betim"?"Sada Betim":"Iveco 7 Lagoas"):est==="patio"?"Chegou · aguardando descarga no pátio da "+(r0.dest==="Betim"?"Sada Betim":"Iveco 7 Lagoas"):r0.carga==="porto"?"No porto · "+BI_SIT[r0.tone]:BI_SIT[r0.tone]+(r0.gap!=null?" "+dur(r0.gap):"");
    return {placa:pl, rs, cns:rs.map(r=>r.cn), f, node:r0.node, dest:r0.dest, carga:r0.carga, est, mov, tone:r0.tone, tipo:(()=>{ const t=a3Tipo(rs.find(r=>r.p)&&rs.find(r=>r.p).p); return rs.length>=2&&t!=="rodotrem"&&t!=="truck"?"bitrem":t; })(), tam:((rs.find(r=>r.p)||{}).p||{}).tipo_veiculo||"", q, crit:rs.some(r=>r.crit), sitTxt}; });
  return {vs, sv};
}
function a3PontoNo(id){ const n=NO[id]; if(!n||!n.ll) return null; const p=a3XZ(n.ll); let best=null;
  [A3.curve,A3.curveB].filter(Boolean).forEach(cv=>{ for(let i=0;i<=600;i++){ const t=i/600, q=cv.getPointAt(t), d=(q.x-p.x)**2+(q.z-p.z)**2; if(!best||d<best.d) best={cv,t,d}; } }); return best; }
function a3Limpar(){ A3.objs.forEach(o=>{ o.parent&&o.parent.remove(o); }); A3.objs=[]; A3.pick=[]; A3.anims=[]; }
/* trajetórias: pista (mão direita) ou linha reta de estacionamento */
const A3_V=new THREE.Vector3();
function a3PathPista(cv,faixa=2.6){ const L=cv.userData.L; return s=>{ const u=Math.max(0,Math.min(1,s/L)), p=cv.getPointAt(u), tg=cv.getTangentAt(u); let x=p.x-tg.z*faixa, z=p.z+tg.x*faixa;
  if(s<0){ x+=tg.x*s; z+=tg.z*s; } else if(s>L){ x+=tg.x*(s-L); z+=tg.z*(s-L); } return new THREE.Vector3(x,a3RoadY(cv,u)+.16,z); }; }
function a3PathReta(o,dir){ return s=>new THREE.Vector3(o.x+dir.x*s,o.y,o.z+dir.z*s); }
/* posiciona cavalo e reboques: eixos sobre a trajetória, reboque girando no pino-rei (curvas e rampas) */
function a3Pose(a,s){ const k=a.k, P=a.path, T=a.wrap, pF=P(s), pR=P(s-a.wb*k);
  const yaw=Math.atan2(pF.x-pR.x,pF.z-pR.z), pitch=-Math.atan2(pF.y-pR.y,Math.hypot(pF.x-pR.x,pF.z-pR.z));
  T.rotation.set(pitch,yaw,0,"YXZ"); T.position.copy(pF); T.updateMatrixWorld(true); const fa=T.localToWorld(A3_V.set(0,0,.2)); T.position.sub(fa.sub(pF)); T.updateMatrixWorld(true);
  let prev=T, hitch=-4.25, sK=s-a.wb*k;
  a.rebs.forEach(rb=>{ const KP=prev.localToWorld(new THREE.Vector3(0,0,hitch)), pT=P(sK-rb.D*k);
    const y2=Math.atan2(KP.x-pT.x,KP.z-pT.z), p2=-Math.atan2(KP.y-pT.y,Math.hypot(KP.x-pT.x,KP.z-pT.z));
    rb.obj.position.copy(KP); rb.obj.rotation.set(p2,y2,0,"YXZ"); rb.obj.updateMatrixWorld(true); prev=rb.obj; hitch=-rb.H; sK-=rb.H*k; }); }
function a3Pino(cor,mov){ const k=cor+"|"+(mov?1:0); A3.pinTex=A3.pinTex||{};
  if(!A3.pinTex[k]) A3.pinTex[k]=a3Tex(128,160,(x,w,h)=>{ const c="#"+cor.toString(16).padStart(6,"0"); x.fillStyle="rgba(0,0,0,.25)"; x.beginPath(); x.ellipse(w/2,h-8,16,6,0,0,Math.PI*2); x.fill();
    x.fillStyle=c; x.beginPath(); x.arc(w/2,56,50,0,Math.PI*2); x.fill(); x.beginPath(); x.moveTo(w/2-26,96); x.lineTo(w/2,h-12); x.lineTo(w/2+26,96); x.fill();
    x.lineWidth=7; x.strokeStyle="#fff"; x.beginPath(); x.arc(w/2,56,50,0,Math.PI*2); x.stroke();
    x.font="54px 'Segoe UI Emoji','Apple Color Emoji','Noto Color Emoji',sans-serif"; x.textAlign="center"; x.textBaseline="middle"; x.fillText(mov?"🚛":"🅿",w/2,60); });
  const s=new THREE.Sprite(new THREE.SpriteMaterial({map:A3.pinTex[k],depthTest:true,depthWrite:false,transparent:true,sizeAttenuation:false})); s.scale.set(.048,.06,1); s.center.set(.5,0); s.renderOrder=12; return s; }
function a3Popular(){
  const {vs,sv}=a3Dados(), sc=A3.scene; a3Limpar();
  const add=o=>{ sc.add(o); A3.objs.push(o); return o; };
  const cont={}; const slot={}, K=1.5;
  vs.forEach(v=>{ if(!a3Mostra(v.est,v)) return;
    const V=a3Veiculo(v), T=V.T; T.scale.setScalar(K); T.userData.v=v; add(T); A3.pick.push(T);
    V.rebs.forEach(rb=>{ rb.obj.scale.setScalar(K); rb.obj.userData.v=v; rb.obj.userData.trator=T; add(rb.obj); A3.pick.push(rb.obj); });
    const a={v,wrap:T,g:T,rebs:V.rebs,wb:V.wb,k:K,rodas:V.ws,conts:V.conts,fase:a3Hash(v.placa)%100/100,vel:v.mov?3.2:0,s0:0,modo:"road",path:null,info:null};
    if(v.est==="desc"||v.est==="done"||v.est==="patio"){ const pl=A3.plantas[v.dest==="Betim"?"Sada Betim":"Iveco 7 Lagoas"]||A3.plantas["Iveco 7 Lagoas"], k=pl.rot, S=slot[k]=slot[k]||{doca:0,patio:0};
      let o; const L=pl.G.L; // da traseira da carreta ao eixo dianteiro, em unidades da planta
      if(v.est==="desc"&&S.doca<8){ const i=S.doca++; o=pl.g.localToWorld(new THREE.Vector3(-18.9+i*5.4,0,.4+L)); a.naDoca=true; }
      else { const i=S.patio++, fila=Math.floor(i/9)%2, col=i%9, extra=Math.floor(i/18); o=pl.g.localToWorld(new THREE.Vector3(-21.6+col*5.4+extra*1.2,0,(fila?pl.G.r1:pl.G.r0)+L)); if(v.est==="desc"){ v.est="patio"; v.sitTxt="Aguardando doca livre na "+(v.dest==="Betim"?"Sada Betim":"Iveco 7 Lagoas"); } }
      o.y=pl.y+.3*pl.esc; a.path=a3PathReta(o,pl.fwd); a.modo="park"; }
    else if(v.carga==="porto"&&(v.node==="betim"||/SADA BETIM/i.test((v.f&&v.f.localizacao)||""))&&A3.plantas["Sada Betim"]){ const pl=A3.plantas["Sada Betim"], k=pl.rot, S=slot[k]=slot[k]||{doca:0,patio:0}, L=pl.G.L;
      const i=S.patio++, fila=Math.floor(i/9)%2, col=i%9, extra=Math.floor(i/18); const o=pl.g.localToWorld(new THREE.Vector3(-21.6+col*5.4+extra*1.2,0,(fila?pl.G.r1:pl.G.r0)+L)); o.y=pl.y+.3*pl.esc;
      a.path=a3PathReta(o,pl.fwd); a.modo="park"; v.sitTxt="Aguardando veículo na Sada Betim · "+BI_SIT[v.tone]+(v.rs[0].gap!=null?" "+dur(v.rs[0].gap):""); }
    else if(v.carga==="porto"||!v.node){ const i=(slot.porto=(slot.porto||0)+1)-1; const o=new THREE.Vector3(A3.portoPos.x-(i%6)*6.2,A3.portoC.y,A3.portoPos.z-Math.floor(i/6)*27); a.path=a3PathReta(o,new THREE.Vector3(0,0,1)); a.modo="park"; }
    else { const info=a3PontoNo(v.node); if(!info){ a.path=a3PathReta(A3.portoPos.clone(),new THREE.Vector3(0,0,1)); a.modo="park"; } else { a.info=info; const LA=A3.curve.userData.L;
        if(info.cv===A3.curveB){ const sBH=A3.sB0, LB=A3.curveB.userData.L; a.cv=A3.curve; a.grp="B"; a.s0=Math.min(sBH+info.t*LB, sBH+LB-46); a.mkPath=fx=>{ const pa=a3PathPista(A3.curve,fx), pb=a3PathPista(A3.curveB,fx); return s=>s<sBH?pa(s):pb(s-sBH); }; a.path=a.mkPath(2.6); }
        else { a.cv=A3.curve; a.grp="A"; a.s0=Math.max(46,Math.min(LA-46,info.t*LA)); a.mkPath=fx=>a3PathPista(A3.curve,fx); a.path=a.mkPath(2.6); } } }
    if(!a.cv) a.vel=0;
    // sinalização
    let sin=null;
    if(v.est==="crit"||v.est==="manut"){ sin=a3Sirene(); sin.position.set(0,4.72,0); T.add(sin); if(v.est==="manut"){ const w=a3Emoji("🔧",2.4); w.position.set(0,7.8,0); T.add(w); } }
    else if(v.est==="warn"){ sin=a3Exclam(); sin.position.set(0,6.2,0); T.add(sin); }
    else if(v.est==="ok"){ sin=a3Joinha(); sin.position.set(0,6.6,0); T.add(sin); }
    else if(v.est==="done"){ const s=a3Emoji("✅",2.6); s.position.set(0,6.6,0); T.add(s); }
    if(v.crit){ const c=a3Sprite("CRÍTICO",{tam:26,cor:"#fff",fundo:"#C0392B",escala:.8}); c.position.set(0,v.est==="ok"?9.8:9,0); T.add(c); T.userData.crl=c; }
    const lb=a3Sprite(`${v.cns.join(" + ")}  ·  ${v.placa}`,{tam:26,escala:.9,borda:"#"+(A3_COR[v.est]||0x4755A0).toString(16).padStart(6,"0")}); lb.position.set(0,v.crit?12:10.4,0); lb.visible=A3.labels; T.add(lb); T.userData.lb=lb;
    { const pin=a3Pino(A3_COR[v.est]||0x4755A0,v.mov); pin.position.set(0,15,0); T.add(pin); T.userData.pin=pin; }
    if(A3.selCn&&A3.selCn.size){ const cor=A3_COR[v.est]||0x4755A0; 
      const an=new THREE.Mesh(new THREE.TorusGeometry(4,.25,8,40),new THREE.MeshBasicMaterial({color:cor,transparent:true,opacity:.8})); an.rotation.x=Math.PI/2; an.position.y=.3; T.add(an); T.userData.anel=an; lb.position.y=v.crit?14:12.5; }
    T.traverse(o=>{ if(o.isSprite){ o.material.depthTest=true; o.material.depthWrite=false; } });
    a.sin=sin; A3.anims.push(a);
  });
  // espaçamento mínimo entre veículos na mesma pista
  // comboio sem sobreposição: rodovia duplicada (2 faixas no mesmo sentido); cada caminhão anda só na sua janela,
  // sempre com distância segura do caminhão da frente na mesma faixa
  A3.anims.forEach(a=>{ if(!a.grp) return; a.comp=(a.wb+a.rebs.reduce((s,rb)=>s+rb.D+(rb.H||0),0)+5)*a.k; a.A=a.vel?16:0; });
  const M=8, req=(tras,frente)=>tras.A+frente.A+frente.comp+M;
  const arruma=(lst,ini,fim)=>{ lst.sort((a,b)=>a.s0-b.s0); if(!lst.length) return;
    lst[0].s0=Math.max(lst[0].s0,ini+lst[0].comp+lst[0].A);
    for(let i=1;i<lst.length;i++) lst[i].s0=Math.max(lst[i].s0,lst[i-1].s0+req(lst[i-1],lst[i]));
    const last=lst[lst.length-1]; if(last.s0+last.A>fim){ last.s0=fim-last.A; for(let i=lst.length-2;i>=0;i--) lst[i].s0=Math.min(lst[i].s0,lst[i+1].s0-req(lst[i],lst[i+1])); }
    if(lst[0].s0-lst[0].A-lst[0].comp<ini){ // não coube: reduz as janelas e distribui por igual
      const tot=lst.reduce((s,a)=>s+a.comp+M,0), nMov=lst.filter(a=>a.vel).length*2||1, A=Math.max(0,Math.min(16,(fim-ini-tot)/nMov));
      lst.forEach(a=>{ if(a.vel) a.A=A; }); let s=ini; lst.forEach(a=>{ s+=a.comp+a.A; a.s0=s; s+=a.A+M; }); } };
  ["A","B"].forEach(gp=>{ const lst0=A3.anims.filter(a=>a.grp===gp); const orig=new Map(lst0.map(a=>[a,a.s0]));
   for(const Aj of [16,12,8,5,2,0]){ const lst=lst0.slice().sort((a,b)=>orig.get(a)-orig.get(b)); lst.forEach(a=>{ a.s0=orig.get(a); a.A=a.vel?Aj:0; });
    const ini=gp==="A"?30:A3.sB0+34, fim=gp==="A"?A3.curve.userData.L-40:A3.sB0+A3.curveB.userData.L-30;
    const faixas=[[],[]]; lst.forEach((a,i)=>{ const f=i%2; faixas[f].push(a); a.faixa=f?-3.1:3.1; a.path=a.mkPath(a.faixa); });
    faixas.forEach(f=>arruma(f,ini,fim));
    // nas curvas fechadas a carreta "corta" a curva e invade a faixa ao lado: ali não deixa dois caminhões lado a lado
    const ang=s=>{ const P=lst[0].path, a1=P(s-1), a2=P(s+1); return Math.atan2(a2.x-a1.x,a2.z-a1.z); };
    const curva=(s1,s2)=>{ let m=0; for(let s=s1;s<=s2;s+=6){ let d=Math.abs(ang(s+18)-ang(s-18)); if(d>Math.PI) d=2*Math.PI-d; m=Math.max(m,d); } return m; };
    for(let it=0;it<30;it++){ let mudou=false; const todos=lst.slice().sort((x,y)=>x.s0-y.s0);
      for(let i=0;i<todos.length;i++) for(let j=i+1;j<todos.length;j++){ const r=todos[i], f=todos[j]; if(r.faixa===f.faixa) continue;
        const rIni=r.s0-r.comp-r.A, rFim=r.s0+r.A, fIni=f.s0-f.comp-f.A, fFim=f.s0+f.A; if(rFim+4<=fIni||fFim+4<=rIni) continue;
        if(curva(Math.min(rIni,fIni),Math.max(rFim,fFim))<0.3) continue;
        r.s0=fIni-4-r.A; mudou=true; }
      if(!mudou) break; faixas.forEach(f=>{ f.sort((x,y)=>x.s0-y.s0); for(let i=f.length-2;i>=0;i--) f[i].s0=Math.min(f[i].s0,f[i+1].s0-req(f[i],f[i+1])); }); }
    if(lst.every(a=>a.s0-a.comp-a.A>=ini-1)) break; }
  });
  A3.anims.forEach(a=>{ if(a.path) a3Pose(a,a.s0); });
  if(sv.length&&a3Mostra("info")){ const lb=a3Sprite(A3.selCn&&A3.selCn.size?`Sem veículo: ${sv.slice(0,4).map(r=>r.cn).join(", ")}${sv.length>4?" e mais "+(sv.length-4):""}`:`${sv.length} container${sv.length>1?"s":""} aguardando veículo`,{tam:28,cor:"#fff",fundo:"#4755A0",escala:1.2}); lb.position.set(A3.portoC.x,20,A3.portoC.z+30); add(lb); }
  // alertas nas rodovias
  const now=new Date();
  listaAlertas().forEach(a=>{ const s=statusAl(a,now); if(s.k!=="ativo") return; const grave=a.tipo==="acidente"||a.tipo==="interdicao"||a.sev==="alta";
    if(!grave&&!/obra|lentidao|restricao/.test(a.tipo)) return;
    (a.nos||[]).slice(0,2).forEach((id,k)=>{ const pn=a3PontoNo(id); if(!pn) return; const L=pn.cv.userData.L, t=Math.max(.01,Math.min(.99,pn.t-(30+k*40)/L)), p=pn.cv.getPointAt(t), tg=pn.cv.getTangentAt(t), ang=Math.atan2(tg.x,tg.z);
      const g=new THREE.Group(); g.rotation.y=ang; add(g); const nx=-tg.z, nz=tg.x;
      const monta=s=>{ while(g.children.length) g.remove(g.children[0]);
        if(grave){ [["amb",-3],["pol",4],["bomb",11]].forEach(([tp,zz])=>{ const c=a3Carro(tp); c.position.set(-.8*s,0,zz); g.add(c); c.userData.alarme=1; });
          for(let i=0;i<5;i++){ const cn=a3Cone(); cn.position.set(1.8*s,0,-7+i*4.5); g.add(cn); } }
        else { for(let i=0;i<3;i++){ const w=a3Trabalhador(); w.position.set(-1.2*s,0,(i-1)*3.2); w.rotation.y=i*1.3; g.add(w); w.userData.trab=1; }
          for(let i=0;i<6;i++){ const cn=a3Cone(); cn.position.set(1.4*s,0,-9+i*3.4); g.add(cn); }
          const pl=a3Box(3,1.8,.15,a3Mat(0xFF8C00),.08); pl.position.set(1.4*s,1.6,-12); g.add(pl); } };
      // escolhe o lado/distância em que nenhum caminhão (faixas de todas as pistas) passa por cima
      const faixas=A3.faixasPts||(A3.faixasPts=(()=>{ const P=[]; [A3.curve,A3.curveB].filter(Boolean).forEach(cv=>{ const f=a3PathPista(cv), L=cv.userData.L; for(let s=0;s<=L;s+=1.5){ const q=f(s); P.push(q.x,q.z); } }); return P; })());
      const folga=()=>{ let m=1e9; g.updateMatrixWorld(true); const v=new THREE.Vector3(); g.children.forEach(c=>{ c.getWorldPosition(v); for(let k=0;k<faixas.length;k+=2){ const d=(faixas[k]-v.x)**2+(faixas[k+1]-v.z)**2; if(d<m) m=d; } }); return Math.sqrt(m); };
      let ok=false; for(const off of [8.6,10,12,14,17,20]){ for(const s of (grave?[1,-1]:[-1,1])){ monta(s); g.position.set(p.x+nx*off*s,a3Chao(p.x+nx*off*s,p.z+nz*off*s)+.04,p.z+nz*off*s); if(folga()>=4.6){ ok=true; break; } } if(ok) break; }
      g.children.forEach(c=>{ if(c.userData.alarme) A3.anims.push({alarme:c}); if(c.userData.trab) A3.anims.push({trab:c,fase:Math.random()*2}); });
      const lb=a3Sprite((grave?"⚠ ":"🚧 ")+a.titulo,{tam:24,cor:"#fff",fundo:grave?"#B8322A":"#C87400",escala:.9}); lb.position.set(0,grave?9:7,0); g.add(lb); }); });
  a3Hud(vs,sv);
}
/* ---------- animação ---------- */
function a3Loop(){
  A3.raf=requestAnimationFrame(a3Loop); if(!A3.vis) return;
  const dt=Math.min(.05,A3.clock.getDelta()), tt=A3.clock.elapsedTime, W=90;
  A3.anims.forEach(a=>{
    if(a.alarme){ const on=Math.floor(tt*6)%2===0; a.alarme.userData.l1.material.color.setHex(on?0xff2020:0x330000); a.alarme.userData.l2.material.color.setHex(on?0x000022:(a.alarme.userData.l2.material.color.getHex()&0x00ffff?0x2060ff:0xff2020)); return; }
    if(a.trab){ a.trab.userData.braco.rotation.x=Math.sin(tt*4+a.fase)*.9-.3; return; }
    const T=a.wrap, sin=a.sin;
    if(a.vel&&a.path&&a.A>=8){ const W2=2*a.A, ph=(tt*a.vel+a.fase*W2)%W2, s=a.s0+ph-a.A; a3Pose(a,s);
      const f=Math.min(1,ph/1.2,(W2-ph)/1.2), e=a.k*(.02+.98*f*f*(3-2*f)); T.scale.setScalar(e); a.rebs.forEach(rb=>rb.obj.scale.setScalar(e));
      const w=dt*a.vel/(.55*a.k); a.rodas.forEach(r=>r.rotation.x+=w); }
    else if(a.vel&&a.path){ // rodovia cheia: sem espaço para avançar, fica na posição com rodas girando e leve trepidação
      if(!a.fixo){ a3Pose(a,a.s0); a.fixo=true; a.y0=T.position.y; } T.position.y=a.y0+Math.sin(tt*18+a.fase*9)*.035;
      const w=dt*a.vel/(.55*a.k); a.rodas.forEach(r=>r.rotation.x+=w); }
    if(sin){ const u=sin.userData;
      if(u.rot){ u.rot.rotation.y+=dt*9; u.cg.rotation.y+=dt*9; u.cup.material.emissiveIntensity=1+Math.sin(tt*18)*.6; }
      if(u.ring&&!u.s){ sin.position.y=6.2+Math.abs(Math.sin(tt*3+a.fase*6))*1.2; sin.rotation.y+=dt*1.5; u.ring.scale.setScalar(1+((tt*1.2+a.fase)%1)*1.2); u.ring.material.opacity=.8-((tt*1.2+a.fase)%1)*.8; }
      if(u.s){ sin.position.y=6.6+Math.sin(tt*2.5+a.fase*6)*.5; const k=1+Math.sin(tt*5+a.fase)*.08; u.s.scale.set(3.2*k,3.2*k,1); u.ring.scale.setScalar(1+((tt+a.fase)%1)*1.3); u.ring.material.opacity=.8-((tt+a.fase)%1)*.8; } }
    if(a.naDoca){ const ab=1.55+Math.sin(tt*.8+a.fase*6)*.25; (a.conts||[]).forEach(c=>c.userData.portas.forEach(({piv,sd})=>piv.rotation.y=-sd*ab)); }
    if(T.userData.anel){ const f=(tt*.8+a.fase)%1; T.userData.anel.scale.setScalar(1+f*1.6); T.userData.anel.material.opacity=.85*(1-f); }
    if(T.userData.pin) T.userData.pin.visible=A3.camera.position.distanceTo(T.position)>70;
    if(T.userData.lb){ const perto=A3.todosNum||(A3.selCn&&A3.selCn.size>0)||A3.camera.position.distanceTo(T.position)<A3.distLb; T.userData.lb.visible = A3.sel===a.v || (A3.labels && perto); if(T.userData.crl) T.userData.crl.visible=perto||A3.sel===a.v; }
  });
  if(A3.uVento) A3.uVento.value=tt*(A3.ventoForte?1.9:1); a3ClimaPasso(dt,tt); if(A3.stacker) a3StackerPasso(A3.stacker,tt); a3PortariaPasso(dt,tt);
  (A3.nuvens||[]).forEach((n,i)=>{ n.position.x+=dt*(1.5+i%3*.5); if(n.position.x>260) n.position.x=-280; });
  if(A3.seguir){ const d=A3.seguir.position.clone().sub(A3.controls.target); A3.controls.target.add(d); A3.camera.position.add(d); }
  if(A3.tour&&A3.tourAlvo){ const alvo=A3.tourAlvo.position; A3.controls.target.lerp(alvo,.05); const desejo=new THREE.Vector3(alvo.x+28,alvo.y+22,alvo.z+36); A3.camera.position.lerp(desejo,.03); }
  else if(A3.foco){ A3.controls.target.lerp(A3.foco,.08); if(A3.controls.target.distanceTo(A3.foco)<.5) A3.foco=null; }
  (A3.cidLb||[]).forEach(l=>l.visible=A3.camera.position.distanceTo(l.position)<300);
  // sombra acompanha a região observada
  const tg=A3.controls.target, dist=A3.camera.position.distanceTo(tg), ext=Math.max(60,Math.min(260,dist*.8)), sc=A3.sol.shadow.camera;
  if(Math.abs(sc.right-ext)>4){ sc.left=-ext; sc.right=ext; sc.top=ext; sc.bottom=-ext; sc.updateProjectionMatrix(); }
  A3.sol.position.set(tg.x-240,tg.y+200,tg.z+150); A3.sol.target.position.copy(tg); A3.sol.target.updateMatrixWorld();
  A3.ceu.position.copy(A3.camera.position);
  A3.controls.update(); A3.renderer.render(A3.scene,A3.camera);
  a3Som(tt);
}

/* sirene sonora (WebAudio) */
function a3Som(tt){ if(!A3.audioNodes) return; const on=A3.sound&&A3.vis&&A3.anims.some(a=>a.v&&(a.v.est==="crit"));
  const {osc,gain,ctx}=A3.audioNodes; const f=900+Math.sin(tt*Math.PI*1.4)*300; osc.frequency.setTargetAtTime(f,ctx.currentTime,.02); gain.gain.setTargetAtTime(on?.035:0,ctx.currentTime,.08); }
function a3AtivaSom(v){ A3.sound=v; if(v&&!A3.audioNodes){ try{ const ctx=new (window.AudioContext||window.webkitAudioContext)(), osc=ctx.createOscillator(), gain=ctx.createGain(); osc.type="sawtooth"; gain.gain.value=0; const lp=ctx.createBiquadFilter(); lp.type="lowpass"; lp.frequency.value=2200; osc.connect(lp); lp.connect(gain); gain.connect(ctx.destination); osc.start(); A3.audioNodes={ctx,osc,gain}; }catch(e){ A3.sound=false; } }
  if(A3.audioNodes&&A3.audioNodes.ctx.state==="suspended") A3.audioNodes.ctx.resume(); }
/* ---------- HUD, seleção e tour ---------- */
function a3Hud(vs,sv){ const el=document.getElementById("a3-hud"); if(!el) return; const c=k=>vs.filter(v=>v.est===k).length;
  const it=[["crit","🚨","Atrasados",c("crit")+c("manut")],["warn","❗","Em risco",c("warn")],["ok","👍","No prazo",c("ok")],["porto","🏗️","Aguardando na Sada Caju",vs.filter(v=>v.carga==="porto"&&v.node!=="betim").length],["patio","🅿️","No pátio (chegou)",c("patio")],["desc","📦","Descarregando na doca",c("desc")],["done","✅","Entregues hoje",c("done")],["info","⏳","Sem veículo",sv.length]];
  el.innerHTML=it.map(([k,e,t,n])=>`<button type="button" class="a3-chip${A3.soCat===k?" sel":A3.soCat?" off":""}" data-a3h="${k}" aria-pressed="${A3.soCat===k}" style="--c:#${(A3_COR[k]||(k==="porto"?0xD98E04:0x4755A0)).toString(16).padStart(6,"0")}" title="${A3.soCat===k?"Mostrar todos de novo":"Mostrar só "+t.toLowerCase()}"><span>${e}</span><b>${n}</b><small>${t}</small></button>`).join("");
  el.querySelectorAll("[data-a3h]").forEach(b=>b.onclick=()=>{ const k=b.dataset.a3h; A3.soCat=A3.soCat===k?null:k; A3.seguir=null; a3Popular(); A3.sig=a3Sig(); a3Banner(); if(A3.soCat) a3Enquadrar(); else a3VisaoGeral(); });
}
function a3Selecionar(v,o){ A3.sel=v; if(!v) A3.seguir=null; else if(o) A3.seguir=o.userData&&o.userData.v?o:null; const box=document.getElementById("a3-info"); if(!box) return; if(!v){ box.hidden=true; return; }
  A3.foco=o&&!A3.seguir?o.position.clone():null; A3.tour=false; const tb=document.getElementById("a3-tour"); tb&&tb.setAttribute("aria-pressed","false");
  const f=v.f, q=v.q; box.hidden=false;
  box.innerHTML=`<button class="a3-x" type="button" aria-label="Fechar">×</button><div class="a3-it"><span class="a3-dot" style="background:#${(A3_COR[v.est]||0x4755A0).toString(16).padStart(6,"0")}"></span><b class="mono">${esc(v.placa)}</b>${f.placa_reboque?` <span class="sub mono">/ ${esc(f.placa_reboque)}</span>`:""}</div>
    <div class="a3-sit">${esc(v.sitTxt)}</div>
    ${v.rs.map(r=>`<div class="a3-cn"><span class="cn">${esc(r.cn)}</span>${armadorDe(r.cn)?` <span class="sub">· ${esc(armadorDe(r.cn))}</span>`:""}${r.crit?` <span class="linha">${esc(r.crit)}</span>`:""}<div class="sub">necessidade ${r.need?fmt(r.need):"—"}${r.gap!=null?` · <b>${dur(r.gap)}</b>`:""}</div></div>`).join("")}
    <dl><dt>Local</dt><dd>${esc(lugar(f.localizacao))}</dd><dt>Destino</dt><dd>${esc(v.dest)}</dd><dt>Faltam</dt><dd>${q&&q.km!=null?q.km+" km":"—"}</dd><dt>Previsão</dt><dd>${f.chegada?"chegou "+fmt(f.chegada):f.prev_chegada?fmt(f.prev_chegada):q&&q.eta?"≈ "+fmt(iso(q.eta)):"—"}</dd><dt>Motorista</dt><dd>${esc(f.motorista||"—")}</dd><dt>Veículo</dt><dd>${esc({carreta:"Carreta porta-container",bitrem:"Bitrem",rodotrem:"Rodotrem",sider:"Carreta sider",truck:"Truck"}[v.tipo])}</dd></dl>
    <div class="row"><button class="btn sm" type="button" id="a3-ed">✎ Editar</button>${v.est==="crit"?`<button class="btn sm" type="button" id="a3-sir">🔊 Tocar sirene</button>`:""}</div>`;
  box.querySelector(".a3-x").onclick=()=>a3Selecionar(null);
  box.querySelector("#a3-ed").onclick=()=>painelVeiculo(v.placa,v.cns[0]);
  const sr=box.querySelector("#a3-sir"); sr&&(sr.onclick=()=>{ a3AtivaSom(true); const sb=document.getElementById("a3-som"); sb&&sb.setAttribute("aria-pressed","true"); setTimeout(()=>{ if(!A3.somFixo){ A3.sound=false; sb&&sb.setAttribute("aria-pressed","false"); } },3000); });
}
function a3Tour(){ if(!A3.tour) return; const alvos=A3.anims.filter(a=>a.wrap); if(!alvos.length) return; A3.tourI=(A3.tourI+1)%alvos.length; A3.tourAlvo=alvos[A3.tourI].wrap; a3Selecionar(alvos[A3.tourI].v,null); A3.tour=true; clearTimeout(A3.tourT); A3.tourT=setTimeout(a3Tour,6000); }
/* ---------- filtro de containers do Painel 3D (seleção múltipla) ---------- */
try{ A3.selCn=new Set(JSON.parse(localStorage.getItem("iveco.a3sel")||"[]")); }catch(e){ A3.selCn=new Set(); }
try{ A3.todosNum=localStorage.getItem("iveco.a3num")==="1"; }catch(e){}
function a3Mostra(est,v){ const c=A3.soCat; if(!c) return true; if(c==="porto") return !!(v&&v.carga==="porto"&&v.node!=="betim"&&!v.manut&&v.est!=="desc"&&v.est!=="patio"&&v.est!=="done"); if(c==="crit") return est==="crit"||est==="manut"; return est===c; }
function a3LimpaTudo(){ A3.selCn=new Set(); A3.soCat=null; A3.seguir=null; a3SalvaSel(); try{ localStorage.removeItem("iveco.a3sel"); }catch(e){} a3AplicaSel(); if(A3.ok){ a3VisaoGeral(); a3Selecionar(null); } }
function a3SalvaSel(){ try{ localStorage.setItem("iveco.a3sel",JSON.stringify([...A3.selCn])); }catch(e){} }
function a3Candidatos(){ const hoje=iso(new Date()).slice(0,10);
  return biLinhas().filter(r=>r.carga!=="entregue"||(r.f&&r.f.chegada&&dia(r.f.chegada)>=iso(new Date(Date.now()-3*864e5)).slice(0,10)))
    .sort((a,b)=>{ const O={transito:0,descarga:1,porto:2,betim:3,entregue:4,semveic:5}; return (O[a.carga]??9)-(O[b.carga]??9)||a.cn.localeCompare(b.cn); }); }
function a3FiltroUI(el){ const btn=el.querySelector("#a3-fil"), pop=el.querySelector("#a3-pop"); let q="", marc=new Set(A3.selCn);
  const CARGA={transito:"Em trânsito",porto:"No porto",descarga:"Descarga",entregue:"Entregue",semveic:"Sem veículo",betim:"Em Betim"};
  const desenha=()=>{ const L=a3Candidatos(), Q=q.trim().toUpperCase().replace(/\s/g,""), vis=L.filter(r=>!Q||r.cn.includes(Q)||String(r.placa||"").toUpperCase().includes(Q)||String((r.f&&r.f.localizacao)||"").toUpperCase().includes(q.trim().toUpperCase()));
    pop.innerHTML=`<div class="a3-ph"><input id="a3-q" type="search" placeholder="Buscar container, placa ou local — ou cole uma lista" value="${esc(q)}" autocomplete="off"><span class="sub">${marc.size} selecionado${marc.size===1?"":"s"}</span></div>
      <div class="a3-pl">${vis.length?vis.slice(0,400).map(r=>`<label class="a3-pi${marc.has(r.cn)?" on":""}"><input type="checkbox" value="${r.cn}" ${marc.has(r.cn)?"checked":""}><span class="cn mono">${r.cn}</span><span class="a3-pm">${r.f?`<b class="mono">${esc(r.placa||"—")}</b> · ${esc(CARGA[r.carga]||r.carga)}${r.f.localizacao?" · "+esc(lugar(r.f.localizacao)):""}`:`<i>sem veículo</i>`}</span><span class="a3-pd" style="background:#${(A3_COR[r.manut?"crit":r.tone]||0x4755A0).toString(16).padStart(6,"0")}"></span></label>`).join(""):`<p class="sub" style="padding:10px">Nenhum container encontrado.</p>`}</div>
      <div class="a3-pf"><button class="btn sm" type="button" id="a3-pall">Marcar os ${Math.min(vis.length,400)} listados</button><button class="btn sm" type="button" id="a3-pclr">Limpar seleção</button><span style="flex:1"></span><button class="btn sm pri" type="button" id="a3-pok">Mostrar no mapa</button></div>`;
    const inp=pop.querySelector("#a3-q"); inp.oninput=e=>{ const v=e.target.value, lst=consExtrai(v); if(lst.length>1){ const ex=new Set(L.map(r=>r.cn)); lst.forEach(c=>{ if(ex.has(c)) marc.add(c); }); const fora=lst.filter(c=>!ex.has(c)); q=""; desenha(); if(fora.length) toast(`${lst.length-fora.length} marcados · não encontrados: ${fora.slice(0,5).join(", ")}${fora.length>5?"…":""}`); else toast(lst.length+" containers marcados"); return; } q=v; const pos=e.target.selectionStart; desenha(); const n=pop.querySelector("#a3-q"); n.focus(); n.setSelectionRange(pos,pos); };
    pop.querySelectorAll(".a3-pi input").forEach(c=>c.onchange=()=>{ c.checked?marc.add(c.value):marc.delete(c.value); c.closest(".a3-pi").classList.toggle("on",c.checked); pop.querySelector(".a3-ph .sub").textContent=marc.size+" selecionado"+(marc.size===1?"":"s"); });
    pop.querySelector("#a3-pall").onclick=()=>{ vis.slice(0,400).forEach(r=>marc.add(r.cn)); desenha(); };
    pop.querySelector("#a3-pclr").onclick=()=>{ marc.clear(); q=""; pop.querySelectorAll(".a3-pi input").forEach(c=>{ c.checked=false; c.closest(".a3-pi").classList.remove("on"); }); const s=pop.querySelector(".a3-ph .sub"); if(s) s.textContent="0 selecionados"; try{ a3LimpaTudo(); }catch(e){ console.error(e); } desenha(); };
    pop.querySelector("#a3-pok").onclick=()=>{ A3.selCn=new Set(marc); a3SalvaSel(); fecha(); a3AplicaSel(); };
  };
  const fecha=()=>{ pop.hidden=true; btn.setAttribute("aria-expanded","false"); };
  btn.onclick=e=>{ e.stopPropagation(); if(!pop.hidden){ fecha(); return; } marc=new Set(A3.selCn); q=""; desenha(); pop.hidden=false; btn.setAttribute("aria-expanded","true"); setTimeout(()=>{ const i=pop.querySelector("#a3-q"); i&&i.focus(); },30); };
  pop.addEventListener("click",e=>e.stopPropagation());
  document.addEventListener("click",e=>{ if(!pop.hidden&&!e.target.closest(".a3-fwrap")) fecha(); });
  document.addEventListener("keydown",e=>{ if(e.key==="Escape"&&!pop.hidden) fecha(); });
  a3Banner(); }
function a3Banner(){ const b=document.getElementById("a3-ban"), n=document.getElementById("a3-fn"); if(!b) return; const k=A3.selCn.size;
  if(n) n.textContent=k?` (${k})`:""; document.getElementById("a3-fil")&&document.getElementById("a3-fil").classList.toggle("on",!!k);
  const NOMES={crit:"Atrasados",warn:"Em risco",ok:"No prazo",porto:"Aguardando na Sada Caju",patio:"No pátio (chegou)",desc:"Descarregando na doca",done:"Entregues hoje",info:"Sem veículo"};
  if(!k&&!A3.soCat){ b.hidden=true; return; }
  if(!k){ b.hidden=false; b.innerHTML=`<div class="a3-bl"><span>🔎 Mostrando só: <b>${NOMES[A3.soCat]}</b> · ${A3.anims.filter(a=>a.v).length} veículo(s) no mapa</span><span style="flex:1"></span><button class="btn sm" type="button" id="a3-bfoc">⌖ Ver todos</button><button class="btn sm" type="button" id="a3-bclr">✕ Limpar filtros</button></div>`;
    b.querySelector("#a3-bclr").onclick=()=>a3LimpaTudo(); b.querySelector("#a3-bfoc").onclick=()=>a3Enquadrar(); return; } const L=biLinhas().filter(r=>A3.selCn.has(r.cn)), cv=L.filter(r=>r.f).length;
  b.hidden=false; b.innerHTML=`<div class="a3-bl"><span>📦 Mostrando <b>${k}</b> container${k>1?"s":""} selecionado${k>1?"s":""} · <b>${cv}</b> com veículo no mapa${k-cv?` · <b>${k-cv}</b> sem veículo`:""}</span><span style="flex:1"></span><button class="btn sm" type="button" id="a3-bfoc">⌖ Ver todos</button><button class="btn sm" type="button" id="a3-bclr">✕ Limpar filtros</button></div>
    <div class="a3-bc">${L.map(r=>r.f?`<button type="button" class="a3-chipc" data-ir="${esc(r.placa||r.cn)}" style="--c:#${(A3_COR[r.manut?"crit":r.tone]||0x4755A0).toString(16).padStart(6,"0")}" title="Ir até o veículo e acompanhar"><b class="mono">${r.cn}</b> ${esc(r.placa||"")}</button>`:`<span class="a3-chipc off"><b class="mono">${r.cn}</b> sem veículo</span>`).join("")}</div>`;
  b.querySelectorAll("[data-ir]").forEach(x=>x.onclick=()=>a3IrPara(x.dataset.ir));
  b.querySelector("#a3-bclr").onclick=()=>a3LimpaTudo();
  b.querySelector("#a3-bfoc").onclick=()=>a3Enquadrar(); }
function a3IrPara(pl){ if(!A3.ok) return; const a=A3.anims.find(a=>a.v&&(a.v.placa===pl||a.v.cns.includes(pl))); if(!a) return; A3.tour=false; A3.tourAlvo=null; A3.foco=null;
  const p=a.wrap.position; A3.controls.target.copy(p); A3.camera.position.copy(a.wrap.localToWorld(new THREE.Vector3(-22,18,-14))); A3.seguir=a.wrap; a3Selecionar(a.v,null); A3.seguir=a.wrap;
  document.getElementById("a3-stage").scrollIntoView({behavior:"smooth",block:"center"}); }
function a3AplicaSel(){ A3.seguir=null; a3Banner(); if(!A3.ok) return; a3Popular(); A3.sig=a3Sig(); if(A3.selCn.size) a3Enquadrar(); }
function a3Enquadrar(){ const ts=A3.anims.filter(a=>a.wrap).map(a=>a.wrap.position); if(!ts.length){ a3VisaoGeral(); return; }
  A3.tour=false; A3.tourAlvo=null; A3.foco=null; const bx=new THREE.Box3(); ts.forEach(p=>bx.expandByPoint(p)); const c=bx.getCenter(new THREE.Vector3()), sz=bx.getSize(new THREE.Vector3()), R=Math.max(40,sz.x,sz.z)*1.15;
  A3.controls.target.copy(c); A3.camera.position.set(c.x+R*.35,c.y+R*.75,c.z+R*.7); A3.controls.update();
  if(ts.length===1){ const a=A3.anims.find(a=>a.wrap); a3Selecionar(a.v,a.wrap); } }
function a3FullSync(el){ const on=document.fullscreenElement===el||el.classList.contains("a3-full"); el.classList.toggle("a3-isfull",on); document.body.style.overflow=el.classList.contains("a3-full")?"hidden":"";
  const b=el.querySelector("#a3-full"); if(b){ b.textContent=on?"✕ Sair da tela cheia":"⛶ Tela cheia"; b.setAttribute("aria-pressed",String(on)); } const f=el.querySelector("#a3-fsb"); if(f){ f.textContent=on?"✕":"⛶"; f.title=on?"Sair da tela cheia":"Tela cheia"; } }
/* ---------- condições meteorológicas nas cidades ---------- */
const A3_CLIMA_CID=["rio","petropolis","areal","jf","sdumont","barbacena","lafaiete","congonhas","novalima","bh","betim","sete"];
const A3_TIPOS={sol:["☀️","Sol"],parcial:["⛅","Parcialmente nublado"],nublado:["☁️","Nublado"],neblina:["🌫️","Neblina"],garoa:["🌦️","Garoa"],chuva:["🌧️","Chuva"],forte:["🌧️","Chuva forte"],trovoada:["⛈️","Trovoada"],vento:["💨","Ventania"]};
function a3WMO(c,vento){ let t= c<=1?"sol":c===2?"parcial":c===3?"nublado":(c===45||c===48)?"neblina":(c>=51&&c<=57)?"garoa":(c===65||c===67||c===82)?"forte":((c>=61&&c<=67)||(c>=80&&c<=82))?"chuva":c>=95?"trovoada":"nublado";
  if(vento>=38&&(t==="sol"||t==="parcial"||t==="nublado")) t="vento"; return t; }
async function a3ClimaBusca(){ const ids=A3_CLIMA_CID.filter(id=>NO[id]&&NO[id].ll);
  const url="https://api.open-meteo.com/v1/forecast?latitude="+ids.map(id=>NO[id].ll[0]).join(",")+"&longitude="+ids.map(id=>NO[id].ll[1]).join(",")+"&current=temperature_2m,weather_code,wind_speed_10m,precipitation&timezone=America%2FSao_Paulo";
  const ctl=new AbortController(), to=setTimeout(()=>ctl.abort(),8000);
  try{ const r=await fetch(url,{signal:ctl.signal}); clearTimeout(to); if(!r.ok) throw new Error("HTTP "+r.status); let j=await r.json(); if(!Array.isArray(j)) j=[j];
    const out={}; ids.forEach((id,i)=>{ const c=j[i]&&j[i].current; if(!c) return; out[id]={tipo:a3WMO(c.weather_code,c.wind_speed_10m),temp:Math.round(c.temperature_2m),vento:Math.round(c.wind_speed_10m),chuva:c.precipitation,fonte:"auto"}; });
    return {cid:out,em:iso(new Date()),fonte:"Open-Meteo"}; }catch(e){ clearTimeout(to); return null; } }
async function a3ClimaCarrega(forcar){
  const man=(A3.climaDb&&A3.climaDb.cid)||{}, agora=Date.now();
  const venceu=!A3.climaAuto||agora-A3.climaAutoT>15*60000, retenta=!A3.climaFalhaT||agora-A3.climaFalhaT>2*60000;
  if(forcar||(venceu&&retenta)){ if(A3.climaBuscando) return; A3.climaBuscando=true; let a=null; try{ a=await a3ClimaBusca(); }finally{ A3.climaBuscando=false; }
    if(a){ A3.climaAuto=a; A3.climaAutoT=agora; A3.climaStatus="auto"; A3.climaFalhaT=0;
      /* compartilha a leitura: quem estiver numa rede sem acesso ao serviço usa a última leitura salva */
      const da=A3.climaDb&&A3.climaDb.auto; if(state.db&&(!da||agora-new Date(da.em).getTime()>10*60000)){ try{ await state.db.doc("meta/clima").set(Object.assign({},A3.climaDb||{},{auto:a})); }catch(e){} } }
    else { A3.climaFalhaT=agora; const da=A3.climaDb&&A3.climaDb.auto;
      if(da&&da.cid&&agora-new Date(da.em).getTime()<3*3600000){ A3.climaAuto=da; A3.climaAutoT=new Date(da.em).getTime(); A3.climaStatus="salvo"; }
      else if(!A3.climaAuto) A3.climaStatus="sem"; } }
  const cid={}; A3_CLIMA_CID.forEach(id=>{ const m=man[id], a=A3.climaAuto&&A3.climaAuto.cid[id]; cid[id]=m&&m.fixo?m:(a||m||null); });
  A3.clima=cid; if(A3.ok) a3ClimaCena(); a3ClimaHud(); }
/* atualização automática do clima: confere a cada minuto, busca de novo a cada 15 min (ou 2 min se falhou) */
setInterval(()=>{ if(A3.clima!==undefined||A3.climaStatus) a3ClimaCarrega(false); },60000);
function a3ClimaDb(){ if(!state.db||A3.climaSub) return; try{ A3.climaSub=state.db.doc("meta/clima").onSnapshot(s=>{ A3.climaDb=s.exists?s.data():null; a3ClimaCarrega(false); },()=>{}); }catch(e){ A3.climaSub=true; } }
/* texturas */
function a3TexGota(){ return A3.texGota||(A3.texGota=a3Tex(8,64,(x,w,h)=>{ const g=x.createLinearGradient(0,0,0,h); g.addColorStop(0,"rgba(200,220,255,0)"); g.addColorStop(1,"rgba(210,230,255,.9)"); x.fillStyle=g; x.fillRect(2,0,4,h); })); }
function a3ClimaSprite(c,nome){ const [em,txt]=A3_TIPOS[c.tipo]||["❔",""]; const cv=document.createElement("canvas"), x=cv.getContext("2d"); cv.width=300; cv.height=120;
  x.fillStyle="rgba(255,255,255,.93)"; x.beginPath(); x.roundRect?x.roundRect(4,4,292,112,24):x.rect(4,4,292,112); x.fill(); x.strokeStyle={trovoada:"#6B4FA0",forte:"#1D5E9E",chuva:"#1D5E9E",garoa:"#4F86C6",sol:"#E0A020",vento:"#5A6A77"}[c.tipo]||"#8897A3"; x.lineWidth=5; x.stroke();
  x.font="64px 'Segoe UI Emoji','Apple Color Emoji','Noto Color Emoji',sans-serif"; x.textBaseline="middle"; x.fillText(em,16,62);
  x.fillStyle="#13202A"; x.font="bold 44px Arial"; x.fillText((c.temp!=null?c.temp+"°":"—"),104,46); x.font="600 22px Arial"; x.fillStyle="#46555F"; x.fillText(txt+(c.vento!=null?" · "+c.vento+" km/h":""),104,90);
  const t=new THREE.CanvasTexture(cv); const s=new THREE.Sprite(new THREE.SpriteMaterial({map:t,depthTest:false,transparent:true,sizeAttenuation:false})); s.scale.set(.135,.054,1); s.center.set(.5,0); s.renderOrder=13; return s; }
/* monta os efeitos na cena */
function a3ClimaCena(){ const sc=A3.scene; (A3.climaObjs||[]).forEach(o=>{ o.parent&&o.parent.remove(o); }); A3.climaObjs=[]; A3.climaFx=[]; if(A3.climaOff) return;
  const add=o=>{ sc.add(o); A3.climaObjs.push(o); return o; };
  Object.entries(A3.clima||{}).forEach(([id,c])=>{ if(!c||!NO[id]) return; const p=a3XZ(NO[id].ll), y0=a3Chao(p.x,p.z), R=34;
    const ic=a3ClimaSprite(c,NO[id].n); ic.position.set(p.x,y0+30,p.z); add(ic);
    const fx={id,c,p,y0,R};
    const chuva=c.tipo==="chuva"||c.tipo==="forte"||c.tipo==="trovoada"||c.tipo==="garoa";
    if(chuva||c.tipo==="nublado"||c.tipo==="neblina"){ // nuvens escuras locais
      const cor=c.tipo==="trovoada"?0x55606B:chuva?0x7F8B96:0xC9D1D8, m=new THREE.MeshStandardMaterial({color:cor,roughness:1,transparent:true,opacity:c.tipo==="neblina"?.35:.88,depthWrite:false}), g=new THREE.Group(), geo=new THREE.SphereGeometry(1,16,12), r=a3Rnd(a3Hash(id));
      const n=c.tipo==="trovoada"?9:6; for(let i=0;i<n;i++){ const s=new THREE.Mesh(geo,m); const e=7+r()*7; s.scale.set(e*1.5,e*.6,e); s.position.set((r()-.5)*R*1.3,r()*4,(r()-.5)*R); g.add(s); }
      g.position.set(p.x,y0+(c.tipo==="neblina"?6:46),p.z); add(g); fx.nuvem=g; }
    if(chuva){ const N=c.tipo==="garoa"?500:c.tipo==="forte"||c.tipo==="trovoada"?1800:1100, pos=new Float32Array(N*3), vel=new Float32Array(N), r=a3Rnd(a3Hash(id)+5);
      for(let i=0;i<N;i++){ pos[i*3]=p.x+(r()-.5)*R*1.6; pos[i*3+1]=y0+r()*44; pos[i*3+2]=p.z+(r()-.5)*R*1.4; vel[i]=(c.tipo==="garoa"?22:48)+r()*16; }
      const geo=new THREE.BufferGeometry(); geo.setAttribute("position",new THREE.BufferAttribute(pos,3));
      const pts=new THREE.Points(geo,new THREE.PointsMaterial({map:a3TexGota(),size:c.tipo==="garoa"?.9:1.6,transparent:true,depthWrite:false,color:0xDDE8F5})); add(pts); fx.chuva={pts,vel,N}; }
    if(c.tipo==="trovoada"){ const luz=new THREE.PointLight(0xC8D4FF,0,160,1.5); luz.position.set(p.x,y0+40,p.z); add(luz);
      const raio=new THREE.Line(new THREE.BufferGeometry(),new THREE.LineBasicMaterial({color:0xF4F2FF,transparent:true,opacity:0,linewidth:2})); add(raio); fx.trov={luz,raio,prox:1+Math.random()*3}; }
    if(c.tipo==="sol"||c.tipo==="parcial"){ const s=a3Emoji("☀️",7); s.position.set(p.x+10,y0+44,p.z-6); s.material.depthTest=true; add(s); fx.sol=s; }
    if(c.tipo==="vento"||(c.vento||0)>=28){ const N=36, g=new THREE.Group(), m=new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.55,depthWrite:false}), r=a3Rnd(a3Hash(id)+9);
      for(let i=0;i<N;i++){ const f=new THREE.Mesh(new THREE.PlaneGeometry(6+r()*6,.25),m); f.rotation.x=-Math.PI/2; f.position.set((r()-.5)*R*1.6,4+r()*16,(r()-.5)*R*1.4); f.userData.v=18+r()*14; g.add(f); f.rotation.z=0; }
      g.position.set(p.x,y0,p.z); add(g); fx.vento={g,R}; }
    if(c.tipo==="neblina"){ const m=new THREE.Mesh(new THREE.CylinderGeometry(R,R,10,32,1,true),new THREE.MeshBasicMaterial({color:0xEEF2F5,transparent:true,opacity:.28,depthWrite:false,side:THREE.DoubleSide})); m.position.set(p.x,y0+5,p.z); add(m); }
    A3.climaFx.push(fx); });
  A3.ventoForte=Object.values(A3.clima||{}).some(c=>c&&(c.tipo==="vento"||c.tipo==="trovoada"));
}
function a3ClimaPasso(dt,tt){ (A3.climaFx||[]).forEach(fx=>{
  if(fx.chuva){ const P=fx.chuva.pts.geometry.attributes.position, v=fx.chuva.vel; for(let i=0;i<fx.chuva.N;i++){ let y=P.array[i*3+1]-v[i]*dt; P.array[i*3]+=dt*4; if(y<fx.y0){ y=fx.y0+44; P.array[i*3]=fx.p.x+(Math.random()-.5)*fx.R*1.6; } P.array[i*3+1]=y; } P.needsUpdate=true; }
  if(fx.nuvem){ fx.nuvem.position.x=fx.p.x+Math.sin(tt*.12+fx.p.z)*4; }
  if(fx.sol){ const k=7+Math.sin(tt*2)*.5; fx.sol.scale.set(k,k,1); fx.sol.material.rotation=tt*.25; }
  if(fx.vento){ fx.vento.g.children.forEach(f=>{ f.position.x+=f.userData.v*dt; if(f.position.x>fx.R) f.position.x=-fx.R; f.material.opacity=.5; }); }
  if(fx.trov){ const T=fx.trov; T.prox-=dt; if(T.prox<=0){ T.prox=2+Math.random()*4; T.flash=.35;
      const pts=[]; let x=fx.p.x+(Math.random()-.5)*fx.R, z=fx.p.z+(Math.random()-.5)*fx.R, y=fx.y0+44; while(y>fx.y0){ pts.push(new THREE.Vector3(x,y,z)); y-=3+Math.random()*4; x+=(Math.random()-.5)*4; z+=(Math.random()-.5)*4; } pts.push(new THREE.Vector3(x,fx.y0,z));
      T.raio.geometry.dispose(); T.raio.geometry=new THREE.BufferGeometry().setFromPoints(pts); if(A3.sound) a3Trovao(); }
    if(T.flash>0){ T.flash-=dt; const f=Math.max(0,T.flash)/.35, pisca=(Math.floor(T.flash*30)%2)?1:.4; T.luz.intensity=6*f*pisca; T.raio.material.opacity=f*pisca; } else { T.luz.intensity=0; T.raio.material.opacity=0; } }
}); }
function a3Trovao(){ try{ const ctx=(A3.audioNodes&&A3.audioNodes.ctx)||new (window.AudioContext||window.webkitAudioContext)(); const d=1.8, b=ctx.createBuffer(1,ctx.sampleRate*d,ctx.sampleRate), a=b.getChannelData(0); for(let i=0;i<a.length;i++) a[i]=(Math.random()*2-1)*Math.pow(1-i/a.length,2);
  const s=ctx.createBufferSource(); s.buffer=b; const lp=ctx.createBiquadFilter(); lp.type="lowpass"; lp.frequency.value=380; const g=ctx.createGain(); g.gain.value=.25; s.connect(lp); lp.connect(g); g.connect(ctx.destination); s.start(ctx.currentTime+.4); }catch(e){} }
/* painel de clima (legenda + edição manual) */
function a3ClimaHud(){ const el=document.getElementById("a3-clima"); if(!el) return; const C=A3.clima||{};
  const lst=A3_CLIMA_CID.filter(id=>C[id]).map(id=>{ const c=C[id], [em]=A3_TIPOS[c.tipo]||["❔"]; return `<span class="a3-cl" title="${esc((A3_TIPOS[c.tipo]||[,""])[1])}${c.vento!=null?" · vento "+c.vento+" km/h":""}">${em} <b>${esc(NO[id].n.split(" /")[0])}</b> ${c.temp!=null?c.temp+"°":""}</span>`; }).join("");
  const st=A3.climaStatus==="auto"?`Tempo real (Open-Meteo) · atualizado ${A3.climaAuto?fmt(A3.climaAuto.em).slice(-5):""} · renova a cada 15 min`:A3.climaStatus==="salvo"?`Última leitura salva (Open-Meteo) · ${A3.climaAuto?fmt(A3.climaAuto.em):""}`:A3.climaStatus==="sem"?(window.CONFIG_NUVEM?"Sem acesso ao serviço de clima nesta rede — tentando de novo a cada 2 min · ✎ Ajustar para informar":"Sem acesso ao serviço de clima — use ✎ Ajustar para informar"):"Carregando clima…";
  el.innerHTML=`<span class="a3-cls">🌦 ${st}</span>${lst}<span style="flex:1"></span><button class="btn sm" type="button" id="a3-clr">↻ Atualizar</button><button class="btn sm" type="button" id="a3-cle">✎ Ajustar</button><button class="btn sm" type="button" id="a3-clo" aria-pressed="${!A3.climaOff}">${A3.climaOff?"Mostrar clima":"Ocultar clima"}</button><button class="btn sm${A3.todosNum?" pri":""}" type="button" id="a3-cln" aria-pressed="${!!A3.todosNum}">${A3.todosNum?"Ocultar nº containers":"Mostrar nº containers"}</button>`;
  el.querySelector("#a3-clr").onclick=()=>{ A3.climaStatus=null; a3ClimaHud(); a3ClimaCarrega(true); };
  el.querySelector("#a3-clo").onclick=()=>{ A3.climaOff=!A3.climaOff; if(A3.ok) a3ClimaCena(); a3ClimaHud(); };
  el.querySelector("#a3-cle").onclick=()=>a3ClimaEditar();
  el.querySelector("#a3-cln").onclick=()=>{ A3.todosNum=!A3.todosNum; try{ localStorage.setItem("iveco.a3num",A3.todosNum?"1":"0"); }catch(e){} a3ClimaHud(); }; }
function a3ClimaEditar(){ const C=A3.clima||{}, man=(A3.climaDb&&A3.climaDb.cid)||{};
  const ops=Object.entries(A3_TIPOS).map(([k,[e,t]])=>`<option value="${k}">${e} ${t}</option>`).join("");
  const html=`<h2 style="margin:0 0 4px">Clima nas cidades</h2><p class="sub" style="margin:0 0 12px">Marque “fixar” para manter sua informação no lugar da automática (ex.: chuva informada pelo motorista).</p>
    <div class="a3-clg">${A3_CLIMA_CID.filter(id=>NO[id]).map(id=>{ const c=C[id]||{}, m=man[id]||{}; return `<div class="a3-clrow" data-id="${id}"><b>${esc(NO[id].n)}</b><select class="c-t">${ops}</select><input class="c-temp" type="number" placeholder="°C" value="${c.temp??""}"><input class="c-v" type="number" placeholder="km/h" value="${c.vento??""}"><label class="chk"><input type="checkbox" class="c-f" ${m.fixo?"checked":""}> fixar</label></div>`; }).join("")}</div>
    <div class="row" style="margin-top:14px;gap:8px;justify-content:flex-end"><button class="btn" type="button" id="c-cancel">Cancelar</button><button class="btn pri" type="button" id="c-ok">Salvar</button></div>`;
  const ov=document.createElement("div"); ov.className="a3-modal"; ov.innerHTML=`<div class="a3-mbox">${html}</div>`; (document.fullscreenElement||document.body).appendChild(ov);
  ov.querySelectorAll(".a3-clrow").forEach(r=>{ const c=C[r.dataset.id]; if(c) r.querySelector(".c-t").value=c.tipo; });
  const fecha=()=>ov.remove(); ov.onclick=e=>{ if(e.target===ov) fecha(); }; ov.querySelector("#c-cancel").onclick=fecha;
  ov.querySelector("#c-ok").onclick=async()=>{ const cid={}; ov.querySelectorAll(".a3-clrow").forEach(r=>{ const t=r.querySelector(".c-temp").value, v=r.querySelector(".c-v").value; cid[r.dataset.id]={tipo:r.querySelector(".c-t").value,temp:t===""?null:+t,vento:v===""?null:+v,fixo:r.querySelector(".c-f").checked,fonte:"manual"}; });
    A3.climaDb={cid,em:iso(new Date())}; fecha(); a3ClimaCarrega(false);
    try{ state.db&&await state.db.doc("meta/clima").set(A3.climaDb); toast("Clima atualizado"); }catch(e){ toast("Clima aplicado só nesta tela ("+(e.code||e.message)+")"); } }; }
/* ---------- aba ---------- */
function renderAnim(){
  const el=$("#v-anim"); if(!el||el.hidden){ A3.vis=false; return; }
  A3.vis=true;
  if(!el.dataset.pronto){ el.dataset.pronto="1";
    el.innerHTML=`<div class="a3-top"><div><h2>Painel 3D · operação Iveco</h2><p class="sub">Arraste para girar, role para aproximar, clique num veículo para ver os detalhes. Os filtros do Painel BI valem aqui, exceto quando você escolhe containers em “Filtrar containers”.</p></div>
      <div class="a3-acts"><div class="a3-fwrap"><button class="btn a3-fbtn" type="button" id="a3-fil" aria-expanded="false">📦 Filtrar containers<span id="a3-fn"></span></button><div class="a3-pop" id="a3-pop" hidden></div></div><button class="btn" type="button" id="a3-tour" aria-pressed="false">▶ Passeio pelos veículos</button><button class="btn" type="button" id="a3-som" aria-pressed="false">🔈 Sirene</button><button class="btn" type="button" id="a3-lab" aria-pressed="true">🏷 Rótulos</button><button class="btn" type="button" id="a3-visao">⤢ Visão geral</button><button class="btn" type="button" id="a3-full" title="Tela cheia (Esc para sair)">⛶ Tela cheia</button><label class="btn" for="a3-logo">🖼 Logotipo das portas</label><input type="file" id="a3-logo" accept="image/png,image/jpeg,image/webp,image/svg+xml" hidden></div></div>
      <div class="a3-hud" id="a3-hud"></div>
      <div class="a3-clima" id="a3-clima"></div><div class="a3-ban" id="a3-ban" hidden></div><div class="a3-stage" id="a3-stage"><button type="button" class="a3-fsb" id="a3-fsb" title="Tela cheia">⛶</button><div class="a3-load" id="a3-load">Carregando o cenário 3D…</div><div class="a3-tip" id="a3-tip" hidden></div><aside class="a3-info" id="a3-info" hidden></aside></div>
      <div class="a3-leg"><span>🚨 sirene = atrasado</span><span>❗ = em risco</span><span>👍 = no prazo</span><span>🅿️ pátio = chegou, aguardando doca</span><span>portas abertas na doca = descarregando</span><span>🏗️ Sada Caju = aguardando carregamento</span><span>🚑🚓🚒 = acidente / interdição</span><span>👷 = obra / trânsito</span><span>🌧️⛈️☀️💨 = clima na cidade</span></div>`;
    const st=el.querySelector("#a3-stage");
    a3Load().then(()=>{ if(!A3.logoSrc) a3AplicaLogo(A3_LOGO); A3.portaTex=a3TexPorta(); a3Montar(st); el.querySelector("#a3-load").remove(); a3Popular(); A3.sig=a3Sig(); a3Loop(); a3LogoDb(); if(A3.selCn&&A3.selCn.size) a3Enquadrar(); a3ClimaDb(); a3ClimaCarrega(false); setInterval(()=>{ if(A3.vis) a3ClimaCarrega(false); },10*60000); })
      .catch(e=>{ el.querySelector("#a3-load").textContent="Não foi possível carregar o cenário 3D ("+e.message+"). Recarregue a página."; });
    a3FiltroUI(el);
    const tFull=()=>{ const on=!!(document.fullscreenElement===el||el.classList.contains("a3-full"));
      if(on){ if(document.fullscreenElement) document.exitFullscreen().catch(()=>{}); el.classList.remove("a3-full"); a3FullSync(el); return; }
      const alt=()=>{ el.classList.add("a3-full"); a3FullSync(el); };
      if(el.requestFullscreen){ el.requestFullscreen().then(()=>a3FullSync(el)).catch(alt); } else alt(); };
    el.querySelector("#a3-full").onclick=tFull; el.querySelector("#a3-fsb").onclick=tFull;
    document.addEventListener("fullscreenchange",()=>a3FullSync(el));
    document.addEventListener("keydown",e=>{ if(e.key==="Escape"&&el.classList.contains("a3-full")&&!document.querySelector(".a3-pop:not([hidden])")){ el.classList.remove("a3-full"); a3FullSync(el); } });
    el.querySelector("#a3-tour").onclick=ev=>{ A3.tour=!A3.tour; ev.currentTarget.setAttribute("aria-pressed",String(A3.tour)); if(A3.tour) a3Tour(); else { clearTimeout(A3.tourT); A3.tourAlvo=null; } };
    el.querySelector("#a3-som").onclick=ev=>{ const on=!A3.sound; A3.somFixo=on; a3AtivaSom(on); ev.currentTarget.setAttribute("aria-pressed",String(on)); ev.currentTarget.textContent=on?"🔊 Sirene ligada":"🔈 Sirene"; };
    el.querySelector("#a3-lab").onclick=ev=>{ A3.labels=!A3.labels; ev.currentTarget.setAttribute("aria-pressed",String(A3.labels)); A3.anims.forEach(a=>{ if(a.g&&a.g.userData.lb) a.g.userData.lb.visible=A3.labels; }); };
    el.querySelector("#a3-visao").onclick=()=>{ if(!A3.ok) return; A3.seguir=null; A3.tour=false; A3.tourAlvo=null; A3.foco=null; el.querySelector("#a3-tour").setAttribute("aria-pressed","false"); a3VisaoGeral(); };
    el.querySelector("#a3-logo").onchange=e=>{ const f=e.target.files[0]; if(!f) return; const rd=new FileReader(); rd.onload=()=>{ const im=new Image(); im.onload=async()=>{ const c=document.createElement("canvas"), r=Math.min(1,320/Math.max(im.width,im.height)); c.width=Math.round(im.width*r); c.height=Math.round(im.height*r); c.getContext("2d").drawImage(im,0,0,c.width,c.height); const url=c.toDataURL("image/png");
        a3AplicaLogo(url); try{ state.db&&await state.db.doc("meta/logo").set({img:url,em:iso(new Date())}); toast("Logotipo aplicado nas portas"); }catch(er){ toast("Logotipo aplicado só nesta tela ("+(er.code||er.message)+")"); } }; im.src=rd.result; }; rd.readAsDataURL(f); e.target.value=""; };
  } else if(A3.ok){ const s=a3Sig(); if(s!==A3.sig){ A3.sig=s; a3Popular(); } }
}
function a3Sig(){ const {vs,sv}=a3Dados(); return vs.map(v=>v.placa+v.est+v.node+v.carga+v.cns.map(armadorDe).join(",")).join("|")+"#"+sv.length+"#"+listaAlertas().length; }
function a3AplicaLogo(url){ if(A3.logoSrc===url) return; A3.logoSrc=url; const im=new Image(); im.onload=()=>{ A3.logoImg=im; if(!A3.portaTex) return; const t=a3TexPorta(); A3.portaTex.image=t.image; A3.portaTex.needsUpdate=true; }; im.src=url; }
function a3LogoDb(){ if(!state.db||A3.logoSub) return; try{ A3.logoSub=state.db.doc("meta/logo").onSnapshot(s=>{ const d=s.exists?s.data():null; if(d&&d.img) a3AplicaLogo(d.img); },()=>{}); }catch(e){ A3.logoSub=true; } }
document.addEventListener("visibilitychange",()=>{ if(document.hidden) A3.vis=false; else renderAnim(); });

const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

/* ---------- datas ---------- */
const pad = n => String(n).padStart(2,"0");
function toD(s){ if(!s) return null; const d = new Date(s); return isNaN(d) ? null : d; }
function iso(d){ return d.getFullYear()+"-"+pad(d.getMonth()+1)+"-"+pad(d.getDate())+"T"+pad(d.getHours())+":"+pad(d.getMinutes()); }
function fmt(s){ const d = typeof s==="string"? toD(s) : s; if(!d) return "—"; return pad(d.getDate())+"/"+pad(d.getMonth()+1)+" "+pad(d.getHours())+":"+pad(d.getMinutes()); }
function fmtH(s){ const d = toD(s); return d? pad(d.getHours())+":"+pad(d.getMinutes()) : "—"; }
function dia(s){ return s ? s.slice(0,10) : ""; }
function diaBR(k){ return k ? k.slice(8,10)+"/"+k.slice(5,7)+"/"+k.slice(0,4) : ""; }
function dur(min){ const a=Math.abs(Math.round(min)); const h=Math.floor(a/60), m=a%60; return (min<0?"−":"+")+h+"h"+pad(m); }
function ago(s){ const d=toD(s); if(!d) return "—"; const m=Math.round((Date.now()-d)/60000); if(m<1) return "agora"; if(m<60) return "há "+m+" min"; const h=Math.floor(m/60); return "há "+h+"h"+pad(m%60); }
// Excel serial -> iso local (sem fuso)
function serialToIso(n){ const ms = Math.round((n-25569)*86400000); const d = new Date(ms); return d.getUTCFullYear()+"-"+pad(d.getUTCMonth()+1)+"-"+pad(d.getUTCDate())+"T"+pad(d.getUTCHours())+":"+pad(d.getUTCMinutes()); }
function parseVal(v){
  if(v==null) return null;
  if(typeof v==="number"){ if(v>0 && v<1){ const t=Math.round(v*1440); return {time:pad(Math.floor(t/60))+":"+pad(t%60)}; } if(v>20000 && v<80000) return {iso:serialToIso(v)}; return null; }
  if(v instanceof Date) return {iso:iso(v)};
  const s=String(v).trim(); let m;
  if((m=s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})(?:\s+(\d{1,2}):(\d{2})(?::\d{2})?)?$/))){ let y=+m[3]; if(y<100) y+=2000; return {iso:y+"-"+pad(m[2])+"-"+pad(m[1])+"T"+pad(m[4]||0)+":"+pad(m[5]||0)}; }
  if((m=s.match(/^(\d{4})-(\d{2})-(\d{2})(?:[T\s](\d{2}):(\d{2}))?/))) return {iso:m[1]+"-"+m[2]+"-"+m[3]+"T"+(m[4]||"00")+":"+(m[5]||"00")};
  if((m=s.match(/^(\d{1,2}):(\d{2})(?::\d{2})?$/))) return {time:pad(m[1])+":"+m[2]};
  return null;
}
const pIso = v => { const r=parseVal(v); return r&&r.iso ? r.iso : null; };

/* ---------- análise ---------- */
function analisa(p, f, now){
  const need = toD(p.necessidade);
  const r = { tone:"info", label:"", gap:null, eta:null, flags:[], rank:3 };
  if(!need){ r.label="Sem horário de necessidade"; return r; }
  if(!f){
    if(now>need){ r.tone="crit"; r.label="Sem veículo · necessidade vencida"; r.gap=(now-need)/60000; }
    else { const falta=(need-now)/60000; r.tone = falta<360 ? "warn":"info"; r.label = "Sem veículo alocado"; r.flags.push({t:"info", s:"faltam "+dur(falta).slice(1)}); }
  } else {
    const prev = toD(f.prev_chegada), cheg = toD(f.chegada);
    if(cheg && viaBetim(f)){ const env=enviarIveco(f); r.tone = now>need ? "crit" : "warn"; r.label = env ? "Enviar para a Iveco (em Betim)" : "Em Betim · "+String(f.status||"").toLowerCase(); if(now>need) r.gap=(now-need)/60000; if(env) r.flags.push({t:"crit", s:`Entregue em Betim ${fmt(f.chegada)} · parado há ${dur((now-cheg)/60000).slice(1)}`}); }
    else if(cheg){ r.eta=f.chegada; r.gap=(cheg-need)/60000; r.tone = r.gap<=0 ? "ok" : (r.gap<=RISK_MIN?"warn":"crit"); r.label = r.gap<=0 ? "Entregue no prazo" : "Entregue com atraso"; }
    else if(!prev){ r.label = (f.status||"").toUpperCase().includes("CARREG")||(f.localizacao||"").toUpperCase().includes("CARREG") ? "No porto · aguardando carregamento" : "Sem previsão de chegada"; r.tone = now>need ? "crit" : "warn"; if(now>need) r.gap=(now-need)/60000; }
    else { r.eta=f.prev_chegada; r.gap=(prev-need)/60000; r.tone = r.gap<=0 ? "ok" : (r.gap<=RISK_MIN ? "warn" : "crit"); r.label = r.gap<=0 ? "No prazo" : (r.gap<=RISK_MIN ? "Risco de atraso" : "Atraso previsto"); }
    if(!cheg && viaBetim(f)) r.flags.push({t:"info", s:"Destino no follow: Betim"});
    const dp = toD(f.data_prog);
    if(emManut(f)){ r.flags.unshift({t:"crit", s:"🔧 "+manutTxt(f)}); if(r.tone!=="crit"){ r.tone="crit"; r.label="Veículo em manutenção"; } }
    if(dp && Math.abs(dp-need)>=60000) r.flags.push({t:"warn", s:"Follow informa programação "+fmt(f.data_prog)});
    if(!cheg && f.atualizadoEm && (now-toD(f.atualizadoEm))/60000 > STALE_MIN) r.flags.push({t:"crit", s:"Follow sem atualização "+ago(f.atualizadoEm)});
  }
  r.rank = {crit:0,warn:1,info:2,ok:3}[r.tone];
  return r;
}
const isLinha = p => /LINHA/i.test(p.criticidade||"");
const isCrit = p => !!(p && String(p.criticidade||"").trim());

/* follow vigente: ignora follow de viagem anterior (chegada antes do carregamento desta programação) */
/* "(vazio)", "-", "N/A" da planilha = campo em branco (senão vários containers sem placa viram "1 veículo") */
function limpaVazios(f){ ["placa_cavalo","placa_reboque","motorista","marca","localizacao","local_entrega"].forEach(k=>{ if(typeof f[k]==="string"&&/^\s*(\(?\s*vazi[oa]\s*\)?|-+|n\/?a|null|—)\s*$/i.test(f[k])) f[k]=""; }); return f; }
function followVelho(f,p){ if(!f||!p||!f.chegada||!p.data_carregamento) return false; const c=toD(f.chegada), d=toD(p.data_carregamento); return !!(c&&d&&(d-c)>2*864e5); }
/* programação vigente: está na última programação importada (imports não apagam quem saiu da planilha) */
function progVigente(p){ const up=String(state.meta.ultimaProg||"").slice(0,16); return !!p&&(!up||String(p.atualizadoEm||"").slice(0,16)>=up); }
function followDe(cn){ const f=state.follow[cn], p=state.prog[cn]; return followVelho(f,p)?undefined:f; }
/* conferência programação × follow (último follow importado) */
function confereFollow(r){ const p=r.p, fo=state.follow[r.cn], uf=String(state.meta.ultimoFollow||"").slice(0,16);
  if(p&&!progVigente(p)) return "";
  if(p&&!fo) return "nunca"; if(p&&followVelho(fo,p)) return "anterior";
  if(p&&fo&&uf&&String(fo.atualizadoEm||"").slice(0,16)<uf&&r.carga!=="entregue") return "saiu";
  if(!p&&fo&&uf&&String(fo.atualizadoEm||"").slice(0,16)>=uf) return "semprog";
  return ""; }
function linhasComp(){
  const now = new Date();
  return Object.values(state.prog).filter(p=>progVigente(p)).map(p => ({p, f:followDe(p.container), a:analisa(p, followDe(p.container), now)}))
    .sort((x,y)=> x.a.rank-y.a.rank || (isLinha(y.p)-isLinha(x.p)) || String(x.p.necessidade).localeCompare(String(y.p.necessidade)));
}
function filtra(rows, pick){
  const q = state.q.trim().toUpperCase();
  return rows.filter(r => {
    if(state.dia && dia(r.p ? r.p.necessidade : "") !== state.dia && r.p) return false;
    if(state.sit && r.a && r.a.tone!==state.sit) return false;
    if(state.soCrit && r.p && !isCrit(r.p)) return false;
    if(!q) return true;
    return pick(r).toUpperCase().includes(q);
  });
}

/* ---------- render ---------- */
function render(){
  $("#st-now").textContent = fmt(new Date());
  $("#st-follow").textContent = state.meta.ultimoFollow ? fmt(state.meta.ultimoFollow)+" ("+ago(state.meta.ultimoFollow)+")" : "—";
  $("#st-prog").textContent = state.meta.ultimaProg ? fmt(state.meta.ultimaProg) : "—";
  renderDias();
  const all = linhasComp();
  const scoped = all.filter(r => !state.dia || dia(r.p.necessidade)===state.dia);
  renderKpis(scoped); renderInsights(scoped);
  const rows = filtra(all, r => [r.p.container, r.f&&r.f.motorista, r.f&&r.f.placa_cavalo, r.f&&r.f.localizacao, r.p.solicitante, r.p.navio].join(" "));
  $("#c-comp").textContent = rows.length;
  renderComp(rows); renderTl(rows); renderFora(); renderProg(); renderInd(); renderCrit(); renderRod(); renderBI(); renderAnim(); renderTab(); renderFC();
  /* resumo aberto: refaz com os dados novos (se o texto não foi editado) */
  if(window.__gerAtu){ clearTimeout(window.__gerT); window.__gerT=setTimeout(()=>{ const t=document.querySelector("#g-txt"); if(window.__gerAtu&&!(t&&t.dataset.editado)) window.__gerAtu(); },1500); }
}

function renderDias(){
  const sel = $("#f-dia"); const dias = [...new Set(Object.values(state.prog).map(p=>dia(p.necessidade)).filter(Boolean))].sort();
  const cur = state.dia;
  const html = '<option value="">Todos os dias</option>' + dias.map(d=>`<option value="${d}">Necessidade ${diaBR(d)}</option>`).join("");
  if(sel.dataset.h!==html){ sel.innerHTML=html; sel.dataset.h=html; }
  sel.value = dias.includes(cur) ? cur : "";
}

function renderKpis(rows){
  const n=rows.length, com=rows.filter(r=>r.f).length, sem=n-com;
  const noPrazo=rows.filter(r=>r.a.tone==="ok").length;
  const atraso=rows.filter(r=>r.f && r.a.gap>0).length;
  const semVenc=rows.filter(r=>!r.f && r.a.tone==="crit").length;
  const linha=rows.filter(r=>isLinha(r.p)), linhaRisco=linha.filter(r=>r.a.tone!=="ok").length;
  const gaps=rows.filter(r=>r.f && r.a.eta && r.a.gap!=null).map(r=>r.a.gap);
  const med = gaps.length ? gaps.reduce((a,b)=>a+b,0)/gaps.length : null;
  const ader = n ? Math.round(noPrazo/n*100) : 0;
  const k=(cls,t,v,s)=>`<div class="kpi ${cls}"><span class="k">${t}</span><span class="v">${v}</span><span class="s">${s}</span></div>`;
  $("#kpis").innerHTML =
    k("acc","Programados",n,"containers solicitados")+
    k(com<n?"warn":"ok","Com veículo",com,`${n?Math.round(com/n*100):0}% com follow`)+
    k(sem?"crit":"ok","Sem veículo",sem,`${semVenc} já vencidos`)+
    k(atraso?"crit":"ok","Atraso x necessidade",atraso,"em trânsito ou no porto")+
    k(linhaRisco?"crit":"ok","Item p/ linha em risco",linhaRisco,`de ${linha.length} críticos`)+
    k(med>0?"warn":"ok","Desvio médio ETA",med==null?"—":dur(med),"previsão − necessidade")+
    k(ader>=90?"ok":(ader>=70?"warn":"crit"),"Aderência",ader+"%","no prazo ou entregue");
}

function renderInsights(rows){
  const out=[]; const now=new Date();
  const n=rows.length; if(!n){ $("#insights").innerHTML='<h2>Análise</h2><div class="ins info"><i></i><span>Importe a programação da Iveco para ver a análise.</span></div>'; return; }
  const semVenc=rows.filter(r=>!r.f && toD(r.p.necessidade)<now);
  const sem=rows.filter(r=>!r.f);
  const porto=rows.filter(r=>r.f && !r.f.prev_chegada && !r.f.chegada);
  const linhaRisco=rows.filter(r=>isLinha(r.p) && r.a.tone!=="ok");
  const div=rows.filter(r=>r.a.flags.some(f=>f.s.startsWith("Follow informa")));
  const stale=rows.filter(r=>r.a.flags.some(f=>f.s.startsWith("Follow sem")));
  const trans=rows.filter(r=>r.f && r.a.eta && !r.f.chegada);
  const melhor=trans.slice().sort((a,b)=>a.a.gap-b.a.gap)[0];
  const pior=trans.slice().sort((a,b)=>b.a.gap-a.a.gap)[0];
  const cn = arr => arr.slice(0,6).map(r=>`<span class="mono">${esc(r.p.container)}</span>`).join(", ")+(arr.length>6?` e mais ${arr.length-6}`:"");
  if(linhaRisco.length) out.push(["crit",`<b>${linhaRisco.length} de ${rows.filter(r=>isLinha(r.p)).length} itens para linha</b> não atendem a necessidade: ${cn(linhaRisco)}. Priorizar escalonamento com o cliente.`]);
  if(sem.length) out.push(["crit",`<b>${sem.length} containers programados sem veículo no follow</b>${semVenc.length?` (${semVenc.length} já passaram do horário)`:""}: ${cn(sem)}.`]);
  if(porto.length) out.push(["warn",`<b>${porto.length} ainda no porto aguardando carregamento</b>, sem previsão de chegada: ${cn(porto)}.`]);
  if(trans.length) out.push([pior&&pior.a.gap>RISK_MIN?"crit":"warn",`Em trânsito: <b>${trans.filter(r=>r.a.gap<=0).length} de ${trans.length}</b> chegam dentro da necessidade. Maior atraso previsto: <span class="mono">${esc(pior.p.container)}</span> ${dur(pior.a.gap)}; mais próximo: <span class="mono">${esc(melhor.p.container)}</span> ${dur(melhor.a.gap)}.`]);
  if(div.length) out.push(["warn",`<b>${div.length} follows informam horário programado diferente</b> da programação Iveco: ${cn(div)}. Alinhar a coluna DATA PROGRAMADA do follow com a do cliente.`]);
  if(stale.length) out.push(["crit",`<b>${stale.length} follows sem atualização há mais de ${STALE_MIN} min</b>. O combinado é de hora em hora: importe o último e-mail.`]);
  if(!out.length) out.push(["ok","Todos os containers programados estão cobertos e dentro da necessidade."]);
  $("#insights").innerHTML = '<h2>Análise · necessidade do cliente × follow-up</h2>' + out.map(([t,h])=>`<div class="ins ${t}"><i></i><span>${h}</span></div>`).join("");
}

function renderComp(rows){
  if(!rows.length){ $("#v-comp").innerHTML='<div class="empty">Nenhum container para os filtros atuais.</div>'; return; }
  $("#v-comp").innerHTML = `<table><thead><tr><th></th><th>Container</th><th>Necessidade Iveco</th><th>Criticidade</th><th>Situação</th><th>Posição (follow)</th><th>Previsão / chegada</th><th>Desvio</th><th>Veículo</th><th>Descarga</th></tr></thead><tbody>${
    rows.map(r=>{ const p=r.p, f=r.f, a=r.a; return `<tr data-cn="${esc(p.container)}" data-tone="${a.tone}" tabindex="0">
      <td class="sev"></td>
      <td><div class="cn">${esc(p.container)}</div><div class="sub">${esc(p.navio||"")}</div></td>
      <td class="num"><b>${fmt(p.necessidade)}</b><div class="sub">${esc(p.solicitante||"")}</div></td>
      <td>${isLinha(p)?'<span class="linha">Item p/ linha</span>':'<span class="sub">—</span>'}<div class="sub">${esc(p.carga||"")}${p.desova==="SIM"?" · desova":""}</div></td>
      <td><span class="pill ${a.tone}">${esc(a.label)}</span>${a.flags.length?`<div class="chips">${a.flags.map(x=>`<span class="chip ${x.t}">${esc(x.s)}</span>`).join("")}</div>`:""}</td>
      <td>${f?`${esc(f.localizacao||"—")}<div class="sub">${esc(f.status||"")}${f.atualizadoEm?` · follow ${fmtH(f.atualizadoEm)}`:""}${f.editadoEm&&(!f.atualizadoEm||f.editadoEm>f.atualizadoEm)?` · editado ${fmtH(f.editadoEm)}`:""}</div>`:'<span class="sub">Sem follow</span>'}</td>
      <td class="num">${f&&f.chegada?`<b>${fmt(f.chegada)}</b><div class="sub">chegou</div>`:(f&&f.prev_chegada?fmt(f.prev_chegada):"—")}${f&&f.inicio?`<div class="sub">saída ${fmt(f.inicio)}</div>`:""}</td>
      <td>${a.gap!=null?`<span class="gap ${a.tone==="info"?"":a.tone}">${dur(a.gap)}</span>`:'<span class="sub">—</span>'}</td>
      <td>${f?`<span class="mono">${esc(f.placa_cavalo||"")}</span><div class="sub">${esc(f.motorista||"")}</div>`:'<span class="sub">—</span>'}</td>
      <td>${esc(p.local_descarga??"")}<div class="sub">dev. vazio ${p.limite_devolucao?fmt(p.limite_devolucao).slice(0,5):"—"}</div></td>
    </tr>`;}).join("")}</tbody></table>`;
}

function renderTl(rows){
  const el=$("#v-tl"); if(el.hidden) return;
  const now=new Date();
  const items=rows.filter(r=>toD(r.p.necessidade)).slice().sort((a,b)=>String(a.p.necessidade).localeCompare(String(b.p.necessidade)));
  if(!items.length){ el.innerHTML='<div class="empty">Sem dados para a linha do tempo.</div>'; return; }
  let t0=Infinity,t1=-Infinity;
  items.forEach(r=>{ [r.p.necessidade, r.a.eta].forEach(s=>{const d=toD(s); if(d){t0=Math.min(t0,+d);t1=Math.max(t1,+d);}}); });
  t0=Math.min(t0,+now); t1=Math.max(t1,+now);
  const H=3600000; t0=Math.floor(t0/H)*H - H; t1=Math.ceil(t1/H)*H + H;
  const W=Math.max(760, el.clientWidth-2), L=128, R=24, top=30, rh=26, h=top+items.length*rh+10;
  const x=t=>L+(t-t0)/(t1-t0)*(W-L-R);
  const span=(t1-t0)/H, step= span>36?6: span>18?3: span>9?2:1;
  let g="";
  for(let t=t0;t<=t1;t+=H){ const d=new Date(t); if(d.getHours()%step) continue; const X=x(t); g+=`<line class="grid" x1="${X}" x2="${X}" y1="${top-6}" y2="${h-6}"/><text x="${X}" y="${top-12}" text-anchor="middle">${d.getHours()===0?pad(d.getDate())+"/"+pad(d.getMonth()+1):pad(d.getHours())+"h"}</text>`; }
  const col={crit:"var(--crit)",warn:"var(--warn)",ok:"var(--ok)",info:"var(--info)"};
  items.forEach((r,i)=>{
    const y=top+i*rh+rh/2, xn=x(+toD(r.p.necessidade)), c=col[r.a.tone];
    g+=`<text class="lbl" x="8" y="${y+4}">${esc(r.p.container)}</text>`;
    if(isLinha(r.p)) g+=`<text x="${L-8}" y="${y+4}" text-anchor="end" style="fill:var(--crit);font-weight:700">L</text>`;
    if(r.a.eta){ const xe=x(+toD(r.a.eta)); g+=`<line x1="${xn}" x2="${xe}" y1="${y}" y2="${y}" stroke="${c}" stroke-width="3" stroke-linecap="round" opacity=".55"/><circle cx="${xe}" cy="${y}" r="5" fill="${c}"/><text x="${xe+(xe>=xn?9:-9)}" y="${y+4}" text-anchor="${xe>=xn?"start":"end"}" style="fill:${c};font-weight:600">${dur(r.a.gap)}</text>`; }
    else { g+=`<text x="${xn+10}" y="${y+4}" style="fill:${c}">${r.f?"sem previsão":"sem veículo"}</text>`; }
    g+=`<path d="M${xn} ${y-6} L${xn+6} ${y} L${xn} ${y+6} L${xn-6} ${y}Z" fill="var(--surface)" stroke="var(--need)" stroke-width="1.6"/>`;
  });
  const xnw=x(+now); g+=`<line class="now" x1="${xnw}" x2="${xnw}" y1="${top-6}" y2="${h-6}"/><text class="nowt" x="${xnw+4}" y="${h-10}">agora ${fmtH(iso(now))}</text>`;
  el.innerHTML=`<svg width="${W}" height="${h}" viewBox="0 0 ${W} ${h}" role="img" aria-label="Linha do tempo: necessidade Iveco versus previsão de chegada">${g}</svg>`;
}

function renderFora(){
  const now=new Date(); const q=state.q.trim().toUpperCase();
  const rows=Object.values(state.follow).filter(f=>!state.prog[f.container])
    .filter(f=>!q || [f.container,f.motorista,f.placa_cavalo,f.localizacao,f.local_entrega].join(" ").toUpperCase().includes(q))
    .map(f=>{ const dp=toD(f.data_prog), ref=toD(f.chegada)||toD(f.prev_chegada); let gap=null,tone="info",label=f.status||"—";
      if(f.chegada){ tone="ok"; } else if(dp && ref){ gap=(ref-dp)/60000; tone=gap<=0?"ok":gap<=RISK_MIN?"warn":"crit"; } else if(dp && now>dp){ gap=(now-dp)/60000; tone="crit"; }
      if(f.chegada && dp){ gap=(toD(f.chegada)-dp)/60000; }
      return {f,gap,tone,label}; })
    .sort((a,b)=>({crit:0,warn:1,info:2,ok:3}[a.tone]-{crit:0,warn:1,info:2,ok:3}[b.tone]) || String(a.f.data_prog).localeCompare(String(b.f.data_prog)));
  $("#c-fora").textContent=rows.length;
  if(!rows.length){ $("#v-fora").innerHTML='<div class="empty">Todos os containers do follow estão na programação atual.</div>'; return; }
  $("#v-fora").innerHTML=`<table><thead><tr><th></th><th>Container</th><th>Destino</th><th>Status</th><th>Localização</th><th>Programado (follow)</th><th>Previsão</th><th>Chegada</th><th>Desvio</th><th>Veículo</th></tr></thead><tbody>${
   rows.map(({f,gap,tone,label})=>`<tr data-cn="${esc(f.container)}" data-tone="${tone}" tabindex="0"><td class="sev"></td>
    <td><div class="cn">${esc(f.container)}</div>${f.idOriginal&&f.idOriginal!==f.container?`<div class="sub">${esc(f.idOriginal)}</div>`:""}</td>
    <td>${esc(f.local_entrega||"")}</td><td><span class="pill ${tone==="info"?"mut":tone}">${esc(label)}</span></td>
    <td>${esc(f.localizacao||"—")}<div class="sub">${f.atualizadoEm?ago(f.atualizadoEm):""}</div></td>
    <td class="num">${fmt(f.data_prog)}</td><td class="num">${fmt(f.prev_chegada)}</td><td class="num">${fmt(f.chegada)}</td>
    <td>${gap!=null?`<span class="gap ${tone==="info"?"":tone}">${dur(gap)}</span>`:'<span class="sub">—</span>'}</td>
    <td><span class="mono">${esc(f.placa_cavalo||"")}</span><div class="sub">${esc(f.motorista||"")}</div></td></tr>`).join("")}</tbody></table>`;
}

function renderProg(){
  const q=state.q.trim().toUpperCase();
  const rows=Object.values(state.prog).filter(p=>!state.dia||dia(p.necessidade)===state.dia)
    .filter(p=>!state.soCrit||isCrit(p))
    .filter(p=>!q||[p.container,p.solicitante,p.navio,p.or].join(" ").toUpperCase().includes(q))
    .sort((a,b)=>String(a.necessidade).localeCompare(String(b.necessidade)));
  $("#c-prog").textContent=rows.length;
  if(!rows.length){ $("#v-prog").innerHTML='<div class="empty">Nenhuma programação importada.</div>'; return; }
  $("#v-prog").innerHTML=`<table><thead><tr><th></th><th>Container</th><th>Carregamento</th><th>Necessidade</th><th>Criticidade</th><th>Solicitante</th><th>Carga</th><th>Navio</th><th>OR / Shipment</th><th>Descarga</th><th>Dev. vazio</th><th>Obs</th></tr></thead><tbody>${
   rows.map(p=>`<tr data-cn="${esc(p.container)}" tabindex="0"><td class="sev"></td><td class="cn">${esc(p.container)}</td>
    <td class="num">${fmt(p.data_carregamento).slice(0,5)}</td><td class="num"><b>${fmt(p.necessidade)}</b></td>
    <td>${isLinha(p)?'<span class="linha">Item p/ linha</span>':'<span class="sub">—</span>'}</td>
    <td>${esc(p.solicitante||"")}</td><td>${esc(p.carga||"")}${p.desova==="SIM"?'<div class="sub">com desova</div>':""}</td>
    <td>${esc(p.navio||"")}</td><td class="mono" style="font-size:12px">${esc(p.or||"")}<div class="sub">${esc(p.shipment||"")}</div></td>
    <td>${esc(p.local_descarga??"")}</td><td class="num">${fmt(p.limite_devolucao).slice(0,5)}</td><td class="sub">${esc(p.obs||"")}</td></tr>`).join("")}</tbody></table>`;
}

/* ---------- críticos Iveco ---------- */
function proximoPasso(r, lead, now){
  const p=r.p, f=r.f, need=toD(p.necessidade), quem=p.solicitante&&!/^FIFO$/i.test(p.solicitante)?p.solicitante:"o solicitante Iveco";
  const passos=[];
  if(emManut(f)) passos.push(`Veículo em manutenção: avisar ${quem} agora e avaliar troca do cavalo mecânico para seguir com o container.`);
  if(r.a.flags.some(x=>x.s.startsWith("Follow sem"))) passos.push("Atualizar a posição: o follow está sem atualização.");
  if(!f || (!f.chegada && !f.prev_chegada)){
    const acao = !f ? "Alocar veículo" : "Priorizar o carregamento no terminal";
    if(lead){ const saidaMax=new Date(need-lead*60000), chegaAgora=new Date(+now+lead*60000);
      passos.push(saidaMax>now ? `${acao}: para cumprir, a saída precisa ocorrer até ${fmt(saidaMax)} (viagem média de ${dur(lead).slice(1)}).`
        : `${acao}. Mesmo saindo agora, a chegada estimada é ${fmt(chegaAgora)} (${dur((chegaAgora-need)/60000)} sobre a necessidade). Negociar nova janela com ${quem}.`); }
    else passos.push(`${acao} e informar ${quem} sobre a nova janela.`);
  } else if(f.chegada){ passos.push(r.a.gap>0?"Entregue com atraso: registrar a causa.":"Entregue no prazo."); }
  else if(r.a.gap>0){ passos.push(`Informar ${quem} da previsão ${fmt(f.prev_chegada)} (${dur(r.a.gap)}) e confirmar se a linha suporta a espera.`); }
  else passos.push("Dentro do prazo: manter o acompanhamento de hora em hora.");
  const dv=r.a.flags.find(x=>x.s.startsWith("Follow informa")); if(dv) passos.push(`Corrigir no follow o horário programado para ${fmt(p.necessidade)} (hoje está ${dv.s.replace("Follow informa programação ","")}).`);
  return passos;
}
function trilha(r, now){
  const f=r.f, need=toD(r.p.necessidade); if(!f||!f.inicio) return "";
  const ini=toD(f.inicio), fim=toD(f.chegada)||toD(f.prev_chegada); if(!ini||!fim) return "";
  const t0=+ini, t1=Math.max(+fim,+need,+now), pos=t=>Math.max(0,Math.min(100,(t-t0)/(t1-t0)*100));
  const pNow=pos(+now), pNeed=pos(+need), pFim=pos(+fim), tone=r.a.tone;
  return `<div class="trilha" aria-label="Andamento da viagem">
    <div class="tr-track"><div class="tr-fill ${tone}" style="width:${f.chegada?pFim:Math.min(pNow,pFim)}%"></div>
      ${need>=ini?`<span class="tr-need" style="left:${pNeed}%" title="Necessidade ${fmt(r.p.necessidade)}"></span>`:""}
      ${!f.chegada?`<span class="tr-now" style="left:${pNow}%" title="Agora"></span>`:""}
      <span class="tr-end ${tone}" style="left:${pFim}%" title="${f.chegada?"Chegada":"Previsão"} ${fmt(f.chegada||f.prev_chegada)}"></span></div>
    <div class="tr-lbl"><span>Saída ${fmt(f.inicio)}</span><span>${f.chegada?"Chegada":"Previsão"} ${fmt(f.chegada||f.prev_chegada)}</span></div></div>`;
}
function listaCrit(rows, lead, now){
  return `<div class="tbl-wrap"><table class="crit-list"><thead><tr><th></th><th>Container</th><th>Necessidade</th><th>Prazo</th><th>Situação</th><th>Posição atual</th><th>Previsão</th><th>× Necessidade</th><th>Veículo</th><th>Solicitante</th></tr></thead><tbody>${
    rows.map(r=>{ const p=r.p,f=r.f,a=r.a, falta=(toD(p.necessidade)-now)/60000, entregue=f&&f.chegada;
      const cd = entregue ? `<span class="sub">entregue</span>` : falta>0 ? `<b class="${falta<180?"t-warn":"t-info"}">vence em ${dur(falta).slice(1)}</b>` : `<b class="t-crit">vencida há ${dur(-falta).slice(1)}</b>`;
      const passos=proximoPasso(r,lead,now);
      return `<tr data-cn="${esc(p.container)}" data-tone="${r.tone2}" tabindex="0"><td class="sev"></td>
        <td><div class="cn">${esc(p.container)}</div><span class="linha">${esc(p.criticidade)}</span></td>
        <td class="num"><b>${fmt(p.necessidade)}</b></td>
        <td style="white-space:nowrap">${cd}</td>
        <td><span class="pill ${r.tone2}">${esc(a.label)}</span>${a.flags.some(x=>x.s.startsWith("Follow sem"))?`<div class="chips"><span class="chip crit">follow desatualizado</span></div>`:""}</td>
        <td>${f?esc(lugar(f.localizacao)):'<span class="sub">Sem veículo</span>'}</td>
        <td class="num" style="white-space:nowrap">${r.est?`<span title="Estimativa se sair agora">≈ ${fmt(r.est)}</span><div class="sub">se sair agora</div>`:(f?fmt(f.chegada||f.prev_chegada):"—")}</td>
        <td><span class="gap ${r.gap2==null?"":r.tone2}">${r.gap2!=null?(r.est?"≈ ":"")+dur(r.gap2):"—"}</span></td>
        <td>${f?`<span class="mono">${esc(f.placa_cavalo||"")}</span><div class="sub">${esc(f.motorista||"")}</div>`:'<span class="sub">—</span>'}</td>
        <td>${esc(p.solicitante||"—")}</td></tr>
        <tr class="nx-row" data-cn="${esc(p.container)}" data-tone="${r.tone2}"><td class="sev"></td><td colspan="9"><span class="cc-next-t">Próximo passo</span> ${passos.map(esc).join(" <span class=\"sub\">·</span> ")}</td></tr>`; }).join("")}</tbody></table></div>`;
}
function cardCrit(r, lead, now){
  const p=r.p,f=r.f,a=r.a, need=toD(p.necessidade), falta=(need-now)/60000;
  const cd = falta>0 ? `Vence em ${dur(falta).slice(1)}` : `Vencida há ${dur(-falta).slice(1)}`;
  const prevs=(f&&f.hist||[]).filter(h=>h.prev).map(h=>h.prev); const drift = prevs.length>1 && prevs[0]!==prevs[prevs.length-1] ? `Previsão mudou de ${fmt(prevs[0])} para ${fmt(prevs[prevs.length-1])}` : "";
  const passos=proximoPasso(r,lead,now);
  return `<article class="ccard" data-cn="${esc(p.container)}" data-tone="${r.tone2}" tabindex="0">
    <header class="cc-head"><div><div class="cc-cn">${esc(p.container)}</div><div class="sub">${esc(p.navio||"")} · ${esc(p.carga||"")}${p.desova==="SIM"?" · com desova":""}</div></div>
      <div class="cc-tags"><span class="linha">${esc(p.criticidade)}</span><span class="pill ${r.tone2}">${esc(a.label)}</span></div></header>
    <div class="cc-clock ${falta>0?(falta<180?"warn":"info"):"crit"}"><span class="cc-need">Necessidade <b>${fmt(p.necessidade)}</b></span><span class="cc-cd">${cd}</span></div>
    <dl class="cc-facts">
      <div><dt>Posição atual</dt><dd>${f?esc(lugar(f.localizacao)):"Sem veículo alocado"}</dd></div>
      <div><dt>Previsão de chegada</dt><dd class="num">${r.est?`≈ ${fmt(r.est)} <span class="sub">se sair agora</span>`:(f?fmt(f.prev_chegada):"—")}</dd></div>
      <div><dt>Previsão × necessidade</dt><dd><span class="gap ${r.gap2==null?"":r.tone2}">${r.gap2!=null?(r.est?"≈ ":"")+dur(r.gap2):"—"}</span></dd></div>
      <div><dt>Último follow (planilha)</dt><dd>${f&&f.atualizadoEm?`${fmt(f.atualizadoEm)} · ${ago(f.atualizadoEm)}`:"—"}${f&&f.editadoEm&&(!f.atualizadoEm||f.editadoEm>f.atualizadoEm)?`<div class="sub">editado ${fmt(f.editadoEm)}</div>`:""}</dd></div>
    </dl>
    ${trilha(r,now)}
    ${emManut(f)?`<div class="manut-bar">🔧 ${esc(manutTxt(f))}</div>`:""}
    ${chipsRodovia(f,now,lead)}
    ${drift?`<div class="chip warn" style="align-self:flex-start">${esc(drift)}</div>`:""}
    <div class="cc-next"><span class="cc-next-t">Próximo passo</span><ul>${passos.map(s=>`<li>${esc(s)}</li>`).join("")}</ul></div>
    <footer class="cc-foot">
      <span><b>Solicitante</b> ${esc(p.solicitante||"—")}</span>
      <span><b>Veículo</b> ${f?`<span class="mono">${esc(f.placa_cavalo||"")}</span> · ${esc(f.motorista||"")}`:"—"}</span>
      <span><b>OR</b> <span class="mono">${esc(p.or||"—")}</span></span>
      <span><b>Shipment</b> <span class="mono">${esc(p.shipment||"—")}</span></span>
      <span><b>Descarga</b> ${esc(p.local_descarga||"—")}</span>
      ${p.obs?`<span><b>Obs</b> ${esc(p.obs)}</span>`:""}
    </footer></article>`;
}
function entreguesCrit(rows){
  if(!rows.length) return `<div class="empty tbl-wrap">Nenhum processo crítico entregue${state.dia?" para "+diaBR(state.dia):""} até agora.</div>`;
  return `<div class="tbl-wrap"><table class="ent-list"><thead><tr><th></th><th>Container</th><th>Necessidade</th><th>Chegada</th><th>Resultado</th><th>Viagem</th><th>Veículo</th><th>Solicitante</th></tr></thead><tbody>${
    rows.map(r=>{ const p=r.p,f=r.f, g=(toD(f.chegada)-toD(p.necessidade))/60000, via=f.inicio?(toD(f.chegada)-toD(f.inicio))/60000:null, t=g<=0?"ok":g<=RISK_MIN?"warn":"crit";
      return `<tr data-cn="${esc(p.container)}" data-tone="${t}" tabindex="0"><td class="sev"></td>
        <td><div class="cn">${esc(p.container)}</div><span class="linha">${esc(p.criticidade)}</span></td>
        <td class="num">${fmt(p.necessidade)}</td><td class="num"><b>${fmt(f.chegada)}</b></td>
        <td><span class="pill ${t}">${g<=0?"No prazo":"Com atraso"}</span> <span class="gap ${t}">${dur(g)}</span></td>
        <td class="num">${via!=null&&via>0?dur(via).slice(1):"—"}</td>
        <td><span class="mono">${esc(f.placa_cavalo||"")}</span><div class="sub">${esc(f.motorista||"")}</div></td>
        <td>${esc(p.solicitante||"—")}</td></tr>`; }).join("")}</tbody></table></div>`;
}
function renderCrit(){
  const el=$("#v-crit"), now=new Date(), q=state.q.trim().toUpperCase();
  const todos=linhasComp().filter(r=>isCrit(r.p) && (!state.dia||dia(r.p.necessidade)===state.dia));
  const isEnt=r=>entregueIveco(r.f);
  $("#c-crit").textContent=todos.filter(r=>!isEnt(r)).length;
  if(el.hidden) return;
  if(!todos.length && !Object.keys(state.prog).length){ el.innerHTML='<div class="empty tbl-wrap">Importe a programação da Iveco para ver os processos críticos.</div>'; return; }
  const lead=calcInd("tudo").lead;
  todos.forEach(r=>{ const f=r.f, semPrev=!f||(!f.chegada&&!f.prev_chegada);
    r.est = semPrev&&lead ? new Date(+now+lead*60000) : null;
    r.gap2 = r.est ? (r.est-toD(r.p.necessidade))/60000 : r.a.gap;
    r.tone2 = r.est ? (r.gap2>RISK_MIN?"crit":r.gap2>0?"warn":r.a.tone) : r.a.tone; });
  const RK={crit:0,warn:1,info:2,ok:3};
  const busca=r=>!q||[r.p.container,r.p.solicitante,r.f&&r.f.motorista,r.f&&r.f.placa_cavalo].join(" ").toUpperCase().includes(q);
  const and=todos.filter(r=>!isEnt(r)), ent=todos.filter(isEnt);
  const andV=and.filter(busca).sort((a,b)=>RK[a.tone2]-RK[b.tone2] || (b.gap2??-1e9)-(a.gap2??-1e9));
  const entV=ent.filter(busca).sort((a,b)=>String(b.f.chegada).localeCompare(String(a.f.chegada)));
  const filtro=state.critFiltro||"andamento";
  // resumo focado nos não entregues
  const venc=and.filter(r=>toD(r.p.necessidade)<now), sem=and.filter(r=>!r.f), porto=and.filter(r=>r.f&&!r.f.prev_chegada),
        trAtr=and.filter(r=>r.f&&r.f.prev_chegada&&r.a.gap>0), fora=and.filter(r=>r.tone2!=="ok"&&r.tone2!=="info");
  const pior=and.filter(r=>r.gap2!=null).sort((a,b)=>b.gap2-a.gap2)[0];
  const prox=and.map(r=>({r,f:(toD(r.p.necessidade)-now)/60000})).filter(x=>x.f>0).sort((a,b)=>a.f-b.f)[0];
  const entOk=ent.filter(r=>toD(r.f.chegada)<=toD(r.p.necessidade)).length;
  const niveis=[...new Set(todos.map(r=>r.p.criticidade))];
  const tiers=[["crit","Ação imediata","necessidade vencida ou atraso acima de 2h"],["warn","Atenção","risco de atraso de até 2h ou prazo curto"],["ok","Dentro do prazo","manter acompanhamento"]]
    .map(([k,t,d])=>({k,t,d,rows:andV.filter(r=>k==="ok"?(r.tone2==="ok"||r.tone2==="info"):r.tone2===k)})).filter(x=>x.rows.length);
  const secAnd = `<section class="cs-sec">
      <div class="sec-h"><h2>Em andamento <span class="sec-n">${and.length}</span></h2>
        <div class="seg" role="group" aria-label="Visualização"><button type="button" data-cm="cards" aria-pressed="${state.critModo!=="lista"}">Cards</button><button type="button" data-cm="lista" aria-pressed="${state.critModo==="lista"}">Lista</button></div></div>
      ${andV.length ? tiers.map(tr=>`<div class="tier ${tr.k}"><div class="tier-h"><span class="tier-dot"></span><b>${tr.t}</b><span class="sec-n">${tr.rows.length}</span><span class="sub">${tr.d}</span></div>
        ${state.critModo==="lista"?listaCrit(tr.rows,lead,now):`<div class="cgrid">${tr.rows.map(r=>cardCrit(r,lead,now)).join("")}</div>`}</div>`).join("")
        : `<div class="empty tbl-wrap">Nenhum processo crítico em andamento${q?" para a busca":""}.</div>`}
    </section>`;
  const secEnt = `<section class="cs-sec ent">
      <div class="sec-h"><h2>Entregues <span class="sec-n">${ent.length}</span></h2>
        ${ent.length?`<span class="sub">${entOk} de ${ent.length} no prazo · pontualidade ${Math.round(entOk/ent.length*100)}%</span>`:""}</div>
      ${entreguesCrit(entV)}</section>`;
  el.innerHTML=`
    <div class="crit-sum">
      <div class="cs-main"><span class="eyebrow">Sinalizados pela Iveco${niveis.length?" · "+niveis.map(esc).join(", "):""} · não entregues</span>
        <div class="cs-big"><b>${fora.length}</b> de ${and.length} em andamento fora do prazo</div>
        <div class="cs-sub">${pior?`Pior caso: <span class="mono">${esc(pior.p.container)}</span> <b class="t-crit">${pior.est?"≈ ":""}${dur(pior.gap2)}</b>`:""}${prox?` &nbsp;·&nbsp; Próxima necessidade: <span class="mono">${esc(prox.r.p.container)}</span> vence em <b>${dur(prox.f).slice(1)}</b>`:""}</div></div>
      <div class="cs-stats">
        ${and.some(r=>emManut(r.f))?`<div class="crit"><b>${and.filter(r=>emManut(r.f)).length}</b><span>🔧 em manutenção</span></div>`:""}
        <div class="crit"><b>${venc.length}</b><span>necessidade vencida</span></div>
        <div class="crit"><b>${sem.length}</b><span>sem veículo</span></div>
        <div class="warn"><b>${porto.length}</b><span>no porto</span></div>
        <div class="crit"><b>${trAtr.length}</b><span>em trânsito c/ atraso</span></div>
        <div class="ok"><b>${ent.length}</b><span>entregues</span></div>
      </div></div>
    <div class="row"><div class="seg" role="group" aria-label="Filtrar processos críticos">
      <button type="button" data-cf="andamento" aria-pressed="${filtro==="andamento"}">Em andamento (${and.length})</button>
      <button type="button" data-cf="entregues" aria-pressed="${filtro==="entregues"}">Entregues (${ent.length})</button>
      <button type="button" data-cf="todos" aria-pressed="${filtro==="todos"}">Todos (${todos.length})</button></div></div>
    ${filtro!=="entregues"?secAnd:""}
    ${filtro!=="andamento"?secEnt:""}
    <div class="note">Crítico é todo container com o campo "Nível de criticidade" preenchido na programação da Iveco. Entregue é o container com chegada no cliente registrada no follow. ${lead?`Para quem ainda está no porto ou sem veículo, a estimativa usa a viagem média observada no follow (${dur(lead).slice(1)}).`:""} Clique no processo para atualizar o follow.</div>`;
}
document.addEventListener("click",e=>{ const c=e.target.closest(".ccard[data-cn]"); if(c) painelEdit(c.dataset.cn);
  const b=e.target.closest("[data-cm]"); if(b){ state.critModo=b.dataset.cm; try{localStorage.setItem("iveco.critModo",state.critModo);}catch(_){} renderCrit(); }
  const cf=e.target.closest("[data-cf]"); if(cf){ state.critFiltro=cf.dataset.cf; try{localStorage.setItem("iveco.critFiltro",state.critFiltro);}catch(_){} renderCrit(); } });
try{ state.critModo=localStorage.getItem("iveco.critModo")||"cards"; state.critFiltro=localStorage.getItem("iveco.critFiltro")||"andamento"; }catch(e){ state.critModo="cards"; state.critFiltro="andamento"; }
document.addEventListener("keydown",e=>{ if(e.key==="Enter"&&e.target.closest){ const c=e.target.closest(".ccard[data-cn]"); if(c) painelEdit(c.dataset.cn); } });

/* ---------- rodovias ---------- */
const NOS=[
  {id:"rio",n:"Rio (Porto/Caju)",km:0,ll:[-22.884,-43.215],a:["RIO DE JANEIRO","CAJU","PORTO DO RIO"]},
  {id:"caxias",n:"Duque de Caxias",km:20,ll:[-22.75,-43.29],a:["DUQUE DE CAXIAS"]},
  {id:"serra",n:"Serra de Petrópolis",km:40,ll:[-22.58,-43.23],a:["SERRA DE PETROPOLIS","SERRA"]},
  {id:"petropolis",n:"Petrópolis",km:66,ll:[-22.505,-43.178],a:["PETROPOLIS"]},
  {id:"areal",n:"Areal / Três Rios / Levy Gasparian",km:105,ll:[-22.12,-43.2],a:["AREAL","TRES RIOS","LEVY GASPARIAN","COMENDADOR LEVY"]},
  {id:"simao",n:"Simão Pereira",km:135,ll:[-21.963,-43.31],a:["SIMAO PEREIRA","PARAIBUNA"]},
  {id:"matias",n:"Matias Barbosa",km:160,ll:[-21.869,-43.318],a:["MATIAS BARBOSA"]},
  {id:"jf",n:"Juiz de Fora",km:184,ll:[-21.764,-43.35],a:["JUIZ DE FORA"]},
  {id:"sdumont",n:"Santos Dumont",km:228,ll:[-21.457,-43.552],a:["SANTOS DUMONT","EWBANK","OLIVEIRA FORTES","CHAPEU D"]},
  {id:"barbacena",n:"Barbacena",km:265,ll:[-21.226,-43.774],a:["BARBACENA","ALFREDO VASCONCELOS"]},
  {id:"carandai",n:"Carandaí",km:295,ll:[-20.955,-43.806],a:["CARANDAI","RESSAQUINHA"]},
  {id:"lafaiete",n:"Cons. Lafaiete",km:332,ll:[-20.66,-43.786],a:["LAFAIETE","CRISTIANO OTONI","QUELUZITO"]},
  {id:"congonhas",n:"Congonhas",km:358,ll:[-20.5,-43.857],a:["CONGONHAS"]},
  {id:"novalima",n:"Itabirito / Nova Lima",km:405,ll:[-20.1,-43.88],a:["ITABIRITO","NOVA LIMA","OURO PRETO","MOEDA"]},
  {id:"bh",n:"BH / Contagem",km:449,ll:[-19.92,-43.99],a:["BELO HORIZONTE","CONTAGEM"]},
  {id:"esmeraldas",n:"Esmeraldas",km:456,ll:[-19.763,-44.314],a:["ESMERALDAS"]},
  {id:"neves",n:"Ribeirão das Neves",km:462,ll:[-19.767,-44.087],a:["RIBEIRAO DAS NEVES","NEVES"]},
  {id:"pleopoldo",n:"Pedro Leopoldo / Vespasiano",km:472,ll:[-19.618,-44.043],a:["PEDRO LEOPOLDO","VESPASIANO","CONFINS","LAGOA SANTA","SAO JOSE DA LAPA"]},
  {id:"matozinhos",n:"Matozinhos / Capim Branco",km:482,ll:[-19.557,-44.081],a:["MATOZINHOS","CAPIM BRANCO","PRUDENTE DE MORAIS","FUNILANDIA","JEQUITIBA"]},
  {id:"sete",n:"Sete Lagoas",km:508,ll:[-19.466,-44.247],a:["SETE LAGOAS"]},
  {id:"betim",n:"Betim",km:478,ll:[-19.968,-44.198],a:["BETIM"]}
];
const NO=Object.fromEntries(NOS.map(x=>[x.id,x]));
const BASE=["rio","caxias","serra","petropolis","areal","simao","matias","jf","sdumont","barbacena","carandai","lafaiete","congonhas","novalima","bh"];
const ROTA={SETE:[...BASE,"esmeraldas","neves","pleopoldo","matozinhos","sete"], BETIM:[...BASE,"betim"]};
const LINHA_SETE=[...BASE,"neves","sete"];
const TIPOS={acidente:"Acidente",interdicao:"Interdição",lentidao:"Trânsito intenso",obra:"Obra",restricao:"Restrição",clima:"Clima",historico:"Histórico"};
const DIAS=["dom","seg","ter","qua","qui","sex","sáb"];
const rotaDe = f => /BETIM/.test(norm(f&&f.local_entrega)) ? ROTA.BETIM : ROTA.SETE;
function noDe(txt){ const t=norm(txt); if(!t) return null; for(const x of NOS){ if(!x.dyn && x.a.some(a=>t.includes(a))) return x.id; } const pc=typeof parseCidade==="function"?parseCidade(txt):null; if(pc){ return DYN[pc.nome+"|"+pc.uf]||DYN[pc.nome]||null; } return null; }
const wazeUrl = ll => `https://www.waze.com/ul?ll=${ll[0]}%2C${ll[1]}&zoom=12`;
const gmapsUrl = ll => `https://www.google.com/maps/@${ll[0]},${ll[1]},12z/data=!5m1!1e1`;
const rotaUrl = dest => `https://www.google.com/maps/dir/?api=1&origin=${NO.rio.ll.join(",")}&destination=${NO[dest].ll.join(",")}&travelmode=driving`;
const hm = s => { const [a,b]=String(s||"0:0").split(":").map(Number); return a*60+(b||0); };
function ativoEm(al,t){
  if(!al||al.encerrado||al.tipo==="historico") return false;
  const d=toD(al.validoDe), e=toD(al.validoAte); if(d&&t<d) return false; if(e&&t>e) return false;
  if(!al.janelas||!al.janelas.length) return true;
  const m=t.getHours()*60+t.getMinutes(), dw=t.getDay();
  return al.janelas.some(j=>{ const i=hm(j.ini), f=hm(j.fim), ds=j.dias||[0,1,2,3,4,5,6];
    return i<f ? (ds.includes(dw)&&m>=i&&m<f) : ((ds.includes(dw)&&m>=i)||(ds.includes((dw+6)%7)&&m<f)); });
}
function busca(al,t,quer){ for(let i=1;i<=7*96;i++){ let x=new Date(+t+i*900000); if(ativoEm(al,x)===quer){ for(let k=0;k<15;k++){ const y=new Date(+x-60000); if(y<=t||ativoEm(al,y)!==quer) break; x=y; } x.setSeconds(0,0); return x; } } return null; }
function statusAl(al,now){
  if(al.tipo==="historico") return {k:"info",t:"Histórico do trecho"};
  if(al.encerrado || (al.validoAte&&toD(al.validoAte)<now)) return {k:"fim",t:"Encerrado"};
  if(ativoEm(al,now)){ const fim=(al.janelas&&al.janelas.length)||al.validoAte?busca(al,now,false):null; return {k:"ativo",t:fim?`Ativo agora · até ${fmtDia(fim)}`:"Ativo agora"}; }
  const ini=busca(al,now,true); return ini?{k:"prog",t:`Começa ${fmtDia(ini)} (em ${dur((ini-now)/60000).slice(1)})`,ini}:{k:"fim",t:"Sem janela nos próximos 7 dias"};
}
function fmtDia(d){ const hoje=new Date(); const mesmo=d.toDateString()===hoje.toDateString(); return (mesmo?"hoje ":DIAS[d.getDay()]+" ")+pad(d.getHours())+":"+pad(d.getMinutes()); }
function descJanelas(al){ if(!al.janelas||!al.janelas.length) return "Contínuo";
  return al.janelas.map(j=>{ const ds=j.dias||[]; const d = ds.length===7?"Todos os dias":ds.map(x=>DIAS[x]).join(", "); return `${d}, ${j.ini}–${j.fim}`; }).join(" · "); }
const listaAlertas = () => Object.values(state.alertas||{});
function exposicao(f, now, lead){
  if(!f||f.chegada) return [];
  const rota=rotaDe(f), cur=noDe(f.localizacao); if(!cur) return [];
  const ci=rota.indexOf(cur); if(ci<0) return [];
  const dest=rota[rota.length-1], k0=NO[cur].km, k1=NO[dest].km;
  let t1=toD(f.prev_chegada); if(!t1&&lead) t1=new Date(+now+lead*60000);
  const out=[];
  listaAlertas().forEach(al=>{
    if(al.encerrado || (al.validoAte&&toD(al.validoAte)<now && al.tipo!=="historico")) return;
    const nos=(al.nos||[]).filter(n=>rota.indexOf(n)>=ci); if(!nos.length) return;
    const n=nos.sort((a,b)=>rota.indexOf(a)-rota.indexOf(b))[0];
    const frac = k1>k0 ? (NO[n].km-k0)/(k1-k0) : 0;
    const tp = t1 ? new Date(+now+Math.max(0,Math.min(1,frac))*(t1-now)) : null;
    if(al.tipo==="historico"){ out.push({al,n,tp,nivel:"info",txt:`${NO[n].n}: trecho com histórico de acidentes`}); return; }
    const ref=tp||now, dentro=ativoEm(al,ref);
    let nivel="info", txt;
    if(dentro){ nivel=al.sev==="alta"?"crit":al.sev==="media"?"warn":"info"; txt=`Passa por ${NO[n].n} ${tp?"~"+fmtH(iso(tp)):"agora"} com ${TIPOS[al.tipo].toLowerCase()} ativa`; }
    else { const prox=busca(al,ref,true); const margem=prox?(prox-ref)/60000:null;
      if(margem!=null && margem<=120 && al.sev!=="baixa"){ nivel="warn"; txt=`Passa por ${NO[n].n} ~${fmtH(iso(ref))}; ${TIPOS[al.tipo].toLowerCase()} começa ${fmtDia(prox)} (margem ${dur(margem).slice(1)})`; }
      else if(ativoEm(al,now)) { nivel="info"; txt=`${NO[n].n}: ${TIPOS[al.tipo].toLowerCase()} ativa agora; passagem estimada ~${fmtH(iso(ref))}`; }
      else { nivel="ok"; txt=`Passa por ${NO[n].n} ~${fmtH(iso(ref))}, fora da janela`; } }
    out.push({al,n,tp,nivel,txt});
  });
  const RKN={crit:0,warn:1,info:2,ok:3};
  return out.sort((a,b)=>RKN[a.nivel]-RKN[b.nivel]);
}
function chipsRodovia(f,now,lead){
  const ex=exposicao(f,now,lead).filter(x=>x.nivel==="crit"||x.nivel==="warn"); if(!ex.length) return "";
  return `<div class="chips">${ex.map(x=>`<span class="chip ${x.nivel}" title="${esc(x.al.titulo)}">⚠ ${esc(x.txt)}</span>`).join("")}</div>`;
}
function mapaRota(now){
  const veic={}; Object.values(state.follow).forEach(f=>{ if(f.chegada) return; const n=noDe(f.localizacao); if(!n) return; const dest=rotaDe(f).slice(-1)[0]; if(n===dest && /DESCARGA|CLIENTE/i.test(f.status||"")) return; (veic[n]=veic[n]||[]).push(f); });
  const al=listaAlertas(); const alN={}; al.forEach(a=>{ const s=statusAl(a,now); (a.nos||[]).forEach(n=>{ (alN[n]=alN[n]||[]).push({a,s}); }); });
  const slot=70, L=64, top=66, W=L+ (BASE.length+5)*slot+60, H=250;
  const X=i=>L+i*slot, yMain=top+40, yB=yMain+70;
  const pos={}; BASE.forEach((n,i)=>pos[n]=[X(i),yMain]); pos.esmeraldas=[X(BASE.length),yMain]; pos.neves=[X(BASE.length+1),yMain]; pos.pleopoldo=[X(BASE.length+2),yMain]; pos.matozinhos=[X(BASE.length+3),yMain]; pos.sete=[X(BASE.length+4),yMain]; pos.betim=[X(BASE.length),yB];
  let g=`<line x1="${pos.rio[0]}" y1="${yMain}" x2="${pos.sete[0]}" y2="${yMain}" stroke="var(--line)" stroke-width="6" stroke-linecap="round"/>
    <path d="M${pos.bh[0]} ${yMain} C ${pos.bh[0]+30} ${yMain}, ${pos.betim[0]-30} ${yB}, ${pos.betim[0]} ${yB}" fill="none" stroke="var(--line)" stroke-width="6" stroke-linecap="round"/>
    <text x="${(pos.rio[0]+pos.serra[0])/2}" y="${yMain-52}" text-anchor="middle" class="rl">BR-040 · RJ</text><text x="${pos.jf[0]}" y="${yMain-52}" text-anchor="middle" class="rl">BR-040 · MG</text><text x="${pos.betim[0]+22}" y="${yB+22}" class="rl">BR-381</text>`;
  Object.entries(pos).forEach(([n,[x,y]],i)=>{
    const als=(alN[n]||[]).filter(o=>o.s.k==="ativo"||o.s.k==="prog"||o.s.k==="info");
    const at=als.filter(o=>o.s.k==="ativo"), pr=als.filter(o=>o.s.k==="prog"), hi=als.filter(o=>o.s.k==="info");
    const cor = at.some(o=>o.a.sev==="alta")?"var(--crit)":at.length?"var(--warn)":pr.length?"var(--info)":hi.length?"var(--muted)":null;
    if(cor){ g+=`<g><title>${esc(als.map(o=>o.a.titulo+" — "+o.s.t).join("\n"))}</title><path d="M${x} ${y+13} l8 14 h-16z" fill="${at.length?cor:"var(--surface)"}" stroke="${cor}" stroke-width="1.6"/><text x="${x}" y="${y+25}" text-anchor="middle" style="fill:${at.length?"#fff":cor};font-weight:700;font-size:9px">!</text></g>`; }
    g+=`<circle cx="${x}" cy="${y}" r="6" fill="var(--surface)" stroke="var(--ink)" stroke-width="2"/>`;
    const ly = n==="betim" ? y+44 : (i%2? y+48 : y+62);
    g+=`<text x="${x}" y="${ly}" text-anchor="middle" class="nl">${esc(NO[n].n)}</text>`;
    const vs=veic[n]||[]; if(vs.length){ const crit=vs.some(f=>isCrit(state.prog[f.container])); const cns=[...new Set(vs.map(f=>f.placa_cavalo+" · "+f.container))];
      const cy = n==="betim"? y-26 : y-30;
      g+=`<g class="vk"><title>${esc(NO[n].n)}\n${esc(cns.join("\n"))}</title><rect x="${x-15}" y="${cy-12}" width="30" height="22" rx="5" fill="var(--accent)" ${crit?'stroke="var(--crit)" stroke-width="2.5"':""}/><text x="${x}" y="${cy+3.5}" text-anchor="middle" style="fill:var(--accent-ink);font-weight:700;font-size:12px">${cns.length}</text><path d="M${x-4} ${cy+10} l4 6 l4 -6z" fill="var(--accent)"/></g>`; }
  });
  return `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="Mapa linear do trajeto com veículos e alertas">${g}</svg>`;
}
function renderRod(){
  const el=$("#v-rod"), now=new Date(); const al=listaAlertas();
  const st=al.map(a=>({a,s:statusAl(a,now)}));
  const ativos=st.filter(x=>x.s.k==="ativo"), prox=st.filter(x=>x.s.k==="prog"&&x.s.ini&&(x.s.ini-now)<48*3600000);
  const nAlta=ativos.filter(x=>x.a.sev==="alta"||x.a.tipo==="acidente"||x.a.tipo==="interdicao").length;
  $("#c-rod").textContent=ativos.length; $("#c-rod").className="c"+(nAlta?" crit":"");
  if(el.hidden) return;
  const lead=calcInd("tudo").lead;
  const expostos=Object.values(state.follow).filter(f=>!f.chegada).map(f=>({f,ex:exposicao(f,now,lead).filter(x=>x.nivel==="crit"||x.nivel==="warn")})).filter(x=>x.ex.length)
    .sort((a,b)=>({crit:0,warn:1}[a.ex[0].nivel]-{crit:0,warn:1}[b.ex[0].nivel])||(isCrit(state.prog[b.f.container])-isCrit(state.prog[a.f.container])));
  const rm=state.rodMeta||{};
  const ord={ativo:0,prog:1,info:2,fim:3}, sevO={alta:0,media:1,baixa:2};
  const lista=st.filter(x=>state.rodVer==="todos"||x.s.k!=="fim").sort((a,b)=>ord[a.s.k]-ord[b.s.k]||(sevO[a.a.sev]??3)-(sevO[b.a.sev]??3));
  const card=({a,s})=>{ const n0=NO[(a.nos||[])[0]]||NO.rio; const tone= s.k==="ativo"?(a.sev==="alta"?"crit":"warn"): s.k==="prog"?"info": s.k==="info"?"mut":"mut";
    return `<article class="acard" data-al="${esc(a.id)}" data-tone="${tone}">
      <div class="ac-top"><span class="pill ${tone==="mut"?"mut":tone}">${esc(s.t)}</span><span class="ac-tipo">${esc(TIPOS[a.tipo]||a.tipo)} · ${esc(a.rodovia||"")}</span>${a.origem==="auto"?'<span class="sub">automático</span>':""}</div>
      <h4>${esc(a.titulo)}</h4>
      <div class="sub">${(a.nos||[]).map(n=>esc(NO[n]?NO[n].n:n)).join(" · ")}${a.km?` · km ${esc(a.km)}`:""}${a.sentido?` · sentido ${esc(a.sentido)}`:""}</div>
      ${a.descricao?`<p>${esc(a.descricao)}</p>`:""}
      <div class="ac-meta"><span><b>Horário</b> ${esc(descJanelas(a))}</span>${a.validoAte?`<span><b>Até</b> ${fmt(a.validoAte)}</span>`:""}<span><b>Atualizado</b> ${a.atualizadoEm?ago(a.atualizadoEm):"—"}</span></div>
      <div class="ac-links"><a href="${wazeUrl(n0.ll)}" target="_blank" rel="noopener">Waze ao vivo</a><a href="${gmapsUrl(n0.ll)}" target="_blank" rel="noopener">Trânsito no Google Maps</a>${a.url?`<a href="${esc(a.url)}" target="_blank" rel="noopener">Fonte: ${esc(a.fonte||"notícia")}</a>`:(a.fonte?`<span class="sub">Fonte: ${esc(a.fonte)}</span>`:"")}
        <button class="btn ghost sm" type="button" data-edal="${esc(a.id)}">Editar</button></div></article>`; };
  const tr = expostos.map(({f,ex})=>{ const p=state.prog[f.container];
    return `<tr data-cn="${esc(f.container)}" data-tone="${ex[0].nivel}" tabindex="0"><td class="sev"></td>
      <td><div class="cn">${esc(f.container)}</div>${isCrit(p)?`<span class="linha">${esc(p.criticidade)}</span>`:""}</td>
      <td>${esc(lugar(f.localizacao))}<div class="sub">→ ${esc(lugar(f.local_entrega))}</div></td>
      <td class="num">${f.prev_chegada?fmt(f.prev_chegada):'<span class="sub">no porto</span>'}</td>
      <td>${ex.map(x=>`<div class="exl ${x.nivel}">${esc(x.txt)}</div>`).join("")}</td></tr>`; }).join("");
  el.innerHTML=`
   <div class="rod-head"><div><h2>Condições das rodovias</h2>
      <div class="note">Última verificação automática: <b>${rm.atualizadoEm?fmt(rm.atualizadoEm)+" ("+ago(rm.atualizadoEm)+")":"—"}</b>. As ocorrências são atualizadas de hora em hora por pesquisa em notícias, PRF e concessionárias, e a equipe pode lançar alertas na hora. ${rm.resumo?`<br>${esc(rm.resumo)}`:""}</div></div>
      <div class="actions"><button class="btn primary" type="button" id="rod-new">Novo alerta</button><button class="btn" type="button" id="rod-cli">Resumo p/ cliente</button></div></div>
   <div class="kpis">
     <div class="kpi ${nAlta?"crit":ativos.length?"warn":"ok"}"><span class="k">Ativos agora</span><span class="v">${ativos.length}</span><span class="s">${nAlta} de alta gravidade</span></div>
     <div class="kpi ${prox.length?"warn":"ok"}"><span class="k">Começam em até 48h</span><span class="v">${prox.length}</span><span class="s">restrições e obras programadas</span></div>
     <div class="kpi ${expostos.some(x=>x.ex[0].nivel==="crit")?"crit":expostos.length?"warn":"ok"}"><span class="k">Veículos expostos</span><span class="v">${expostos.length}</span><span class="s">passam por alerta ativo ou perto dele</span></div>
     <div class="kpi"><span class="k">Acidentes / interdições</span><span class="v">${ativos.filter(x=>x.a.tipo==="acidente"||x.a.tipo==="interdicao").length}</span><span class="s">ativos no trajeto</span></div>
   </div>
   <div class="chart"><h3>Trajeto Rio → Sete Lagoas / Betim</h3>
     <div class="lg"><span><i style="background:var(--accent)"></i>Veículos no trecho (borda vermelha = crítico Iveco)</span><span><i style="background:var(--crit)"></i>Alerta ativo grave</span><span><i style="background:var(--warn)"></i>Alerta ativo</span><span><i style="background:var(--surface);border:1.5px solid var(--info)"></i>Programado</span><span><i style="background:var(--surface);border:1.5px solid var(--muted)"></i>Histórico</span></div>
     <div class="mapwrap">${mapaRota(now)}</div>
     <div class="row"><span class="sub">Rota completa com trânsito:</span><a class="lnk" href="${rotaUrl("sete")}" target="_blank" rel="noopener">Rio → Sete Lagoas</a><a class="lnk" href="${rotaUrl("betim")}" target="_blank" rel="noopener">Rio → Betim</a><a class="lnk" href="${wazeUrl(NO.serra.ll)}" target="_blank" rel="noopener">Waze: Serra de Petrópolis</a><a class="lnk" href="${wazeUrl(NO.bh.ll)}" target="_blank" rel="noopener">Waze: Grande BH</a></div></div>
   <div class="chart"><div class="sec-h" style="border-bottom-width:1px"><h3>Alertas</h3><div class="seg" role="group"><button type="button" data-rv="ativos" aria-pressed="${state.rodVer!=="todos"}">Vigentes</button><button type="button" data-rv="todos" aria-pressed="${state.rodVer==="todos"}">Todos</button></div></div>
       <div class="alist">${lista.length?lista.map(card).join(""):'<div class="empty">Nenhum alerta vigente.</div>'}</div></div>
   <div class="chart"><h3>Veículos com alerta no caminho</h3>
       <div class="note">Mostra quem passa por alerta de gravidade média ou alta dentro do horário dele, ou até 2h antes de começar. A passagem por cada trecho é estimada pela posição atual e pela previsão de chegada do follow. Para quem está no porto, a estimativa considera saída agora.</div>
       ${tr?`<div class="tbl-wrap" style="box-shadow:none"><table style="min-width:720px"><thead><tr><th></th><th>Container</th><th>Posição → destino</th><th>Previsão</th><th style="width:55%">No caminho</th></tr></thead><tbody>${tr}</tbody></table></div>`:'<div class="empty">Nenhum veículo passa por alerta vigente.</div>'}
       <h3 style="margin-top:8px">Contatos das concessionárias</h3>
       <div class="contatos"><div><b>Elovias</b> (BR-040 RJ, Serra de Petrópolis)<br><span class="mono sel">0800 040 0495</span> · WhatsApp <span class="mono sel">(21) 98040-0113</span></div>
         <div><b>EPR Via Mineira</b> (BR-040 Juiz de Fora–BH)<br><span class="mono sel">0800 003 1040</span></div></div></div>
   ${(()=>{ const dyn=NOS.filter(n=>n.dyn), nr=cidadesNaoReconhecidas(); if(!dyn.length&&!nr.length) return "";
     return `<div class="chart"><h3>Cidades adicionadas à rota</h3><div class="note">Cidades que apareceram no follow fora da lista fixa da rota. Os km são estimados pela posição da cidade (IBGE) projetada na BR-040/BR-381, somando o desvio até a rodovia.</div>
       ${dyn.length?`<div class="tbl-wrap" style="box-shadow:none"><table style="min-width:620px"><thead><tr><th>Cidade</th><th>Km até Sete Lagoas</th><th>Km até Betim</th><th>Desvio até a rodovia</th><th>Origem</th></tr></thead><tbody>${dyn.map(n=>`<tr><td><b>${esc(n.n)}</b></td><td class="num">${kmAte(n,"sete")} km</td><td class="num">${kmAte(n,"betim")} km</td><td class="num">${n.desvio?n.desvio+" km":"—"}</td><td>${n.manual?"informado manualmente":"automático"}</td></tr>`).join("")}</tbody></table></div>`:""}
       ${nr.length?`<h3 style="margin-top:6px">Não reconhecidas</h3><div class="note">Não foram encontradas na lista de municípios (confira a grafia no follow). Informe os km até a Iveco Sete Lagoas para incluir.</div>
         <div class="cid-nr">${nr.map((l,i)=>`<div class="row"><span style="min-width:220px">${esc(l)}</span><input type="number" min="0" id="cid-km-${i}" placeholder="km até Sete Lagoas" style="width:170px"><button class="btn sm" type="button" data-cidnr="${i}" data-loc="${esc(l)}" style="margin-left:0">Incluir</button></div>`).join("")}</div>`:""}</div>`; })()}`;
  el.querySelector("#rod-new").onclick=()=>painelAlerta(null);
  el.querySelectorAll("[data-cidnr]").forEach(b=>b.onclick=async()=>{ const km=+el.querySelector("#cid-km-"+b.dataset.cidnr).value; if(!(km>=0)||!el.querySelector("#cid-km-"+b.dataset.cidnr).value){ toast("Informe os km até Sete Lagoas"); return; }
    const pc=parseCidade(b.dataset.loc)||{nome:norm(b.dataset.loc),uf:""}; const id="c-"+pc.nome.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")+(pc.uf?"-"+pc.uf.toLowerCase():"");
    const doc={id,chave:pc.nome,nome:pc.nome,uf:pc.uf,lat:null,lon:null,kmRota:NO.sete.km-km,desvio:0,ramo:"",origem:"manual",criadoEm:iso(new Date()),exemplo:b.dataset.loc};
    registraCidade(doc); try{ await state.db.doc("cidades/"+id).set(doc); toast("Cidade incluída"); }catch(e){ toast("Falha ao salvar: "+(e.message||e.code)); } render(); });
  el.querySelector("#rod-cli").onclick=painelRodCliente;
  el.querySelectorAll("[data-rv]").forEach(b=>b.onclick=()=>{ state.rodVer=b.dataset.rv; renderRod(); });
  el.querySelectorAll("[data-edal]").forEach(b=>b.onclick=e=>{ e.stopPropagation(); painelAlerta(b.dataset.edal); });
}
function painelAlerta(id){
  const a = id ? Object.assign({}, state.alertas[id]) : {tipo:"acidente", sev:"alta", rodovia:"BR-040", nos:[], janelas:[], validoDe:iso(new Date())};
  const j=(a.janelas&&a.janelas[0])||null;
  openPanel(`<h3>${id?"Editar alerta":"Novo alerta de rodovia"}</h3><p>Use para acidentes, interdições e lentidão informados pelo rastreador, motoristas ou concessionárias.</p>
   <div class="fgrid">
    <label class="f full">Título<input id="a-tit" value="${esc(a.titulo||"")}" placeholder="Ex.: Carreta tombada na BR-040 em Santos Dumont"></label>
    <label class="f">Tipo<select id="a-tipo">${Object.entries(TIPOS).map(([k,v])=>`<option value="${k}" ${k===a.tipo?"selected":""}>${v}</option>`).join("")}</select></label>
    <label class="f">Gravidade<select id="a-sev">${[["alta","Alta"],["media","Média"],["baixa","Baixa"]].map(([k,v])=>`<option value="${k}" ${k===a.sev?"selected":""}>${v}</option>`).join("")}</select></label>
    <label class="f">Rodovia<input id="a-rod" value="${esc(a.rodovia||"")}"></label>
    <label class="f">Km / sentido<input id="a-km" value="${esc([a.km,a.sentido].filter(Boolean).join(" / "))}" placeholder="640 / BH"></label>
    <div class="f full"><span>Trechos afetados</span><div class="nos">${NOS.map(n=>`<label class="chk"><input type="checkbox" value="${n.id}" ${(a.nos||[]).includes(n.id)?"checked":""}> ${esc(n.n)}</label>`).join("")}</div></div>
    <label class="f full">Descrição<textarea id="a-desc" style="min-height:80px;font-family:var(--f-ui);font-size:14px">${esc(a.descricao||"")}</textarea></label>
    <label class="f">Início<input id="a-ini" type="datetime-local" value="${String(a.validoDe||"").slice(0,16)}"></label>
    <label class="f">Término (vazio = em aberto)<input id="a-fim" type="datetime-local" value="${String(a.validoAte||"").slice(0,16)}"></label>
    <div class="f full"><span>Janela de horário (opcional, para obras e restrições)</span><div class="row">${DIAS.map((d,i)=>`<label class="chk"><input type="checkbox" class="a-dia" value="${i}" ${j&&j.dias.includes(i)?"checked":""}> ${d}</label>`).join("")}
      <input id="a-jini" type="time" value="${j?j.ini:""}" aria-label="Início da janela"> até <input id="a-jfim" type="time" value="${j?j.fim:""}" aria-label="Fim da janela"></div></div>
    <label class="f">Fonte<input id="a-fonte" value="${esc(a.fonte||"")}" placeholder="PRF, concessionária, motorista…"></label>
    <label class="f">Link da fonte<input id="a-url" value="${esc(a.url||"")}"></label>
   </div>
   <div id="a-msg"></div>
   <div class="row"><button class="btn primary" id="a-save" type="button">Salvar</button><button class="btn ghost" id="a-x" type="button">Cancelar</button>
     ${id?`<button class="btn" id="a-end" type="button" style="margin-left:auto">${a.encerrado?"Reabrir":"Encerrar (via liberada)"}</button><button class="btn danger" id="a-del" type="button">Excluir</button>`:""}</div>`, el=>{
    const v=s=>el.querySelector(s).value.trim(); const msg=(t,ok)=>el.querySelector("#a-msg").innerHTML=`<div class="msg ${ok?"ok":"err"}">${esc(t)}</div>`;
    el.querySelector("#a-x").onclick=closePanel;
    const salvar=async extra=>{ if(!state.db){ msg("Sem conexão com a base.",false); return; }
      const nos=[...el.querySelectorAll(".nos input:checked")].map(x=>x.value); if(!v("#a-tit")||!nos.length){ msg("Informe o título e pelo menos um trecho afetado.",false); return; }
      const dias=[...el.querySelectorAll(".a-dia:checked")].map(x=>+x.value), ji=v("#a-jini"), jf=v("#a-jfim");
      const [km,sentido]=v("#a-km").split("/").map(s=>s&&s.trim());
      const doc=Object.assign({}, a, {id:id||("m-"+Date.now().toString(36)), titulo:v("#a-tit"), tipo:v("#a-tipo"), sev:v("#a-sev"), rodovia:v("#a-rod"), km:km||"", sentido:sentido||"", nos, descricao:v("#a-desc"),
        validoDe:v("#a-ini")||iso(new Date()), validoAte:v("#a-fim")||null, janelas:(dias.length&&ji&&jf)?[{dias,ini:ji,fim:jf}]:[], fonte:v("#a-fonte"), url:v("#a-url"), atualizadoEm:iso(new Date()), origem:a.origem||"manual"}, extra||{});
      try{ await state.db.doc("alertas/"+doc.id).set(doc); closePanel(); toast("Alerta salvo"); }catch(e){ msg("Falha ao salvar: "+(e.message||e.code),false); } };
    el.querySelector("#a-save").onclick=()=>salvar();
    const be=el.querySelector("#a-end"); be&&(be.onclick=()=>salvar(a.encerrado?{encerrado:false}:{encerrado:true, validoAte:iso(new Date())}));
    const bd=el.querySelector("#a-del"); let armed=false; bd&&(bd.onclick=async()=>{ if(!armed){ armed=true; bd.textContent="Confirmar exclusão"; return; } try{ await state.db.doc("alertas/"+id).delete(); closePanel(); toast("Alerta excluído"); }catch(e){ msg("Falha: "+(e.message||e.code),false); } });
  });
}
function textoRodCliente(whats){
  const now=new Date(), lead=calcInd("tudo").lead;
  const st=listaAlertas().map(a=>({a,s:statusAl(a,now)})).filter(x=>(x.s.k==="ativo"||(x.s.k==="prog"&&x.s.ini-now<48*3600000)) && x.a.sev!=="baixa");
  const graves=st.filter(x=>x.s.k==="ativo"&&(x.a.tipo==="acidente"||x.a.tipo==="interdicao"));
  const b=whats?"*":"", li=whats?"• ":"• ";
  let t=`${b}Iveco | Condições das rodovias – ${fmt(now)}${b}\n\n`;
  t+= graves.length ? `${whats?"⚠️ ":""}${graves.length} ocorrência(s) com impacto no trajeto:\n${graves.map(x=>li+x.a.titulo+(x.a.km?` (km ${x.a.km})`:"")).join("\n")}\n\n` : `${whats?"✅ ":""}Até o momento, sem acidentes ou interdições identificados no trajeto Rio → Sete Lagoas/Betim.\n\n`;
  const outros=st.filter(x=>!graves.includes(x));
  if(outros.length){ t+=`${b}Pontos de atenção${b}\n`+outros.map(x=>`${li}${b}${x.a.titulo}${b}: ${x.s.k==="ativo"?"ativo agora":x.s.t.toLowerCase()}. Horário: ${descJanelas(x.a)}.`).join("\n")+"\n\n"; }
  const exp=Object.values(state.follow).filter(f=>!f.chegada&&state.prog[f.container]).map(f=>({f,ex:exposicao(f,now,lead).filter(x=>x.nivel==="crit"||x.nivel==="warn")})).filter(x=>x.ex.length);
  if(exp.length){ t+=`${b}Containers com possível impacto${b}\n`+exp.map(x=>`${li}${x.f.container}: ${x.ex[0].txt}`).join("\n")+"\n\n"; }
  t+="Seguimos monitorando de hora em hora e informaremos imediatamente qualquer ocorrência que altere as previsões de chegada.";
  return t;
}
function painelRodCliente(){
  let w=false;
  openPanel(`<h3>Condições das rodovias para o cliente</h3><p>Gerado a partir dos alertas vigentes e da posição dos containers da programação Iveco. Confira e ajuste antes de enviar.</p>
   <div class="row"><div class="seg" role="group"><button type="button" data-fm="mail" aria-pressed="true">E-mail</button><button type="button" data-fm="whats" aria-pressed="false">WhatsApp</button></div></div>
   <textarea id="rc-txt" style="min-height:320px;font-family:var(--f-ui);font-size:13px"></textarea>
   <div class="row"><button class="btn primary" id="rc-copy" type="button">Copiar texto</button><button class="btn ghost" id="rc-x" type="button">Fechar</button></div><div id="rc-msg"></div>`, el=>{
    const ta=el.querySelector("#rc-txt"); const fill=()=>{ ta.value=textoRodCliente(w); el.querySelectorAll("[data-fm]").forEach(b=>b.setAttribute("aria-pressed",String((b.dataset.fm==="whats")===w))); };
    el.querySelectorAll("[data-fm]").forEach(b=>b.onclick=()=>{ w=b.dataset.fm==="whats"; fill(); });
    el.querySelector("#rc-x").onclick=closePanel;
    el.querySelector("#rc-copy").onclick=()=>navigator.clipboard.writeText(ta.value).then(()=>toast("Texto copiado"),()=>{ ta.select(); toast("Texto selecionado: use Ctrl+C"); });
    fill(); });
}


/* distância e tempo restantes até a Iveco (km estimados pela cidade informada no follow) */
function kmRestante(f){ if(!f) return null; if(f.km_manual!=null&&f.km_manual!==""&&f.km_loc===f.localizacao) return +f.km_manual; const rota=rotaDe(f), dest=rota[rota.length-1], n=noDe(f.localizacao); if(n&&NO[n]&&NO[n].dyn) return kmAte(NO[n],dest); if(n==="betim"&&dest==="sete") return (NO.betim.km-NO.bh.km)+(NO.sete.km-NO.bh.km); if(!n||rota.indexOf(n)<0) return null; return Math.max(0, NO[dest].km-NO[n].km); }
function velMedia(){ const lead=calcInd("tudo").lead; return lead ? Math.min(70,Math.max(25, NO.sete.km/(lead/60))) : 40; }
function restante(f, now){
  if(!f) return null;
  if(viaBetim(f)){ const k0=kmRestante(f), km=k0!=null?k0+KM_BETIM_IVECO:null, dest="Iveco (via Betim)";
    if(f.chegada) return {km:KM_BETIM_IVECO, dest, betim:true, txt:`parado em Betim desde ${fmt(f.chegada)} · faltam ≈${KM_BETIM_IVECO} km até a Iveco`, curto:`em Betim · ≈${KM_BETIM_IVECO} km`};
    const prev=toD(f.prev_chegada); const mb=prev?(prev-now)/60000:null;
    return {km, dest, betim:true, min:mb, eta:null, txt:`${km!=null?km+" km até a Iveco · ":""}${prev?(mb>=0?`chega em Betim em ${dur(mb).slice(1)} (${fmtH(f.prev_chegada)})`:`previsão em Betim ${fmtH(f.prev_chegada)} vencida`):"sem previsão"} · depois transferência para a Iveco`, curto:`${km!=null?km+" km · ":""}via Betim`}; }
  const km=kmRestante(f), dest=rotaDe(f)===ROTA.BETIM?"Betim":"Sete Lagoas";
  if(f.chegada) return {km:0, dest, chegou:true, txt:"no cliente", curto:"no cliente"};
  const prev=toD(f.prev_chegada);
  if(prev){ const min=(prev-now)/60000;
    if(min>=0) return {km, dest, min, eta:prev, txt:`${km!=null?km+" km · ":""}chega em ${dur(min).slice(1)} (${fmtH(f.prev_chegada)})`, curto:`${km!=null?km+" km · ":""}${dur(min).slice(1)}`};
    return {km, dest, min, eta:prev, vencida:true, txt:`${km!=null?km+" km · ":""}previsão ${fmtH(f.prev_chegada)} vencida há ${dur(-min).slice(1)}`, curto:`${km!=null?km+" km · ":""}prev. vencida`}; }
  if(km!=null){ const min=km/velMedia()*60, eta=new Date(+now+min*60000); return {km, dest, min, eta, est:true, txt:`${km} km · ≈ ${dur(min).slice(1)} (≈ ${fmtH(iso(eta))}, estimado)`, curto:`${km} km · ≈ ${dur(min).slice(1)}`}; }
  return null;
}
/* ---------- expectativa de chegadas no dia (recebimento até 23:00) ---------- */
const CORTE_H=23;
function biChegadas(rows, now){
  const hoje=iso(now).slice(0,10), corte=new Date(now); corte.setHours(CORTE_H,0,0,0);
  const lead=calcInd("tudo").lead;
  const porPlaca={}; rows.filter(r=>r.f).forEach(r=>{ const k=r.placa||r.cn; (porPlaca[k]=porPlaca[k]||[]).push(r); });
  const out={chegou:[],ate:[],limite:[],depois:[],vencida:[],manut:[],betim:[],corte};
  Object.entries(porPlaca).forEach(([placa,rs])=>{ const f=rs[0].f;
    const v={placa, reboque:f.placa_reboque||"", motorista:f.motorista||"", rs, f, dest:rs[0].dest, crit:rs.some(r=>r.crit), tone:rs.map(r=>r.tone).sort((a,b)=>({crit:0,warn:1,info:2,ok:3}[a]-{crit:0,warn:1,info:2,ok:3}[b]))[0]};
    if(enviarIveco(f)){ v.eta=f.chegada?toD(f.chegada):toD(f.prev_chegada); v.betimTxt=f.chegada?`em Betim desde ${fmt(f.chegada)}`:`a caminho de Betim (${lugar(f.localizacao)})`; if(!f.chegada||dia(f.chegada)===hoje||rs.some(r=>r.nd&&r.nd<now)) out.betim.push(v); return; }
    if(f.chegada){ if(dia(f.chegada)===hoje){ v.eta=toD(f.chegada); out.chegou.push(v); } return; }
    const q=restante(f,now); v.rest=q;
    if(emManut(f)){ v.eta=toD(f.prev_chegada)||null; v.manut=true; out.manut.push(v); return; }
    if(f.prev_chegada && toD(f.prev_chegada)<now){ v.eta=toD(f.prev_chegada); out.vencida.push(v); return; }
    v.eta = q&&q.eta ? q.eta : null; v.est = q&&q.est;
    if(!v.eta) return;
    v.margem=(corte-v.eta)/60000;
    v.ex=exposicao(f,now,lead).filter(x=>x.nivel==="crit"||x.nivel==="warn");
    if(v.eta<=corte){ (v.margem<=60 ? out.limite : out.ate).push(v); } else out.depois.push(v);
  });
  ["chegou","ate","limite","depois","vencida","manut","betim"].forEach(k=>out[k].sort((a,b)=>(a.eta||0)-(b.eta||0)));
  return out;
}
function chegGrafico(C, now){
  const W=900, H=205, L=34, R=16, T=42, B=34, horas=[]; const h0=0, h1=26; // 00h até 02h do dia seguinte
  const base=new Date(now); base.setHours(0,0,0,0);
  const x=t=>L+((t-base)/3600000-h0)/(h1-h0)*(W-L-R);
  const bins={}; const add=(v,k)=>{ if(!v.eta) return; let hh=Math.floor((v.eta-base)/3600000); if(hh<h0) hh=h0; if(hh>=h1) hh=h1-1; const b=(bins[hh]=bins[hh]||{chegou:0,ate:0,limite:0,depois:0}); b[k]++; };
  C.chegou.forEach(v=>add(v,"chegou")); C.ate.forEach(v=>add(v,"ate")); C.limite.forEach(v=>add(v,"limite")); C.depois.forEach(v=>add(v,"depois"));
  const max=Math.max(1,...Object.values(bins).map(b=>b.chegou+b.ate+b.limite+b.depois));
  const y=v=>T+(H-T-B)*(1-v/max), bw=(W-L-R)/(h1-h0)-4;
  let g=`<rect x="${x(new Date(+base+CORTE_H*3600000))}" y="${T-8}" width="${x(new Date(+base+h1*3600000))-x(new Date(+base+CORTE_H*3600000))}" height="${H-T-B+8}" fill="var(--crit-soft)" opacity=".6"/>`;
  for(let v=0; v<=max; v+=Math.max(1,Math.ceil(max/4))) g+=`<line x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)"/><text x="${L-6}" y="${y(v)+4}" text-anchor="end">${v}</text>`;
  for(let hh=h0; hh<h1; hh+=2){ const t=new Date(+base+hh*3600000); g+=`<text x="${x(t)+bw/2+2}" y="${H-14}" text-anchor="middle">${pad(hh%24)}h</text>`; }
  const cores={chegou:"var(--bi-desc)",ate:"var(--ok)",limite:"var(--warn)",depois:"var(--crit)"}, nomes={chegou:"já chegaram",ate:"chegam até 22h",limite:"no limite (22h–23h)",depois:"após 23h"};
  Object.entries(bins).forEach(([hh,b])=>{ let acc=0; const bx=x(new Date(+base+hh*3600000))+2;
    ["chegou","ate","limite","depois"].forEach(k=>{ const n=b[k]; if(!n) return; const y1=y(acc+n), h=y(acc)-y1-(acc?2:0);
      g+=`<rect x="${bx}" y="${y1}" width="${bw}" height="${Math.max(1,h)}" rx="3" fill="${cores[k]}"><title>${pad(hh%24)}h: ${n} veículo${n>1?"s":""} ${nomes[k]}</title></rect>`; acc+=n; });
    g+=`<text x="${bx+bw/2}" y="${y(acc)-5}" text-anchor="middle" style="fill:var(--ink);font-weight:600">${acc}</text>`; });
  const xc=x(new Date(+base+CORTE_H*3600000)), xn=x(now);
  g+=`<line x1="${xc}" x2="${xc}" y1="${T-24}" y2="${H-B}" stroke="var(--crit)" stroke-width="2" stroke-dasharray="5 4"/><text x="${xc-4}" y="${T-28}" text-anchor="end" style="fill:var(--crit);font-weight:700">fim do recebimento 23:00</text>`;
  g+=`<line x1="${xn}" x2="${xn}" y1="${T-24}" y2="${H-B}" stroke="var(--accent)" stroke-width="2"/><text x="${xc-xn<230?xn-4:xn+4}" y="${T-28}" text-anchor="${xc-xn<230?"end":"start"}" style="fill:var(--accent);font-weight:700">agora ${fmtH(iso(now))}</text>`;
  return `<svg viewBox="0 0 ${W} ${H}" class="cheg-svg" role="img" aria-label="Chegadas previstas por hora hoje, com o fim do recebimento às 23h">${g}</svg>`;
}
function chegTexto(C, now){
  const linha=v=>`• ${v.placa}${v.reboque?"/"+v.reboque:""} – ${v.rs.map(r=>r.cn).join(" + ")}${v.crit?" [CRÍTICO]":""} – ${v.dest} – expectativa ${v.rs.map(r=>r.p&&r.p.necessidade?fmt(r.p.necessidade):"fora da programação").join(" / ")} – chegada ${v.eta?fmtH(iso(v.eta)):"—"}${v.est?" (estimado)":""}`;
  let t=`*Expectativa de chegadas na planta – ${fmt(now).slice(0,5)} (recebimento até 23:00)*\n`;
  t+=`Já chegaram hoje: ${C.chegou.length} | Previstos até 23:00: ${C.ate.length+C.limite.length} | Após 23:00: ${C.depois.length}${C.vencida.length?` | Previsão a confirmar: ${C.vencida.length}`:""}\n`;
  if(C.ate.length||C.limite.length) t+=`\n*Chegam até 23:00*\n`+C.ate.concat(C.limite).map(linha).join("\n")+"\n";
  if(C.depois.length) t+=`\n*Previstos após 23:00 (recebimento no dia seguinte)*\n`+C.depois.map(linha).join("\n")+"\n";
  if(C.betim.length) t+=`\n*Em Betim ou indo para Betim – ainda não seguiram para a Iveco*\n`+C.betim.map(v=>linha(v)+" – "+v.betimTxt).join("\n")+"\n";
  if(C.manut.length) t+=`\n*Em manutenção – chegada incerta*\n`+C.manut.map(v=>linha(v)+" – "+manutTxt(v.f)).join("\n")+"\n";
  if(C.vencida.length) t+=`\n*Previsão vencida – confirmando posição*\n`+C.vencida.map(linha).join("\n")+"\n";
  return t;
}
function chegSecao(rows, now){
  const C=biChegadas(rows, now), nC=a=>a.reduce((s,v)=>s+v.rs.length,0);
  const encerrado = now>=C.corte;
  const tr=(v,k)=>{ const m=v.margem; const mtxt = k==="chegou" ? `chegou ${fmtH(iso(v.eta))}` : k==="manut" ? "em manutenção" : k==="betim" ? v.betimTxt : k==="vencida" ? `previsão ${fmtH(iso(v.eta))} vencida` : m>=0 ? `folga ${dur(m).slice(1)}` : `${dur(-m).slice(1)} após o corte`;
    return `<tr data-bp="${esc(v.placa)}" data-tone="${k==="chegou"?"ok":k==="ate"?"ok":k==="limite"?"warn":k==="depois"?"crit":"warn"}" tabindex="0"><td class="sev"></td>
      <td>${truckIcon(k==="chegou"?"desc":v.tone,26)}</td>
      <td><b class="mono">${esc(v.placa)}</b>${v.reboque?`<span class="sub mono"> / ${esc(v.reboque)}</span>`:""}<div class="sub">${esc(v.motorista)}</div></td>
      <td>${v.rs.map(r=>`<div><span class="cn">${esc(r.cn)}</span>${r.crit?` <span class="linha">${esc(r.crit)}</span>`:""}</div>`).join("")}</td>
      <td>${esc(v.dest)}</td>
      <td class="num">${v.rs.map(r=>`<div>${r.p&&r.p.necessidade?`<b>${fmt(r.p.necessidade)}</b>`:`<span class="sub">não consta na programação</span>`}</div>`).join("")}</td>
      <td class="num"><b>${v.eta?fmtH(iso(v.eta)):"—"}</b>${v.est?'<div class="sub">estimado</div>':k==="chegou"?'<div class="sub">chegada</div>':'<div class="sub">previsão follow</div>'}</td>
      <td class="num">${k==="chegou"?"—":v.rest&&v.rest.km!=null?v.rest.km+" km":'<span class="sub">cidade não cadastrada</span>'}<div class="sub">${esc(lugar(v.f.localizacao))}</div></td>
      <td><span class="gap ${k==="depois"?"crit":k==="limite"||k==="vencida"?"warn":"ok"}">${esc(mtxt)}</span>${v.ex&&v.ex.length?`<div class="chips">${v.ex.slice(0,1).map(x=>`<span class="chip ${x.nivel}">⚠ ${esc(x.txt)}</span>`).join("")}</div>`:""}</td><td><button class="btn sm ve-btn" type="button" data-ve="${esc(v.placa)}" data-vcn="${esc(v.rs[0].cn)}" title="Editar os dados deste veículo">✎ Editar</button></td></tr>`; };
  const bloco=(k,titulo,sub,arr)=>arr.length?`<tr class="cheg-g"><td colspan="10"><b>${titulo}</b> <span class="sec-n">${arr.length} veículo${arr.length>1?"s":""} · ${nC(arr)} container${nC(arr)>1?"s":""}</span> <span class="sub">${sub}</span></td></tr>`+arr.map(v=>tr(v,k)).join(""):"";
  const tile=(cls,t,v,s)=>`<div class="cheg-t ${cls}"><b>${v}</b><span>${t}</span><small>${s}</small></div>`;
  return `<section class="bi-panel cheg">
    <div class="bi-mh"><h3>Chegadas previstas hoje na planta <span class="sub" style="font-family:var(--f-ui);font-weight:400">recebimento até 23:00</span></h3>
      <button class="btn sm" type="button" id="cheg-copy" style="margin-left:0">Copiar lista</button></div>
    ${encerrado?'<div class="msg err">O recebimento de hoje já encerrou às 23:00. Os veículos listados como "após 23h" serão recebidos no dia seguinte.</div>':""}
    <div class="cheg-tiles">
      ${tile("desc","Já chegaram hoje",C.chegou.length,`${nC(C.chegou)} containers`)}
      ${tile("ok","Chegam até 23:00",C.ate.length+C.limite.length,`${nC(C.ate)+nC(C.limite)} containers`)}
      ${tile("warn","No limite (22h–23h)",C.limite.length,"menos de 1h de folga")}
      ${tile("crit","Após 23:00",C.depois.length,`${nC(C.depois)} containers ficam para amanhã`)}
      ${tile(C.manut.length?"crit":"mut","🔧 Em manutenção",C.manut.length,C.manut.length?"chegada incerta":"nenhum veículo parado")}
      ${tile("mut","Previsão vencida",C.vencida.length,"confirmar posição")}
      ${tile("tot","Total esperado no dia",C.chegou.length+C.ate.length+C.limite.length,`${nC(C.chegou)+nC(C.ate)+nC(C.limite)} containers até 23:00`)}
    </div>
    <div class="cheg-chart">${chegGrafico(C,now)}</div>
    <div class="lg"><span><i style="background:var(--bi-desc)"></i>Já chegaram</span><span><i style="background:var(--ok)"></i>Chegam até 22h</span><span><i style="background:var(--warn)"></i>No limite (22h–23h)</span><span><i style="background:var(--crit)"></i>Após 23h</span></div>
    <div class="tbl-wrap" style="box-shadow:none"><table class="cheg-tb"><thead><tr><th></th><th></th><th>Placa (cavalo / reboque)</th><th>Containers</th><th>Planta</th><th>Expectativa na planta</th><th>Chegada</th><th>Faltam</th><th>Folga até 23:00</th><th></th></tr></thead><tbody>
      ${bloco("limite","No limite","chegam entre 22:00 e 23:00: acompanhar de perto",C.limite)}
      ${bloco("ate","Chegam até 22:00","",C.ate)}
      ${bloco("depois","Após 23:00","não serão recebidos hoje",C.depois)}
      ${bloco("manut","🔧 Em manutenção","chegada depende da liberação ou da troca do cavalo",C.manut)}
      ${bloco("vencida","Previsão vencida","o follow passou do horário e o veículo não consta como chegado",C.vencida)}
      ${bloco("chegou","Já chegaram hoje","",C.chegou)}
      ${!(C.chegou.length+C.ate.length+C.limite.length+C.depois.length+C.vencida.length+C.manut.length+C.betim.length)?'<tr><td colspan="9" class="empty">Nenhum veículo com chegada prevista para os filtros atuais.</td></tr>':""}
    </tbody></table></div>
    <div class="note">Considera a previsão de chegada do follow. Sem previsão (veículos no porto), a chegada é estimada pela distância restante e pela velocidade média das viagens. Os filtros do painel (container, processos, data programada, destino) também valem aqui.</div>
  </section>`;
}

/* ---------- processos Iveco em Betim (base) ---------- */
function betimLista(now){
  const hoje=iso(now).slice(0,10);
  return Object.values(state.follow).filter(f=>enviarIveco(f)).map(f=>{ const p=state.prog[f.container]; const need=(p&&p.necessidade)||f.data_prog||null, nd=toD(need);
    const parado=f.chegada?(now-toD(f.chegada))/60000:null, atraso=nd&&nd<now?(now-nd)/60000:null;
    return {f,p,cn:f.container,need,nd,parado,atraso,hoje:dia(need)===hoje,venc:!!(nd&&nd<now),fonte:p&&p.necessidade?"programação Iveco":"data programada do follow",crit:isCrit(p)?p.criticidade:""}; })
    .sort((a,b)=>(b.crit?1:0)-(a.crit?1:0) || String(a.need).localeCompare(String(b.need)));
}
function betimTexto(ls, now){
  let t=`*Time Betim – processos Iveco que ainda não seguiram para a planta* (${fmt(now)})\n`;
  ls.forEach(x=>{ const f=x.f; t+=`\n• ${x.cn}${x.crit?` [${x.crit}]`:""} – ${f.placa_cavalo||"—"}${f.placa_reboque?"/"+f.placa_reboque:""}${f.motorista?" – "+f.motorista:""}\n  ${f.chegada?`Em Betim desde ${fmt(f.chegada)}`:`A caminho de Betim (${lugar(f.localizacao)}${f.prev_chegada?", prev. "+fmt(f.prev_chegada):""})`} · Necessidade Iveco: ${x.need?fmt(x.need):"—"}${x.atraso?` (vencida há ${dur(x.atraso).slice(1)})`:""}`; });
  return t+`\n\nPor favor, informar o motivo de o processo ainda não ter seguido para a Iveco (Sete Lagoas) e a previsão de saída de cada container.`;
}
function betimSecao(now){
  const all=betimLista(now); if(!all.length) return "";
  const modo=state.bi.betim||"todos";
  const ls = modo==="hoje" ? all.filter(x=>x.hoje) : modo==="venc" ? all.filter(x=>x.venc) : all;
  const nP=all.filter(x=>x.f.chegada).length, nT=all.length-nP, nH=all.filter(x=>x.hoje).length, nV=all.filter(x=>x.venc).length, nC=all.filter(x=>x.crit).length;
  return `<section class="bi-panel betim">
    <div class="bi-mh"><h3>Processos Iveco em Betim <span class="sub" style="font-family:var(--f-ui);font-weight:400">base/transbordo · só contam como entregues quando chegam na Iveco (Sete Lagoas)</span></h3>
      <button class="btn sm" type="button" id="betim-copy" style="margin-left:0">Copiar mensagem para o time de Betim</button></div>
    <div class="cheg-tiles">
      <div class="cheg-t crit"><b>${nP}</b><span>Enviar para a Iveco</span><small>entregues em Betim, ainda não na Iveco</small></div>
      <div class="cheg-t ${nH?"crit":"mut"}"><b>${nH}</b><span>Necessidade hoje</span><small>programados para hoje</small></div>
      <div class="cheg-t ${nV?"crit":"mut"}"><b>${nV}</b><span>Necessidade vencida</span><small>já deveriam estar na Iveco</small></div>
      <div class="cheg-t ${nC?"crit":"mut"}"><b>${nC}</b><span>Críticos Iveco</span><small>item para linha / crítico</small></div>
    </div>
    <div class="row"><div class="seg" role="group" aria-label="Filtro Betim"><button type="button" data-bt="todos" aria-pressed="${modo==="todos"}">Todos (${all.length})</button><button type="button" data-bt="hoje" aria-pressed="${modo==="hoje"}">Necessidade hoje (${nH})</button><button type="button" data-bt="venc" aria-pressed="${modo==="venc"}">Vencidos (${nV})</button></div></div>
    <div class="tbl-wrap" style="box-shadow:none"><table class="cheg-tb"><thead><tr><th></th><th>Container</th><th>Placa (cavalo / reboque)</th><th>Situação</th><th>Necessidade Iveco</th><th>Atraso / tempo parado</th></tr></thead><tbody>
    ${ls.length?ls.map(x=>{ const f=x.f, t=x.venc?"crit":"warn"; return `<tr data-cn="${esc(x.cn)}" data-tone="${t}" tabindex="0"><td class="sev"></td>
      <td><span class="cn">${esc(x.cn)}</span>${x.crit?` <span class="linha">${esc(x.crit)}</span>`:""}${x.hoje?' <span class="pill crit">hoje</span>':""}</td>
      <td><b class="mono">${esc(f.placa_cavalo||"—")}</b>${f.placa_reboque?`<span class="sub mono"> / ${esc(f.placa_reboque)}</span>`:""}<div class="sub">${esc(f.motorista||"")}</div></td>
      <td><span class="pill crit">Enviar para a Iveco</span>${f.chegada?`<div class="sub">em Betim desde ${fmt(f.chegada)}${f.statusOriginal?` · follow: ${esc(f.statusOriginal)}`:` · follow: ${esc(f.status||"")}`}</div>`:`<div class="sub">a caminho de Betim</div>`}${f.chegada?"":`<div class="sub">${esc(lugar(f.localizacao))}${f.prev_chegada?` · prev. ${fmt(f.prev_chegada)}`:""}</div>`}</td>
      <td class="num"><b>${x.need?fmt(x.need):"—"}</b><div class="sub">${esc(x.fonte)}</div></td>
      <td>${x.atraso?`<span class="gap crit">vencida há ${dur(x.atraso).slice(1)}</span>`:x.nd?`<span class="gap warn">faltam ${dur((x.nd-now)/60000).slice(1)}</span>`:"—"}${x.parado?`<div class="sub">parado em Betim há ${dur(x.parado).slice(1)}</div>`:""}</td></tr>`; }).join(""):'<tr><td colspan="6" class="empty">Nenhum processo neste filtro.</td></tr>'}
    </tbody></table></div>
    <div class="note">Considera somente os containers do follow com local de entrega BETIM e status geral ENTREGUE. A necessidade vem da programação da Iveco; quando o container não está na programação atual, usa a data programada do follow. Clique no container para ver ou editar o follow.</div>
  </section>`;
}

/* caixa de seleção múltipla (estilo segmentação do Power BI) */
function msel(id,label,opts,sel,cfg){ cfg=cfg||{}; const s=new Set(A(sel)), n=s.size, aberto=state.biOpen===id;
  const um = n===1 ? (opts.find(o=>o.v===[...s][0])||{t:[...s][0]}).t : "";
  const resumo = !n ? "Todos" : (cfg.padrao && mesmo([...s],cfg.padrao)) ? cfg.rotuloPadrao : n===1 ? um : `${n} selecionados`;
  const q=aberto?(state.biQ||""):"";
  return `<div class="bi-f ms${aberto?" open":""}" data-ms="${id}"><span>${label}</span>
    <button type="button" class="ms-btn" aria-haspopup="listbox" aria-expanded="${aberto}"><span>${esc(resumo)}</span>${n?`<b class="ms-n">${n}</b>`:""}</button>
    ${aberto?`<div class="ms-pop" role="listbox" aria-multiselectable="true" aria-label="${esc(label)}">
      ${cfg.busca?`<input class="ms-q" type="search" placeholder="Buscar ${esc(label.toLowerCase())}…" value="${esc(q)}" autocomplete="off">`:""}
      <div class="ms-acts"><button type="button" data-msall>Selecionar todos</button><button type="button" data-msclr>Limpar</button>${cfg.padrao?`<button type="button" data-msdef>${esc(cfg.rotuloPadrao)}</button>`:""}</div>
      <div class="ms-list">${opts.map(o=>`<label class="ms-o"${q&&!norm(o.t+" "+(o.sub||"")).includes(norm(q))?" hidden":""}><input type="checkbox" value="${esc(o.v)}" ${s.has(o.v)?"checked":""}><span>${esc(o.t)}${o.sub?`<small>${esc(o.sub)}</small>`:""}</span></label>`).join("")||'<div class="sub">Sem opções</div>'}</div>
      <div class="ms-foot"><span class="sub">${n?`${n} de ${opts.length}`:"Nenhum marcado = todos"}</span><button type="button" data-msok>OK</button></div></div>`:""}
  </div>`;
}

/* ---------- cidades novas: reconhecimento automático ---------- */
// Municípios de MG, RJ, ES e SP (IBGE, coordenadas da sede) para localizar cidades que não estão na rota
const MUN_TXT="ABADIA DOS DOURADOS|MG|-18.4831|-47.3916|Abadia dos Dourados;ABAETE|MG|-19.1551|-45.4444|Abaeté;ABRE CAMPO|MG|-20.2996|-42.4743|Abre Campo;ACAIACA|MG|-20.3590|-43.1439|Acaiaca;ACUCENA|MG|-19.0671|-42.5419|Açucena;ADAMANTINA|SP|-21.6820|-51.0737|Adamantina;ADOLFO|SP|-21.2325|-49.6451|Adolfo;AFONSO CLAUDIO|ES|-20.0778|-41.1261|Afonso Cláudio;AGUA BOA|MG|-17.9914|-42.3806|Água Boa;AGUA COMPRIDA|MG|-20.0576|-48.1069|Água Comprida;AGUA DOCE DO NORTE|ES|-18.5482|-40.9854|Água Doce do Norte;AGUAI|SP|-22.0572|-46.9735|Aguaí;AGUANIL|MG|-20.9439|-45.3915|Aguanil;AGUAS DA PRATA|SP|-21.9319|-46.7176|Águas da Prata;AGUAS DE LINDOIA|SP|-22.4733|-46.6314|Águas de Lindóia;AGUAS DE SANTA BARBARA|SP|-22.8812|-49.2421|Águas de Santa Bárbara;AGUAS DE SAO PEDRO|SP|-22.5977|-47.8734|Águas de São Pedro;AGUAS FORMOSAS|MG|-17.0802|-40.9384|Águas Formosas;AGUAS VERMELHAS|MG|-15.7431|-41.4571|Águas Vermelhas;AGUDOS|SP|-22.4694|-48.9863|Agudos;AGUIA BRANCA|ES|-18.9846|-40.7437|Águia Branca;AIMORES|MG|-19.5007|-41.0746|Aimorés;AIURUOCA|MG|-21.9736|-44.6042|Aiuruoca;ALAGOA|MG|-22.1710|-44.6413|Alagoa;ALAMBARI|SP|-23.5503|-47.8980|Alambari;ALBERTINA|MG|-22.2018|-46.6139|Albertina;ALEGRE|ES|-20.7580|-41.5382|Alegre;ALEM PARAIBA|MG|-21.8797|-42.7176|Além Paraíba;ALFENAS|MG|-21.4256|-45.9477|Alfenas;ALFREDO CHAVES|ES|-20.6396|-40.7543|Alfredo Chaves;ALFREDO MARCONDES|SP|-21.9527|-51.4140|Alfredo Marcondes;ALFREDO VASCONCELOS|MG|-21.1535|-43.7718|Alfredo Vasconcelos;ALMENARA|MG|-16.1785|-40.6942|Almenara;ALPERCATA|MG|-18.9740|-41.9700|Alpercata;ALPINOPOLIS|MG|-20.8631|-46.3878|Alpinópolis;ALTAIR|SP|-20.5242|-49.0571|Altair;ALTEROSA|MG|-21.2488|-46.1387|Alterosa;ALTINOPOLIS|SP|-21.0214|-47.3712|Altinópolis;ALTO ALEGRE|SP|-21.5811|-50.1680|Alto Alegre;ALTO CAPARAO|MG|-20.4310|-41.8738|Alto Caparaó;ALTO JEQUITIBA|MG|-20.4208|-41.9670|Alto Jequitibá;ALTO RIO DOCE|MG|-21.0281|-43.4067|Alto Rio Doce;ALTO RIO NOVO|ES|-19.0618|-41.0209|Alto Rio Novo;ALUMINIO|SP|-23.5306|-47.2546|Alumínio;ALVARENGA|MG|-19.4174|-41.7317|Alvarenga;ALVARES FLORENCE|SP|-20.3203|-49.9141|Álvares Florence;ALVARES MACHADO|SP|-22.0764|-51.4722|Álvares Machado;ALVARO DE CARVALHO|SP|-22.0841|-49.7190|Álvaro de Carvalho;ALVINLANDIA|SP|-22.4435|-49.7623|Alvinlândia;ALVINOPOLIS|MG|-20.1098|-43.0535|Alvinópolis;ALVORADA DE MINAS|MG|-18.7334|-43.3638|Alvorada de Minas;AMERICANA|SP|-22.7374|-47.3331|Americana;AMERICO BRASILIENSE|SP|-21.7288|-48.1147|Américo Brasiliense;AMERICO DE CAMPOS|SP|-20.2985|-49.7359|Américo de Campos;AMPARO|SP|-22.7088|-46.7720|Amparo;AMPARO DO SERRA|MG|-20.5051|-42.8009|Amparo do Serra;ANALANDIA|SP|-22.1289|-47.6619|Analândia;ANCHIETA|ES|-20.7955|-40.6425|Anchieta;ANDRADAS|MG|-22.0695|-46.5724|Andradas;ANDRADINA|SP|-20.8948|-51.3786|Andradina;ANDRELANDIA|MG|-21.7411|-44.3117|Andrelândia;ANGATUBA|SP|-23.4917|-48.4139|Angatuba;ANGELANDIA|MG|-17.7279|-42.2641|Angelândia;ANGRA DOS REIS|RJ|-23.0011|-44.3196|Angra dos Reis;ANHEMBI|SP|-22.7930|-48.1336|Anhembi;ANHUMAS|SP|-22.2934|-51.3895|Anhumas;ANTONIO CARLOS|MG|-21.3210|-43.7451|Antônio Carlos;ANTONIO DIAS|MG|-19.6491|-42.8732|Antônio Dias;ANTONIO PRADO DE MINAS|MG|-21.0192|-42.1109|Antônio Prado de Minas;APARECIDA|SP|-22.8495|-45.2325|Aparecida;APARECIDA D'OESTE|SP|-20.4487|-50.8835|Aparecida d'Oeste;APERIBE|RJ|-21.6252|-42.1017|Aperibé;APIACA|ES|-21.1523|-41.5693|Apiacá;APIAI|SP|-24.5108|-48.8443|Apiaí;ARACAI|MG|-19.1955|-44.2493|Araçaí;ARACARIGUAMA|SP|-23.4366|-47.0608|Araçariguama;ARACATUBA|SP|-21.2076|-50.4401|Araçatuba;ARACITABA|MG|-21.3446|-43.3736|Aracitaba;ARACOIABA DA SERRA|SP|-23.5029|-47.6166|Araçoiaba da Serra;ARACRUZ|ES|-19.8200|-40.2764|Aracruz;ARACUAI|MG|-16.8523|-42.0637|Araçuaí;ARAGUARI|MG|-18.6456|-48.1934|Araguari;ARAMINA|SP|-20.0882|-47.7873|Aramina;ARANDU|SP|-23.1386|-49.0487|Arandu;ARANTINA|MG|-21.9102|-44.2555|Arantina;ARAPEI|SP|-22.6717|-44.4441|Arapeí;ARAPONGA|MG|-20.6686|-42.5178|Araponga;ARAPORA|MG|-18.4357|-49.1847|Araporã;ARAPUA|MG|-19.0268|-46.1484|Arapuá;ARARAQUARA|SP|-21.7845|-48.1780|Araraquara;ARARAS|SP|-22.3572|-47.3842|Araras;ARARUAMA|RJ|-22.8697|-42.3326|Araruama;ARAUJOS|MG|-19.9405|-45.1671|Araújos;ARAXA|MG|-19.5902|-46.9438|Araxá;ARCEBURGO|MG|-21.3590|-46.9401|Arceburgo;ARCO-IRIS|SP|-21.7728|-50.4660|Arco-Íris;ARCOS|MG|-20.2863|-45.5373|Arcos;AREADO|MG|-21.3572|-46.1421|Areado;AREAL|RJ|-22.2283|-43.1118|Areal;AREALVA|SP|-22.0310|-48.9135|Arealva;AREIAS|SP|-22.5786|-44.6992|Areias;AREIOPOLIS|SP|-22.6672|-48.6681|Areiópolis;ARGIRITA|MG|-21.6083|-42.8292|Argirita;ARICANDUVA|MG|-17.8666|-42.5533|Aricanduva;ARINOS|MG|-15.9187|-46.1043|Arinos;ARIRANHA|SP|-21.1872|-48.7904|Ariranha;ARMACAO DOS BUZIOS|RJ|-22.7528|-41.8846|Armação dos Búzios;ARRAIAL DO CABO|RJ|-22.9774|-42.0267|Arraial do Cabo;ARTUR NOGUEIRA|SP|-22.5727|-47.1727|Artur Nogueira;ARUJA|SP|-23.3965|-46.3200|Arujá;ASPASIA|SP|-20.1600|-50.7280|Aspásia;ASSIS|SP|-22.6600|-50.4183|Assis;ASTOLFO DUTRA|MG|-21.3184|-42.8572|Astolfo Dutra;ATALEIA|MG|-18.0438|-41.1149|Ataléia;ATIBAIA|SP|-23.1171|-46.5563|Atibaia;ATILIO VIVACQUA|ES|-20.9130|-41.1986|Atilio Vivacqua;AUGUSTO DE LIMA|MG|-18.0997|-44.2655|Augusto de Lima;AURIFLAMA|SP|-20.6836|-50.5572|Auriflama;AVAI|SP|-22.1514|-49.3356|Avaí;AVANHANDAVA|SP|-21.4584|-49.9509|Avanhandava;AVARE|SP|-23.1067|-48.9251|Avaré;BADY BASSITT|SP|-20.9197|-49.4385|Bady Bassitt;BAEPENDI|MG|-21.9570|-44.8874|Baependi;BAIXO GUANDU|ES|-19.5213|-41.0109|Baixo Guandu;BALBINOS|SP|-21.8963|-49.3619|Balbinos;BALDIM|MG|-19.2832|-43.9613|Baldim;BALSAMO|SP|-20.7348|-49.5865|Bálsamo;BAMBUI|MG|-20.0166|-45.9754|Bambuí;BANANAL|SP|-22.6819|-44.3281|Bananal;BANDEIRA|MG|-15.8783|-40.5622|Bandeira;BANDEIRA DO SUL|MG|-21.7308|-46.3833|Bandeira do Sul;BARAO DE ANTONINA|SP|-23.6284|-49.5634|Barão de Antonina;BARAO DE COCAIS|MG|-19.9389|-43.4755|Barão de Cocais;BARAO DE MONTE ALTO|MG|-21.2444|-42.2372|Barão de Monte Alto;BARBACENA|MG|-21.2214|-43.7703|Barbacena;BARBOSA|SP|-21.2657|-49.9518|Barbosa;BARIRI|SP|-22.0730|-48.7438|Bariri;BARRA BONITA|SP|-22.4909|-48.5583|Barra Bonita;BARRA DE SAO FRANCISCO|ES|-18.7548|-40.8965|Barra de São Francisco;BARRA DO CHAPEU|SP|-24.4722|-49.0238|Barra do Chapéu;BARRA DO PIRAI|RJ|-22.4715|-43.8269|Barra do Piraí;BARRA DO TURVO|SP|-24.7590|-48.5013|Barra do Turvo;BARRA LONGA|MG|-20.2869|-43.0402|Barra Longa;BARRA MANSA|RJ|-22.5481|-44.1752|Barra Mansa;BARRETOS|SP|-20.5531|-48.5698|Barretos;BARRINHA|SP|-21.1864|-48.1636|Barrinha;BARROSO|MG|-21.1907|-43.9720|Barroso;BARUERI|SP|-23.5057|-46.8790|Barueri;BASTOS|SP|-21.9210|-50.7357|Bastos;BATATAIS|SP|-20.8929|-47.5921|Batatais;BAURU|SP|-22.3246|-49.0871|Bauru;BEBEDOURO|SP|-20.9491|-48.4791|Bebedouro;BELA VISTA DE MINAS|MG|-19.8302|-43.0922|Bela Vista de Minas;BELFORD ROXO|RJ|-22.7640|-43.3992|Belford Roxo;BELMIRO BRAGA|MG|-21.9440|-43.4084|Belmiro Braga;BELO HORIZONTE|MG|-19.9102|-43.9266|Belo Horizonte;BELO ORIENTE|MG|-19.2199|-42.4828|Belo Oriente;BELO VALE|MG|-20.4077|-44.0275|Belo Vale;BENTO DE ABREU|SP|-21.2686|-50.8140|Bento de Abreu;BERILO|MG|-16.9567|-42.4606|Berilo;BERIZAL|MG|-15.6100|-41.7432|Berizal;BERNARDINO DE CAMPOS|SP|-23.0164|-49.4679|Bernardino de Campos;BERTIOGA|SP|-23.8486|-46.1396|Bertioga;BERTOPOLIS|MG|-17.0590|-40.5800|Bertópolis;BETIM|MG|-19.9668|-44.2008|Betim;BIAS FORTES|MG|-21.6020|-43.7574|Bias Fortes;BICAS|MG|-21.7232|-43.0560|Bicas;BILAC|SP|-21.4040|-50.4746|Bilac;BIQUINHAS|MG|-18.7754|-45.4974|Biquinhas;BIRIGUI|SP|-21.2910|-50.3432|Birigui;BIRITIBA-MIRIM|SP|-23.5698|-46.0407|Biritiba-Mirim;BOA ESPERANCA|MG|-21.0927|-45.5612|Boa Esperança;BOA ESPERANCA|ES|-18.5395|-40.3025|Boa Esperança;BOA ESPERANCA DO SUL|SP|-21.9918|-48.3906|Boa Esperança do Sul;BOCAINA|SP|-22.1365|-48.5230|Bocaina;BOCAINA DE MINAS|MG|-22.1697|-44.3972|Bocaina de Minas;BOCAIUVA|MG|-17.1135|-43.8104|Bocaiúva;BOFETE|SP|-23.1055|-48.2582|Bofete;BOITUVA|SP|-23.2855|-47.6786|Boituva;BOM DESPACHO|MG|-19.7386|-45.2622|Bom Despacho;BOM JARDIM|RJ|-22.1545|-42.4251|Bom Jardim;BOM JARDIM DE MINAS|MG|-21.9479|-44.1885|Bom Jardim de Minas;BOM JESUS DA PENHA|MG|-21.0148|-46.5174|Bom Jesus da Penha;BOM JESUS DO AMPARO|MG|-19.7054|-43.4782|Bom Jesus do Amparo;BOM JESUS DO GALHO|MG|-19.8360|-42.3165|Bom Jesus do Galho;BOM JESUS DO ITABAPOANA|RJ|-21.1449|-41.6822|Bom Jesus do Itabapoana;BOM JESUS DO NORTE|ES|-21.1173|-41.6731|Bom Jesus do Norte;BOM JESUS DOS PERDOES|SP|-23.1356|-46.4675|Bom Jesus dos Perdões;BOM REPOUSO|MG|-22.4675|-46.1440|Bom Repouso;BOM SUCESSO|MG|-21.0329|-44.7537|Bom Sucesso;BOM SUCESSO DE ITARARE|SP|-24.3155|-49.1451|Bom Sucesso de Itararé;BONFIM|MG|-20.3302|-44.2366|Bonfim;BONFINOPOLIS DE MINAS|MG|-16.5680|-45.9839|Bonfinópolis de Minas;BONITO DE MINAS|MG|-15.3231|-44.7543|Bonito de Minas;BORA|SP|-22.2696|-50.5409|Borá;BORACEIA|SP|-22.1926|-48.7808|Boracéia;BORBOREMA|SP|-21.6214|-49.0741|Borborema;BORDA DA MATA|MG|-22.2707|-46.1653|Borda da Mata;BOREBI|SP|-22.5728|-48.9707|Borebi;BOTELHOS|MG|-21.6412|-46.3910|Botelhos;BOTUCATU|SP|-22.8837|-48.4437|Botucatu;BOTUMIRIM|MG|-16.8657|-43.0086|Botumirim;BRAGANCA PAULISTA|SP|-22.9527|-46.5419|Bragança Paulista;BRAS PIRES|MG|-20.8419|-43.2406|Brás Pires;BRASILANDIA DE MINAS|MG|-16.9999|-46.0081|Brasilândia de Minas;BRASILIA DE MINAS|MG|-16.2104|-44.4299|Brasília de Minas;BRAUNA|SP|-21.4990|-50.3175|Braúna;BRAUNAS|MG|-19.0562|-42.7099|Braúnas;BRAZOPOLIS|MG|-22.4743|-45.6166|Brazópolis;BREJETUBA|ES|-20.1395|-41.2954|Brejetuba;BREJO ALEGRE|SP|-21.1651|-50.1861|Brejo Alegre;BRODOWSKI|SP|-20.9845|-47.6572|Brodowski;BROTAS|SP|-22.2795|-48.1251|Brotas;BRUMADINHO|MG|-20.1510|-44.2007|Brumadinho;BUENO BRANDAO|MG|-22.4383|-46.3491|Bueno Brandão;BUENOPOLIS|MG|-17.8744|-44.1775|Buenópolis;BUGRE|MG|-19.4231|-42.2552|Bugre;BURI|SP|-23.7977|-48.5958|Buri;BURITAMA|SP|-21.0661|-50.1475|Buritama;BURITIS|MG|-15.6218|-46.4221|Buritis;BURITIZAL|SP|-20.1911|-47.7096|Buritizal;BURITIZEIRO|MG|-17.3656|-44.9606|Buritizeiro;CABECEIRA GRANDE|MG|-16.0335|-47.0862|Cabeceira Grande;CABO FRIO|RJ|-22.8894|-42.0286|Cabo Frio;CABO VERDE|MG|-21.4699|-46.3919|Cabo Verde;CABRALIA PAULISTA|SP|-22.4576|-49.3393|Cabrália Paulista;CABREUVA|SP|-23.3053|-47.1362|Cabreúva;CACAPAVA|SP|-23.0992|-45.7076|Caçapava;CACHOEIRA DA PRATA|MG|-19.5210|-44.4544|Cachoeira da Prata;CACHOEIRA DE MINAS|MG|-22.3511|-45.7809|Cachoeira de Minas;CACHOEIRA DE PAJEU|MG|-15.9688|-41.4948|Cachoeira de Pajeú;CACHOEIRA DOURADA|MG|-18.5161|-49.5039|Cachoeira Dourada;CACHOEIRA PAULISTA|SP|-22.6665|-45.0154|Cachoeira Paulista;CACHOEIRAS DE MACACU|RJ|-22.4658|-42.6523|Cachoeiras de Macacu;CACHOEIRO DE ITAPEMIRIM|ES|-20.8462|-41.1198|Cachoeiro de Itapemirim;CACONDE|SP|-21.5280|-46.6437|Caconde;CAETANOPOLIS|MG|-19.2971|-44.4189|Caetanópolis;CAETE|MG|-19.8826|-43.6704|Caeté;CAFELANDIA|SP|-21.8031|-49.6092|Cafelândia;CAIABU|SP|-22.0127|-51.2394|Caiabu;CAIANA|MG|-20.6956|-41.9292|Caiana;CAIEIRAS|SP|-23.3607|-46.7397|Caieiras;CAIUA|SP|-21.8322|-51.9969|Caiuá;CAJAMAR|SP|-23.3550|-46.8781|Cajamar;CAJATI|SP|-24.7324|-48.1223|Cajati;CAJOBI|SP|-20.8773|-48.8063|Cajobi;CAJURI|MG|-20.7903|-42.7925|Cajuri;CAJURU|SP|-21.2749|-47.3030|Cajuru;CALDAS|MG|-21.9183|-46.3843|Caldas;CAMACHO|MG|-20.6294|-45.1593|Camacho;CAMANDUCAIA|MG|-22.7515|-46.1494|Camanducaia;CAMBUCI|RJ|-21.5691|-41.9187|Cambuci;CAMBUI|MG|-22.6115|-46.0572|Cambuí;CAMBUQUIRA|MG|-21.8540|-45.2896|Cambuquira;CAMPANARIO|MG|-18.2427|-41.7355|Campanário;CAMPANHA|MG|-21.8360|-45.4004|Campanha;CAMPESTRE|MG|-21.7079|-46.2381|Campestre;CAMPINA DO MONTE ALEGRE|SP|-23.5895|-48.4758|Campina do Monte Alegre;CAMPINA VERDE|MG|-19.5382|-49.4862|Campina Verde;CAMPINAS|SP|-22.9053|-47.0659|Campinas;CAMPO AZUL|MG|-16.5028|-44.8096|Campo Azul;CAMPO BELO|MG|-20.8932|-45.2699|Campo Belo;CAMPO DO MEIO|MG|-21.1127|-45.8273|Campo do Meio;CAMPO FLORIDO|MG|-19.7631|-48.5716|Campo Florido;CAMPO LIMPO PAULISTA|SP|-23.2078|-46.7889|Campo Limpo Paulista;CAMPOS ALTOS|MG|-19.6914|-46.1725|Campos Altos;CAMPOS DO JORDAO|SP|-22.7296|-45.5833|Campos do Jordão;CAMPOS DOS GOYTACAZES|RJ|-21.7622|-41.3181|Campos dos Goytacazes;CAMPOS GERAIS|MG|-21.2370|-45.7569|Campos Gerais;CAMPOS NOVOS PAULISTA|SP|-22.6020|-49.9987|Campos Novos Paulista;CANA VERDE|MG|-21.0232|-45.1801|Cana Verde;CANAA|MG|-20.6869|-42.6167|Canaã;CANANEIA|SP|-25.0144|-47.9341|Cananéia;CANAPOLIS|MG|-18.7212|-49.2035|Canápolis;CANAS|SP|-22.7003|-45.0521|Canas;CANDEIAS|MG|-20.7692|-45.2765|Candeias;CANDIDO MOTA|SP|-22.7471|-50.3873|Cândido Mota;CANDIDO RODRIGUES|SP|-21.3275|-48.6327|Cândido Rodrigues;CANITAR|SP|-23.0040|-49.7839|Canitar;CANTAGALO|RJ|-21.9797|-42.3664|Cantagalo;CANTAGALO|MG|-18.5248|-42.6223|Cantagalo;CAPAO BONITO|SP|-24.0113|-48.3482|Capão Bonito;CAPARAO|MG|-20.5289|-41.9061|Caparaó;CAPELA DO ALTO|SP|-23.4685|-47.7388|Capela do Alto;CAPELA NOVA|MG|-20.9179|-43.6220|Capela Nova;CAPELINHA|MG|-17.6888|-42.5147|Capelinha;CAPETINGA|MG|-20.6163|-47.0571|Capetinga;CAPIM BRANCO|MG|-19.5471|-44.1304|Capim Branco;CAPINOPOLIS|MG|-18.6862|-49.5706|Capinópolis;CAPITAO ANDRADE|MG|-19.0748|-41.8614|Capitão Andrade;CAPITAO ENEAS|MG|-16.3265|-43.7084|Capitão Enéas;CAPITOLIO|MG|-20.6164|-46.0493|Capitólio;CAPIVARI|SP|-22.9951|-47.5071|Capivari;CAPUTIRA|MG|-20.1703|-42.2683|Caputira;CARAGUATATUBA|SP|-23.6125|-45.4125|Caraguatatuba;CARAI|MG|-17.1862|-41.7004|Caraí;CARANAIBA|MG|-20.8707|-43.7417|Caranaíba;CARANDAI|MG|-20.9566|-43.8110|Carandaí;CARANGOLA|MG|-20.7343|-42.0313|Carangola;CARAPEBUS|RJ|-22.1821|-41.6630|Carapebus;CARAPICUIBA|SP|-23.5235|-46.8407|Carapicuíba;CARATINGA|MG|-19.7868|-42.1292|Caratinga;CARBONITA|MG|-17.5255|-43.0137|Carbonita;CARDOSO|SP|-20.0800|-49.9183|Cardoso;CARDOSO MOREIRA|RJ|-21.4846|-41.6165|Cardoso Moreira;CAREACU|MG|-22.0424|-45.6960|Careaçu;CARIACICA|ES|-20.2632|-40.4165|Cariacica;CARLOS CHAGAS|MG|-17.6973|-40.7723|Carlos Chagas;CARMESIA|MG|-19.0877|-43.1382|Carmésia;CARMO|RJ|-21.9310|-42.6046|Carmo;CARMO DA CACHOEIRA|MG|-21.4633|-45.2201|Carmo da Cachoeira;CARMO DA MATA|MG|-20.5575|-44.8735|Carmo da Mata;CARMO DE MINAS|MG|-22.1204|-45.1307|Carmo de Minas;CARMO DO CAJURU|MG|-20.1912|-44.7664|Carmo do Cajuru;CARMO DO PARANAIBA|MG|-18.9910|-46.3167|Carmo do Paranaíba;CARMO DO RIO CLARO|MG|-20.9736|-46.1149|Carmo do Rio Claro;CARMOPOLIS DE MINAS|MG|-20.5396|-44.6336|Carmópolis de Minas;CARNEIRINHO|MG|-19.6987|-50.6894|Carneirinho;CARRANCAS|MG|-21.4898|-44.6446|Carrancas;CARVALHOPOLIS|MG|-21.7735|-45.8421|Carvalhópolis;CARVALHOS|MG|-22.0000|-44.4632|Carvalhos;CASA BRANCA|SP|-21.7708|-47.0852|Casa Branca;CASA GRANDE|MG|-20.7925|-43.9343|Casa Grande;CASCALHO RICO|MG|-18.5772|-47.8716|Cascalho Rico;CASIMIRO DE ABREU|RJ|-22.4812|-42.2066|Casimiro de Abreu;CASSIA|MG|-20.5831|-46.9201|Cássia;CASSIA DOS COQUEIROS|SP|-21.2801|-47.1643|Cássia dos Coqueiros;CASTELO|ES|-20.6033|-41.2031|Castelo;CASTILHO|SP|-20.8689|-51.4884|Castilho;CATAGUASES|MG|-21.3924|-42.6896|Cataguases;CATANDUVA|SP|-21.1314|-48.9770|Catanduva;CATAS ALTAS|MG|-20.0734|-43.4061|Catas Altas;CATAS ALTAS DA NORUEGA|MG|-20.6901|-43.4939|Catas Altas da Noruega;CATIGUA|SP|-21.0519|-49.0616|Catiguá;CATUJI|MG|-17.3018|-41.5276|Catuji;CATUTI|MG|-15.3616|-42.9627|Catuti;CAXAMBU|MG|-21.9753|-44.9319|Caxambu;CEDRAL|SP|-20.9009|-49.2664|Cedral;CEDRO DO ABAETE|MG|-19.1458|-45.7120|Cedro do Abaeté;CENTRAL DE MINAS|MG|-18.7612|-41.3143|Central de Minas;CENTRALINA|MG|-18.5852|-49.2014|Centralina;CERQUEIRA CESAR|SP|-23.0380|-49.1655|Cerqueira César;CERQUILHO|SP|-23.1665|-47.7459|Cerquilho;CESARIO LANGE|SP|-23.2260|-47.9545|Cesário Lange;CHACARA|MG|-21.6733|-43.2150|Chácara;CHALE|MG|-20.0453|-41.6897|Chalé;CHAPADA DO NORTE|MG|-17.0881|-42.5392|Chapada do Norte;CHAPADA GAUCHA|MG|-15.3014|-45.6116|Chapada Gaúcha;CHARQUEADA|SP|-22.5096|-47.7755|Charqueada;CHAVANTES|SP|-23.0366|-49.7096|Chavantes;CHIADOR|MG|-21.9996|-43.0617|Chiador;CIPOTANEA|MG|-20.9026|-43.3629|Cipotânea;CLARAVAL|MG|-20.3970|-47.2768|Claraval;CLARO DOS POCOES|MG|-17.0820|-44.2061|Claro dos Poções;CLAUDIO|MG|-20.4437|-44.7673|Cláudio;CLEMENTINA|SP|-21.5604|-50.4525|Clementina;COIMBRA|MG|-20.8535|-42.8008|Coimbra;COLATINA|ES|-19.5493|-40.6269|Colatina;COLINA|SP|-20.7114|-48.5387|Colina;COLOMBIA|SP|-20.1768|-48.6865|Colômbia;COLUNA|MG|-18.2311|-42.8352|Coluna;COMENDADOR GOMES|MG|-19.6973|-49.0789|Comendador Gomes;COMENDADOR LEVY GASPARIAN|RJ|-22.0404|-43.2140|Comendador Levy Gasparian;COMERCINHO|MG|-16.2963|-41.7945|Comercinho;CONCEICAO DA APARECIDA|MG|-21.0960|-46.2049|Conceição da Aparecida;CONCEICAO DA BARRA|ES|-18.5883|-39.7362|Conceição da Barra;CONCEICAO DA BARRA DE MINAS|MG|-21.1316|-44.4729|Conceição da Barra de Minas;CONCEICAO DAS ALAGOAS|MG|-19.9172|-48.3839|Conceição das Alagoas;CONCEICAO DAS PEDRAS|MG|-22.1576|-45.4562|Conceição das Pedras;CONCEICAO DE IPANEMA|MG|-19.9326|-41.6908|Conceição de Ipanema;CONCEICAO DE MACABU|RJ|-22.0834|-41.8719|Conceição de Macabu;CONCEICAO DO CASTELO|ES|-20.3639|-41.2417|Conceição do Castelo;CONCEICAO DO MATO DENTRO|MG|-19.0344|-43.4221|Conceição do Mato Dentro;CONCEICAO DO PARA|MG|-19.7456|-44.8945|Conceição do Pará;CONCEICAO DO RIO VERDE|MG|-21.8778|-45.0870|Conceição do Rio Verde;CONCEICAO DOS OUROS|MG|-22.4078|-45.7996|Conceição dos Ouros;CONCHAL|SP|-22.3375|-47.1729|Conchal;CONCHAS|SP|-23.0154|-48.0134|Conchas;CONEGO MARINHO|MG|-15.2892|-44.4181|Cônego Marinho;CONFINS|MG|-19.6282|-43.9931|Confins;CONGONHAL|MG|-22.1488|-46.0430|Congonhal;CONGONHAS|MG|-20.4958|-43.8510|Congonhas;CONGONHAS DO NORTE|MG|-18.8021|-43.6767|Congonhas do Norte;CONQUISTA|MG|-19.9312|-47.5492|Conquista;CONSELHEIRO LAFAIETE|MG|-20.6634|-43.7846|Conselheiro Lafaiete;CONSELHEIRO PENA|MG|-19.1789|-41.4736|Conselheiro Pena;CONSOLACAO|MG|-22.5493|-45.9255|Consolação;CONTAGEM|MG|-19.9321|-44.0539|Contagem;COQUEIRAL|MG|-21.1858|-45.4366|Coqueiral;CORACAO DE JESUS|MG|-16.6841|-44.3635|Coração de Jesus;CORDEIRO|RJ|-22.0267|-42.3648|Cordeiro;CORDEIROPOLIS|SP|-22.4778|-47.4519|Cordeirópolis;CORDISBURGO|MG|-19.1224|-44.3224|Cordisburgo;CORDISLANDIA|MG|-21.7891|-45.6999|Cordislândia;CORINTO|MG|-18.3690|-44.4542|Corinto;COROACI|MG|-18.6156|-42.2791|Coroaci;COROADOS|SP|-21.3521|-50.2859|Coroados;COROMANDEL|MG|-18.4734|-47.1933|Coromandel;CORONEL FABRICIANO|MG|-19.5179|-42.6276|Coronel Fabriciano;CORONEL MACEDO|SP|-23.6261|-49.3100|Coronel Macedo;CORONEL MURTA|MG|-16.6148|-42.1840|Coronel Murta;CORONEL PACHECO|MG|-21.5898|-43.2560|Coronel Pacheco;CORONEL XAVIER CHAVES|MG|-21.0277|-44.2206|Coronel Xavier Chaves;CORREGO DANTA|MG|-19.8198|-45.9032|Córrego Danta;CORREGO DO BOM JESUS|MG|-22.6269|-46.0241|Córrego do Bom Jesus;CORREGO FUNDO|MG|-20.4474|-45.5617|Córrego Fundo;CORREGO NOVO|MG|-19.8361|-42.3988|Córrego Novo;CORUMBATAI|SP|-22.2213|-47.6215|Corumbataí;COSMOPOLIS|SP|-22.6419|-47.1926|Cosmópolis;COSMORAMA|SP|-20.4755|-49.7827|Cosmorama;COTIA|SP|-23.6022|-46.9190|Cotia;COUTO DE MAGALHAES DE MINAS|MG|-18.0727|-43.4648|Couto de Magalhães de Minas;CRAVINHOS|SP|-21.3380|-47.7324|Cravinhos;CRISOLITA|MG|-17.2381|-40.9184|Crisólita;CRISTAIS|MG|-20.8733|-45.5167|Cristais;CRISTAIS PAULISTA|SP|-20.4036|-47.4209|Cristais Paulista;CRISTALIA|MG|-16.7160|-42.8571|Cristália;CRISTIANO OTONI|MG|-20.8324|-43.8166|Cristiano Otoni;CRISTINA|MG|-22.2080|-45.2673|Cristina;CRUCILANDIA|MG|-20.3923|-44.3334|Crucilândia;CRUZALIA|SP|-22.7373|-50.7909|Cruzália;CRUZEIRO|SP|-22.5728|-44.9690|Cruzeiro;CRUZEIRO DA FORTALEZA|MG|-18.9440|-46.6669|Cruzeiro da Fortaleza;CRUZILIA|MG|-21.8400|-44.8067|Cruzília;CUBATAO|SP|-23.8911|-46.4240|Cubatão;CUNHA|SP|-23.0731|-44.9576|Cunha;CUPARAQUE|MG|-18.9648|-41.0986|Cuparaque;CURRAL DE DENTRO|MG|-15.9327|-41.8557|Curral de Dentro;CURVELO|MG|-18.7527|-44.4303|Curvelo;DATAS|MG|-18.4478|-43.6591|Datas;DELFIM MOREIRA|MG|-22.5036|-45.2792|Delfim Moreira;DELFINOPOLIS|MG|-20.3468|-46.8456|Delfinópolis;DELTA|MG|-19.9721|-47.7841|Delta;DESCALVADO|SP|-21.9002|-47.6181|Descalvado;DESCOBERTO|MG|-21.4600|-42.9618|Descoberto;DESTERRO DE ENTRE RIOS|MG|-20.6650|-44.3334|Desterro de Entre Rios;DESTERRO DO MELO|MG|-21.1430|-43.5178|Desterro do Melo;DIADEMA|SP|-23.6813|-46.6205|Diadema;DIAMANTINA|MG|-18.2413|-43.6031|Diamantina;DIOGO DE VASCONCELOS|MG|-20.4879|-43.1953|Diogo de Vasconcelos;DIONISIO|MG|-19.8433|-42.7701|Dionísio;DIRCE REIS|SP|-20.4642|-50.6073|Dirce Reis;DIVINESIA|MG|-20.9917|-43.0003|Divinésia;DIVINO|MG|-20.6134|-42.1438|Divino;DIVINO DAS LARANJEIRAS|MG|-18.7755|-41.4781|Divino das Laranjeiras;DIVINO DE SAO LOURENCO|ES|-20.6229|-41.6937|Divino de São Lourenço;DIVINOLANDIA|SP|-21.6637|-46.7361|Divinolândia;DIVINOLANDIA DE MINAS|MG|-18.8004|-42.6103|Divinolândia de Minas;DIVINOPOLIS|MG|-20.1446|-44.8912|Divinópolis;DIVISA ALEGRE|MG|-15.7221|-41.3463|Divisa Alegre;DIVISA NOVA|MG|-21.5092|-46.1904|Divisa Nova;DIVISOPOLIS|MG|-15.7254|-40.9997|Divisópolis;DOBRADA|SP|-21.5155|-48.3935|Dobrada;DOIS CORREGOS|SP|-22.3673|-48.3819|Dois Córregos;DOLCINOPOLIS|SP|-20.1240|-50.5149|Dolcinópolis;DOM BOSCO|MG|-16.6520|-46.2597|Dom Bosco;DOM CAVATI|MG|-19.3735|-42.1121|Dom Cavati;DOM JOAQUIM|MG|-18.9610|-43.2544|Dom Joaquim;DOM SILVERIO|MG|-20.1627|-42.9627|Dom Silvério;DOM VICOSO|MG|-22.2511|-45.1643|Dom Viçoso;DOMINGOS MARTINS|ES|-20.3603|-40.6594|Domingos Martins;DONA EUSEBIA|MG|-21.3190|-42.8070|Dona Eusébia;DORES DE CAMPOS|MG|-21.1139|-44.0207|Dores de Campos;DORES DE GUANHAES|MG|-19.0516|-42.9254|Dores de Guanhães;DORES DO INDAIA|MG|-19.4628|-45.5927|Dores do Indaiá;DORES DO RIO PRETO|ES|-20.6931|-41.8405|Dores do Rio Preto;DORES DO TURVO|MG|-20.9785|-43.1834|Dores do Turvo;DORESOPOLIS|MG|-20.2868|-45.9007|Doresópolis;DOURADO|SP|-22.1044|-48.3178|Dourado;DOURADOQUARA|MG|-18.4338|-47.5993|Douradoquara;DRACENA|SP|-21.4843|-51.5350|Dracena;DUARTINA|SP|-22.4146|-49.4084|Duartina;DUAS BARRAS|RJ|-22.0536|-42.5232|Duas Barras;DUMONT|SP|-21.2324|-47.9756|Dumont;DUQUE DE CAXIAS|RJ|-22.7858|-43.3049|Duque de Caxias;DURANDE|MG|-20.2058|-41.7977|Durandé;ECHAPORA|SP|-22.4326|-50.2038|Echaporã;ECOPORANGA|ES|-18.3702|-40.8360|Ecoporanga;ELDORADO|SP|-24.5281|-48.1141|Eldorado;ELIAS FAUSTO|SP|-23.0428|-47.3682|Elias Fausto;ELISIARIO|SP|-21.1678|-49.1146|Elisiário;ELOI MENDES|MG|-21.6088|-45.5691|Elói Mendes;EMBAUBA|SP|-20.9796|-48.8325|Embaúba;EMBU DAS ARTES|SP|-23.6437|-46.8579|Embu das Artes;EMBU-GUACU|SP|-23.8297|-46.8136|Embu-Guaçu;EMILIANOPOLIS|SP|-21.8314|-51.4832|Emilianópolis;ENGENHEIRO CALDAS|MG|-19.2065|-42.0503|Engenheiro Caldas;ENGENHEIRO COELHO|SP|-22.4836|-47.2110|Engenheiro Coelho;ENGENHEIRO NAVARRO|MG|-17.2831|-43.9470|Engenheiro Navarro;ENGENHEIRO PAULO DE FRONTIN|RJ|-22.5498|-43.6827|Engenheiro Paulo de Frontin;ENTRE FOLHAS|MG|-19.6218|-42.2306|Entre Folhas;ENTRE RIOS DE MINAS|MG|-20.6706|-44.0654|Entre Rios de Minas;ERVALIA|MG|-20.8403|-42.6544|Ervália;ESMERALDAS|MG|-19.7640|-44.3065|Esmeraldas;ESPERA FELIZ|MG|-20.6508|-41.9119|Espera Feliz;ESPINOSA|MG|-14.9249|-42.8090|Espinosa;ESPIRITO SANTO DO DOURADO|MG|-22.0454|-45.9548|Espírito Santo do Dourado;ESPIRITO SANTO DO PINHAL|SP|-22.1909|-46.7477|Espírito Santo do Pinhal;ESPIRITO SANTO DO TURVO|SP|-22.6925|-49.4341|Espírito Santo do Turvo;ESTIVA|MG|-22.4577|-46.0191|Estiva;ESTIVA GERBI|SP|-22.2713|-46.9481|Estiva Gerbi;ESTRELA D'OESTE|SP|-20.2875|-50.4049|Estrela d'Oeste;ESTRELA DALVA|MG|-21.7412|-42.4574|Estrela Dalva;ESTRELA DO INDAIA|MG|-19.5169|-45.7859|Estrela do Indaiá;ESTRELA DO NORTE|SP|-22.4859|-51.6632|Estrela do Norte;ESTRELA DO SUL|MG|-18.7399|-47.6956|Estrela do Sul;EUCLIDES DA CUNHA PAULISTA|SP|-22.5545|-52.5928|Euclides da Cunha Paulista;EUGENOPOLIS|MG|-21.1002|-42.1878|Eugenópolis;EWBANK DA CAMARA|MG|-21.5498|-43.5068|Ewbank da Câmara;EXTREMA|MG|-22.8540|-46.3178|Extrema;FAMA|MG|-21.4089|-45.8286|Fama;FARIA LEMOS|MG|-20.8097|-42.0213|Faria Lemos;FARTURA|SP|-23.3916|-49.5124|Fartura;FELICIO DOS SANTOS|MG|-18.0755|-43.2422|Felício dos Santos;FELISBURGO|MG|-16.6348|-40.7605|Felisburgo;FELIXLANDIA|MG|-18.7507|-44.9004|Felixlândia;FERNANDES TOURINHO|MG|-19.1541|-42.0803|Fernandes Tourinho;FERNANDO PRESTES|SP|-21.2661|-48.6874|Fernando Prestes;FERNANDOPOLIS|SP|-20.2806|-50.2471|Fernandópolis;FERNAO|SP|-22.3607|-49.5187|Fernão;FERRAZ DE VASCONCELOS|SP|-23.5411|-46.3710|Ferraz de Vasconcelos;FERROS|MG|-19.2343|-43.0192|Ferros;FERVEDOURO|MG|-20.7260|-42.2790|Fervedouro;FLORA RICA|SP|-21.6727|-51.3821|Flora Rica;FLOREAL|SP|-20.6752|-50.1513|Floreal;FLORESTAL|MG|-19.8880|-44.4318|Florestal;FLORIDA PAULISTA|SP|-21.6127|-51.1724|Flórida Paulista;FLORINIA|SP|-22.8680|-50.6814|Florínia;FORMIGA|MG|-20.4618|-45.4268|Formiga;FORMOSO|MG|-14.9446|-46.2371|Formoso;FORTALEZA DE MINAS|MG|-20.8508|-46.7120|Fortaleza de Minas;FORTUNA DE MINAS|MG|-19.5578|-44.4472|Fortuna de Minas;FRANCA|SP|-20.5352|-47.4039|Franca;FRANCISCO BADARO|MG|-16.9883|-42.3568|Francisco Badaró;FRANCISCO DUMONT|MG|-17.3107|-44.2317|Francisco Dumont;FRANCISCO MORATO|SP|-23.2792|-46.7448|Francisco Morato;FRANCISCO SA|MG|-16.4827|-43.4896|Francisco Sá;FRANCISCOPOLIS|MG|-17.9578|-42.0094|Franciscópolis;FRANCO DA ROCHA|SP|-23.3229|-46.7290|Franco da Rocha;FREI GASPAR|MG|-18.0709|-41.4325|Frei Gaspar;FREI INOCENCIO|MG|-18.5556|-41.9121|Frei Inocêncio;FREI LAGONEGRO|MG|-18.1751|-42.7617|Frei Lagonegro;FRONTEIRA|MG|-20.2748|-49.1984|Fronteira;FRONTEIRA DOS VALES|MG|-16.8898|-40.9230|Fronteira dos Vales;FRUTA DE LEITE|MG|-16.1225|-42.5288|Fruta de Leite;FRUTAL|MG|-20.0259|-48.9355|Frutal;FUNDAO|ES|-19.9370|-40.4078|Fundão;FUNILANDIA|MG|-19.3661|-44.0610|Funilândia;GABRIEL MONTEIRO|SP|-21.5294|-50.5573|Gabriel Monteiro;GALIA|SP|-22.2918|-49.5504|Gália;GALILEIA|MG|-19.0005|-41.5387|Galiléia;GAMELEIRAS|MG|-15.0829|-43.1250|Gameleiras;GARCA|SP|-22.2125|-49.6546|Garça;GASTAO VIDIGAL|SP|-20.7948|-50.1912|Gastão Vidigal;GAVIAO PEIXOTO|SP|-21.8367|-48.4957|Gavião Peixoto;GENERAL SALGADO|SP|-20.6485|-50.3640|General Salgado;GETULINA|SP|-21.7961|-49.9312|Getulina;GLAUCILANDIA|MG|-16.8481|-43.6920|Glaucilândia;GLICERIO|SP|-21.3812|-50.2123|Glicério;GOIABEIRA|MG|-18.9807|-41.2235|Goiabeira;GOIANA|MG|-21.5360|-43.1957|Goianá;GONCALVES|MG|-22.6545|-45.8556|Gonçalves;GONZAGA|MG|-18.8196|-42.4769|Gonzaga;GOUVEIA|MG|-18.4519|-43.7423|Gouveia;GOVERNADOR LINDENBERG|ES|-19.1864|-40.4473|Governador Lindenberg;GOVERNADOR VALADARES|MG|-18.8545|-41.9555|Governador Valadares;GRAO MOGOL|MG|-16.5662|-42.8923|Grão Mogol;GRUPIARA|MG|-18.5003|-47.7318|Grupiara;GUACUI|ES|-20.7668|-41.6734|Guaçuí;GUAICARA|SP|-21.6195|-49.8013|Guaiçara;GUAIMBE|SP|-21.9091|-49.8986|Guaimbê;GUAIRA|SP|-20.3196|-48.3120|Guaíra;GUANHAES|MG|-18.7713|-42.9312|Guanhães;GUAPE|MG|-20.7631|-45.9152|Guapé;GUAPIACU|SP|-20.7959|-49.2172|Guapiaçu;GUAPIARA|SP|-24.1892|-48.5295|Guapiara;GUAPIMIRIM|RJ|-22.5347|-42.9895|Guapimirim;GUARA|SP|-20.4302|-47.8236|Guará;GUARACAI|SP|-21.0292|-51.2119|Guaraçaí;GUARACI|SP|-20.4977|-48.9391|Guaraci;GUARACIABA|MG|-20.5716|-43.0094|Guaraciaba;GUARACIAMA|MG|-17.0142|-43.6675|Guaraciama;GUARANESIA|MG|-21.3009|-46.7964|Guaranésia;GUARANI|MG|-21.3563|-43.0328|Guarani;GUARANI D'OESTE|SP|-20.0746|-50.3411|Guarani d'Oeste;GUARANTA|SP|-21.8942|-49.5914|Guarantã;GUARAPARI|ES|-20.6772|-40.5093|Guarapari;GUARARA|MG|-21.7304|-43.0334|Guarará;GUARARAPES|SP|-21.2544|-50.6453|Guararapes;GUARAREMA|SP|-23.4112|-46.0369|Guararema;GUARATINGUETA|SP|-22.8075|-45.1938|Guaratinguetá;GUARDA-MOR|MG|-17.7673|-47.0998|Guarda-Mor;GUAREI|SP|-23.3714|-48.1837|Guareí;GUARIBA|SP|-21.3594|-48.2316|Guariba;GUARUJA|SP|-23.9888|-46.2580|Guarujá;GUARULHOS|SP|-23.4538|-46.5333|Guarulhos;GUATAPARA|SP|-21.4944|-48.0356|Guatapará;GUAXUPE|MG|-21.3050|-46.7081|Guaxupé;GUIDOVAL|MG|-21.1550|-42.7887|Guidoval;GUIMARANIA|MG|-18.8425|-46.7901|Guimarânia;GUIRICEMA|MG|-21.0098|-42.7207|Guiricema;GURINHATA|MG|-19.2143|-49.7876|Gurinhatã;GUZOLANDIA|SP|-20.6467|-50.6645|Guzolândia;HELIODORA|MG|-22.0644|-45.5453|Heliodora;HERCULANDIA|SP|-22.0038|-50.3907|Herculândia;HOLAMBRA|SP|-22.6405|-47.0487|Holambra;HORTOLANDIA|SP|-22.8529|-47.2143|Hortolândia;IACANGA|SP|-21.8896|-49.0310|Iacanga;IACRI|SP|-21.8572|-50.6932|Iacri;IAPU|MG|-19.4387|-42.2147|Iapu;IARAS|SP|-22.8682|-49.1634|Iaras;IBATE|SP|-21.9584|-47.9882|Ibaté;IBATIBA|ES|-20.2347|-41.5087|Ibatiba;IBERTIOGA|MG|-21.4330|-43.9639|Ibertioga;IBIA|MG|-19.4749|-46.5474|Ibiá;IBIAI|MG|-16.8591|-44.9046|Ibiaí;IBIRA|SP|-21.0830|-49.2448|Ibirá;IBIRACATU|MG|-15.6605|-44.1667|Ibiracatu;IBIRACI|MG|-20.4611|-47.1222|Ibiraci;IBIRACU|ES|-19.8366|-40.3732|Ibiraçu;IBIRAREMA|SP|-22.8185|-50.0739|Ibirarema;IBIRITE|MG|-20.0252|-44.0569|Ibirité;IBITINGA|SP|-21.7562|-48.8319|Ibitinga;IBITIRAMA|ES|-20.5466|-41.6667|Ibitirama;IBITIURA DE MINAS|MG|-22.0604|-46.4368|Ibitiúra de Minas;IBITURUNA|MG|-21.1541|-44.7479|Ibituruna;IBIUNA|SP|-23.6596|-47.2230|Ibiúna;ICARAI DE MINAS|MG|-16.2140|-44.9034|Icaraí de Minas;ICEM|SP|-20.3391|-49.1915|Icém;ICONHA|ES|-20.7913|-40.8132|Iconha;IEPE|SP|-22.6602|-51.0779|Iepê;IGARACU DO TIETE|SP|-22.5090|-48.5597|Igaraçu do Tietê;IGARAPAVA|SP|-20.0407|-47.7466|Igarapava;IGARAPE|MG|-20.0707|-44.2994|Igarapé;IGARATA|SP|-23.2037|-46.1570|Igaratá;IGARATINGA|MG|-19.9476|-44.7063|Igaratinga;IGUABA GRANDE|RJ|-22.8495|-42.2299|Iguaba Grande;IGUAPE|SP|-24.6990|-47.5537|Iguape;IGUATAMA|MG|-20.1776|-45.7111|Iguatama;IJACI|MG|-21.1738|-44.9233|Ijaci;ILHA COMPRIDA|SP|-24.7307|-47.5383|Ilha Comprida;ILHA SOLTEIRA|SP|-20.4326|-51.3426|Ilha Solteira;ILHABELA|SP|-23.7785|-45.3552|Ilhabela;ILICINEA|MG|-20.9402|-45.8308|Ilicínea;IMBE DE MINAS|MG|-19.6017|-41.9695|Imbé de Minas;INCONFIDENTES|MG|-22.3136|-46.3264|Inconfidentes;INDAIABIRA|MG|-15.4911|-42.2005|Indaiabira;INDAIATUBA|SP|-23.0816|-47.2101|Indaiatuba;INDIANA|SP|-22.1738|-51.2555|Indiana;INDIANOPOLIS|MG|-19.0341|-47.9155|Indianópolis;INDIAPORA|SP|-19.9790|-50.2909|Indiaporã;INGAI|MG|-21.4024|-44.9152|Ingaí;INHAPIM|MG|-19.5476|-42.1147|Inhapim;INHAUMA|MG|-19.4898|-44.3934|Inhaúma;INIMUTABA|MG|-18.7271|-44.3584|Inimutaba;INUBIA PAULISTA|SP|-21.7695|-50.9633|Inúbia Paulista;IPABA|MG|-19.4158|-42.4139|Ipaba;IPANEMA|MG|-19.7992|-41.7164|Ipanema;IPATINGA|MG|-19.4703|-42.5476|Ipatinga;IPAUSSU|SP|-23.0575|-49.6279|Ipaussu;IPERO|SP|-23.3513|-47.6927|Iperó;IPEUNA|SP|-22.4355|-47.7151|Ipeúna;IPIACU|MG|-18.6927|-49.9436|Ipiaçu;IPIGUA|SP|-20.6557|-49.3842|Ipiguá;IPORANGA|SP|-24.5847|-48.5971|Iporanga;IPUA|SP|-20.4438|-48.0129|Ipuã;IPUIUNA|MG|-22.1013|-46.1915|Ipuiúna;IRACEMAPOLIS|SP|-22.5832|-47.5230|Iracemápolis;IRAI DE MINAS|MG|-18.9819|-47.4610|Iraí de Minas;IRAPUA|SP|-21.2768|-49.4164|Irapuã;IRAPURU|SP|-21.5684|-51.3472|Irapuru;IRUPI|ES|-20.3501|-41.6444|Irupi;ITABERA|SP|-23.8638|-49.1400|Itaberá;ITABIRA|MG|-19.6239|-43.2312|Itabira;ITABIRINHA|MG|-18.5712|-41.2340|Itabirinha;ITABIRITO|MG|-20.2501|-43.8038|Itabirito;ITABORAI|RJ|-22.7565|-42.8639|Itaboraí;ITACAMBIRA|MG|-17.0625|-43.3069|Itacambira;ITACARAMBI|MG|-15.0890|-44.0950|Itacarambi;ITAGUACU|ES|-19.8018|-40.8601|Itaguaçu;ITAGUAI|RJ|-22.8636|-43.7798|Itaguaí;ITAGUARA|MG|-20.3947|-44.4875|Itaguara;ITAI|SP|-23.4213|-49.0920|Itaí;ITAIPE|MG|-17.4014|-41.6697|Itaipé;ITAJOBI|SP|-21.3123|-49.0629|Itajobi;ITAJU|SP|-21.9857|-48.8116|Itaju;ITAJUBA|MG|-22.4225|-45.4598|Itajubá;ITALVA|RJ|-21.4296|-41.7014|Italva;ITAMARANDIBA|MG|-17.8552|-42.8561|Itamarandiba;ITAMARATI DE MINAS|MG|-21.4179|-42.8130|Itamarati de Minas;ITAMBACURI|MG|-18.0350|-41.6830|Itambacuri;ITAMBE DO MATO DENTRO|MG|-19.4158|-43.3182|Itambé do Mato Dentro;ITAMOGI|MG|-21.0758|-47.0460|Itamogi;ITAMONTE|MG|-22.2859|-44.8680|Itamonte;ITANHAEM|SP|-24.1736|-46.7880|Itanhaém;ITANHANDU|MG|-22.2942|-44.9382|Itanhandu;ITANHOMI|MG|-19.1736|-41.8630|Itanhomi;ITAOBIM|MG|-16.5571|-41.5017|Itaobim;ITAOCA|SP|-24.6393|-48.8413|Itaóca;ITAOCARA|RJ|-21.6748|-42.0758|Itaocara;ITAPAGIPE|MG|-19.9062|-49.3781|Itapagipe;ITAPECERICA|MG|-20.4704|-45.1270|Itapecerica;ITAPECERICA DA SERRA|SP|-23.7161|-46.8572|Itapecerica da Serra;ITAPEMIRIM|ES|-21.0095|-40.8307|Itapemirim;ITAPERUNA|RJ|-21.1997|-41.8799|Itaperuna;ITAPETININGA|SP|-23.5886|-48.0483|Itapetininga;ITAPEVA|SP|-23.9788|-48.8764|Itapeva;ITAPEVA|MG|-22.7665|-46.2241|Itapeva;ITAPEVI|SP|-23.5488|-46.9327|Itapevi;ITAPIRA|SP|-22.4357|-46.8224|Itapira;ITAPIRAPUA PAULISTA|SP|-24.5720|-49.1661|Itapirapuã Paulista;ITAPOLIS|SP|-21.5942|-48.8149|Itápolis;ITAPORANGA|SP|-23.7043|-49.4819|Itaporanga;ITAPUI|SP|-22.2324|-48.7197|Itapuí;ITAPURA|SP|-20.6419|-51.5063|Itapura;ITAQUAQUECETUBA|SP|-23.4835|-46.3457|Itaquaquecetuba;ITARANA|ES|-19.8750|-40.8753|Itarana;ITARARE|SP|-24.1085|-49.3352|Itararé;ITARIRI|SP|-24.2834|-47.1736|Itariri;ITATIAIA|RJ|-22.4897|-44.5675|Itatiaia;ITATIAIUCU|MG|-20.1983|-44.4211|Itatiaiuçu;ITATIBA|SP|-23.0035|-46.8464|Itatiba;ITATINGA|SP|-23.1047|-48.6157|Itatinga;ITAU DE MINAS|MG|-20.7375|-46.7525|Itaú de Minas;ITAUNA|MG|-20.0818|-44.5801|Itaúna;ITAVERAVA|MG|-20.6769|-43.6141|Itaverava;ITINGA|MG|-16.6100|-41.7672|Itinga;ITIRAPINA|SP|-22.2562|-47.8166|Itirapina;ITIRAPUA|SP|-20.6416|-47.2194|Itirapuã;ITOBI|SP|-21.7309|-46.9743|Itobi;ITU|SP|-23.2544|-47.2927|Itu;ITUETA|MG|-19.3999|-41.1746|Itueta;ITUIUTABA|MG|-18.9772|-49.4639|Ituiutaba;ITUMIRIM|MG|-21.3171|-44.8724|Itumirim;ITUPEVA|SP|-23.1526|-47.0593|Itupeva;ITURAMA|MG|-19.7276|-50.1966|Iturama;ITUTINGA|MG|-21.3000|-44.6567|Itutinga;ITUVERAVA|SP|-20.3355|-47.7902|Ituverava;IUNA|ES|-20.3531|-41.5334|Iúna;JABORANDI|SP|-20.6884|-48.4112|Jaborandi;JABOTICABAL|SP|-21.2520|-48.3252|Jaboticabal;JABOTICATUBAS|MG|-19.5119|-43.7373|Jaboticatubas;JACAREI|SP|-23.2983|-45.9658|Jacareí;JACI|SP|-20.8805|-49.5797|Jaci;JACINTO|MG|-16.1428|-40.2950|Jacinto;JACUI|MG|-21.0137|-46.7359|Jacuí;JACUPIRANGA|SP|-24.6963|-48.0064|Jacupiranga;JACUTINGA|MG|-22.2860|-46.6166|Jacutinga;JAGUARACU|MG|-19.6470|-42.7498|Jaguaraçu;JAGUARE|ES|-18.9070|-40.0759|Jaguaré;JAGUARIUNA|SP|-22.7037|-46.9851|Jaguariúna;JAIBA|MG|-15.3432|-43.6688|Jaíba;JALES|SP|-20.2672|-50.5494|Jales;JAMBEIRO|SP|-23.2522|-45.6942|Jambeiro;JAMPRUCA|MG|-18.4610|-41.8090|Jampruca;JANAUBA|MG|-15.8022|-43.3132|Janaúba;JANDIRA|SP|-23.5275|-46.9023|Jandira;JANUARIA|MG|-15.4802|-44.3639|Januária;JAPARAIBA|MG|-20.1442|-45.5015|Japaraíba;JAPERI|RJ|-22.6435|-43.6602|Japeri;JAPONVAR|MG|-15.9891|-44.2758|Japonvar;JARDINOPOLIS|SP|-21.0176|-47.7606|Jardinópolis;JARINU|SP|-23.1039|-46.7280|Jarinu;JAU|SP|-22.2936|-48.5592|Jaú;JECEABA|MG|-20.5339|-43.9894|Jeceaba;JENIPAPO DE MINAS|MG|-17.0831|-42.2589|Jenipapo de Minas;JEQUERI|MG|-20.4542|-42.6651|Jequeri;JEQUITAI|MG|-17.2290|-44.4376|Jequitaí;JEQUITIBA|MG|-19.2345|-44.0304|Jequitibá;JEQUITINHONHA|MG|-16.4375|-41.0117|Jequitinhonha;JERIQUARA|SP|-20.3116|-47.5918|Jeriquara;JERONIMO MONTEIRO|ES|-20.7994|-41.3948|Jerônimo Monteiro;JESUANIA|MG|-21.9887|-45.2911|Jesuânia;JOAIMA|MG|-16.6522|-41.0229|Joaíma;JOANESIA|MG|-19.1729|-42.6775|Joanésia;JOANOPOLIS|SP|-22.9270|-46.2741|Joanópolis;JOAO MONLEVADE|MG|-19.8126|-43.1735|João Monlevade;JOAO NEIVA|ES|-19.7577|-40.3860|João Neiva;JOAO PINHEIRO|MG|-17.7398|-46.1715|João Pinheiro;JOAO RAMALHO|SP|-22.2473|-50.7694|João Ramalho;JOAQUIM FELICIO|MG|-17.7580|-44.1643|Joaquim Felício;JORDANIA|MG|-15.9009|-40.1841|Jordânia;JOSE BONIFACIO|SP|-21.0551|-49.6892|José Bonifácio;JOSE GONCALVES DE MINAS|MG|-16.9053|-42.6014|José Gonçalves de Minas;JOSE RAYDAN|MG|-18.2195|-42.4946|José Raydan;JOSENOPOLIS|MG|-16.5417|-42.5151|Josenópolis;JUATUBA|MG|-19.9448|-44.3451|Juatuba;JUIZ DE FORA|MG|-21.7595|-43.3398|Juiz de Fora;JULIO MESQUITA|SP|-22.0112|-49.7873|Júlio Mesquita;JUMIRIM|SP|-23.0884|-47.7868|Jumirim;JUNDIAI|SP|-23.1852|-46.8974|Jundiaí;JUNQUEIROPOLIS|SP|-21.5103|-51.4342|Junqueirópolis;JUQUIA|SP|-24.3101|-47.6426|Juquiá;JUQUITIBA|SP|-23.9244|-47.0653|Juquitiba;JURAMENTO|MG|-16.8473|-43.5865|Juramento;JURUAIA|MG|-21.2493|-46.5735|Juruaia;JUVENILIA|MG|-14.2662|-44.1597|Juvenília;LADAINHA|MG|-17.6279|-41.7488|Ladainha;LAGAMAR|MG|-18.1759|-46.8063|Lagamar;LAGOA DA PRATA|MG|-20.0237|-45.5401|Lagoa da Prata;LAGOA DOS PATOS|MG|-16.9780|-44.5754|Lagoa dos Patos;LAGOA DOURADA|MG|-20.9139|-44.0797|Lagoa Dourada;LAGOA FORMOSA|MG|-18.7715|-46.4012|Lagoa Formosa;LAGOA GRANDE|MG|-17.8323|-46.5165|Lagoa Grande;LAGOA SANTA|MG|-19.6397|-43.8932|Lagoa Santa;LAGOINHA|SP|-23.0846|-45.1944|Lagoinha;LAJE DO MURIAE|RJ|-21.2091|-42.1271|Laje do Muriaé;LAJINHA|MG|-20.1539|-41.6228|Lajinha;LAMBARI|MG|-21.9671|-45.3498|Lambari;LAMIM|MG|-20.7900|-43.4706|Lamim;LARANJA DA TERRA|ES|-19.8994|-41.0621|Laranja da Terra;LARANJAL|MG|-21.3715|-42.4732|Laranjal;LARANJAL PAULISTA|SP|-23.0506|-47.8375|Laranjal Paulista;LASSANCE|MG|-17.8870|-44.5735|Lassance;LAVINIA|SP|-21.1639|-51.0412|Lavínia;LAVRAS|MG|-21.2480|-45.0009|Lavras;LAVRINHAS|SP|-22.5700|-44.9024|Lavrinhas;LEANDRO FERREIRA|MG|-19.7193|-45.0279|Leandro Ferreira;LEME|SP|-22.1809|-47.3841|Leme;LEME DO PRADO|MG|-17.0793|-42.6936|Leme do Prado;LENCOIS PAULISTA|SP|-22.6027|-48.8037|Lençóis Paulista;LEOPOLDINA|MG|-21.5296|-42.6421|Leopoldina;LIBERDADE|MG|-22.0275|-44.3208|Liberdade;LIMA DUARTE|MG|-21.8386|-43.7934|Lima Duarte;LIMEIRA|SP|-22.5660|-47.3970|Limeira;LIMEIRA DO OESTE|MG|-19.5512|-50.5815|Limeira do Oeste;LINDOIA|SP|-22.5226|-46.6500|Lindóia;LINHARES|ES|-19.3946|-40.0643|Linhares;LINS|SP|-21.6718|-49.7526|Lins;LONTRA|MG|-15.9013|-44.3060|Lontra;LORENA|SP|-22.7334|-45.1197|Lorena;LOURDES|SP|-20.9660|-50.2263|Lourdes;LOUVEIRA|SP|-23.0856|-46.9484|Louveira;LUCELIA|SP|-21.7182|-51.0215|Lucélia;LUCIANOPOLIS|SP|-22.4294|-49.5220|Lucianópolis;LUIS ANTONIO|SP|-21.5500|-47.7801|Luís Antônio;LUISBURGO|MG|-20.4468|-42.0976|Luisburgo;LUISLANDIA|MG|-16.1095|-44.5886|Luislândia;LUIZIANIA|SP|-21.6737|-50.3294|Luiziânia;LUMINARIAS|MG|-21.5145|-44.9034|Luminárias;LUPERCIO|SP|-22.4146|-49.8180|Lupércio;LUTECIA|SP|-22.3384|-50.3940|Lutécia;LUZ|MG|-19.7911|-45.6794|Luz;MACAE|RJ|-22.3768|-41.7848|Macaé;MACATUBA|SP|-22.5002|-48.7102|Macatuba;MACAUBAL|SP|-20.8022|-49.9687|Macaubal;MACEDONIA|SP|-20.1444|-50.1973|Macedônia;MACHACALIS|MG|-17.0723|-40.7245|Machacalis;MACHADO|MG|-21.6778|-45.9219|Machado;MACUCO|RJ|-21.9813|-42.2533|Macuco;MADRE DE DEUS DE MINAS|MG|-21.4830|-44.3287|Madre de Deus de Minas;MAGDA|SP|-20.6445|-50.2305|Magda;MAGE|RJ|-22.6632|-43.0315|Magé;MAIRINQUE|SP|-23.5398|-47.1850|Mairinque;MAIRIPORA|SP|-23.3171|-46.5897|Mairiporã;MALACACHETA|MG|-17.8456|-42.0769|Malacacheta;MAMONAS|MG|-15.0479|-42.9469|Mamonas;MANDURI|SP|-23.0056|-49.3202|Manduri;MANGA|MG|-14.7529|-43.9391|Manga;MANGARATIBA|RJ|-22.9594|-44.0409|Mangaratiba;MANHUACU|MG|-20.2572|-42.0280|Manhuaçu;MANHUMIRIM|MG|-20.3591|-41.9589|Manhumirim;MANTENA|MG|-18.7761|-40.9874|Mantena;MANTENOPOLIS|ES|-18.8594|-41.1240|Mantenópolis;MAR DE ESPANHA|MG|-21.8707|-43.0062|Mar de Espanha;MARABA PAULISTA|SP|-22.1068|-51.9617|Marabá Paulista;MARACAI|SP|-22.6149|-50.6713|Maracaí;MARAPOAMA|SP|-21.2587|-49.1300|Marapoama;MARATAIZES|ES|-21.0398|-40.8384|Marataízes;MARAVILHAS|MG|-19.5076|-44.6779|Maravilhas;MARECHAL FLORIANO|ES|-20.4159|-40.6700|Marechal Floriano;MARIA DA FE|MG|-22.3044|-45.3773|Maria da Fé;MARIANA|MG|-20.3765|-43.4140|Mariana;MARIAPOLIS|SP|-21.7959|-51.1824|Mariápolis;MARICA|RJ|-22.9354|-42.8246|Maricá;MARILAC|MG|-18.5079|-42.0822|Marilac;MARILANDIA|ES|-19.4114|-40.5456|Marilândia;MARILIA|SP|-22.2171|-49.9501|Marília;MARINOPOLIS|SP|-20.4389|-50.8254|Marinópolis;MARIO CAMPOS|MG|-20.0582|-44.1883|Mário Campos;MARIPA DE MINAS|MG|-21.6979|-42.9546|Maripá de Minas;MARLIERIA|MG|-19.7096|-42.7327|Marliéria;MARMELOPOLIS|MG|-22.4470|-45.1645|Marmelópolis;MARTINHO CAMPOS|MG|-19.3306|-45.2434|Martinho Campos;MARTINOPOLIS|SP|-22.1462|-51.1709|Martinópolis;MARTINS SOARES|MG|-20.2546|-41.8786|Martins Soares;MATA VERDE|MG|-15.6869|-40.7366|Mata Verde;MATAO|SP|-21.6025|-48.3640|Matão;MATERLANDIA|MG|-18.4699|-43.0579|Materlândia;MATEUS LEME|MG|-19.9794|-44.4318|Mateus Leme;MATHIAS LOBATO|MG|-18.5900|-41.9166|Mathias Lobato;MATIAS BARBOSA|MG|-21.8690|-43.3135|Matias Barbosa;MATIAS CARDOSO|MG|-14.8563|-43.9146|Matias Cardoso;MATIPO|MG|-20.2873|-42.3401|Matipó;MATO VERDE|MG|-15.3944|-42.8600|Mato Verde;MATOZINHOS|MG|-19.5543|-44.0868|Matozinhos;MATUTINA|MG|-19.2179|-45.9664|Matutina;MAUA|SP|-23.6677|-46.4613|Mauá;MEDEIROS|MG|-19.9865|-46.2181|Medeiros;MEDINA|MG|-16.2245|-41.4728|Medina;MENDES|RJ|-22.5245|-43.7312|Mendes;MENDES PIMENTEL|MG|-18.6631|-41.4052|Mendes Pimentel;MENDONCA|SP|-21.1757|-49.5791|Mendonça;MERCES|MG|-21.1976|-43.3337|Mercês;MERIDIANO|SP|-20.3579|-50.1811|Meridiano;MESOPOLIS|SP|-19.9684|-50.6326|Mesópolis;MESQUITA|RJ|-22.8028|-43.4601|Mesquita;MESQUITA|MG|-19.2240|-42.6079|Mesquita;MIGUEL PEREIRA|RJ|-22.4572|-43.4803|Miguel Pereira;MIGUELOPOLIS|SP|-20.1796|-48.0310|Miguelópolis;MIMOSO DO SUL|ES|-21.0628|-41.3615|Mimoso do Sul;MINAS NOVAS|MG|-17.2156|-42.5884|Minas Novas;MINDURI|MG|-21.6797|-44.6051|Minduri;MINEIROS DO TIETE|SP|-22.4120|-48.4510|Mineiros do Tietê;MIRA ESTRELA|SP|-19.9789|-50.1390|Mira Estrela;MIRABELA|MG|-16.2560|-44.1602|Mirabela;MIRACATU|SP|-24.2766|-47.4625|Miracatu;MIRACEMA|RJ|-21.4148|-42.1938|Miracema;MIRADOURO|MG|-20.8899|-42.3458|Miradouro;MIRAI|MG|-21.2021|-42.6122|Miraí;MIRANDOPOLIS|SP|-21.1313|-51.1035|Mirandópolis;MIRANTE DO PARANAPANEMA|SP|-22.2904|-51.9084|Mirante do Paranapanema;MIRASSOL|SP|-20.8169|-49.5206|Mirassol;MIRASSOLANDIA|SP|-20.6179|-49.4617|Mirassolândia;MIRAVANIA|MG|-14.7348|-44.4092|Miravânia;MOCOCA|SP|-21.4647|-47.0024|Mococa;MOEDA|MG|-20.3399|-44.0509|Moeda;MOEMA|MG|-19.8387|-45.4127|Moema;MOGI DAS CRUZES|SP|-23.5208|-46.1854|Mogi das Cruzes;MOGI GUACU|SP|-22.3675|-46.9428|Mogi Guaçu;MOGI MIRIM|SP|-22.4332|-46.9532|Mogi Mirim;MOMBUCA|SP|-22.9285|-47.5590|Mombuca;MONCOES|SP|-20.8509|-50.0975|Monções;MONGAGUA|SP|-24.0809|-46.6265|Mongaguá;MONJOLOS|MG|-18.3245|-44.1180|Monjolos;MONSENHOR PAULO|MG|-21.7579|-45.5391|Monsenhor Paulo;MONTALVANIA|MG|-14.4197|-44.3719|Montalvânia;MONTANHA|ES|-18.1303|-40.3668|Montanha;MONTE ALEGRE DE MINAS|MG|-18.8690|-48.8810|Monte Alegre de Minas;MONTE ALEGRE DO SUL|SP|-22.6817|-46.6810|Monte Alegre do Sul;MONTE ALTO|SP|-21.2655|-48.4971|Monte Alto;MONTE APRAZIVEL|SP|-20.7680|-49.7184|Monte Aprazível;MONTE AZUL|MG|-15.1514|-42.8718|Monte Azul;MONTE AZUL PAULISTA|SP|-20.9065|-48.6387|Monte Azul Paulista;MONTE BELO|MG|-21.3271|-46.3635|Monte Belo;MONTE CARMELO|MG|-18.7302|-47.4912|Monte Carmelo;MONTE CASTELO|SP|-21.2981|-51.5679|Monte Castelo;MONTE FORMOSO|MG|-16.8691|-41.2473|Monte Formoso;MONTE MOR|SP|-22.9450|-47.3122|Monte Mor;MONTE SANTO DE MINAS|MG|-21.1873|-46.9753|Monte Santo de Minas;MONTE SIAO|MG|-22.4335|-46.5730|Monte Sião;MONTEIRO LOBATO|SP|-22.9544|-45.8407|Monteiro Lobato;MONTES CLAROS|MG|-16.7282|-43.8578|Montes Claros;MONTEZUMA|MG|-15.1702|-42.4941|Montezuma;MORADA NOVA DE MINAS|MG|-18.5998|-45.3584|Morada Nova de Minas;MORRO AGUDO|SP|-20.7288|-48.0581|Morro Agudo;MORRO DA GARCA|MG|-18.5356|-44.6010|Morro da Garça;MORRO DO PILAR|MG|-19.2236|-43.3795|Morro do Pilar;MORUNGABA|SP|-22.8811|-46.7896|Morungaba;MOTUCA|SP|-21.5103|-48.1538|Motuca;MUCURICI|ES|-18.0965|-40.5200|Mucurici;MUNHOZ|MG|-22.6092|-46.3620|Munhoz;MUNIZ FREIRE|ES|-20.4652|-41.4156|Muniz Freire;MUQUI|ES|-20.9509|-41.3460|Muqui;MURIAE|MG|-21.1300|-42.3693|Muriaé;MURUTINGA DO SUL|SP|-20.9908|-51.2774|Murutinga do Sul;MUTUM|MG|-19.8121|-41.4407|Mutum;MUZAMBINHO|MG|-21.3692|-46.5213|Muzambinho;NACIP RAYDAN|MG|-18.4544|-42.2481|Nacip Raydan;NANTES|SP|-22.6156|-51.2400|Nantes;NANUQUE|MG|-17.8481|-40.3533|Nanuque;NAQUE|MG|-19.2291|-42.3312|Naque;NARANDIBA|SP|-22.4057|-51.5274|Narandiba;NATALANDIA|MG|-16.5021|-46.4874|Natalândia;NATERCIA|MG|-22.1158|-45.5123|Natércia;NATIVIDADE|RJ|-21.0390|-41.9697|Natividade;NATIVIDADE DA SERRA|SP|-23.3707|-45.4468|Natividade da Serra;NAZARE PAULISTA|SP|-23.1747|-46.3983|Nazaré Paulista;NAZARENO|MG|-21.2168|-44.6138|Nazareno;NEPOMUCENO|MG|-21.2324|-45.2350|Nepomuceno;NEVES PAULISTA|SP|-20.8430|-49.6358|Neves Paulista;NHANDEARA|SP|-20.6945|-50.0436|Nhandeara;NILOPOLIS|RJ|-22.8057|-43.4233|Nilópolis;NINHEIRA|MG|-15.3148|-41.7564|Ninheira;NIPOA|SP|-20.9114|-49.7833|Nipoã;NITEROI|RJ|-22.8832|-43.1034|Niterói;NOVA ALIANCA|SP|-21.0156|-49.4986|Nova Aliança;NOVA BELEM|MG|-18.4925|-41.1107|Nova Belém;NOVA CAMPINA|SP|-24.1224|-48.9022|Nova Campina;NOVA CANAA PAULISTA|SP|-20.3836|-50.9483|Nova Canaã Paulista;NOVA CASTILHO|SP|-20.7615|-50.3477|Nova Castilho;NOVA ERA|MG|-19.7577|-43.0333|Nova Era;NOVA EUROPA|SP|-21.7765|-48.5705|Nova Europa;NOVA FRIBURGO|RJ|-22.2932|-42.5377|Nova Friburgo;NOVA GRANADA|SP|-20.5321|-49.3123|Nova Granada;NOVA GUATAPORANGA|SP|-21.3320|-51.6447|Nova Guataporanga;NOVA IGUACU|RJ|-22.7556|-43.4603|Nova Iguaçu;NOVA INDEPENDENCIA|SP|-21.1026|-51.4905|Nova Independência;NOVA LIMA|MG|-19.9758|-43.8509|Nova Lima;NOVA LUZITANIA|SP|-20.8560|-50.2617|Nova Luzitânia;NOVA MODICA|MG|-18.4417|-41.4984|Nova Módica;NOVA ODESSA|SP|-22.7832|-47.2941|Nova Odessa;NOVA PONTE|MG|-19.1461|-47.6779|Nova Ponte;NOVA PORTEIRINHA|MG|-15.7993|-43.2941|Nova Porteirinha;NOVA RESENDE|MG|-21.1286|-46.4157|Nova Resende;NOVA SERRANA|MG|-19.8713|-44.9847|Nova Serrana;NOVA UNIAO|MG|-19.6876|-43.5830|Nova União;NOVA VENECIA|ES|-18.7150|-40.4053|Nova Venécia;NOVAIS|SP|-20.9893|-48.9141|Novais;NOVO CRUZEIRO|MG|-17.4654|-41.8826|Novo Cruzeiro;NOVO HORIZONTE|SP|-21.4651|-49.2234|Novo Horizonte;NOVO ORIENTE DE MINAS|MG|-17.4089|-41.2194|Novo Oriente de Minas;NOVORIZONTE|MG|-16.0162|-42.4044|Novorizonte;NUPORANGA|SP|-20.7296|-47.7429|Nuporanga;OCAUCU|SP|-22.4380|-49.9220|Ocauçu;OLARIA|MG|-21.8598|-43.9356|Olaria;OLEO|SP|-22.9435|-49.3419|Óleo;OLHOS D'AGUA|MG|-17.3982|-43.5719|Olhos d'Água;OLIMPIA|SP|-20.7366|-48.9106|Olímpia;OLIMPIO NORONHA|MG|-22.0685|-45.2657|Olímpio Noronha;OLIVEIRA|MG|-20.6982|-44.8290|Oliveira;OLIVEIRA FORTES|MG|-21.3401|-43.4499|Oliveira Fortes;ONCA DE PITANGUI|MG|-19.7276|-44.8058|Onça de Pitangui;ONDA VERDE|SP|-20.6042|-49.2929|Onda Verde;ORATORIOS|MG|-20.4298|-42.7977|Oratórios;ORIENTE|SP|-22.1549|-50.0971|Oriente;ORINDIUVA|SP|-20.1861|-49.3464|Orindiúva;ORIZANIA|MG|-20.5142|-42.1991|Orizânia;ORLANDIA|SP|-20.7169|-47.8852|Orlândia;OSASCO|SP|-23.5324|-46.7916|Osasco;OSCAR BRESSANE|SP|-22.3149|-50.2811|Oscar Bressane;OSVALDO CRUZ|SP|-21.7968|-50.8793|Osvaldo Cruz;OURINHOS|SP|-22.9797|-49.8697|Ourinhos;OURO BRANCO|MG|-20.5263|-43.6962|Ouro Branco;OURO FINO|MG|-22.2779|-46.3716|Ouro Fino;OURO PRETO|MG|-20.3796|-43.5120|Ouro Preto;OURO VERDE|SP|-21.4872|-51.7024|Ouro Verde;OURO VERDE DE MINAS|MG|-18.0719|-41.2734|Ouro Verde de Minas;OUROESTE|SP|-20.0061|-50.3768|Ouroeste;PACAEMBU|SP|-21.5627|-51.2654|Pacaembu;PADRE CARVALHO|MG|-16.3646|-42.5088|Padre Carvalho;PADRE PARAISO|MG|-17.0758|-41.4821|Padre Paraíso;PAI PEDRO|MG|-15.5271|-43.0700|Pai Pedro;PAINEIRAS|MG|-18.8993|-45.5321|Paineiras;PAINS|MG|-20.3705|-45.6627|Pains;PAIVA|MG|-21.2913|-43.4088|Paiva;PALESTINA|SP|-20.3900|-49.4309|Palestina;PALMA|MG|-21.3748|-42.3123|Palma;PALMARES PAULISTA|SP|-21.0854|-48.8037|Palmares Paulista;PALMEIRA D'OESTE|SP|-20.4148|-50.7632|Palmeira d'Oeste;PALMITAL|SP|-22.7858|-50.2180|Palmital;PALMOPOLIS|MG|-16.7364|-40.4296|Palmópolis;PANCAS|ES|-19.2229|-40.8534|Pancas;PANORAMA|SP|-21.3540|-51.8562|Panorama;PAPAGAIOS|MG|-19.4419|-44.7468|Papagaios;PARA DE MINAS|MG|-19.8534|-44.6114|Pará de Minas;PARACAMBI|RJ|-22.6078|-43.7108|Paracambi;PARACATU|MG|-17.2252|-46.8711|Paracatu;PARAGUACU|MG|-21.5465|-45.7374|Paraguaçu;PARAGUACU PAULISTA|SP|-22.4114|-50.5732|Paraguaçu Paulista;PARAIBA DO SUL|RJ|-22.1585|-43.3040|Paraíba do Sul;PARAIBUNA|SP|-23.3872|-45.6639|Paraibuna;PARAISO|SP|-21.0159|-48.7761|Paraíso;PARAISOPOLIS|MG|-22.5539|-45.7803|Paraisópolis;PARANAPANEMA|SP|-23.3862|-48.7214|Paranapanema;PARANAPUA|SP|-20.1048|-50.5886|Paranapuã;PARAOPEBA|MG|-19.2732|-44.4044|Paraopeba;PARAPUA|SP|-21.7792|-50.7949|Parapuã;PARATY|RJ|-23.2221|-44.7175|Paraty;PARDINHO|SP|-23.0841|-48.3679|Pardinho;PARIQUERA-ACU|SP|-24.7147|-47.8742|Pariquera-Açu;PARISI|SP|-20.3034|-50.0163|Parisi;PASSA QUATRO|MG|-22.3871|-44.9709|Passa Quatro;PASSA TEMPO|MG|-20.6539|-44.4926|Passa Tempo;PASSA-VINTE|MG|-22.2097|-44.2344|Passa-Vinte;PASSABEM|MG|-19.3509|-43.1383|Passabém;PASSOS|MG|-20.7193|-46.6090|Passos;PATIS|MG|-16.0773|-44.0787|Patis;PATOS DE MINAS|MG|-18.5699|-46.5013|Patos de Minas;PATROCINIO|MG|-18.9379|-46.9934|Patrocínio;PATROCINIO DO MURIAE|MG|-21.1544|-42.2125|Patrocínio do Muriaé;PATROCINIO PAULISTA|SP|-20.6384|-47.2801|Patrocínio Paulista;PATY DO ALFERES|RJ|-22.4309|-43.4285|Paty do Alferes;PAULA CANDIDO|MG|-20.8754|-42.9752|Paula Cândido;PAULICEIA|SP|-21.3153|-51.8321|Paulicéia;PAULINIA|SP|-22.7542|-47.1488|Paulínia;PAULISTANIA|SP|-22.5768|-49.4008|Paulistânia;PAULISTAS|MG|-18.4276|-42.8628|Paulistas;PAULO DE FARIA|SP|-20.0296|-49.4000|Paulo de Faria;PAVAO|MG|-17.4267|-41.0035|Pavão;PECANHA|MG|-18.5441|-42.5583|Peçanha;PEDERNEIRAS|SP|-22.3511|-48.7781|Pederneiras;PEDRA AZUL|MG|-16.0086|-41.2909|Pedra Azul;PEDRA BELA|SP|-22.7902|-46.4455|Pedra Bela;PEDRA BONITA|MG|-20.5219|-42.3304|Pedra Bonita;PEDRA DO ANTA|MG|-20.5968|-42.7123|Pedra do Anta;PEDRA DO INDAIA|MG|-20.2563|-45.2107|Pedra do Indaiá;PEDRA DOURADA|MG|-20.8266|-42.1515|Pedra Dourada;PEDRALVA|MG|-22.2386|-45.4654|Pedralva;PEDRANOPOLIS|SP|-20.2474|-50.1129|Pedranópolis;PEDRAS DE MARIA DA CRUZ|MG|-15.6032|-44.3910|Pedras de Maria da Cruz;PEDREGULHO|SP|-20.2535|-47.4775|Pedregulho;PEDREIRA|SP|-22.7413|-46.8948|Pedreira;PEDRINHAS PAULISTA|SP|-22.8174|-50.7933|Pedrinhas Paulista;PEDRINOPOLIS|MG|-19.2241|-47.4579|Pedrinópolis;PEDRO CANARIO|ES|-18.3004|-39.9574|Pedro Canário;PEDRO DE TOLEDO|SP|-24.2764|-47.2354|Pedro de Toledo;PEDRO LEOPOLDO|MG|-19.6308|-44.0383|Pedro Leopoldo;PEDRO TEIXEIRA|MG|-21.7076|-43.7430|Pedro Teixeira;PENAPOLIS|SP|-21.4148|-50.0769|Penápolis;PEQUERI|MG|-21.8341|-43.1145|Pequeri;PEQUI|MG|-19.6284|-44.6604|Pequi;PERDIGAO|MG|-19.9411|-45.0780|Perdigão;PERDIZES|MG|-19.3434|-47.2963|Perdizes;PERDOES|MG|-21.0932|-45.0896|Perdões;PEREIRA BARRETO|SP|-20.6368|-51.1123|Pereira Barreto;PEREIRAS|SP|-23.0804|-47.9720|Pereiras;PERIQUITO|MG|-19.1573|-42.2333|Periquito;PERUIBE|SP|-24.3120|-47.0012|Peruíbe;PESCADOR|MG|-18.3570|-41.6006|Pescador;PETROPOLIS|RJ|-22.5200|-43.1926|Petrópolis;PIACATU|SP|-21.5921|-50.6003|Piacatu;PIAU|MG|-21.5096|-43.3130|Piau;PIEDADE|SP|-23.7139|-47.4256|Piedade;PIEDADE DE CARATINGA|MG|-19.7593|-42.0756|Piedade de Caratinga;PIEDADE DE PONTE NOVA|MG|-20.2438|-42.7379|Piedade de Ponte Nova;PIEDADE DO RIO GRANDE|MG|-21.4690|-44.1938|Piedade do Rio Grande;PIEDADE DOS GERAIS|MG|-20.4715|-44.2243|Piedade dos Gerais;PILAR DO SUL|SP|-23.8077|-47.7222|Pilar do Sul;PIMENTA|MG|-20.4827|-45.8049|Pimenta;PINDAMONHANGABA|SP|-22.9246|-45.4613|Pindamonhangaba;PINDORAMA|SP|-21.1853|-48.9086|Pindorama;PINGO-D'AGUA|MG|-19.7287|-42.4095|Pingo-d'Água;PINHALZINHO|SP|-22.7811|-46.5897|Pinhalzinho;PINHEIRAL|RJ|-22.5172|-44.0022|Pinheiral;PINHEIROS|ES|-18.4141|-40.2171|Pinheiros;PINTOPOLIS|MG|-16.0572|-45.1402|Pintópolis;PIQUEROBI|SP|-21.8747|-51.7282|Piquerobi;PIQUETE|SP|-22.6069|-45.1869|Piquete;PIRACAIA|SP|-23.0525|-46.3594|Piracaia;PIRACEMA|MG|-20.5089|-44.4783|Piracema;PIRACICABA|SP|-22.7338|-47.6476|Piracicaba;PIRAI|RJ|-22.6215|-43.9081|Piraí;PIRAJU|SP|-23.1981|-49.3803|Piraju;PIRAJUBA|MG|-19.9092|-48.7027|Pirajuba;PIRAJUI|SP|-21.9990|-49.4608|Pirajuí;PIRANGA|MG|-20.6834|-43.2967|Piranga;PIRANGI|SP|-21.0886|-48.6607|Pirangi;PIRANGUCU|MG|-22.5249|-45.4945|Piranguçu;PIRANGUINHO|MG|-22.3950|-45.5324|Piranguinho;PIRAPETINGA|MG|-21.6554|-42.3434|Pirapetinga;PIRAPORA|MG|-17.3392|-44.9340|Pirapora;PIRAPORA DO BOM JESUS|SP|-23.3965|-46.9991|Pirapora do Bom Jesus;PIRAPOZINHO|SP|-22.2711|-51.4976|Pirapozinho;PIRASSUNUNGA|SP|-21.9960|-47.4257|Pirassununga;PIRATININGA|SP|-22.4142|-49.1339|Piratininga;PIRAUBA|MG|-21.2825|-43.0172|Piraúba;PITANGUEIRAS|SP|-21.0132|-48.2210|Pitangueiras;PITANGUI|MG|-19.6741|-44.8964|Pitangui;PIUMA|ES|-20.8334|-40.7268|Piúma;PIUMHI|MG|-20.4762|-45.9589|Piumhi;PLANALTO|SP|-21.0342|-49.9330|Planalto;PLANURA|MG|-20.1376|-48.7000|Planura;PLATINA|SP|-22.6371|-50.2104|Platina;POA|SP|-23.5333|-46.3473|Poá;POCO FUNDO|MG|-21.7800|-45.9658|Poço Fundo;POCOS DE CALDAS|MG|-21.7800|-46.5692|Poços de Caldas;POCRANE|MG|-19.6208|-41.6334|Pocrane;POLONI|SP|-20.7829|-49.8258|Poloni;POMPEIA|SP|-22.1070|-50.1760|Pompéia;POMPEU|MG|-19.2257|-45.0141|Pompéu;PONGAI|SP|-21.7396|-49.3604|Pongaí;PONTAL|SP|-21.0216|-48.0423|Pontal;PONTALINDA|SP|-20.4396|-50.5258|Pontalinda;PONTE NOVA|MG|-20.4111|-42.8978|Ponte Nova;PONTES GESTAL|SP|-20.1727|-49.7064|Pontes Gestal;PONTO BELO|ES|-18.1253|-40.5458|Ponto Belo;PONTO CHIQUE|MG|-16.6282|-45.0588|Ponto Chique;PONTO DOS VOLANTES|MG|-16.7473|-41.5025|Ponto dos Volantes;POPULINA|SP|-19.9453|-50.5380|Populina;PORANGABA|SP|-23.1761|-48.1195|Porangaba;PORCIUNCULA|RJ|-20.9632|-42.0465|Porciúncula;PORTEIRINHA|MG|-15.7404|-43.0281|Porteirinha;PORTO FELIZ|SP|-23.2093|-47.5251|Porto Feliz;PORTO FERREIRA|SP|-21.8498|-47.4870|Porto Ferreira;PORTO FIRME|MG|-20.6642|-43.0834|Porto Firme;PORTO REAL|RJ|-22.4175|-44.2952|Porto Real;POTE|MG|-17.8077|-41.7860|Poté;POTIM|SP|-22.8343|-45.2552|Potim;POTIRENDABA|SP|-21.0428|-49.3815|Potirendaba;POUSO ALEGRE|MG|-22.2266|-45.9389|Pouso Alegre;POUSO ALTO|MG|-22.1964|-44.9748|Pouso Alto;PRACINHA|SP|-21.8496|-51.0868|Pracinha;PRADOPOLIS|SP|-21.3626|-48.0679|Pradópolis;PRADOS|MG|-21.0597|-44.0778|Prados;PRAIA GRANDE|SP|-24.0084|-46.4121|Praia Grande;PRATA|MG|-19.3086|-48.9276|Prata;PRATANIA|SP|-22.8112|-48.6636|Pratânia;PRATAPOLIS|MG|-20.7411|-46.8624|Pratápolis;PRATINHA|MG|-19.7390|-46.3755|Pratinha;PRESIDENTE ALVES|SP|-22.0999|-49.4381|Presidente Alves;PRESIDENTE BERNARDES|SP|-22.0082|-51.5565|Presidente Bernardes;PRESIDENTE BERNARDES|MG|-20.7656|-43.1895|Presidente Bernardes;PRESIDENTE EPITACIO|SP|-21.7651|-52.1111|Presidente Epitácio;PRESIDENTE JUSCELINO|MG|-18.6401|-44.0600|Presidente Juscelino;PRESIDENTE KENNEDY|ES|-21.0964|-41.0468|Presidente Kennedy;PRESIDENTE KUBITSCHEK|MG|-18.6193|-43.5628|Presidente Kubitschek;PRESIDENTE OLEGARIO|MG|-18.4096|-46.4165|Presidente Olegário;PRESIDENTE PRUDENTE|SP|-22.1207|-51.3925|Presidente Prudente;PRESIDENTE VENCESLAU|SP|-21.8732|-51.8447|Presidente Venceslau;PROMISSAO|SP|-21.5356|-49.8599|Promissão;PRUDENTE DE MORAIS|MG|-19.4742|-44.1591|Prudente de Morais;QUADRA|SP|-23.2993|-48.0547|Quadra;QUARTEL GERAL|MG|-19.2703|-45.5569|Quartel Geral;QUATA|SP|-22.2456|-50.6966|Quatá;QUATIS|RJ|-22.4045|-44.2597|Quatis;QUEIMADOS|RJ|-22.7102|-43.5518|Queimados;QUEIROZ|SP|-21.7969|-50.2415|Queiroz;QUELUZ|SP|-22.5312|-44.7781|Queluz;QUELUZITO|MG|-20.7416|-43.8851|Queluzito;QUINTANA|SP|-22.0692|-50.3070|Quintana;QUISSAMA|RJ|-22.1031|-41.4693|Quissamã;RAFARD|SP|-23.0105|-47.5318|Rafard;RANCHARIA|SP|-22.2269|-50.8930|Rancharia;RAPOSOS|MG|-19.9636|-43.8079|Raposos;RAUL SOARES|MG|-20.1061|-42.4502|Raul Soares;RECREIO|MG|-21.5289|-42.4676|Recreio;REDENCAO DA SERRA|SP|-23.2638|-45.5422|Redenção da Serra;REDUTO|MG|-20.2401|-41.9848|Reduto;REGENTE FEIJO|SP|-22.2181|-51.3055|Regente Feijó;REGINOPOLIS|SP|-21.8914|-49.2268|Reginópolis;REGISTRO|SP|-24.4979|-47.8449|Registro;RESENDE|RJ|-22.4705|-44.4509|Resende;RESENDE COSTA|MG|-20.9171|-44.2407|Resende Costa;RESPLENDOR|MG|-19.3194|-41.2462|Resplendor;RESSAQUINHA|MG|-21.0642|-43.7598|Ressaquinha;RESTINGA|SP|-20.6056|-47.4833|Restinga;RIACHINHO|MG|-16.2258|-45.9888|Riachinho;RIACHO DOS MACHADOS|MG|-16.0091|-43.0488|Riacho dos Machados;RIBEIRA|SP|-24.6517|-49.0044|Ribeira;RIBEIRAO BONITO|SP|-22.0685|-48.1820|Ribeirão Bonito;RIBEIRAO BRANCO|SP|-24.2206|-48.7635|Ribeirão Branco;RIBEIRAO CORRENTE|SP|-20.4579|-47.5904|Ribeirão Corrente;RIBEIRAO DAS NEVES|MG|-19.7621|-44.0844|Ribeirão das Neves;RIBEIRAO DO SUL|SP|-22.7890|-49.9330|Ribeirão do Sul;RIBEIRAO DOS INDIOS|SP|-21.8382|-51.6103|Ribeirão dos Índios;RIBEIRAO GRANDE|SP|-24.1011|-48.3679|Ribeirão Grande;RIBEIRAO PIRES|SP|-23.7067|-46.4058|Ribeirão Pires;RIBEIRAO PRETO|SP|-21.1699|-47.8099|Ribeirão Preto;RIBEIRAO VERMELHO|MG|-21.1879|-45.0637|Ribeirão Vermelho;RIFAINA|SP|-20.0803|-47.4291|Rifaina;RINCAO|SP|-21.5894|-48.0728|Rincão;RINOPOLIS|SP|-21.7284|-50.7239|Rinópolis;RIO ACIMA|MG|-20.0876|-43.7878|Rio Acima;RIO BANANAL|ES|-19.2719|-40.3366|Rio Bananal;RIO BONITO|RJ|-22.7181|-42.6276|Rio Bonito;RIO CASCA|MG|-20.2285|-42.6462|Rio Casca;RIO CLARO|RJ|-22.7200|-44.1419|Rio Claro;RIO CLARO|SP|-22.3984|-47.5546|Rio Claro;RIO DAS FLORES|RJ|-22.1692|-43.5856|Rio das Flores;RIO DAS OSTRAS|RJ|-22.5174|-41.9475|Rio das Ostras;RIO DAS PEDRAS|SP|-22.8417|-47.6047|Rio das Pedras;RIO DE JANEIRO|RJ|-22.9129|-43.2003|Rio de Janeiro;RIO DO PRADO|MG|-16.6056|-40.5714|Rio do Prado;RIO DOCE|MG|-20.2412|-42.8995|Rio Doce;RIO ESPERA|MG|-20.8550|-43.4721|Rio Espera;RIO GRANDE DA SERRA|SP|-23.7437|-46.3971|Rio Grande da Serra;RIO MANSO|MG|-20.2666|-44.3069|Rio Manso;RIO NOVO|MG|-21.4649|-43.1168|Rio Novo;RIO NOVO DO SUL|ES|-20.8556|-40.9388|Rio Novo do Sul;RIO PARANAIBA|MG|-19.1861|-46.2455|Rio Paranaíba;RIO PARDO DE MINAS|MG|-15.6160|-42.5405|Rio Pardo de Minas;RIO PIRACICABA|MG|-19.9284|-43.1829|Rio Piracicaba;RIO POMBA|MG|-21.2712|-43.1696|Rio Pomba;RIO PRETO|MG|-22.0861|-43.8293|Rio Preto;RIO VERMELHO|MG|-18.2922|-43.0018|Rio Vermelho;RIOLANDIA|SP|-19.9868|-49.6836|Riolândia;RITAPOLIS|MG|-21.0276|-44.3204|Ritápolis;RIVERSUL|SP|-23.8290|-49.4290|Riversul;ROCHEDO DE MINAS|MG|-21.6284|-43.0165|Rochedo de Minas;RODEIRO|MG|-21.2035|-42.8586|Rodeiro;ROMARIA|MG|-18.8838|-47.5782|Romaria;ROSANA|SP|-22.5782|-53.0603|Rosana;ROSARIO DA LIMEIRA|MG|-20.9812|-42.5112|Rosário da Limeira;ROSEIRA|SP|-22.8938|-45.3070|Roseira;RUBELITA|MG|-16.4053|-42.2610|Rubelita;RUBIACEA|SP|-21.3006|-50.7296|Rubiácea;RUBIM|MG|-16.3775|-40.5397|Rubim;RUBINEIA|SP|-20.1759|-51.0070|Rubinéia;SABARA|MG|-19.8840|-43.8263|Sabará;SABINO|SP|-21.4593|-49.5755|Sabino;SABINOPOLIS|MG|-18.6653|-43.0752|Sabinópolis;SACRAMENTO|MG|-19.8622|-47.4508|Sacramento;SAGRES|SP|-21.8823|-50.9594|Sagres;SALES|SP|-21.3427|-49.4897|Sales;SALES OLIVEIRA|SP|-20.7696|-47.8369|Sales Oliveira;SALESOPOLIS|SP|-23.5288|-45.8465|Salesópolis;SALINAS|MG|-16.1753|-42.2964|Salinas;SALMOURAO|SP|-21.6267|-50.8614|Salmourão;SALTINHO|SP|-22.8442|-47.6754|Saltinho;SALTO|SP|-23.1996|-47.2931|Salto;SALTO DA DIVISA|MG|-16.0063|-39.9391|Salto da Divisa;SALTO DE PIRAPORA|SP|-23.6474|-47.5743|Salto de Pirapora;SALTO GRANDE|SP|-22.8894|-49.9831|Salto Grande;SANDOVALINA|SP|-22.4551|-51.7648|Sandovalina;SANTA ADELIA|SP|-21.2427|-48.8063|Santa Adélia;SANTA ALBERTINA|SP|-20.0311|-50.7297|Santa Albertina;SANTA BARBARA|MG|-19.9604|-43.4101|Santa Bárbara;SANTA BARBARA D'OESTE|SP|-22.7553|-47.4143|Santa Bárbara d'Oeste;SANTA BARBARA DO LESTE|MG|-19.9753|-42.1457|Santa Bárbara do Leste;SANTA BARBARA DO MONTE VERDE|MG|-21.9592|-43.7027|Santa Bárbara do Monte Verde;SANTA BARBARA DO TUGURIO|MG|-21.2431|-43.5607|Santa Bárbara do Tugúrio;SANTA BRANCA|SP|-23.3933|-45.8875|Santa Branca;SANTA CLARA D'OESTE|SP|-20.0900|-50.9491|Santa Clara d'Oeste;SANTA CRUZ DA CONCEICAO|SP|-22.1405|-47.4512|Santa Cruz da Conceição;SANTA CRUZ DA ESPERANCA|SP|-21.2951|-47.4304|Santa Cruz da Esperança;SANTA CRUZ DAS PALMEIRAS|SP|-21.8235|-47.2480|Santa Cruz das Palmeiras;SANTA CRUZ DE MINAS|MG|-21.1241|-44.2202|Santa Cruz de Minas;SANTA CRUZ DE SALINAS|MG|-16.0967|-41.7418|Santa Cruz de Salinas;SANTA CRUZ DO ESCALVADO|MG|-20.2372|-42.8169|Santa Cruz do Escalvado;SANTA CRUZ DO RIO PARDO|SP|-22.8988|-49.6354|Santa Cruz do Rio Pardo;SANTA EFIGENIA DE MINAS|MG|-18.8235|-42.4388|Santa Efigênia de Minas;SANTA ERNESTINA|SP|-21.4618|-48.3953|Santa Ernestina;SANTA FE DE MINAS|MG|-16.6859|-45.4102|Santa Fé de Minas;SANTA FE DO SUL|SP|-20.2083|-50.9320|Santa Fé do Sul;SANTA GERTRUDES|SP|-22.4572|-47.5272|Santa Gertrudes;SANTA HELENA DE MINAS|MG|-16.9707|-40.6727|Santa Helena de Minas;SANTA ISABEL|SP|-23.3172|-46.2237|Santa Isabel;SANTA JULIANA|MG|-19.3108|-47.5322|Santa Juliana;SANTA LEOPOLDINA|ES|-20.0999|-40.5270|Santa Leopoldina;SANTA LUCIA|SP|-21.6850|-48.0885|Santa Lúcia;SANTA LUZIA|MG|-19.7548|-43.8497|Santa Luzia;SANTA MARGARIDA|MG|-20.3839|-42.2519|Santa Margarida;SANTA MARIA DA SERRA|SP|-22.5661|-48.1593|Santa Maria da Serra;SANTA MARIA DE ITABIRA|MG|-19.4431|-43.1064|Santa Maria de Itabira;SANTA MARIA DE JETIBA|ES|-20.0253|-40.7439|Santa Maria de Jetibá;SANTA MARIA DO SALTO|MG|-16.2479|-40.1512|Santa Maria do Salto;SANTA MARIA DO SUACUI|MG|-18.1896|-42.4139|Santa Maria do Suaçuí;SANTA MARIA MADALENA|RJ|-21.9547|-42.0098|Santa Maria Madalena;SANTA MERCEDES|SP|-21.3495|-51.7564|Santa Mercedes;SANTA RITA D'OESTE|SP|-20.1414|-50.8358|Santa Rita d'Oeste;SANTA RITA DE CALDAS|MG|-22.0292|-46.3385|Santa Rita de Caldas;SANTA RITA DE IBITIPOCA|MG|-21.5658|-43.9163|Santa Rita de Ibitipoca;SANTA RITA DE JACUTINGA|MG|-22.1474|-44.0977|Santa Rita de Jacutinga;SANTA RITA DE MINAS|MG|-19.8760|-42.1363|Santa Rita de Minas;SANTA RITA DO ITUETO|MG|-19.3576|-41.3821|Santa Rita do Itueto;SANTA RITA DO PASSA QUATRO|SP|-21.7083|-47.4780|Santa Rita do Passa Quatro;SANTA RITA DO SAPUCAI|MG|-22.2461|-45.7034|Santa Rita do Sapucaí;SANTA ROSA DA SERRA|MG|-19.5186|-45.9611|Santa Rosa da Serra;SANTA ROSA DE VITERBO|SP|-21.4776|-47.3622|Santa Rosa de Viterbo;SANTA SALETE|SP|-20.2429|-50.6887|Santa Salete;SANTA TERESA|ES|-19.9363|-40.5979|Santa Teresa;SANTA VITORIA|MG|-18.8414|-50.1208|Santa Vitória;SANTANA DA PONTE PENSA|SP|-20.2523|-50.8014|Santana da Ponte Pensa;SANTANA DA VARGEM|MG|-21.2449|-45.5005|Santana da Vargem;SANTANA DE CATAGUASES|MG|-21.2893|-42.5524|Santana de Cataguases;SANTANA DE PARNAIBA|SP|-23.4439|-46.9178|Santana de Parnaíba;SANTANA DE PIRAPAMA|MG|-18.9962|-44.0409|Santana de Pirapama;SANTANA DO DESERTO|MG|-21.9512|-43.1583|Santana do Deserto;SANTANA DO GARAMBEU|MG|-21.5983|-44.1050|Santana do Garambéu;SANTANA DO JACARE|MG|-20.9007|-45.1285|Santana do Jacaré;SANTANA DO MANHUACU|MG|-20.1031|-41.9278|Santana do Manhuaçu;SANTANA DO PARAISO|MG|-19.3661|-42.5446|Santana do Paraíso;SANTANA DO RIACHO|MG|-19.1662|-43.7220|Santana do Riacho;SANTANA DOS MONTES|MG|-20.7868|-43.6949|Santana dos Montes;SANTO ANASTACIO|SP|-21.9747|-51.6527|Santo Anastácio;SANTO ANDRE|SP|-23.6737|-46.5432|Santo André;SANTO ANTONIO DA ALEGRIA|SP|-21.0864|-47.1464|Santo Antônio da Alegria;SANTO ANTONIO DE PADUA|RJ|-21.5410|-42.1832|Santo Antônio de Pádua;SANTO ANTONIO DE POSSE|SP|-22.6029|-46.9192|Santo Antônio de Posse;SANTO ANTONIO DO AMPARO|MG|-20.9430|-44.9176|Santo Antônio do Amparo;SANTO ANTONIO DO ARACANGUA|SP|-20.9331|-50.4980|Santo Antônio do Aracanguá;SANTO ANTONIO DO AVENTUREIRO|MG|-21.7606|-42.8115|Santo Antônio do Aventureiro;SANTO ANTONIO DO GRAMA|MG|-20.3185|-42.6047|Santo Antônio do Grama;SANTO ANTONIO DO ITAMBE|MG|-18.4609|-43.3006|Santo Antônio do Itambé;SANTO ANTONIO DO JACINTO|MG|-16.5332|-40.1817|Santo Antônio do Jacinto;SANTO ANTONIO DO JARDIM|SP|-22.1121|-46.6845|Santo Antônio do Jardim;SANTO ANTONIO DO MONTE|MG|-20.0850|-45.2947|Santo Antônio do Monte;SANTO ANTONIO DO PINHAL|SP|-22.8270|-45.6630|Santo Antônio do Pinhal;SANTO ANTONIO DO RETIRO|MG|-15.3393|-42.6171|Santo Antônio do Retiro;SANTO ANTONIO DO RIO ABAIXO|MG|-19.2374|-43.2604|Santo Antônio do Rio Abaixo;SANTO EXPEDITO|SP|-21.8467|-51.3929|Santo Expedito;SANTO HIPOLITO|MG|-18.2968|-44.2229|Santo Hipólito;SANTOPOLIS DO AGUAPEI|SP|-21.6376|-50.5044|Santópolis do Aguapeí;SANTOS|SP|-23.9535|-46.3350|Santos;SANTOS DUMONT|MG|-21.4634|-43.5499|Santos Dumont;SAO BENTO ABADE|MG|-21.5839|-45.0699|São Bento Abade;SAO BENTO DO SAPUCAI|SP|-22.6837|-45.7287|São Bento do Sapucaí;SAO BERNARDO DO CAMPO|SP|-23.6914|-46.5646|São Bernardo do Campo;SAO BRAS DO SUACUI|MG|-20.6242|-43.9515|São Brás do Suaçuí;SAO CAETANO DO SUL|SP|-23.6229|-46.5548|São Caetano do Sul;SAO CARLOS|SP|-22.0174|-47.8860|São Carlos;SAO DOMINGOS DAS DORES|MG|-19.5246|-42.0106|São Domingos das Dores;SAO DOMINGOS DO NORTE|ES|-19.1452|-40.6281|São Domingos do Norte;SAO DOMINGOS DO PRATA|MG|-19.8678|-42.9710|São Domingos do Prata;SAO FELIX DE MINAS|MG|-18.5959|-41.4889|São Félix de Minas;SAO FIDELIS|RJ|-21.6551|-41.7560|São Fidélis;SAO FRANCISCO|SP|-20.3623|-50.6952|São Francisco;SAO FRANCISCO|MG|-15.9514|-44.8593|São Francisco;SAO FRANCISCO DE ITABAPOANA|RJ|-21.4702|-41.1091|São Francisco de Itabapoana;SAO FRANCISCO DE PAULA|MG|-20.7036|-44.9838|São Francisco de Paula;SAO FRANCISCO DE SALES|MG|-19.8611|-49.7727|São Francisco de Sales;SAO FRANCISCO DO GLORIA|MG|-20.7923|-42.2673|São Francisco do Glória;SAO GABRIEL DA PALHA|ES|-19.0182|-40.5365|São Gabriel da Palha;SAO GERALDO|MG|-20.9252|-42.8364|São Geraldo;SAO GERALDO DA PIEDADE|MG|-18.8411|-42.2867|São Geraldo da Piedade;SAO GERALDO DO BAIXIO|MG|-18.9097|-41.3630|São Geraldo do Baixio;SAO GONCALO|RJ|-22.8268|-43.0634|São Gonçalo;SAO GONCALO DO ABAETE|MG|-18.3315|-45.8265|São Gonçalo do Abaeté;SAO GONCALO DO PARA|MG|-19.9822|-44.8593|São Gonçalo do Pará;SAO GONCALO DO RIO ABAIXO|MG|-19.8221|-43.3660|São Gonçalo do Rio Abaixo;SAO GONCALO DO RIO PRETO|MG|-18.0025|-43.3854|São Gonçalo do Rio Preto;SAO GONCALO DO SAPUCAI|MG|-21.8932|-45.5893|São Gonçalo do Sapucaí;SAO GOTARDO|MG|-19.3087|-46.0465|São Gotardo;SAO JOAO BATISTA DO GLORIA|MG|-20.6350|-46.5080|São João Batista do Glória;SAO JOAO DA BARRA|RJ|-21.6380|-41.0446|São João da Barra;SAO JOAO DA BOA VISTA|SP|-21.9707|-46.7944|São João da Boa Vista;SAO JOAO DA LAGOA|MG|-16.8455|-44.3507|São João da Lagoa;SAO JOAO DA MATA|MG|-21.9280|-45.9297|São João da Mata;SAO JOAO DA PONTE|MG|-15.9271|-44.0096|São João da Ponte;SAO JOAO DAS DUAS PONTES|SP|-20.3879|-50.3792|São João das Duas Pontes;SAO JOAO DAS MISSOES|MG|-14.8859|-44.0922|São João das Missões;SAO JOAO DE IRACEMA|SP|-20.5111|-50.3561|São João de Iracema;SAO JOAO DE MERITI|RJ|-22.8058|-43.3729|São João de Meriti;SAO JOAO DEL REI|MG|-21.1311|-44.2526|São João del Rei;SAO JOAO DO MANHUACU|MG|-20.3933|-42.1533|São João do Manhuaçu;SAO JOAO DO MANTENINHA|MG|-18.7230|-41.1628|São João do Manteninha;SAO JOAO DO ORIENTE|MG|-19.3384|-42.1575|São João do Oriente;SAO JOAO DO PACUI|MG|-16.5373|-44.5134|São João do Pacuí;SAO JOAO DO PARAISO|MG|-15.3168|-42.0213|São João do Paraíso;SAO JOAO DO PAU D'ALHO|SP|-21.2662|-51.6672|São João do Pau d'Alho;SAO JOAO EVANGELISTA|MG|-18.5480|-42.7655|São João Evangelista;SAO JOAO NEPOMUCENO|MG|-21.5381|-43.0069|São João Nepomuceno;SAO JOAQUIM DA BARRA|SP|-20.5812|-47.8593|São Joaquim da Barra;SAO JOAQUIM DE BICAS|MG|-20.0480|-44.2749|São Joaquim de Bicas;SAO JOSE DA BARRA|MG|-20.7178|-46.3130|São José da Barra;SAO JOSE DA BELA VISTA|SP|-20.5935|-47.6424|São José da Bela Vista;SAO JOSE DA LAPA|MG|-19.6971|-43.9586|São José da Lapa;SAO JOSE DA SAFIRA|MG|-18.3243|-42.1431|São José da Safira;SAO JOSE DA VARGINHA|MG|-19.7006|-44.5560|São José da Varginha;SAO JOSE DE UBA|RJ|-21.3661|-41.9511|São José de Ubá;SAO JOSE DO ALEGRE|MG|-22.3243|-45.5258|São José do Alegre;SAO JOSE DO BARREIRO|SP|-22.6414|-44.5774|São José do Barreiro;SAO JOSE DO CALCADO|ES|-21.0274|-41.6636|São José do Calçado;SAO JOSE DO DIVINO|MG|-18.4793|-41.3907|São José do Divino;SAO JOSE DO GOIABAL|MG|-19.9214|-42.7035|São José do Goiabal;SAO JOSE DO JACURI|MG|-18.2810|-42.6729|São José do Jacuri;SAO JOSE DO MANTIMENTO|MG|-20.0058|-41.7486|São José do Mantimento;SAO JOSE DO RIO PARDO|SP|-21.5953|-46.8873|São José do Rio Pardo;SAO JOSE DO RIO PRETO|SP|-20.8113|-49.3758|São José do Rio Preto;SAO JOSE DO VALE DO RIO PRETO|RJ|-22.1525|-42.9327|São José do Vale do Rio Preto;SAO JOSE DOS CAMPOS|SP|-23.1896|-45.8841|São José dos Campos;SAO LOURENCO|MG|-22.1166|-45.0506|São Lourenço;SAO LOURENCO DA SERRA|SP|-23.8491|-46.9432|São Lourenço da Serra;SAO LUIZ DO PARAITINGA|SP|-23.2220|-45.3109|São Luiz do Paraitinga;SAO MANUEL|SP|-22.7321|-48.5723|São Manuel;SAO MATEUS|ES|-18.7214|-39.8579|São Mateus;SAO MIGUEL ARCANJO|SP|-23.8782|-47.9935|São Miguel Arcanjo;SAO MIGUEL DO ANTA|MG|-20.7067|-42.7174|São Miguel do Anta;SAO PAULO|SP|-23.5329|-46.6395|São Paulo;SAO PEDRO|SP|-22.5483|-47.9096|São Pedro;SAO PEDRO DA ALDEIA|RJ|-22.8429|-42.1026|São Pedro da Aldeia;SAO PEDRO DA UNIAO|MG|-21.1310|-46.6123|São Pedro da União;SAO PEDRO DO SUACUI|MG|-18.3609|-42.5981|São Pedro do Suaçuí;SAO PEDRO DO TURVO|SP|-22.7453|-49.7428|São Pedro do Turvo;SAO PEDRO DOS FERROS|MG|-20.1732|-42.5251|São Pedro dos Ferros;SAO ROMAO|MG|-16.3641|-45.0749|São Romão;SAO ROQUE|SP|-23.5226|-47.1357|São Roque;SAO ROQUE DE MINAS|MG|-20.2490|-46.3639|São Roque de Minas;SAO ROQUE DO CANAA|ES|-19.7411|-40.6526|São Roque do Canaã;SAO SEBASTIAO|SP|-23.7951|-45.4143|São Sebastião;SAO SEBASTIAO DA BELA VISTA|MG|-22.1583|-45.7546|São Sebastião da Bela Vista;SAO SEBASTIAO DA GRAMA|SP|-21.7041|-46.8208|São Sebastião da Grama;SAO SEBASTIAO DA VARGEM ALEGRE|MG|-19.7477|-43.3679|São Sebastião da Vargem Alegre;SAO SEBASTIAO DO ALTO|RJ|-21.9578|-42.1328|São Sebastião do Alto;SAO SEBASTIAO DO ANTA|MG|-19.5064|-41.9850|São Sebastião do Anta;SAO SEBASTIAO DO MARANHAO|MG|-18.0873|-42.5659|São Sebastião do Maranhão;SAO SEBASTIAO DO OESTE|MG|-20.2758|-45.0063|São Sebastião do Oeste;SAO SEBASTIAO DO PARAISO|MG|-20.9167|-46.9837|São Sebastião do Paraíso;SAO SEBASTIAO DO RIO PRETO|MG|-19.2959|-43.1757|São Sebastião do Rio Preto;SAO SEBASTIAO DO RIO VERDE|MG|-22.2183|-44.9761|São Sebastião do Rio Verde;SAO SIMAO|SP|-21.4732|-47.5518|São Simão;SAO THOME DAS LETRAS|MG|-21.7218|-44.9849|São Thomé das Letras;SAO TIAGO|MG|-20.9075|-44.5098|São Tiago;SAO TOMAS DE AQUINO|MG|-20.7791|-47.0962|São Tomás de Aquino;SAO VICENTE|SP|-23.9574|-46.3883|São Vicente;SAO VICENTE DE MINAS|MG|-21.7042|-44.4431|São Vicente de Minas;SAPUCAI-MIRIM|MG|-22.7409|-45.7380|Sapucaí-Mirim;SAPUCAIA|RJ|-21.9949|-42.9142|Sapucaia;SAQUAREMA|RJ|-22.9292|-42.5099|Saquarema;SARAPUI|SP|-23.6397|-47.8249|Sarapuí;SARDOA|MG|-18.7828|-42.3629|Sardoá;SARUTAIA|SP|-23.2721|-49.4763|Sarutaiá;SARZEDO|MG|-20.0367|-44.1446|Sarzedo;SEBASTIANOPOLIS DO SUL|SP|-20.6523|-49.9250|Sebastianópolis do Sul;SEM-PEIXE|MG|-20.1008|-42.8483|Sem-Peixe;SENADOR AMARAL|MG|-22.5869|-46.1763|Senador Amaral;SENADOR CORTES|MG|-21.7986|-42.9424|Senador Cortes;SENADOR FIRMINO|MG|-20.9158|-43.0904|Senador Firmino;SENADOR JOSE BENTO|MG|-22.1633|-46.1792|Senador José Bento;SENADOR MODESTINO GONCALVES|MG|-17.9465|-43.2172|Senador Modestino Gonçalves;SENHORA DE OLIVEIRA|MG|-20.7972|-43.3394|Senhora de Oliveira;SENHORA DO PORTO|MG|-18.8909|-43.0799|Senhora do Porto;SENHORA DOS REMEDIOS|MG|-21.0351|-43.5812|Senhora dos Remédios;SERICITA|MG|-20.4748|-42.4828|Sericita;SERITINGA|MG|-21.9134|-44.5180|Seritinga;SEROPEDICA|RJ|-22.7526|-43.7155|Seropédica;SERRA|ES|-20.1210|-40.3074|Serra;SERRA AZUL|SP|-21.3074|-47.5602|Serra Azul;SERRA AZUL DE MINAS|MG|-18.3602|-43.1675|Serra Azul de Minas;SERRA DA SAUDADE|MG|-19.4447|-45.7950|Serra da Saudade;SERRA DO SALITRE|MG|-19.1083|-46.6961|Serra do Salitre;SERRA DOS AIMORES|MG|-17.7872|-40.2453|Serra dos Aimorés;SERRA NEGRA|SP|-22.6139|-46.7033|Serra Negra;SERRANA|SP|-21.2043|-47.5952|Serrana;SERRANIA|MG|-21.5441|-46.0417|Serrania;SERRANOPOLIS DE MINAS|MG|-15.8176|-42.8732|Serranópolis de Minas;SERRANOS|MG|-21.8857|-44.5125|Serranos;SERRO|MG|-18.5991|-43.3744|Serro;SERTAOZINHO|SP|-21.1316|-47.9875|Sertãozinho;SETE BARRAS|SP|-24.3820|-47.9279|Sete Barras;SETE LAGOAS|MG|-19.4569|-44.2413|Sete Lagoas;SETUBINHA|MG|-17.6002|-42.1587|Setubinha;SEVERINIA|SP|-20.8108|-48.8054|Severínia;SILVA JARDIM|RJ|-22.6574|-42.3961|Silva Jardim;SILVEIRANIA|MG|-21.1615|-43.2128|Silveirânia;SILVEIRAS|SP|-22.6638|-44.8522|Silveiras;SILVIANOPOLIS|MG|-22.0274|-45.8385|Silvianópolis;SIMAO PEREIRA|MG|-21.9640|-43.3088|Simão Pereira;SIMONESIA|MG|-20.1341|-42.0091|Simonésia;SOBRALIA|MG|-19.2345|-42.0998|Sobrália;SOCORRO|SP|-22.5903|-46.5251|Socorro;SOLEDADE DE MINAS|MG|-22.0554|-45.0464|Soledade de Minas;SOORETAMA|ES|-19.1897|-40.0974|Sooretama;SOROCABA|SP|-23.4969|-47.4451|Sorocaba;SUD MENNUCCI|SP|-20.6872|-50.9238|Sud Mennucci;SUMARE|SP|-22.8204|-47.2728|Sumaré;SUMIDOURO|RJ|-22.0485|-42.6761|Sumidouro;SUZANAPOLIS|SP|-20.4981|-51.0268|Suzanápolis;SUZANO|SP|-23.5448|-46.3112|Suzano;TABAPUA|SP|-20.9602|-49.0307|Tabapuã;TABATINGA|SP|-21.7239|-48.6896|Tabatinga;TABOAO DA SERRA|SP|-23.6019|-46.7526|Taboão da Serra;TABULEIRO|MG|-21.3632|-43.2381|Tabuleiro;TACIBA|SP|-22.3866|-51.2882|Taciba;TAGUAI|SP|-23.4452|-49.4024|Taguaí;TAIACU|SP|-21.1431|-48.5112|Taiaçu;TAIOBEIRAS|MG|-15.8106|-42.2259|Taiobeiras;TAIUVA|SP|-21.1223|-48.4528|Taiúva;TAMBAU|SP|-21.7029|-47.2703|Tambaú;TANABI|SP|-20.6228|-49.6563|Tanabi;TANGUA|RJ|-22.7423|-42.7202|Tanguá;TAPARUBA|MG|-19.7621|-41.6080|Taparuba;TAPIRA|MG|-19.9166|-46.8264|Tapira;TAPIRAI|MG|-19.8936|-46.0221|Tapiraí;TAPIRAI|SP|-23.9612|-47.5062|Tapiraí;TAPIRATIBA|SP|-21.4713|-46.7448|Tapiratiba;TAQUARACU DE MINAS|MG|-19.6652|-43.6922|Taquaraçu de Minas;TAQUARAL|SP|-21.0737|-48.4126|Taquaral;TAQUARITINGA|SP|-21.4049|-48.5103|Taquaritinga;TAQUARITUBA|SP|-23.5307|-49.2410|Taquarituba;TAQUARIVAI|SP|-23.9211|-48.6948|Taquarivaí;TARABAI|SP|-22.3016|-51.5621|Tarabai;TARUMA|SP|-22.7429|-50.5786|Tarumã;TARUMIRIM|MG|-19.2835|-42.0097|Tarumirim;TATUI|SP|-23.3487|-47.8461|Tatuí;TAUBATE|SP|-23.0104|-45.5593|Taubaté;TEIXEIRAS|MG|-20.6561|-42.8564|Teixeiras;TEJUPA|SP|-23.3425|-49.3722|Tejupá;TEODORO SAMPAIO|SP|-22.5299|-52.1682|Teodoro Sampaio;TEOFILO OTONI|MG|-17.8595|-41.5087|Teófilo Otoni;TERESOPOLIS|RJ|-22.4165|-42.9752|Teresópolis;TERRA ROXA|SP|-20.7870|-48.3314|Terra Roxa;TIETE|SP|-23.1101|-47.7164|Tietê;TIMBURI|SP|-23.2057|-49.6096|Timburi;TIMOTEO|MG|-19.5811|-42.6471|Timóteo;TIRADENTES|MG|-21.1102|-44.1744|Tiradentes;TIROS|MG|-19.0037|-45.9626|Tiros;TOCANTINS|MG|-21.1774|-43.0127|Tocantins;TOCOS DO MOJI|MG|-22.3698|-46.0971|Tocos do Moji;TOLEDO|MG|-22.7421|-46.3728|Toledo;TOMBOS|MG|-20.9086|-42.0228|Tombos;TORRE DE PEDRA|SP|-23.2462|-48.1955|Torre de Pedra;TORRINHA|SP|-22.4237|-48.1731|Torrinha;TRABIJU|SP|-22.0388|-48.3342|Trabiju;TRAJANO DE MORAES|RJ|-22.0638|-42.0643|Trajano de Moraes;TREMEMBE|SP|-22.9571|-45.5475|Tremembé;TRES CORACOES|MG|-21.6921|-45.2511|Três Corações;TRES FRONTEIRAS|SP|-20.2344|-50.8905|Três Fronteiras;TRES MARIAS|MG|-18.2048|-45.2473|Três Marias;TRES PONTAS|MG|-21.3694|-45.5109|Três Pontas;TRES RIOS|RJ|-22.1165|-43.2185|Três Rios;TUIUTI|SP|-22.8193|-46.6937|Tuiuti;TUMIRITINGA|MG|-18.9844|-41.6527|Tumiritinga;TUPA|SP|-21.9335|-50.5191|Tupã;TUPACIGUARA|MG|-18.5866|-48.6985|Tupaciguara;TUPI PAULISTA|SP|-21.3825|-51.5750|Tupi Paulista;TURIUBA|SP|-20.9428|-50.1135|Turiúba;TURMALINA|SP|-20.0486|-50.4792|Turmalina;TURMALINA|MG|-17.2828|-42.7285|Turmalina;TURVOLANDIA|MG|-21.8733|-45.7859|Turvolândia;UBA|MG|-21.1204|-42.9359|Ubá;UBAI|MG|-16.2885|-44.7783|Ubaí;UBAPORANGA|MG|-19.6351|-42.1059|Ubaporanga;UBARANA|SP|-21.1650|-49.7198|Ubarana;UBATUBA|SP|-23.4332|-45.0834|Ubatuba;UBERABA|MG|-19.7472|-47.9381|Uberaba;UBERLANDIA|MG|-18.9141|-48.2749|Uberlândia;UBIRAJARA|SP|-22.5272|-49.6613|Ubirajara;UCHOA|SP|-20.9511|-49.1713|Uchoa;UMBURATIBA|MG|-17.2548|-40.5779|Umburatiba;UNAI|MG|-16.3592|-46.9022|Unaí;UNIAO DE MINAS|MG|-19.5299|-50.3380|União de Minas;UNIAO PAULISTA|SP|-20.8862|-49.9025|União Paulista;URANIA|SP|-20.2455|-50.6455|Urânia;URU|SP|-21.7866|-49.2848|Uru;URUANA DE MINAS|MG|-16.0634|-46.2443|Uruana de Minas;URUCANIA|MG|-20.3521|-42.7370|Urucânia;URUCUIA|MG|-16.1244|-45.7352|Urucuia;URUPES|SP|-21.2032|-49.2931|Urupês;VALENCA|RJ|-22.2445|-43.7129|Valença;VALENTIM GENTIL|SP|-20.4217|-50.0889|Valentim Gentil;VALINHOS|SP|-22.9698|-46.9974|Valinhos;VALPARAISO|SP|-21.2229|-50.8699|Valparaíso;VARGEM|SP|-22.8870|-46.4124|Vargem;VARGEM ALEGRE|MG|-19.5988|-42.2949|Vargem Alegre;VARGEM ALTA|ES|-20.6690|-41.0179|Vargem Alta;VARGEM BONITA|MG|-20.3333|-46.3688|Vargem Bonita;VARGEM GRANDE DO RIO PARDO|MG|-15.3987|-42.3085|Vargem Grande do Rio Pardo;VARGEM GRANDE DO SUL|SP|-21.8322|-46.8913|Vargem Grande do Sul;VARGEM GRANDE PAULISTA|SP|-23.5993|-47.0220|Vargem Grande Paulista;VARGINHA|MG|-21.5556|-45.4364|Varginha;VARJAO DE MINAS|MG|-18.3741|-46.0313|Varjão de Minas;VARRE-SAI|RJ|-20.9276|-41.8701|Varre-Sai;VARZEA DA PALMA|MG|-17.5944|-44.7226|Várzea da Palma;VARZEA PAULISTA|SP|-23.2136|-46.8234|Várzea Paulista;VARZELANDIA|MG|-15.6992|-44.0278|Varzelândia;VASSOURAS|RJ|-22.4059|-43.6686|Vassouras;VAZANTE|MG|-17.9827|-46.9088|Vazante;VENDA NOVA DO IMIGRANTE|ES|-20.3270|-41.1355|Venda Nova do Imigrante;VERA CRUZ|SP|-22.2183|-49.8207|Vera Cruz;VERDELANDIA|MG|-15.5845|-43.6121|Verdelândia;VEREDINHA|MG|-17.3974|-42.7307|Veredinha;VERISSIMO|MG|-19.6657|-48.3118|Veríssimo;VERMELHO NOVO|MG|-20.0406|-42.2688|Vermelho Novo;VESPASIANO|MG|-19.6883|-43.9239|Vespasiano;VIANA|ES|-20.3825|-40.4933|Viana;VICOSA|MG|-20.7559|-42.8742|Viçosa;VIEIRAS|MG|-20.8670|-42.2401|Vieiras;VILA PAVAO|ES|-18.6091|-40.6090|Vila Pavão;VILA VALERIO|ES|-18.9958|-40.3849|Vila Valério;VILA VELHA|ES|-20.3417|-40.2875|Vila Velha;VINHEDO|SP|-23.0302|-46.9833|Vinhedo;VIRADOURO|SP|-20.8734|-48.2930|Viradouro;VIRGEM DA LAPA|MG|-16.8070|-42.3431|Virgem da Lapa;VIRGINIA|MG|-22.3264|-45.0965|Virgínia;VIRGINOPOLIS|MG|-18.8154|-42.7015|Virginópolis;VIRGOLANDIA|MG|-18.4738|-42.3067|Virgolândia;VISCONDE DO RIO BRANCO|MG|-21.0127|-42.8361|Visconde do Rio Branco;VISTA ALEGRE DO ALTO|SP|-21.1692|-48.6284|Vista Alegre do Alto;VITORIA|ES|-20.3155|-40.3128|Vitória;VITORIA BRASIL|SP|-20.1956|-50.4875|Vitória Brasil;VOLTA GRANDE|MG|-21.7671|-42.5375|Volta Grande;VOLTA REDONDA|RJ|-22.5202|-44.0996|Volta Redonda;VOTORANTIM|SP|-23.5446|-47.4388|Votorantim;VOTUPORANGA|SP|-20.4237|-49.9781|Votuporanga;WENCESLAU BRAZ|MG|-22.5368|-45.3626|Wenceslau Braz;ZACARIAS|SP|-21.0506|-50.0552|Zacarias";
let MUN=null; function munIdx(){ if(MUN) return MUN; MUN={}; MUN_TXT.split(";").forEach(l=>{ const [k,uf,la,lo,nome]=l.split("|"); MUN[k+"|"+uf]=[+la,+lo,nome,uf]; (MUN[k]=MUN[k]||[]).push([+la,+lo,nome,uf]); }); return MUN; }
function parseCidade(txt){ let t=norm(txt).replace(/\s*AGUARDANDO.*$/,"").trim(); if(!t) return null;
  const m=t.match(/^(.*?)\s*-\s*([A-Z]{2})\b/); return m?{nome:m[1].trim(),uf:m[2]}:{nome:t.replace(/\s*-\s*$/,""),uf:""}; }
const DYN={}; // nome normalizado (e nome|UF) -> id do nó dinâmico
function registraCidade(c){ if(!c||!c.id) return; if(!NO[c.id]){ const n={id:c.id,n:c.nome+(c.uf?" - "+c.uf:""),km:c.kmRota,ll:c.lat!=null?[c.lat,c.lon]:null,a:[],dyn:true,ramo:c.ramo||"",desvio:c.desvio||0,manual:c.origem==="manual"}; NOS.push(n); NO[c.id]=n; } else Object.assign(NO[c.id],{km:c.kmRota,ramo:c.ramo||"",desvio:c.desvio||0});
  DYN[c.chave]=c.id; if(c.uf) DYN[c.chave+"|"+c.uf]=c.id; }
// projeta a cidade no trajeto (BR-040 até Sete Lagoas e ramal BH–Betim) e estima o km da rota + o desvio até ela
function projetaCidade(lat,lon){
  const kx=Math.cos(lat*Math.PI/180)*111.32, ky=110.57;
  const segs=[]; for(let i=1;i<LINHA_SETE.length;i++) segs.push([LINHA_SETE[i-1],LINHA_SETE[i],""]); segs.push(["bh","betim","betim"]);
  let best=null;
  segs.forEach(([a,b,ramo])=>{ const A=NO[a],B=NO[b]; const ax=A.ll[1]*kx, ay=A.ll[0]*ky, bx=B.ll[1]*kx, by=B.ll[0]*ky, px=lon*kx, py=lat*ky;
    const dx=bx-ax, dy=by-ay, L2=dx*dx+dy*dy; let t=L2?((px-ax)*dx+(py-ay)*dy)/L2:0; t=Math.max(0,Math.min(1,t));
    const d=Math.hypot(px-(ax+t*dx), py-(ay+t*dy)); if(!best||d<best.d) best={d,km:A.km+t*(B.km-A.km),ramo}; });
  return {kmRota:Math.round(best.km), desvio:Math.round(best.d*1.3), ramo:best.ramo};
}
function kmAte(node, dest){ // km da cidade até o destino (Sete Lagoas ou Betim), somando o desvio até a rodovia
  const k=node.km, dv=node.desvio||0;
  if(dest==="betim") return Math.round((node.ramo==="betim" ? Math.abs(NO.betim.km-k) : (k<=NO.bh.km ? NO.betim.km-k : (k-NO.bh.km)+(NO.betim.km-NO.bh.km))) + dv);
  return Math.round((node.ramo==="betim" ? (k-NO.bh.km)+(NO.sete.km-NO.bh.km) : Math.abs(NO.sete.km-k)) + dv);
}
const cidTentadas=new Set();
async function autoCidades(fs){
  if(!state.db) return {novas:[],falhas:[]};
  const novas=[], falhas=[];
  for(const f of fs){ if(!f||!f.localizacao||noDe(f.localizacao)) continue; const pc=parseCidade(f.localizacao); if(!pc||!pc.nome) continue;
    const chave=pc.nome, tag=chave+"|"+pc.uf; if(cidTentadas.has(tag)) continue; cidTentadas.add(tag);
    const idx=munIdx(); const m=(pc.uf&&idx[tag]) || (idx[chave]&&idx[chave].length===1?idx[chave][0]:null);
    if(!m){ falhas.push(f.localizacao); continue; }
    const pj=projetaCidade(m[0],m[1]); const id="c-"+chave.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")+"-"+m[3].toLowerCase();
    const doc={id,chave,nome:m[2],uf:m[3],lat:m[0],lon:m[1],kmRota:pj.kmRota,desvio:pj.desvio,ramo:pj.ramo,origem:"auto",criadoEm:iso(new Date()),exemplo:f.localizacao};
    registraCidade(doc); novas.push(doc);
    try{ await state.db.doc("cidades/"+id).set(doc); }catch(e){}
  }
  return {novas,falhas};
}
function cidadesNaoReconhecidas(){ const s=new Set(); Object.values(state.follow).forEach(f=>{ if(!f.chegada && f.localizacao && !noDe(f.localizacao)) s.add(f.localizacao); }); return [...s]; }
/* ---------- painel BI ---------- */
const BI_SIT={crit:"Atrasado",warn:"Em risco",ok:"No prazo",info:"Sem veículo"};
const BI_CARGA={transito:"Em trânsito",porto:"No porto",descarga:"Aguardando descarga",entregue:"Entregue",semveic:"Sem veículo"};
const BI_TONE_COR={crit:"var(--crit)",warn:"var(--warn)",ok:"var(--ok)",info:"var(--info)",desc:"var(--bi-desc)",done:"var(--muted)"};
function biConfere(rows){ const uf=state.meta.ultimoFollow; if(!Object.keys(state.prog).length) return "";
  const G={nunca:[],anterior:[],saiu:[],semprog:[]}; rows.forEach(r=>{ const k=confereFollow(r); if(k) G[k].push(r); });
  if(state.bi.prog==="prog") G.semprog=[];
  const tot=G.nunca.length+G.anterior.length+G.saiu.length; const n=tot+G.semprog.length;
  const ordn=a=>a.sort((x,y)=>String(x.need).localeCompare(String(y.need))||x.cn.localeCompare(y.cn));
  const chip=r=>{ const fo=state.follow[r.cn]; const extra=r.saiu||""; return `<button type="button" class="cf-c" data-cfed="${esc(r.cn)}" title="Abrir ${esc(r.cn)} para alocar veículo / editar"><b class="mono">${esc(r.cn)}</b>${r.crit?' <span class="cf-s" title="'+esc(r.crit)+'">🚨</span>':""}<span class="sub">${r.need?"nec. "+esc(fmt(r.need).slice(0,11)):"sem necessidade"}${extra}</span></button>`; };
  G.anterior.forEach(r=>{ const fo=state.follow[r.cn]; r.saiu=fo&&fo.chegada?` · entregue ${esc(fmt(fo.chegada).slice(0,5))} (outra viagem)`:""; });
  G.saiu.forEach(r=>{ const fo=state.follow[r.cn]; r.saiu=fo?` · último: ${esc((fo.status||"—").toLowerCase())} ${esc(fmt(fo.atualizadoEm).slice(0,5))}`:""; });
  G.semprog.forEach(r=>{ r.saiu=r.f?" · "+esc((r.f.status||"").toLowerCase()):""; });
  const bloco=(k,t,d,cls)=>G[k].length?`<div class="cf-g ${cls}"><div class="cf-gh"><b>${t}</b><span class="cf-n">${G[k].length}</span><span class="sub">${d}</span></div><div class="cf-l">${ordn(G[k]).map(chip).join("")}</div></div>`:"";
  const aberto=state.cfAberto!==false;
  return `<section class="cf ${tot?"tem":"ok"}"><button type="button" class="cf-h" id="cf-tog" aria-expanded="${aberto}"><span class="cf-ic">${tot?"⚠️":"✅"}</span><div><b>Programação × Follow-up</b><span>${tot?`<b>${tot}</b> container${tot>1?"s":""} da programação ${tot>1?"estão":"está"} fora do último follow`:"Todos os containers da programação estão no último follow"}${uf?` · follow de ${esc(fmt(uf))}`:""} · respeita os filtros de data, criticidade e container acima</span></div><span class="cf-ar">${aberto?"▴":"▾"}</span></button>
    ${aberto&&n?`<div class="cf-b">${bloco("nunca","Sem follow","programados e sem nenhum registro no follow","r")}${bloco("anterior","Follow só de viagem anterior","o follow existente é de uma entrega antiga, antes do carregamento desta programação","o")}${bloco("saiu","Saíram do follow em aberto","estavam no follow anterior, sem entrega, e não vieram no último follow","y")}${bloco("semprog","No follow sem programação","aparecem no último follow mas não estão na programação Iveco","g")}</div>`:""}</section>`; }
function biLinhas(){
  const now=new Date(), lead=calcInd("tudo").lead;
  const keys=new Set([...Object.keys(state.follow),...Object.keys(state.prog).filter(cn=>progVigente(state.prog[cn]))]);
  return [...keys].map(cn=>{ const p0=state.prog[cn], p=progVigente(p0)?p0:undefined, f=p?followDe(cn):state.follow[cn];
    /* programação sem hora (00:00) e follow com hora no mesmo dia → vale a hora do follow */
    let need=(p&&p.necessidade)||(f&&f.data_prog)||null; if(p&&f&&f.data_prog&&/T00:00/.test(String(p.necessidade||""))&&!/T00:00/.test(String(f.data_prog))&&dia(f.data_prog)===dia(p.necessidade)) need=f.data_prog; const nd=toD(need);
    let carga;
    if(!f) carga="semveic";
    else if(enviarIveco(f)) carga="betim";
    else if(f.chegada && /ENTREG/i.test(f.status||"")) carga="entregue";
    else if(f.chegada) carga="descarga";
    else if(!f.prev_chegada && /AGUARDANDO CARREG|PORTO|PROGRAMA/i.test((f.localizacao||"")+" "+(f.status||""))) carga="porto";
    else carga="transito";
    const est = (carga==="porto"||carga==="semveic") && lead ? new Date(+now+lead*60000) : null;
    const ref = f&&f.chegada ? toD(f.chegada) : (f&&f.prev_chegada ? toD(f.prev_chegada) : (carga==="transito" ? ((restante(f,now)||{}).eta||est) : est));
    const gap = nd&&ref ? (ref-nd)/60000 : null;
    let tone;
    if(!nd) tone="info";
    else if(carga==="semveic") tone = nd<now ? "crit" : ((nd-now)/60000<360?"warn":"info");
    else if(gap==null) tone = nd<now ? "crit" : "warn";
    else tone = gap<=0 ? "ok" : gap<=RISK_MIN ? "warn" : "crit";
    if(carga==="betim"){ tone = nd&&nd<now ? "crit" : "warn"; }
    const gapB = carga==="betim"&&nd&&nd<now ? (now-nd)/60000 : null;
    const dest = /BETIM/.test(norm((f&&f.local_entrega)||"")) ? "Betim" : "Sete Lagoas";
    const manut=emManut(f); if(manut && carga!=="entregue") tone="crit";
    return {cn,p,f,need,nd,carga,est,ref:carga==="betim"?null:ref,gap:carga==="betim"?gapB:gap,tone,dest,manut,node:f?noDe(f.localizacao):null,crit:isCrit(p)?p.criticidade:"",placa:f?f.placa_cavalo:""};
  });
}
const CARGA_PADRAO=["transito","porto","descarga","semveic"];
const A = v => Array.isArray(v) ? v : (v ? [v] : []);
const mesmo = (a,b) => a.length===b.length && a.every(x=>b.includes(x));
function biFiltra(rows, ignora){
  const b=state.bi, hojeI=iso(new Date()).slice(0,10);
  const cn=A(b.cn), crit=A(b.crit), dias=A(b.dia).map(d=>d==="__hoje__"?hojeI:d), carga=A(b.carga), dest=A(b.dest), sit=A(b.sit);
  return rows.filter(r=>{
    if(cn.length && !cn.includes(r.cn)) return false;
    if(crit.length && !(crit.includes(r.crit) || (r.crit && crit.includes("__crit__")) || (!r.crit && crit.includes("__sem__")))) return false;
    if(dias.length && !dias.includes(dia(r.need))) return false;
    if(ignora!=="carga" && carga.length && !carga.includes(r.carga)) return false;
    if(ignora!=="dest" && dest.length && !dest.includes(r.dest)) return false;
    if(ignora!=="sit" && sit.length && !sit.includes(r.tone)) return false;
    if(b.prog==="prog" && !r.p) return false;
    return true;
  });
}
function truckSym(){ return `<symbol id="bi-wrench" viewBox="0 0 24 24"><path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/></symbol><symbol id="bi-truck" viewBox="0 0 34 22"><path d="M1.5 3.5h19v11h-19z" rx="2"/><path d="M21.5 6.5h6l4.5 4.6v3.4h-10.5z"/><path d="M23.3 7.8h3.6l2.8 2.9h-6.4z" fill="#ffffffcc"/><circle cx="7.5" cy="17" r="2.9" fill="#1c2a33" stroke="#fff" stroke-width="1.2"/><circle cx="26" cy="17" r="2.9" fill="#1c2a33" stroke="#fff" stroke-width="1.2"/></symbol>`; }
function truckIcon(tone,size){ const c=tone==="desc"?"var(--bi-desc)":tone==="done"?"var(--muted)":BI_TONE_COR[tone]||"var(--info)"; return `<svg class="bi-tk" width="${size||26}" height="${Math.round((size||26)*22/34)}" viewBox="0 0 34 22" aria-hidden="true"><use href="#bi-truck" fill="${c}" stroke="#fff" stroke-width="1.1"/></svg>`; }
const LON0=-44.45, LON1=-42.95, LAT0=-19.3, LAT1=-23.0;
function biMapa(rows, now){
  const W=840, H=800, PX=120, PY=30, K=Math.cos(21*Math.PI/180), CALL_X=430; let HF=H;
  const s=(H-PY*2)/(LAT0-LAT1);
  const X=lon=>PX+(lon-LON0)*K*s, Y=lat=>PY+(LAT0-lat)*s;
  const P=id=>[X(NO[id].ll[1]),Y(NO[id].ll[0])];
  const al=listaAlertas().map(a=>({a,s:statusAl(a,now)}));
  const alNo={}; al.forEach(o=>{ if(o.s.k!=="ativo"&&o.s.k!=="prog") return; if(o.a.sev==="baixa") return; (o.a.nos||[]).forEach(n=>{ (alNo[n]=alNo[n]||[]).push(o); }); });
  const sevCor=o=> o.s.k==="prog" ? "var(--info)" : (o.a.tipo==="acidente"||o.a.tipo==="interdicao"||o.a.sev==="alta") ? "var(--crit)" : "var(--warn)";
  let g=`<defs>${truckSym()}<pattern id="bi-dots" width="14" height="14" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1" fill="var(--bi-map-dot)"/></pattern>
    <filter id="bi-sh" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="1" stdDeviation="1.2" flood-opacity=".35"/></filter></defs>
    <rect width="${W}" height="__H__" fill="var(--bi-map)"/><rect width="${W}" height="__H__" fill="url(#bi-dots)"/>`;
  // divisa aproximada RJ/MG e rótulos de estado
  const yDiv=Y(-22.03);
  g+=`<path d="M0 ${yDiv+20} C ${CALL_X*.3} ${yDiv+8}, ${CALL_X*.6} ${yDiv-4}, ${CALL_X-10} ${yDiv-14}" fill="none" stroke="var(--bi-map-line)" stroke-width="1.4" stroke-dasharray="6 5"/>
    <text x="14" y="${Y(-20.75)}" class="bi-st">MINAS GERAIS</text><text x="14" y="${Y(-22.75)}" class="bi-st">RIO DE JANEIRO</text>
    <text x="14" y="${yDiv+36}" class="bi-sm">divisa RJ/MG (aprox.)</text>
    <ellipse cx="${X(-43.14)}" cy="${Y(-22.83)}" rx="14" ry="22" fill="var(--bi-water)"/><text x="${X(-43.14)}" y="${Y(-22.83)+34}" text-anchor="middle" class="bi-sm">Baía de Guanabara</text>`;
  // rotas
  const linha=ids=>ids.map((id,i)=>(i?"L":"M")+P(id).join(" ")).join(" ");
  g+=`<path d="${linha(LINHA_SETE)}" fill="none" stroke="var(--bi-road-bg)" stroke-width="9" stroke-linejoin="round" stroke-linecap="round"/>
      <path d="${linha(["bh","betim"])}" fill="none" stroke="var(--bi-road-bg)" stroke-width="9" stroke-linecap="round"/>
      <path d="${linha(LINHA_SETE)}" fill="none" stroke="var(--bi-road)" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"/>
      <path d="${linha(["bh","betim"])}" fill="none" stroke="var(--bi-road)" stroke-width="4" stroke-linecap="round"/>`;
  // trechos com alerta (meio-segmento antes e depois do nó)
  const vizinhos=id=>{ const r=id==="betim"?ROTA.BETIM:(LINHA_SETE.includes(id)?LINHA_SETE:ROTA.SETE); const i=r.indexOf(id); return [r[i-1],r[i+1]].filter(Boolean); };
  Object.entries(alNo).forEach(([id,os])=>{ const o=os.sort((a,b)=>(a.s.k==="ativo"?0:1)-(b.s.k==="ativo"?0:1))[0]; const [x,y]=P(id);
    vizinhos(id).forEach(v=>{ const [vx,vy]=P(v); g+=`<path d="M${x} ${y} L${(x+vx)/2} ${(y+vy)/2}" stroke="${sevCor(o)}" stroke-width="6" stroke-linecap="round" ${o.s.k==="prog"?'stroke-dasharray="4 5"':""} opacity=".9"/>`; }); });
  // cidades (rótulos à esquerda; os caminhões ficam nos quadros à direita)
  const lab={pleopoldo:[10,4,"start"],matozinhos:[10,4,"start"],bh:[10,-7,"start"],serra:[-10,9,"end"],petropolis:[-10,-5,"end"],matias:[-10,6,"end"],simao:[-10,2,"end"]};
  const comVeic=new Set(rows.filter(r=>r.f&&r.node).map(r=>r.node));
  NOS.forEach(n=>{ if(n.dyn && (!n.ll || !comVeic.has(n.id) || n.ll[1]<LON0 || n.ll[1]>LON1 || n.ll[0]>LAT0 || n.ll[0]<LAT1)) return; const [x,y]=P(n.id), l=lab[n.id]||[-10,4,"end"], dest=n.id==="sete"||n.id==="betim"||n.id==="rio";
    g+=`<circle cx="${x}" cy="${y}" r="${dest?6:4}" fill="var(--bi-city)" stroke="var(--bi-road-bg)" stroke-width="2"/>`;
    if(dest) g+=`<circle cx="${x}" cy="${y}" r="10" fill="none" stroke="var(--bi-green)" stroke-width="1.6"/>`;
    g+=`<text x="${x+l[0]}" y="${y+l[1]}" text-anchor="${l[2]}" class="bi-city${dest?" dest":""}">${esc(n.n)}</text>`; });
  // alertas (triângulos)
  Object.entries(alNo).forEach(([id,os])=>{ const [x,y]=P(id), o=os[0], c=sevCor(o), at=os.some(z=>z.s.k==="ativo");
    g+=`<g class="bi-al" data-alno="${id}"><title>${esc(os.map(z=>`${z.a.titulo} — ${z.s.t}`).join("\n"))}</title><path d="M${x} ${y-22} l9 15 h-18z" fill="${at?c:"var(--surface)"}" stroke="${c}" stroke-width="1.8" filter="url(#bi-sh)"/><text x="${x}" y="${y-10}" text-anchor="middle" style="font-size:10px;font-weight:800;fill:${at?"#fff":c}">!</text></g>`; });
  // cidades com veículo em manutenção
  [...new Set(rows.filter(r=>r.manut&&r.node).map(r=>r.node))].forEach(id=>{ const [x,y]=P(id); g+=`<g><title>Veículo em manutenção</title><circle cx="${x-16}" cy="${y+14}" r="9" fill="var(--crit)" stroke="#fff" stroke-width="1.5" filter="url(#bi-sh)"/><use href="#bi-wrench" x="${x-21.5}" y="${y+8.5}" width="11" height="11" fill="#fff"/></g>`; });
  // caminhões por cidade, em quadros com o número dos containers
  const noMapa=id=>{ const n=NO[id]; return n&&n.ll&&n.ll[1]>=LON0&&n.ll[1]<=LON1&&n.ll[0]<=LAT0&&n.ll[0]>=LAT1; };
  /* sem placa e ainda não carregado = aguardando veículo no local (ex.: Sada Betim), não é caminhão na estrada */
  const agNo={}, porNo={}; rows.filter(r=>r.f&&r.node&&noMapa(r.node)).forEach(r=>{ if(!r.placa&&r.carga!=="descarga"&&r.carga!=="entregue"&&!r.f.chegada&&!r.f.inicio){ (agNo[r.node]=agNo[r.node]||[]).push(r); return; } const k=r.placa||r.cn; const o=(porNo[r.node]=porNo[r.node]||{}); (o[k]=o[k]||[]).push(r); });
  const RK={crit:0,warn:1,ok:2,info:3,desc:4,done:5};
  const grupos=Object.entries(porNo).map(([id,veics])=>{ const lista=Object.entries(veics).map(([placa,rs])=>{ const t=rs.map(r=>r.tone).sort((a,b)=>RK[a]-RK[b])[0];
      const all=rs.every(r=>r.carga==="entregue"), desc=rs.every(r=>r.carga==="descarga"||r.carga==="entregue");
      const pior=rs.slice().sort((a,b)=>(b.gap??-1e9)-(a.gap??-1e9))[0];
      return {placa,rs,tone: all?"done": desc&&t!=="crit"?"desc":t, crit:rs.some(r=>r.crit), manut:rs.some(r=>r.manut), gap:pior.gap, gt:pior.tone}; })
      .sort((a,b)=>(RK[a.tone]??5)-(RK[b.tone]??5));
    const [x,y]=P(id); lista.forEach(v=>{ v.lin=Math.ceil(v.rs.length/2); v.hh=35+(v.lin-1)*13; }); return {id,x,y,lista,h:24+lista.reduce((s,v)=>s+v.hh,0)}; });
  const sv=rows.filter(r=>r.carga==="semveic").sort((a,b)=>(RK[a.tone]??5)-(RK[b.tone]??5)||String(a.need).localeCompare(String(b.need)));
  if(sv.length){ const [x,y]=P("rio"); grupos.push({id:"__sv",x,y:y+1,sv:true,lista:sv.map(r=>({placa:"",rs:[r],tone:r.tone,crit:!!r.crit,gap:r.gap,gt:r.tone,sv:true})),h:24+sv.length*35}); }
  Object.entries(agNo).forEach(([id,rs])=>{ const [x,y]=P(id); rs.sort((a,b)=>(RK[a.tone]??5)-(RK[b.tone]??5)||String(a.need).localeCompare(String(b.need)));
    const sada=rs.some(r=>/SADA/i.test(r.f.localizacao||"")); grupos.push({id,x,y:y+0.5,sv:true,ag:true,nome:(sada?"Sada ":"")+NO[id].n+" · aguardando veículo",lista:rs.map(r=>({placa:"",rs:[r],tone:r.tone,crit:!!r.crit,gap:r.gap,gt:r.tone,sv:true})),h:24+rs.length*35}); });
  grupos.sort((a,b)=>a.y-b.y);
  const CX=CALL_X, CW=W-CALL_X-10; let fundo=PY-10;
  grupos.forEach(gr=>{ gr.by=Math.max(gr.y-gr.h/2, fundo+8); fundo=gr.by+gr.h; });
  HF=Math.max(H, fundo+PY);
  grupos.forEach(gr=>{ const t=gr.lista[0].tone, cor=gr.sv?"var(--info)":t==="desc"?"var(--bi-desc)":t==="done"?"var(--muted)":BI_TONE_COR[t];
    const ay=Math.min(Math.max(gr.y, gr.by+10), gr.by+gr.h-10);
    g+=`<path d="M${gr.x+5} ${gr.y} C ${gr.x+40} ${gr.y}, ${CX-40} ${ay}, ${CX} ${ay}" fill="none" stroke="${cor}" stroke-width="1.4" opacity=".75"/><circle cx="${gr.x}" cy="${gr.y}" r="7" fill="none" stroke="${cor}" stroke-width="2"/>`;
    g+=`<rect x="${CX}" y="${gr.by}" width="${CW}" height="${gr.h}" rx="7" fill="var(--surface)" stroke="${cor}" stroke-width="1.4" filter="url(#bi-sh)"/>
       <rect x="${CX}" y="${gr.by}" width="5" height="${gr.h}" rx="2" fill="${cor}"/>
       <text x="${CX+14}" y="${gr.by+16}" class="bi-gh">${gr.ag?esc(gr.nome):gr.sv?"Sem veículo alocado":esc(NO[gr.id].n)}</text><text x="${CX+CW-10}" y="${gr.by+16}" text-anchor="end" class="bi-gc">${(()=>{ if(gr.sv) return gr.lista.length+" container"+(gr.lista.length>1?"s":""); const nv=gr.lista.filter(v=>v.rs[0].f&&v.rs[0].f.placa_cavalo).length, ns=gr.lista.length-nv; return [nv?nv+" veículo"+(nv>1?"s":""):"", ns?ns+" sem placa":""].filter(Boolean).join(" · "); })()}</text>`;
    if(gr.sv){ gr.lista.forEach((v,i)=>{ const ry=gr.by+22+i*35, r=v.rs[0], c=BI_TONE_COR[v.tone]||"var(--info)";
        g+=`<g class="bi-veh bi-sv" data-cnsv="${esc(r.cn)}" tabindex="0" role="button" aria-label="Container ${esc(r.cn)} sem veículo alocado"><title>${esc(r.cn)} · sem veículo alocado · clique para alocar</title>
          <rect x="${CX+7}" y="${ry-1}" width="${CW-12}" height="33" rx="4" fill="transparent"/>
          <use href="#bi-truck" x="${CX+12}" y="${ry+1}" width="24" height="15.5" fill="none" stroke="${c}" stroke-width="1.6" stroke-dasharray="2.5 2"/>
          ${v.crit?`<circle cx="${CX+36}" cy="${ry+3}" r="4.2" fill="var(--crit)" stroke="#fff" stroke-width="1.1"/><text x="${CX+36}" y="${ry+5.6}" text-anchor="middle" style="font-size:7px;font-weight:800;fill:#fff">!</text>`:""}
          <text x="${CX+44}" y="${ry+13}" class="bi-cn">${esc(r.cn)}</text>
          <text x="${CX+44}" y="${ry+28}" class="bi-rest">${r.need?"necessidade "+esc(fmt(r.need)):"sem necessidade informada"}${r.crit?" · "+esc(r.crit.toLowerCase()):""}</text>
          <text x="${CX+CW-10}" y="${ry+13}" text-anchor="end" class="bi-gap" style="fill:${v.gt==="info"?"var(--muted)":BI_TONE_COR[v.gt]||"var(--muted)"}">${v.gap!=null?dur(v.gap):"—"}</text></g>`; }); return; }
    let acc=0; gr.lista.forEach((v,i)=>{ const ry=gr.by+22+acc; acc+=v.hh||35; const rest=restante(v.rs[0].f,now), c=v.tone==="desc"?"var(--bi-desc)":v.tone==="done"?"var(--muted)":BI_TONE_COR[v.tone], sel=state.bi.sel===v.placa;
      const cns=v.rs.map(r=>r.cn);
      g+=`<g class="bi-veh${sel?" sel":""}" data-placa="${esc(v.placa)}" tabindex="0" role="button" aria-label="Veículo ${esc(v.placa)}, containers ${esc(cns.join(" e "))}"><title>${esc(v.placa)} · ${esc(v.rs.map(r=>`${r.cn} (${BI_SIT[r.tone]}${r.gap!=null?" "+dur(r.gap):""})`).join(", "))}</title>
        <rect x="${CX+7}" y="${ry-1}" width="${CW-12}" height="${(v.hh||35)-2}" rx="4" fill="${sel?"var(--surface2)":"transparent"}" ${sel?'stroke="var(--ink)" stroke-width="1.2"':""}/>
        <use href="#bi-truck" x="${CX+12}" y="${ry+1}" width="24" height="15.5" fill="${c}" stroke="#fff" stroke-width="1.1"/>
        ${v.crit?`<circle cx="${CX+36}" cy="${ry+3}" r="4.2" fill="var(--crit)" stroke="#fff" stroke-width="1.1"/><text x="${CX+36}" y="${ry+5.6}" text-anchor="middle" style="font-size:7px;font-weight:800;fill:#fff">!</text>`:""}
        ${(()=>{ const ln=[]; for(let j=0;j<cns.length;j+=2) ln.push(cns.slice(j,j+2).join(" · ")); return ln.map((t,j)=>`<text x="${CX+44}" y="${ry+13+j*13}" class="bi-cn">${esc(t)}</text>`).join(""); })()}
        ${v.manut?`<g transform="translate(${CX+2} ${ry+13})"><circle cx="7" cy="7" r="7.5" fill="var(--crit)" stroke="#fff" stroke-width="1.2"/><use href="#bi-wrench" x="2.5" y="2.5" width="9" height="9" fill="#fff"/></g>`:""}
        <text x="${CX+44}" y="${ry+28+((v.lin||1)-1)*13}" class="bi-rest" ${v.manut?'style="fill:var(--crit);font-weight:700"':""}>${v.manut?esc(manutTxt(v.rs[0].f)):rest?esc(rest.txt):!v.rs[0].f.placa_cavalo?esc(((v.rs[0].f.status||"").toLowerCase()||"aguardando")+" · sem placa informada"):"posição sem distância"}</text>
        <text x="${CX+CW-10}" y="${ry+13}" text-anchor="end" class="bi-gap" style="fill:${v.gt==="info"?"var(--muted)":BI_TONE_COR[v.gt]||"var(--muted)"}">${v.tone==="done"?"entregue":v.tone==="desc"?"descarga":v.gap!=null?dur(v.gap):"—"}</text></g>`; });
  });
  return `<svg viewBox="0 0 ${W} ${HF}" class="bi-map" role="img" aria-label="Mapa do corredor Rio de Janeiro – Minas Gerais com posição dos veículos, containers e alertas">${g.replace(/__H__/g,HF)}</svg>`;
}
function biDecomp(base){
  const col=(titulo,dim,itens,chave,ordem)=>{ const tot=Math.max(1,...itens.map(x=>x.n)); const selA=A(state.bi[chave]).filter(v=>itens.some(x=>x.k===v)), selv=selA.length&&!(chave==="carga"&&mesmo(selA,CARGA_PADRAO.filter(v=>itens.some(x=>x.k===v))))?selA:[];
    return `<div class="bi-dcol"><div class="bi-dh">${titulo}${selv.length?` <button class="bi-x" data-clr="${chave}" type="button" aria-label="Limpar ${titulo}">×</button>`:""}</div>${
      itens.sort((a,b)=>ordem?ordem.indexOf(a.k)-ordem.indexOf(b.k):b.n-a.n).map(x=>`<button type="button" class="bi-bar${selv.includes(x.k)?" on":""}${selv.length&&!selv.includes(x.k)?" dim":""}" data-dk="${chave}" data-dv="${esc(x.k)}">
        <span class="bi-bl">${esc(x.t)}</span><span class="bi-bt"><i style="width:${Math.max(4,x.n/tot*100)}%;${x.c?`background:${x.c}`:""}"></i></span><span class="bi-bn">${x.n}</span></button>`).join("")}</div>`; };
  const cnt=(rows,fn)=>{ const m={}; rows.forEach(r=>{ const k=fn(r); m[k]=(m[k]||0)+1; }); return m; };
  const rC=biFiltra(base,"carga"), rD=biFiltra(base,"dest"), rS=biFiltra(base,"sit"), rT=biFiltra(base);
  const mc=cnt(rC,r=>r.carga), md=cnt(rD,r=>r.dest), ms=cnt(rS,r=>r.tone);
  return `<div class="bi-dtree">
    <div class="bi-dcol"><div class="bi-dh">Processos</div><div class="bi-bar total"><span class="bi-bl">Iveco</span><span class="bi-bt"><i style="width:100%"></i></span><span class="bi-bn">${rT.length}</span></div></div>
    ${col("Status da carga","carga",Object.entries(mc).map(([k,n])=>({k,n,t:BI_CARGA[k]})),"carga",["transito","porto","betim","descarga","semveic","entregue"])}
    ${col("Destino","dest",Object.entries(md).map(([k,n])=>({k,n,t:k})),"dest")}
    ${col("Situação","sit",Object.entries(ms).map(([k,n])=>({k,n,t:BI_SIT[k],c:BI_TONE_COR[k]})),"sit",["crit","warn","ok","info"])}
  </div>`;
}
function biVeiculo(placa, rows, now, lead){
  const rs=rows.filter(r=>r.placa===placa); if(!rs.length) return "";
  const f=rs[0].f;
  const ex=exposicao(f,now,lead).filter(x=>x.nivel==="crit"||x.nivel==="warn");
  return `<div class="bi-pop"><div class="bi-pop-h">${truckIcon(rs[0].tone,34)}<div><b class="mono">${esc(placa)}</b>${f.placa_reboque?` <span class="sub mono">/ ${esc(f.placa_reboque)}</span>`:""}<div class="sub">${esc(f.motorista||"")} · ${esc(f.marca||"")}</div></div><button class="btn sm ve-btn" type="button" data-ve="${esc(placa)}" data-vcn="${esc(rs[0].cn)}">✎ Editar</button><button class="bi-x" data-close="1" type="button" aria-label="Fechar">×</button></div>
    <div class="bi-pop-l"><span>${esc(lugar(f.localizacao))}</span><span class="sub">→ ${esc(lugar(f.local_entrega))} · follow ${f.atualizadoEm?fmtH(f.atualizadoEm):"—"}</span></div>
    ${emManut(f)?`<div class="manut-bar">🔧 ${esc(manutTxt(f))}</div>`:""}
    ${(()=>{ const q=restante(f,now); if(!q||q.chegou) return ""; return `<div class="bi-rest-box"><div><b>${q.km!=null?q.km+" km":"—"}</b><span>até a Iveco ${esc(q.dest)}</span></div><div><b>${q.vencida?"vencida":(q.est?"≈ ":"")+dur(q.min).slice(1)}</b><span>${q.vencida?"previsão "+fmtH(f.prev_chegada):"para chegar"+(q.est?" (estimado)":"")}</span></div><div><b>${q.eta?fmtH(iso(q.eta)):"—"}</b><span>${q.est?"chegada estimada":"previsão do follow"}</span></div></div>`; })()}
    ${rs.map(r=>`<div class="bi-pop-c" data-cn="${esc(r.cn)}"><div><span class="cn">${esc(r.cn)}</span> ${r.crit?`<span class="linha">${esc(r.crit)}</span>`:""}</div>
      <div class="bi-pop-g"><span>Necessidade<b>${r.need?fmt(r.need):"—"}</b></span><span>${r.f.chegada?"Chegada":"Previsão"}<b>${r.ref?fmt(iso(r.ref)):"—"}${r.est&&!r.f.prev_chegada?" ≈":""}</b></span><span>Desvio<b class="gap ${r.tone==="info"?"":r.tone}">${r.gap!=null?dur(r.gap):"—"}</b></span></div>
      <span class="pill ${r.tone==="info"?"mut":r.tone}">${esc(BI_CARGA[r.carga])} · ${esc(BI_SIT[r.tone])}</span></div>`).join("")}
    ${ex.length?`<div class="chips">${ex.map(x=>`<span class="chip ${x.nivel}">⚠ ${esc(x.txt)}</span>`).join("")}</div>`:""}
  </div>`;
}
const kSide=x=>String(x).split("<br>").map(l=>l.replace(/^(.*?)<b>/,"<span>$1</span><b>")).join("");
function renderBI(){
  const el=$("#v-bi"); if(el.hidden) return;
  const now=new Date(), lead=calcInd("tudo").lead, b=state.bi;
  const base=biLinhas(), rows=biFiltra(base);
  const naMapa=rows.filter(r=>r.f&&r.node), veics=new Set(naMapa.filter(r=>r.carga!=="entregue").map(r=>r.placa));
  const k=(t,v,s,cls,side)=>`<div class="bi-k ${cls||""}"><div class="bi-kv">${v}</div><div class="bi-kt">${t}</div>${side?`<div class="bi-ks">${kSide(side)}</div>`:""}${s?`<div class="bi-kx">${s}</div>`:""}</div>`;
  const nT=rows.filter(r=>r.carga==="transito").length, nP=rows.filter(r=>r.carga==="porto").length, nD=rows.filter(r=>r.carga==="descarga").length, nE=rows.filter(r=>r.carga==="entregue").length, nS=rows.filter(r=>r.carga==="semveic").length;
  const atr=rows.filter(r=>r.tone==="crit"), risco=rows.filter(r=>r.tone==="warn"), ok=rows.filter(r=>r.tone==="ok");
  const critR=rows.filter(r=>r.crit && r.tone!=="ok" && r.carga!=="entregue");
  const alAt=listaAlertas().filter(a=>statusAl(a,now).k==="ativo"), alGr=alAt.filter(a=>a.tipo==="acidente"||a.tipo==="interdicao"||a.sev==="alta");
  const comNeed=rows.filter(r=>r.nd&&r.carga!=="semveic"); const ader=comNeed.length?Math.round(comNeed.filter(r=>r.tone==="ok").length/comNeed.length*100):null;
  const dias=[...new Set(base.map(r=>dia(r.need)).filter(Boolean))].sort().reverse();
  const niveis=[...new Set(base.map(r=>r.crit).filter(Boolean))];
  const lista=rows.slice().sort((a,c)=>({crit:0,warn:1,info:2,ok:3}[a.tone]-{crit:0,warn:1,info:2,ok:3}[c.tone])||(!!c.crit-!!a.crit)||String(a.need).localeCompare(String(c.need)));
  el.innerHTML=`
  <div class="bi-top">
    <div class="bi-head"><div class="bi-brand"><span class="bi-logo">${truckIcon("ok",30).replace('fill="var(--ok)"','fill="#fff"')}</span><div><div class="bi-title">Carga Iveco</div><div class="bi-upd"><span>Última atualização</span><br>${state.meta.ultimoFollow?fmt(state.meta.ultimoFollow):"—"}</div></div></div><div class="bi-acts"><button class="bi-clear bi-cons" id="bi-cons" type="button"><svg width="15" height="15" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-3px;margin-right:6px"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M15.5 15.5 21 21" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>Consulta rápida</button><button class="bi-clear" id="bi-clear" type="button">Limpar filtros</button>    <button class="bi-wa" id="bi-wa" type="button"><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align:-3px;margin-right:6px"><path d="M2.5 11.2 21 3.2l-6.3 17.6-3.4-7.3-8.8-2.3z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M11.3 13.5 21 3.2" stroke="currentColor" stroke-width="2"/></svg>Enviar resumo</button></div></div>
    <div class="bi-fields">
    ${msel("cn","Container / placa",base.slice().sort((x,y)=>x.cn.localeCompare(y.cn)).map(r=>({v:r.cn,t:r.cn,sub:[r.placa,r.f?lugar(r.f.localizacao):"sem veículo",r.crit].filter(Boolean).join(" · ")})),b.cn,{busca:true})}
    ${msel("crit","Processos",[{v:"__crit__",t:"Qualquer crítico Iveco"}].concat(niveis.map(n=>({v:n,t:n}))).concat([{v:"__sem__",t:"Sem criticidade"}]),b.crit)}
    ${msel("dia","Expectativa na planta",[{v:"__hoje__",t:`Hoje (${diaBR(iso(new Date()).slice(0,10)).slice(0,5)})`,sub:"acompanha a data atual"}].concat(dias.map(d=>({v:d,t:diaBR(d)}))),b.dia)}
    ${msel("carga","Status da carga",Object.entries(BI_CARGA).map(([kk,t])=>({v:kk,t})),b.carga,{padrao:CARGA_PADRAO,rotuloPadrao:"Em operação"})}
    ${msel("sit","Situação",Object.entries(BI_SIT).map(([kk,t])=>({v:kk,t})),b.sit)}
    ${msel("dest","Planta de entrega",[{v:"Sete Lagoas",t:"Sete Lagoas"},{v:"Betim",t:"Betim"}],b.dest)}
    <label class="bi-f" title="Follow + programação: todos os processos. Só programação: apenas os que estão na programação Iveco."><span>Base</span><select id="bi-prog"><option value="">Follow + prog.</option><option value="prog" ${b.prog==="prog"?"selected":""}>Só programação</option></select></label>
    </div>
    <div class="bi-row2">
    <div class="bi-quick" role="group" aria-label="Seleções rápidas"><span class="bi-ql">Seleção rápida</span>
      <button type="button" data-q="betim-hoje" aria-pressed="${mesmo(A(b.dest),["Betim"])&&mesmo(A(b.dia),["__hoje__"])}">Planta Betim · expectativa hoje</button>
      <button type="button" data-q="sete-hoje" aria-pressed="${mesmo(A(b.dest),["Sete Lagoas"])&&mesmo(A(b.dia),["__hoje__"])}">Planta Sete Lagoas · expectativa hoje</button>
      <button type="button" data-q="hoje" aria-pressed="${!A(b.dest).length&&mesmo(A(b.dia),["__hoje__"])}">Todas as plantas · hoje</button>
      <button type="button" data-q="betim" aria-pressed="${mesmo(A(b.dest),["Betim"])&&!A(b.dia).length}">Planta Betim · todas as datas</button></div>
    </div>
  </div>
  <div class="bi-kpis">
    ${(()=>{ const hj=iso(now).slice(0,10), cnA=A(b.cn), crA=A(b.crit), deA=A(b.dest); const dSel=[...new Set(A(b.dia).map(d=>d==="__hoje__"?hj:d))].sort(), dK=dSel.length?dSel:[hj], soHoje=dK.length===1&&dK[0]===hj;
      const hoje=base.filter(r=>(r.p||b.prog!=="prog")&&dK.includes(dia(r.need))&&(!cnA.length||cnA.includes(r.cn))&&(!deA.length||deA.includes(r.dest))&&(!crA.length||crA.includes(r.crit)||(r.crit&&crA.includes("__crit__"))||(!r.crit&&crA.includes("__sem__"))));
      const c=f=>hoje.filter(f).length, ent=c(r=>r.carga==="entregue"||r.carga==="descarga"), via=c(r=>r.carga==="transito"||r.carga==="porto"), sv=c(r=>r.carga==="semveic"), at=c(r=>r.tone==="crit");
      return `<div class="bi-k bi-k-hoje" role="button" tabindex="0" id="bi-k-hoje" title="Filtrar os processos com expectativa na planta hoje"><div class="bi-kv">${hoje.length}</div><div class="bi-kt">${soHoje?"Processos do dia":dK.length===1?"Processos de "+diaBR(dK[0]).slice(0,5):"Processos das datas"}</div><div class="bi-ks">${kSide(`Na planta <b>${ent}</b><br>Em viagem <b>${via}</b><br>Sem veículo <b>${sv}</b>`)}</div><div class="bi-kx">expectativa na planta ${dK.length>4?dK.length+" datas":dK.map(d=>diaBR(d).slice(0,5)).join(", ")}${at?` · ${at} atrasado${at>1?"s":""}`:""}</div></div>`; })()}
    ${k("Em viagem",nT+nP,"",null,`Trânsito <b>${nT}</b><br>No porto <b>${nP}</b>`)}
    ${k("Veículos no mapa",veics.size,"",null,`Descarga <b>${nD}</b><br>Entregues <b>${nE}</b>`)}
    ${k("Atrasados",atr.length,"previsão acima de 2h da necessidade","red")}
    ${k("Em risco",risco.length,"até 2h de atraso ou sem previsão","amber")}
    ${k("Críticos Iveco em risco",critR.length,niveis.join(" · ")||"—",critR.length?"red":"")}
    ${(()=>{ const mv=[...new Set(rows.filter(r=>r.manut).map(r=>r.placa))]; return k("🔧 Em manutenção",mv.length,mv.length?mv.join(" · "):"nenhum veículo parado",mv.length?"red pulse":""); })()}
    ${k("Sem veículo",nS,"programados sem follow",nS?"grey":"")}
    ${k("Alertas nas rodovias",alAt.length,alGr.length?`${alGr.length} grave${alGr.length>1?"s":""}`:"sem acidentes ativos",alGr.length?"red":alAt.length?"amber":"")}
    ${k("Aderência",ader==null?"—":ader+"%","no prazo sobre programados",ader!=null&&ader>=90?"":"grey")}
  </div>
  ${(()=>{ const fs=[]; const vistos=new Set(); rows.filter(r=>r.manut).forEach(r=>{ if(vistos.has(r.placa)) return; vistos.add(r.placa); fs.push(r.f); }); if(!fs.length) return "";
     return `<section class="manut-alert" role="alert"><div class="ma-h"><span class="ma-ic">🔧</span><div><b>${fs.length} veículo${fs.length>1?"s":""} em manutenção</b><span>Alerta para o cliente: containers parados até a liberação ou troca do cavalo.</span></div><button class="btn" type="button" id="manut-copy">Copiar aviso ao cliente</button></div>
       <div class="ma-list">${fs.map(f=>{ const cns=rows.filter(r=>r.placa===f.placa_cavalo); return `<div class="ma-i" data-bp="${esc(f.placa_cavalo||"")}"><b class="mono">${esc(f.placa_cavalo||"—")}</b>${f.placa_reboque?`<span class="sub mono"> / ${esc(f.placa_reboque)}</span>`:""} · ${cns.map(r=>`<span class="cn">${esc(r.cn)}</span>${r.crit?` <span class="linha">${esc(r.crit)}</span>`:""}`).join(" + ")}<div class="sub">${esc(manutTxt(f))}${f.motorista?` · ${esc(f.motorista)}`:""}</div></div>`; }).join("")}</div></section>`; })()}
  ${b.consulta&&A(b.cn).length?`<section class="cons-ban" role="status"><span class="cons-ic"><svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="M15.5 15.5 21 21" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg></span><div><b>Consulta rápida: ${A(b.cn).length} container${A(b.cn).length>1?"s":""}</b><span>${veics.size} veículo${veics.size===1?"":"s"} no mapa${A(b.cn).length-rows.filter(r=>r.f).length?` · ${A(b.cn).length-rows.filter(r=>r.f).length} sem veículo alocado`:""} · todos os status, inclusive entregues</span></div><button class="btn" type="button" id="cons-abrir">Editar consulta</button><button class="btn" type="button" id="cons-sair">Voltar à visão completa</button></section>`:""}
  ${biConfere(biFiltra(base,"carga"))}
  ${chegSecao(biFiltra(base,"carga").filter(r=>r.carga!=="semveic"), now)}
  <div class="bi-body">
    <section class="bi-panel bi-left">
      <h3>Resumo operacional</h3>
      ${biDecomp(base)}
      <div class="bi-lh"><h3>Veículos e containers <span class="sec-n">${lista.length}</span></h3><div class="bi-leg">${["crit","warn","ok"].map(t=>`<span>${truckIcon(t,20)}${BI_SIT[t]}</span>`).join("")}<span>${truckIcon("desc",20)}Descarga</span><span>${truckIcon("info",20)}Sem veículo</span></div></div>
      <div class="bi-list">${lista.length?lista.map(r=>`<div class="bi-row${state.bi.sel&&state.bi.sel===r.placa?" sel":""}" data-bp="${esc(r.placa||"")}" data-cn="${esc(r.cn)}" tabindex="0">
        ${truckIcon(r.carga==="descarga"?"desc":r.carga==="entregue"?"done":r.tone,30)}
        <div class="bi-rc"><span class="cn">${esc(r.cn)}</span>${r.crit?` <span class="linha">${esc(r.crit)}</span>`:""}${r.manut?` <span class="manut-tag">🔧 manutenção</span>`:""}<div class="sub">${r.f?`${esc(r.placa)} · ${esc(lugar(r.f.localizacao))}`:"Sem veículo alocado"}</div></div>
        <div class="bi-rn"><span class="sub">Necessidade</span><b>${r.need?fmt(r.need):"—"}</b></div>
        <div class="bi-rn"><span class="sub">${r.f&&r.f.chegada?"Chegada":"Previsão"}</span><b>${r.ref?fmt(iso(r.ref)):"—"}${r.est&&!(r.f&&r.f.prev_chegada)&&!(r.f&&r.f.chegada)?" ≈":""}</b>${(()=>{ const q=r.f&&!r.f.chegada?restante(r.f,now):null; return q?`<span class="sub bi-faltam">faltam ${esc(q.curto)}</span>`:""; })()}</div>
        <div class="bi-rg"><span class="gap ${r.tone==="info"?"":r.tone}">${r.gap!=null?dur(r.gap):"—"}</span><span class="pill ${r.tone==="info"?"mut":r.tone}">${esc(BI_SIT[r.tone])}</span></div><button class="bi-ed" type="button" data-ed="${esc(r.cn)}" data-edp="${esc(r.placa||"")}" title="${r.f?"Editar dados":"Alocar veículo / editar"}" aria-label="Editar ${esc(r.cn)}">✎</button></div>`).join(""):'<div class="empty">Nenhum processo para os filtros.</div>'}</div>
    </section>
    <section class="bi-panel bi-right">
      <div class="bi-mh"><h3>Posição dos veículos</h3><span class="sub">${veics.size} veículo${veics.size===1?"":"s"}${(()=>{ const n=rows.filter(r=>r.carga==="semveic").length; return n?` · ${n} sem veículo alocado`:""; })()} · corredor BR-040 / BR-381</span></div>
      <div class="bi-mapbox">${biMapa(biFiltra(base,"carga").filter(r=>rows.includes(r)||(r.carga==="entregue"&&((r.f&&r.f.chegada&&dia(r.f.chegada)===iso(now).slice(0,10))||A(b.dia).length))).filter(r=>r.carga!=="entregue"||A(b.carga).includes("entregue")||(r.f&&r.f.chegada&&dia(r.f.chegada)===iso(now).slice(0,10))||A(b.dia).length),now)}${b.sel?biVeiculo(b.sel,rows,now,lead):""}</div>
      <div class="note">Distâncias aproximadas pela BR-040/BR-381, a partir da cidade informada no follow até a Iveco (Rio–Sete Lagoas ≈ 508 km). O tempo até a chegada usa a previsão do follow; sem previsão, é estimado pela velocidade média observada nas viagens (≈ ${Math.round(velMedia())} km/h, com paradas).</div>
      <div class="bi-mleg"><span>${truckIcon("crit",22)}Atrasado</span><span>${truckIcon("warn",22)}Em risco</span><span>${truckIcon("ok",22)}No prazo</span><span>${truckIcon("desc",22)}Descarga</span>
        <span><i class="bi-seg" style="background:var(--crit)"></i>Acidente / interdição</span><span><i class="bi-seg" style="background:var(--warn)"></i>Obra / trânsito</span><span><i class="bi-seg dash"></i>Programado</span><span><b class="bi-cr">!</b>Crítico Iveco</span></div>
      <div class="bi-alerts">${alAt.concat(listaAlertas().filter(a=>statusAl(a,now).k==="prog"&&statusAl(a,now).ini-now<24*3600000)).slice(0,5).map(a=>{ const s=statusAl(a,now); const t=s.k==="prog"?"info":(a.tipo==="acidente"||a.tipo==="interdicao"||a.sev==="alta")?"crit":"warn";
        return `<div class="bi-ar ${t}"><b>${esc(a.titulo)}</b><span class="sub">${esc(s.t)}</span></div>`; }).join("")||'<div class="sub">Nenhum alerta ativo no trajeto.</div>'}</div>
    </section>
  </div>`;
  const set=(key,v)=>{ state.bi[key]=v; try{localStorage.setItem("iveco.bi",JSON.stringify(state.bi));}catch(_){} renderBI(); };
  el.querySelector("#bi-prog").onchange=e=>set("prog",e.target.value);
  el.querySelectorAll(".ms").forEach(m=>{ const id=m.dataset.ms;
    m.querySelector(".ms-btn").onclick=ev=>{ ev.stopPropagation(); state.biOpen = state.biOpen===id ? null : id; state.biQ=""; renderBI(); };
    const pop=m.querySelector(".ms-pop"); if(!pop) return;
    pop.onclick=ev=>ev.stopPropagation();
    pop.querySelectorAll('input[type="checkbox"]').forEach(c=>c.onchange=()=>{ const cur=new Set(A(state.bi[id])); c.checked?cur.add(c.value):cur.delete(c.value); set(id,[...cur]); });
    const q=pop.querySelector(".ms-q"); if(q){ q.oninput=()=>{ state.biQ=q.value; const t=norm(q.value); pop.querySelectorAll(".ms-o").forEach(o=>o.hidden=!!t&&!norm(o.textContent).includes(t)); }; setTimeout(()=>{ q.focus(); q.setSelectionRange(q.value.length,q.value.length); },0); }
    pop.querySelector("[data-msall]").onclick=()=>{ const vis=[...pop.querySelectorAll(".ms-o:not([hidden]) input")].map(c=>c.value); set(id,[...new Set(A(state.bi[id]).concat(vis))]); };
    pop.querySelector("[data-msclr]").onclick=()=>set(id,[]);
    const d=pop.querySelector("[data-msdef]"); d&&(d.onclick=()=>set(id,[...CARGA_PADRAO]));
    pop.querySelector("[data-msok]").onclick=()=>{ state.biOpen=null; state.biQ=""; renderBI(); };
  });
  el.querySelectorAll("[data-q]").forEach(x=>x.onclick=()=>{ const q=x.dataset.q; const m={"betim-hoje":["Betim","__hoje__"],"sete-hoje":["Sete Lagoas","__hoje__"],"hoje":["","__hoje__"],"betim":["Betim",""]}[q];
    const ativo=x.getAttribute("aria-pressed")==="true"; state.bi.dest=ativo||!m[0]?[]:[m[0]]; state.bi.dia=ativo||!m[1]?[]:[m[1]]; state.bi.carga=ativo?[...CARGA_PADRAO]:[]; set("sel",""); });
  el.querySelector("#bi-wa").onclick=painelGerente;
  el.querySelector("#bi-cons").onclick=painelConsulta;
  const ca=el.querySelector("#cons-abrir"); ca&&(ca.onclick=painelConsulta);
  const cs=el.querySelector("#cons-sair"); cs&&(cs.onclick=()=>{ state.bi={cn:[],crit:[],dia:[],carga:[...CARGA_PADRAO],sit:[],dest:[],prog:"",sel:""}; state.biOpen=null; set("sel",""); });
  const kh=el.querySelector("#bi-k-hoje"); if(kh){ const go=()=>{ const on=mesmo(A(state.bi.dia),["__hoje__"])&&!A(state.bi.carga).length; state.bi.dia=on?[]:["__hoje__"]; state.bi.carga=on?[...CARGA_PADRAO]:[]; set("sel",""); }; kh.onclick=go; kh.onkeydown=e=>{ if(e.key==="Enter") go(); }; }
  el.querySelector("#bi-clear").onclick=()=>{ state.bi={cn:[],crit:[],dia:[],carga:[...CARGA_PADRAO],sit:[],dest:[],prog:"",sel:""}; state.biOpen=null; set("sel",""); };
  el.querySelectorAll("[data-dk]").forEach(x=>x.onclick=()=>{ const k=x.dataset.dk, v=x.dataset.dv, cur=new Set(A(state.bi[k])); cur.has(v)?cur.delete(v):cur.add(v); set(k,[...cur]); });
  el.querySelectorAll("[data-clr]").forEach(x=>x.onclick=()=>set(x.dataset.clr,[]));
  el.querySelectorAll(".bi-veh").forEach(x=>{ x.onclick=()=>{ if(x.dataset.cnsv){ painelVeiculo("",x.dataset.cnsv); return; } set("sel", state.bi.sel===x.dataset.placa?"":x.dataset.placa); }; x.onkeydown=e=>{ if(e.key==="Enter") x.onclick(); }; });
  el.querySelectorAll("[data-cfed]").forEach(b=>b.onclick=ev=>{ ev.stopPropagation(); painelVeiculo("", b.dataset.cfed); });
  const cft=el.querySelector("#cf-tog"); if(cft) cft.onclick=()=>{ state.cfAberto=state.cfAberto===false; renderBI(); };
  el.querySelectorAll(".bi-ed").forEach(b=>b.onclick=ev=>{ ev.stopPropagation(); painelVeiculo(b.dataset.edp, b.dataset.ed); });
  el.querySelectorAll(".bi-row").forEach(x=>{ x.onclick=()=>{ if(x.dataset.bp) set("sel",x.dataset.bp); else painelEdit(x.dataset.cn); }; x.ondblclick=()=>painelEdit(x.dataset.cn); x.onkeydown=e=>{ if(e.key==="Enter") x.onclick(); }; });
  const cl=el.querySelector("[data-close]"); cl&&(cl.onclick=()=>set("sel",""));
  el.querySelectorAll("[data-ve]").forEach(b=>b.onclick=ev=>{ ev.stopPropagation(); painelVeiculo(b.dataset.ve,b.dataset.vcn); });
  el.querySelectorAll(".cheg-tb tr[data-bp]").forEach(x=>{ x.onclick=()=>{ set("sel",x.dataset.bp); const m=el.querySelector(".bi-mapbox"); m&&m.scrollIntoView({behavior:"smooth",block:"center"}); }; x.onkeydown=e=>{ if(e.key==="Enter") x.onclick(); }; });
  el.querySelectorAll("[data-bt]").forEach(x=>x.onclick=()=>set("betim",x.dataset.bt));
  const bc=el.querySelector("#betim-copy"); bc&&(bc.onclick=()=>{ const m=state.bi.betim||"todos", all=betimLista(new Date()); const ls=m==="hoje"?all.filter(x=>x.hoje):m==="venc"?all.filter(x=>x.venc):all; navigator.clipboard.writeText(betimTexto(ls,new Date())).then(()=>toast("Mensagem copiada"),()=>toast("Não foi possível copiar neste navegador")); });
  const mc=el.querySelector("#manut-copy"); mc&&(mc.onclick=()=>{ const vistos=new Set(), fs=[]; rows.filter(r=>r.manut).forEach(r=>{ if(!vistos.has(r.placa)){ vistos.add(r.placa); fs.push(r.f); } }); navigator.clipboard.writeText(avisoManutCliente(fs)).then(()=>toast("Aviso copiado"),()=>toast("Não foi possível copiar neste navegador")); });
  el.querySelectorAll(".ma-i[data-bp]").forEach(x=>x.onclick=()=>set("sel",x.dataset.bp));
  const cc=el.querySelector("#cheg-copy"); cc&&(cc.onclick=()=>{ const t=chegTexto(biChegadas(biFiltra(base,"carga").filter(r=>r.carga!=="semveic"),new Date()),new Date()); navigator.clipboard.writeText(t).then(()=>toast("Lista copiada"),()=>toast("Não foi possível copiar neste navegador")); });
  el.querySelectorAll(".bi-pop-c").forEach(x=>x.onclick=()=>painelEdit(x.dataset.cn));
}
/* ---------- indicadores ---------- */
const PERIODOS={hoje:"Hoje","7":"Últimos 7 dias","30":"Últimos 30 dias",tudo:"Todo o histórico"};
const media=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:null;
function calcInd(periodo){
  const now=new Date(), hoje=iso(now).slice(0,10);
  let ini=null; if(periodo==="hoje") ini=hoje; else if(periodo!=="tudo"){ const d=new Date(now); d.setDate(d.getDate()-(+periodo-1)); ini=iso(d).slice(0,10); }
  const keys=new Set([...Object.keys(state.prog),...Object.keys(state.follow)]);
  const itens=[...keys].map(cn=>{ const p=state.prog[cn], f=followDe(cn); return {cn,p,f,ref:(p&&p.necessidade)||(f&&f.data_prog)||null, linha:!!p&&isLinha(p)}; })
    .filter(x=>x.ref && (!ini || (periodo==="hoje"? dia(x.ref)===hoje : dia(x.ref)>=ini)));
  const min=(a,b)=>(toD(a)-toD(b))/60000;
  const prog=itens.filter(x=>x.p), comVeic=prog.filter(x=>x.f), semVencidos=prog.filter(x=>!x.f && toD(x.ref)<now);
  const entregues=itens.filter(x=>entregueIveco(x.f)), noPrazo=entregues.filter(x=>min(x.f.chegada,x.ref)<=0);
  const entLinha=entregues.filter(x=>x.linha), atrasados=entregues.filter(x=>min(x.f.chegada,x.ref)>0);
  const transito=itens.filter(x=>x.f&&!x.f.chegada&&x.f.prev_chegada), porto=itens.filter(x=>x.f&&!x.f.chegada&&!x.f.prev_chegada);
  const lead=entregues.filter(x=>x.f.inicio).map(x=>min(x.f.chegada,x.f.inicio)).filter(v=>v>0);
  const erro1=[],erroN=[];
  entregues.forEach(x=>{ const hs=(x.f.hist||[]).filter(h=>h.prev&&!h.cheg); if(!hs.length) return; erro1.push(Math.abs(min(x.f.chegada,hs[0].prev))); erroN.push(Math.abs(min(x.f.chegada,hs[hs.length-1].prev))); });
  const comDp=itens.filter(x=>x.p&&x.f&&x.f.data_prog), div=comDp.filter(x=>Math.abs(min(x.f.data_prog,x.p.necessidade))>=1);
  const B=[["No prazo",v=>v<=0],["Até 2h",v=>v>0&&v<=120],["2 a 6h",v=>v>120&&v<=360],["6 a 12h",v=>v>360&&v<=720],["Acima de 12h",v=>v>720]];
  const buckets=B.map(([nome,fn])=>({nome, ent:entregues.filter(x=>fn(min(x.f.chegada,x.ref))).length, prev:transito.filter(x=>fn(min(x.f.prev_chegada,x.ref))).length}));
  const porDia={}; itens.forEach(x=>{ const d=dia(x.ref); const o=porDia[d]=porDia[d]||{d,ok:0,late:0,pend:0}; if(x.f&&x.f.chegada) (min(x.f.chegada,x.ref)<=0?o.ok++:o.late++); else o.pend++; });
  const dias=Object.values(porDia).sort((a,b)=>a.d.localeCompare(b.d)).slice(-14);
  const grp=(nome,arr)=>{ const e=arr.filter(x=>x.f&&x.f.chegada), ok=e.filter(x=>min(x.f.chegada,x.ref)<=0), t=arr.filter(x=>x.f&&!x.f.chegada&&x.f.prev_chegada);
    return {nome,n:arr.length,comVeic:arr.filter(x=>x.f).length,ent:e.length,ok:ok.length,otd:e.length?ok.length/e.length:null,atraso:media(e.map(x=>min(x.f.chegada,x.ref)).filter(v=>v>0)),trans:t.length,prev:media(t.map(x=>min(x.f.prev_chegada,x.ref)))}; };
  const grupos=[grp("Itens para linha",itens.filter(x=>x.linha)),grp("Demais programados",itens.filter(x=>x.p&&!x.linha))];
  const locs={}; itens.filter(x=>x.f).forEach(x=>{ const l=(x.f.local_entrega||"—").toUpperCase(); (locs[l]=locs[l]||[]).push(x); });
  Object.keys(locs).sort().forEach(l=>grupos.push(grp("Destino "+lugar(l),locs[l])));
  const hs=((state.envios[hoje]&&state.envios[hoje].horarios)||[]).map(toD).filter(Boolean).sort((a,b)=>a-b);
  const horas=new Set(hs.map(d=>d.getHours())); let esperadas=0, maiorGap=null;
  if(hs.length){ esperadas=now.getHours()-hs[0].getHours()+1; const pts=[...hs,now]; maiorGap=0; for(let i=1;i<pts.length;i++) maiorGap=Math.max(maiorGap,(pts[i]-pts[i-1])/60000); }
  const env={feitos:hs.length, horas, primeira:hs[0]||null, esperadas, aderencia:esperadas?Math.min(1,horas.size/esperadas):null, maiorGap};
  return {itens,prog,comVeic,cobertura:prog.length?comVeic.length/prog.length:null,semVencidos,entregues,noPrazo,otd:entregues.length?noPrazo.length/entregues.length:null,
    entLinha,otdLinha:entLinha.length?entLinha.filter(x=>min(x.f.chegada,x.ref)<=0).length/entLinha.length:null,atrasados,atrasoMedio:media(atrasados.map(x=>min(x.f.chegada,x.ref))),
    transito,transitoOk:transito.length?transito.filter(x=>min(x.f.prev_chegada,x.ref)<=0).length/transito.length:null,desvioPrev:media(transito.map(x=>min(x.f.prev_chegada,x.ref))),
    porto,lead:media(lead),nLead:lead.length,erroPrimeira:media(erro1),erroUltima:media(erroN),nErro:erro1.length,divergencia:comDp.length?div.length/comDp.length:null,nDiv:div.length,nDp:comDp.length,
    buckets,dias,grupos,env};
}
function renderInd(){
  const el=$("#v-ind"); if(el.hidden) return;
  const I=calcInd(state.periodo), now=new Date();
  const P=v=>v==null?"—":Math.round(v*100)+"%", Hh=v=>v==null?"—":dur(v).replace(/^[+−]/,""), SH=v=>v==null?"—":dur(v);
  const tn=(v,a,b)=>v==null?"":v>=a?"ok":v>=b?"warn":"crit";
  const k=(cls,t,v,s)=>`<div class="kpi ${cls}"><span class="k">${t}</span><span class="v">${v}</span><span class="s">${s}</span></div>`;
  const E=I.env;
  // gráfico 1: entregas por dia
  let g1='<div class="empty">Sem containers no período.</div>';
  if(I.dias.length){ const W=560,H=220,L=30,R=10,T=18,Bm=28, n=I.dias.length, max=Math.max(1,...I.dias.map(d=>d.ok+d.late+d.pend));
    const bw=Math.min(46,(W-L-R)/n*0.62), y=v=>T+(H-T-Bm)*(1-v/max), step=Math.max(1,Math.ceil(max/4));
    let s=""; for(let v=0;v<=max;v+=step){ s+=`<line x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)"/><text x="${L-6}" y="${y(v)+4}" text-anchor="end">${v}</text>`; }
    I.dias.forEach((d,i)=>{ const cx=L+(W-L-R)*(i+.5)/n, x=cx-bw/2; let base=0;
      [["ok","var(--ok)","no prazo"],["late","var(--crit)","com atraso"],["pend","var(--surface2)","a entregar"]].forEach(([key,c,nome])=>{ const v=d[key]; if(!v) return;
        const y1=y(base+v), h=y(base)-y1-(base?2:0); s+=`<rect x="${x}" y="${y1}" width="${bw}" height="${Math.max(1,h)}" rx="3" fill="${c}" ${key==="pend"?'stroke="var(--muted)" stroke-dasharray="3 2"':""}><title>${diaBR(d.d)}: ${v} ${nome}</title></rect>`; base+=v; });
      s+=`<text x="${cx}" y="${y(base)-5}" text-anchor="middle" style="fill:var(--ink);font-weight:600">${d.ok+d.late+d.pend}</text><text x="${cx}" y="${H-10}" text-anchor="middle">${d.d.slice(8,10)}/${d.d.slice(5,7)}</text>`; });
    g1=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Containers por dia de necessidade: no prazo, com atraso e a entregar">${s}</svg>`; }
  // gráfico 2: desvio
  const W2=560, rh=34, T2=6, L2=96, H2=T2+I.buckets.length*rh, mx=Math.max(1,...I.buckets.map(b=>b.ent+b.prev)); let s2="";
  I.buckets.forEach((b,i)=>{ const yy=T2+i*rh, sc=v=>v/mx*(W2-L2-60); const w1=sc(b.ent), w2=sc(b.prev);
    s2+=`<text x="${L2-8}" y="${yy+rh/2+4}" text-anchor="end" style="fill:var(--ink)">${b.nome}</text>`;
    if(b.ent) s2+=`<rect x="${L2}" y="${yy+7}" width="${w1}" height="${rh-14}" rx="3" fill="var(--accent)"><title>${b.nome}: ${b.ent} entregues</title></rect>`;
    if(b.prev) s2+=`<rect x="${L2+w1+(b.ent?2:0)}" y="${yy+7}" width="${w2}" height="${rh-14}" rx="3" fill="var(--accent)" fill-opacity=".38"><title>${b.nome}: ${b.prev} em trânsito (previsão)</title></rect>`;
    s2+=`<text x="${L2+w1+w2+(b.ent&&b.prev?2:0)+6}" y="${yy+rh/2+4}" style="fill:var(--ink);font-weight:600">${b.ent+b.prev||""}</text>`; });
  s2=`<line x1="${L2}" x2="${L2}" y1="0" y2="${H2}" stroke="var(--line)"/>`+s2;
  // gráfico 3: follows por hora
  const W3=1200,H3=64,cw=(W3-20)/24; let s3="", hNow=now.getHours(), h0=E.primeira?E.primeira.getHours():null;
  for(let h=0;h<24;h++){ const x=10+h*cw, feito=E.horas.has(h), falha=!feito&&h0!=null&&h>=h0&&h<=hNow&&!(h===hNow&&now.getMinutes()<15), fut=h>hNow;
    const fill=feito?"var(--accent)":falha?"var(--crit-soft)":"var(--surface2)", st=falha?'stroke="var(--crit)" stroke-dasharray="3 2"':'stroke="var(--line)"';
    s3+=`<rect x="${x+1.5}" y="8" width="${cw-3}" height="26" rx="3" fill="${fill}" ${st}><title>${pad(h)}h: ${feito?"follow enviado":falha?"sem follow":fut?"ainda não chegou":"antes do 1º follow"}</title></rect>`;
    if(h===hNow) s3+=`<rect x="${x}" y="6.5" width="${cw}" height="29" rx="4" fill="none" stroke="var(--ink)" stroke-width="1.5"/>`;
    if(h%3===0) s3+=`<text x="${x+cw/2}" y="${H3-10}" text-anchor="middle">${pad(h)}h</text>`; }
  const grupoRows=I.grupos.filter(g=>g.n).map(g=>`<tr><td><b>${esc(g.nome)}</b></td><td class="num">${g.n}</td><td class="num">${g.comVeic}</td><td class="num">${g.ent}</td><td class="num">${g.ok}</td>
    <td><span class="gap ${tn(g.otd,.9,.7)}">${P(g.otd)}</span></td><td class="num">${Hh(g.atraso)}</td><td class="num">${g.trans}</td><td><span class="gap ${g.prev==null?"":g.prev<=0?"ok":g.prev<=RISK_MIN?"warn":"crit"}">${SH(g.prev)}</span></td></tr>`).join("");
  el.innerHTML=`
  <div class="ind-head"><div><h2>Indicadores</h2><div class="note">Referência de prazo: horário de necessidade da programação Iveco. Containers fora da programação usam a data programada informada no follow. O período considera o dia de necessidade.</div></div>
    <select id="ind-per" aria-label="Período">${Object.entries(PERIODOS).map(([v,t])=>`<option value="${v}" ${v===state.periodo?"selected":""}>${t}</option>`).join("")}</select></div>
  <div class="sect2">Nível de serviço à Iveco</div>
  <div class="kpis">
    ${k(tn(I.otd,.9,.7),"Pontualidade (OTD)",P(I.otd),`${I.noPrazo.length} de ${I.entregues.length} entregues no prazo`)}
    ${k(tn(I.otdLinha,.9,.7),"OTD itens p/ linha",P(I.otdLinha),`${I.entLinha.length} entregues`)}
    ${k(I.atrasoMedio?"crit":"ok","Atraso médio",Hh(I.atrasoMedio),`nas ${I.atrasados.length} entregas atrasadas`)}
    ${k(tn(I.cobertura,.95,.8),"Cobertura de veículo",P(I.cobertura),`${I.comVeic.length} de ${I.prog.length} programados`)}
    ${k(I.semVencidos.length?"crit":"ok","Sem veículo e vencido",I.semVencidos.length,"necessidade já passou")}
    ${k(tn(I.transitoOk,.9,.7),"Trânsito dentro do prazo",P(I.transitoOk),`${I.transito.length} em trânsito · ${I.porto.length} no porto`)}
    ${k(I.desvioPrev>0?"crit":"ok","Desvio previsto médio",SH(I.desvioPrev),"previsão − necessidade")}
  </div>
  <div class="sect2">Qualidade do follow-up</div>
  <div class="kpis">
    ${k("acc","Follows enviados hoje",E.feitos,E.primeira?`1º às ${fmtH(iso(E.primeira))}`:"nenhum importado hoje")}
    ${k(tn(E.aderencia,.95,.8),"Horas com follow",P(E.aderencia),E.esperadas?`${E.horas.size} de ${E.esperadas} horas desde o 1º`:"—")}
    ${k(E.maiorGap==null?"":E.maiorGap>STALE_MIN?"crit":"ok","Maior intervalo sem follow",Hh(E.maiorGap),"hoje, até agora")}
    ${k(I.divergencia==null?"":I.divergencia>0?"warn":"ok","Programação divergente",P(I.divergencia),`${I.nDiv} de ${I.nDp} follows ≠ Iveco`)}
    ${k("","Erro da 1ª previsão",Hh(I.erroPrimeira),I.nErro?`média em ${I.nErro} entregas`:"aparece após entregas com previsão")}
    ${k("","Erro da última previsão",Hh(I.erroUltima),I.nErro?"antes da chegada":"aparece após entregas com previsão")}
    ${k("acc","Tempo médio de viagem",Hh(I.lead),I.nLead?`início → chegada, ${I.nLead} viagens`:"sem viagens concluídas")}
  </div>
  <div class="cards2">
    <div class="chart"><h3>Containers por dia de necessidade</h3><div class="lg"><span><i style="background:var(--ok)"></i>No prazo</span><span><i style="background:var(--crit)"></i>Com atraso</span><span><i style="background:var(--surface2);border:1px dashed var(--muted)"></i>A entregar</span></div>${g1}</div>
    <div class="chart"><h3>Desvio em relação à necessidade</h3><div class="lg"><span><i style="background:var(--accent)"></i>Entregues (real)</span><span><i style="background:var(--accent);opacity:.38"></i>Em trânsito (previsão)</span></div>
      <svg viewBox="0 0 ${W2} ${H2}" role="img" aria-label="Distribuição do desvio em relação à necessidade">${s2}</svg></div>
  </div>
  <div class="chart"><h3>Follows enviados hoje, hora a hora</h3><div class="lg"><span><i style="background:var(--accent)"></i>Follow enviado</span><span><i style="background:var(--crit-soft);border:1px dashed var(--crit)"></i>Hora sem follow</span><span><i style="background:var(--surface2);border:1px solid var(--line)"></i>Fora do período / ainda não chegou</span></div>
    <div style="overflow-x:auto"><svg viewBox="0 0 ${W3} ${H3}" style="min-width:640px" role="img" aria-label="Follows enviados por hora hoje">${s3}</svg></div>
    <div class="note">Cada importação de follow conta como um envio. A hora atual só é marcada como falha depois dos 15 minutos.</div></div>
  <div class="chart"><h3>Por criticidade e destino</h3><div class="tbl-wrap" style="box-shadow:none"><table style="min-width:760px"><thead><tr><th>Grupo</th><th>Containers</th><th>Com veículo</th><th>Entregues</th><th>No prazo</th><th>OTD</th><th>Atraso médio</th><th>Em trânsito</th><th>Desvio previsto</th></tr></thead><tbody>${grupoRows||'<tr><td colspan="9" class="empty">Sem dados no período.</td></tr>'}</tbody></table></div></div>`;
  el.querySelector("#ind-per").onchange=e=>{ state.periodo=e.target.value; try{localStorage.setItem("iveco.periodo",state.periodo);}catch(_){} renderInd(); };
}

/* ---------- import ---------- */
const norm = s => String(s??"").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[ºª°]/g,"").replace(/\s+/g," ").trim().toUpperCase();
const CNRE = /[A-Z]{4}\s?\d{7}/g;
const FOLLOW_MAP = { "ID (N CTRN/NPROCESSO/NF)":"id", "ID":"id", "CONTAINER":"id", "LOCAL DE ENTREGA":"local_entrega", "STATUS GERAL":"status", "STATUS":"status", "LOCALIZACAO":"localizacao",
  "INICIO DE VIAGEM":"inicio", "PREV. DE CHEGADA":"prev_chegada", "PREVISAO DE CHEGADA":"prev_chegada", "DATA PROGRAMADA":"data_prog", "CHEGADA NO CLIENTE":"chegada",
  "PLACA CAVALO":"placa_cavalo", "PLACA REBOQUE":"placa_reboque", "MOTORISTA":"motorista", "MARCA DO VEICULO":"marca" };
const PROG_MAP = { "DATA DE CARREGAMENTO":"data_carregamento", "PLANTA":"planta", "SOLICITANTE":"solicitante", "CARGA":"carga", "COM DESOVA":"desova", "NAVIO":"navio", "CONTAINER":"container",
  "EXPECTATIVA NA PLANTA":"expectativa", "OR":"or", "SHIPMENT":"shipment", "TIPO DE VEICULO":"tipo_veiculo", "OBS":"obs", "TRANSPORTADORA":"transportadora", "LOCAL DE DESCARGA":"local_descarga",
  "LIMITE DEVOLUCAO VAZIO":"limite_devolucao", "HORARIO DE CHEGADA":"horario", "NIVEL DE CRITICIDADE":"criticidade" };
function headerKind(row){ const n=row.map(norm); if(n.includes("STATUS GERAL")||(n.includes("PLACA CAVALO")&&n.includes("MOTORISTA"))) return "follow"; if(n.includes("EXPECTATIVA NA PLANTA")||(n.includes("CONTAINER")&&n.includes("NIVEL DE CRITICIDADE"))) return "prog"; return null; }
function parseGrid(grid){
  const res={prog:[],follow:[]}; let kind=null, cols=null;
  for(const row of grid){
    if(!row || !row.some(c=>c!==null && c!==undefined && String(c).trim()!=="")) continue;
    const hk=headerKind(row);
    if(hk){ kind=hk; const map=hk==="follow"?FOLLOW_MAP:PROG_MAP; cols=row.map(c=>{ const k=norm(c); return map[k] || (hk==="follow" && (/^ID\b/.test(k)||k.includes("CTRN")) ? "id" : null); }); continue; }
    if(!kind) continue;
    const o={}; cols.forEach((k,i)=>{ if(k) o[k]=row[i]; });
    if(kind==="follow"){ const ids=String(o.id||"").toUpperCase().match(CNRE); if(!ids) continue; res.follow.push({ids:ids.map(s=>s.replace(/\s/g,"")), o}); }
    else { const c=String(o.container||"").toUpperCase().match(CNRE); if(!c) continue; res.prog.push({container:c[0].replace(/\s/g,""), o}); }
  }
  return res;
}
const txt = v => v==null ? "" : String(v).replace(/ /g," ").trim();
// Somente LOCAL DE ENTREGA = BETIM + STATUS GERAL = ENTREGUE => "ENVIAR PARA A IVECO" (Betim não é a planta do cliente)
function statusIveco(f){ if(REGRA_BETIM && f && /BETIM/.test(norm(f.local_entrega||"")) && /ENTREG/i.test(f.status||"")){ f.statusOriginal=f.status; f.status=ST_ENVIAR; } return f; }
function buildFollow(ids,o,now){
  return ids.map(c=>statusIveco({ container:c, idOriginal:txt(o.id), local_entrega:txt(o.local_entrega), status:txt(o.status).toUpperCase(), localizacao:txt(o.localizacao),
    inicio:pIso(o.inicio), prev_chegada:pIso(o.prev_chegada), data_prog:pIso(o.data_prog), chegada:pIso(o.chegada),
    placa_cavalo:txt(o.placa_cavalo), placa_reboque:txt(o.placa_reboque), motorista:txt(o.motorista), marca:txt(o.marca), atualizadoEm:now }));
}
function buildProg(c,o,now){
  let necessidade=null; const e=parseVal(o.expectativa), h=parseVal(o.horario);
  if(e&&e.iso){ necessidade = e.iso.slice(0,11) + (h&&h.time ? h.time : (h&&h.iso ? h.iso.slice(11,16) : e.iso.slice(11,16))); }
  const ld=o.local_descarga;
  return { container:c, data_carregamento:pIso(o.data_carregamento), planta:txt(o.planta), solicitante:txt(o.solicitante), carga:txt(o.carga), desova:txt(o.desova).toUpperCase(),
    navio:txt(o.navio), necessidade, or:txt(o.or), shipment:txt(o.shipment), tipo_veiculo:txt(o.tipo_veiculo), obs:txt(o.obs), transportadora:txt(o.transportadora),
    local_descarga: ld==null?"":txt(ld), limite_devolucao:pIso(o.limite_devolucao), criticidade:txt(o.criticidade).toUpperCase(), atualizadoEm:now };
}
function histEntry(f,t,orig){ return {t:t||f.atualizadoEm, orig:orig||"planilha", status:f.status||"", loc:f.localizacao||"", prev:f.prev_chegada||null, cheg:f.chegada||null}; }
function withHist(novo, antigo, t, orig){
  const h = (antigo && Array.isArray(antigo.hist)) ? antigo.hist.slice() : [];
  const e = histEntry(novo,t,orig), last=h[h.length-1];
  if(!last || last.status!==e.status || last.loc!==e.loc || last.prev!==e.prev || last.cheg!==e.cheg) h.push(e);
  else if(e.orig==="planilha") h[h.length-1] = Object.assign({}, last, {t:e.t, orig:"planilha"});
  novo.hist = h.slice(-48); return novo;
}
async function gravar(parsed){
  if(!state.db) throw new Error("Sem conexão com a base. Recarregue a página.");
  const now=iso(new Date()); let nf=0, np=0;
  // Follow: as informações mais recentes ficam nas últimas linhas.
  // Lê de baixo para cima e usa só a linha mais recente de cada container.
  const vistos=new Set(), recentes=[]; let ignoradas=0;
  for(let i=parsed.follow.length-1;i>=0;i--){ const r=parsed.follow[i];
    const novos=r.ids.filter(c=>!vistos.has(c)); if(!novos.length){ ignoradas++; continue; }
    novos.forEach(c=>vistos.add(c)); recentes.push({ids:novos,o:r.o}); }
  for(const r of recentes){ for(const f of buildFollow(r.ids,r.o,now)){ await state.db.doc("follow/"+f.container).set(withHist(f, state.follow[f.container])); nf++; } }
  for(const r of parsed.prog){ const p=buildProg(r.container,r.o,now); await state.db.doc("prog/"+p.container).set(p); np++; }
  if(nf){ const k=now.slice(0,10), atual=(state.envios[k]&&state.envios[k].horarios)||[];
    await state.db.doc("envios/"+k).set({dia:k, horarios:[...new Set([...atual, now])].sort()}); }
  const meta=Object.assign({}, state.meta); if(nf) meta.ultimoFollow=now; if(np) meta.ultimaProg=now;
  if(nf||np) await state.db.doc("meta/info").set(meta);
  let cid={novas:[],falhas:[]}; try{ cid=await autoCidades(parsed.follow.map(r=>({localizacao:txt(r.o.localizacao)}))); }catch(e){}
  return {nf,np,ignoradas,cid};
}
function gridFromText(t){
  const lines=t.replace(/\r/g,"").split("\n");
  const sep = lines.some(l=>l.includes("\t")) ? "\t" : (lines.some(l=>l.includes(";"))?";":"\t");
  return lines.map(l=>l.split(sep).map(c=>c.trim()));
}
function gridsFromWorkbook(buf){
  const wb=XLSX.read(buf,{type:"array"}); const out={prog:[],follow:[]};
  wb.SheetNames.forEach(n=>{ const ws=wb.Sheets[n];
    // Recalcula a área real da aba a partir das células preenchidas, para não depender da dimensão gravada no arquivo
    // e varrer tudo, inclusive blocos que vêm depois de linhas em branco.
    let r0=Infinity,c0=Infinity,r1=-1,c1=-1; Object.keys(ws).forEach(k=>{ if(k[0]==="!") return; const a=XLSX.utils.decode_cell(k); r0=Math.min(r0,a.r); c0=Math.min(c0,a.c); r1=Math.max(r1,a.r); c1=Math.max(c1,a.c); });
    if(r1<0) return; ws["!ref"]=XLSX.utils.encode_range({s:{r:0,c:0},e:{r:r1,c:c1}});
    const g=XLSX.utils.sheet_to_json(ws,{header:1,raw:true,defval:null,blankrows:true}); const r=parseGrid(g); out.prog.push(...r.prog); out.follow.push(...r.follow); });
  return out;
}

/* ---------- painéis ---------- */
function openPanel(html, onMount){ const o=$("#overlay"); o.innerHTML=`<div class="panel" role="dialog" aria-modal="true">${html}</div>`; o.hidden=false; o.onclick=e=>{ if(e.target===o) closePanel(); }; onMount && onMount(o.firstElementChild); const f=o.querySelector("input,textarea,select,button"); f&&f.focus(); }
function closePanel(){ const o=$("#overlay"); o.hidden=true; o.innerHTML=""; }
document.addEventListener("keydown",e=>{ if(e.key==="Escape" && !$("#overlay").hidden) closePanel(); else if(e.key==="Escape" && state.biOpen){ state.biOpen=null; state.biQ=""; renderBI(); } });
document.addEventListener("click",e=>{ if(state.biOpen && !e.target.closest(".ms")){ state.biOpen=null; state.biQ=""; renderBI(); } });
function toast(t){ const el=$("#toast"); el.textContent=t; el.hidden=false; clearTimeout(toast._t); toast._t=setTimeout(()=>el.hidden=true,3200); }

function painelImport(){
  openPanel(`<h3>Importar follow ou programação</h3>
    <p>Copie a tabela do e-mail (follow de hora em hora ou programação da Iveco), inclusive a linha de cabeçalho, e cole abaixo. O tipo é reconhecido pelos títulos das colunas. Também dá para soltar a planilha .xlsx com as abas.</p>
    <textarea id="imp-txt" placeholder="ID (Nº CTRN/NºPROCESSO/NF)&#9;LOCAL DE ENTREGA&#9;STATUS GERAL&#9;LOCALIZAÇÃO&#9;…"></textarea>
    <div class="drop" id="imp-drop">Solte aqui o arquivo .xlsx ou <label style="color:var(--accent);cursor:pointer;text-decoration:underline">escolha o arquivo<input id="imp-file" type="file" accept=".xlsx,.xls,.xlsm,.csv" hidden></label></div>
    <div id="imp-msg"></div>
    <div class="row"><button class="btn primary" id="imp-go" type="button">Importar texto colado</button><button class="btn ghost" id="imp-x" type="button">Fechar</button></div>
    <p>No follow, a leitura começa pela última linha e sobe até a primeira: para cada container vale a linha mais recente (a mais abaixo), e as repetições mais antigas são ignoradas. Containers já existentes são atualizados, e cada mudança de status, posição ou previsão fica no histórico do container.</p>`, el=>{
      const msg=(t,ok)=>{ el.querySelector("#imp-msg").innerHTML=`<div class="msg ${ok?"ok":"err"}">${esc(t)}</div>`; };
      const run=async parsed=>{ if(!parsed.follow.length && !parsed.prog.length){ msg("Não encontrei cabeçalho de follow (STATUS GERAL) nem de programação (Expectativa na Planta). Copie a tabela junto com a linha de títulos.",false); return; }
        try{ msg("Gravando…",true); const r=await gravar(parsed); msg(`${r.cid&&r.cid.novas.length?`Cidades novas adicionadas à rota: ${r.cid.novas.map(c=>c.nome+" ("+kmAte(NO[c.id],"sete")+" km até Sete Lagoas)").join(", ")}. `:""}${r.cid&&r.cid.falhas.length?`Não reconhecidas (informe na aba Rodovias): ${r.cid.falhas.join(", ")}. `:""}Importado: ${r.nf} containers de follow (linha mais recente de cada) e ${r.np} da programação.${r.ignoradas?` ${r.ignoradas} linha${r.ignoradas>1?"s":""} mais antiga${r.ignoradas>1?"s":""} do follow ignorada${r.ignoradas>1?"s":""}.`:""}`,true); toast("Importação concluída"); }catch(e){ msg("Falha ao gravar: "+(e.message||e.code),false); } };
      el.querySelector("#imp-x").onclick=closePanel;
      el.querySelector("#imp-go").onclick=()=>{ const t=el.querySelector("#imp-txt").value; if(!t.trim()){ msg("Cole a tabela do e-mail no campo acima.",false); return;} run(parseGrid(gridFromText(t))); };
      const file=async f=>{ if(!f) return; try{ const buf=await f.arrayBuffer(); if(typeof XLSX==="undefined") throw new Error("leitor de planilha não carregou"); run(gridsFromWorkbook(buf)); }catch(e){ msg("Não consegui ler o arquivo: "+e.message,false); } };
      el.querySelector("#imp-file").onchange=e=>file(e.target.files[0]);
      const d=el.querySelector("#imp-drop");
      d.ondragover=e=>{e.preventDefault(); d.classList.add("over");}; d.ondragleave=()=>d.classList.remove("over");
      d.ondrop=e=>{e.preventDefault(); d.classList.remove("over"); file(e.dataTransfer.files[0]);};
    });
}

/* ---------- consulta rápida de containers ---------- */
function consExtrai(txt){ const u=String(txt||"").toUpperCase(); const m=u.match(/[A-Z]{4}\s?-?\s?\d{6}\s?-?\s?\d/g)||[]; return [...new Set(m.map(x=>x.replace(/[^A-Z0-9]/g,"")))]; }
function consLinhas(cns){
  const now=new Date(), L=new Map(biLinhas().map(r=>[r.cn,r]));
  return cns.map(cn=>{ const f=followDe(cn)||null, p=state.prog[cn]||null, r=L.get(cn)||null, q=f&&!f.chegada?restante(f,now):null;
    return {cn,f,p,r,q}; });
}
function consSit(o){ if(!o.f&&!o.p) return {k:"mut",t:"Não encontrado"}; if(!o.f) return {k:"info",t:"Sem veículo"};
  if(emManut(o.f)) return {k:"crit",t:"Em manutenção"};
  if(o.r){ const c=o.r.carga; if(c==="entregue") return {k:"ok",t:"Entregue"}; if(c==="descarga") return {k:"desc",t:"Aguard. descarga"}; if(c==="porto") return {k:o.r.tone,t:"No porto"};
    return {k:o.r.tone,t:BI_SIT[o.r.tone]||"Em trânsito"}; }
  return {k:"info",t:o.f.status||"—"}; }
function consTexto(rows){
  return rows.map(o=>{ const f=o.f; if(!f&&!o.p) return `• ${o.cn} – não encontrado no follow nem na programação`;
    if(!f) return `• ${o.cn} – sem veículo alocado – nec. ${fmt(o.p.necessidade)}`;
    const prev=f.chegada?`chegou ${fmt(f.chegada)}`:f.prev_chegada?`prev. ${fmt(f.prev_chegada)}`:(o.q&&o.q.eta?`prev. ≈ ${fmt(iso(o.q.eta))}`:"sem previsão");
    return `• ${o.cn} – ${f.status||"—"} – ${lugar(f.localizacao)} – ${f.placa_cavalo||"—"}${f.placa_reboque?"/"+f.placa_reboque:""} – ${prev}${o.q&&o.q.km!=null?` – faltam ${o.q.km} km`:""}`; }).join("\n");
}
function consHtml(rows){
  const th='style="padding:6px 9px;background:#0B5B35;color:#fff;font-family:Arial,sans-serif;font-size:12px;text-align:left;border:1px solid #0B5B35"', td='style="padding:5px 9px;border:1px solid #D6DEE4;font-family:Arial,sans-serif;font-size:12px"';
  return `<table cellspacing="0" cellpadding="0" style="border-collapse:collapse"><tr>${["Container","Status","Localização atual","Placa (cavalo / reboque)","Previsão de chegada","Km restantes","Necessidade Iveco"].map(h=>`<th ${th}>${h}</th>`).join("")}</tr>${rows.map(o=>{ const f=o.f;
    return `<tr><td ${td}><b>${esc(o.cn)}</b></td><td ${td}>${esc(f?f.status||"—":o.p?"Sem veículo alocado":"Não encontrado")}</td><td ${td}>${esc(f?lugar(f.localizacao):"—")}</td><td ${td}>${esc(f?(f.placa_cavalo||"—")+(f.placa_reboque?" / "+f.placa_reboque:""):"—")}</td><td ${td}>${esc(f?(f.chegada?"chegou "+fmt(f.chegada):f.prev_chegada?fmt(f.prev_chegada):(o.q&&o.q.eta?"≈ "+fmt(iso(o.q.eta)):"—")):"—")}</td><td ${td}>${o.q&&o.q.km!=null?o.q.km+" km":"—"}</td><td ${td}>${o.p&&o.p.necessidade?fmt(o.p.necessidade):"—"}</td></tr>`; }).join("")}</table>`;
}
function consAplicar(cns){
  const b=state.bi;
  if(cns.length){ Object.assign(b,{cn:cns,carga:[],dia:[],dest:[],crit:[],sit:[],prog:"",sel:"",consulta:true}); }
  else if(b.consulta){ Object.assign(b,{cn:[],carga:[...CARGA_PADRAO],sel:"",consulta:false}); }
  else return;
  try{ localStorage.setItem("iveco.bi",JSON.stringify(b)); }catch(e){}
  renderBI();
}
function painelConsulta(){
  let txt=""; try{ txt=localStorage.getItem("iveco.consulta")||""; }catch(e){}
  openPanel(`<h3>Consulta rápida de containers</h3>
    <p>Cole a relação recebida por e-mail ou WhatsApp. O controle reconhece os números de container, com ou sem espaço ou hífen, e busca no follow e na programação atuais.</p>
    <div class="c-in"><textarea id="c-txt" rows="5" placeholder="Cole aqui o texto do e-mail, planilha ou WhatsApp com os containers.&#10;Ex.: ABCU1234567, ABCU7654321&#10;XYZU2345678 – urgente" style="width:100%;min-height:110px">${esc(txt)}</textarea>
      </div>
    <div class="row"><span class="sub" id="c-n"></span><button class="btn" id="c-mail" type="button" style="margin-left:auto">Copiar tabela para e-mail</button><button class="btn" id="c-wa" type="button">Copiar para WhatsApp</button><button class="btn ghost" id="c-clr" type="button">Limpar</button><button class="btn primary" id="c-x" type="button">Ver no mapa</button></div>
    <div id="c-res"></div>`, el=>{
    el.classList.add("xwide");
    const ta=el.querySelector("#c-txt"), res=el.querySelector("#c-res");
    let rows=[];
    const draw=()=>{ const cns=consExtrai(ta.value); rows=consLinhas(cns); try{ localStorage.setItem("iveco.consulta",ta.value); }catch(e){}
      consAplicar(rows.filter(o=>o.f||o.p).map(o=>o.cn));
      const nf=rows.filter(o=>!o.f&&!o.p).length;
      el.querySelector("#c-n").textContent=cns.length?`${cns.length} container${cns.length>1?"s":""} reconhecido${cns.length>1?"s":""}${nf?` · ${nf} não encontrado${nf>1?"s":""}`:""}`:"";
      if(!cns.length){ res.innerHTML='<div class="empty">Nenhum número de container reconhecido ainda. O formato esperado é 4 letras e 7 números (ex.: MSMU1234567).</div>'; return; }
      res.innerHTML=`<div class="tbl-wrap"><table class="cons-tb"><thead><tr><th></th><th>Container</th><th>Status</th><th>Localização atual</th><th>Placa</th><th>Previsão de chegada</th><th class="num">Faltam</th><th>Necessidade</th><th>Situação</th><th>Último follow</th></tr></thead><tbody>
        ${rows.map(o=>{ const f=o.f, s=consSit(o), cor=s.k==="desc"?"desc":s.k==="ok"?"ok":s.k;
          return `<tr data-cn="${esc(o.cn)}" tabindex="0"><td>${truckIcon(s.k==="mut"?"done":s.k,26)}</td><td><span class="cn">${esc(o.cn)}</span>${o.r&&o.r.crit?` <span class="linha">${esc(o.r.crit)}</span>`:""}</td>
            <td>${f?esc(f.status||"—"):'<span class="sub">—</span>'}</td><td>${f?esc(lugar(f.localizacao)):'<span class="sub">—</span>'}${f&&f.local_entrega?`<div class="sub">→ ${esc(lugar(f.local_entrega))}</div>`:""}</td>
            <td class="pl">${f&&f.placa_cavalo?`<b class="mono">${esc(f.placa_cavalo)}</b>${f.placa_reboque?`<span class="sub mono"> / ${esc(f.placa_reboque)}</span>`:""}${f.motorista?`<div class="sub mot" title="${esc(f.motorista)}">${esc(f.motorista)}</div>`:""}`:'<span class="sub">—</span>'}</td>
            <td class="num">${f?(f.chegada?`<b>${fmt(f.chegada)}</b><div class="sub">chegou</div>`:f.prev_chegada?`<b>${fmt(f.prev_chegada)}</b><div class="sub">previsão follow</div>`:o.q&&o.q.eta?`<b>≈ ${fmt(iso(o.q.eta))}</b><div class="sub">estimada</div>`:'<span class="sub">sem previsão</span>'):'<span class="sub">—</span>'}</td>
            <td class="num">${o.q&&o.q.km!=null?`${o.q.km} km`:'<span class="sub">—</span>'}</td>
            <td class="num">${o.p&&o.p.necessidade?fmt(o.p.necessidade):'<span class="sub">não programado</span>'}</td>
            <td><span class="pill ${cor==="info"||cor==="mut"||cor==="desc"?"mut":cor}" style="white-space:nowrap">${esc(s.t)}</span>${o.r&&o.r.gap!=null&&o.r.carga!=="entregue"?` <span class="gap ${o.r.tone}">${dur(o.r.gap)}</span>`:""}</td>
            <td class="num sub">${f&&f.atualizadoEm?fmt(f.atualizadoEm):"—"}</td></tr>`; }).join("")}</tbody></table></div>
        <p class="sub" style="margin-top:6px">Clique numa linha para abrir o follow do container e editar.</p>`;
      res.querySelectorAll("tr[data-cn]").forEach(tr=>{ const go=()=>{ const o=rows.find(x=>x.cn===tr.dataset.cn); if(o&&o.f&&o.f.placa_cavalo) painelVeiculo(o.f.placa_cavalo,o.cn); else painelVeiculo("",o.cn); }; tr.onclick=go; tr.onkeydown=e=>{ if(e.key==="Enter") go(); }; });
    };
    let t=null; ta.oninput=()=>{ clearTimeout(t); t=setTimeout(draw,200); };
    el.querySelector("#c-x").onclick=()=>{ closePanel(); const m=document.querySelector("#v-bi .bi-mapbox"); m&&m.scrollIntoView({behavior:"smooth",block:"start"}); };
    el.querySelector("#c-clr").onclick=()=>{ ta.value=""; draw(); ta.focus(); };
    el.querySelector("#c-wa").onclick=()=>{ if(!rows.length) return; navigator.clipboard.writeText(`*Posição dos containers* – ${fmt(new Date())}\n`+consTexto(rows)).then(()=>toast("Copiado para colar no WhatsApp"),()=>toast("Não foi possível copiar neste navegador")); };
    el.querySelector("#c-mail").onclick=()=>{ if(!rows.length) return; const h=consHtml(rows), tx=consTexto(rows);
      try{ navigator.clipboard.write([new ClipboardItem({"text/html":new Blob([h],{type:"text/html"}),"text/plain":new Blob([tx],{type:"text/plain"})})]).then(()=>toast("Tabela copiada. Cole no corpo do e-mail."),()=>toast("Não foi possível copiar neste navegador")); }catch(e){ toast("Não foi possível copiar neste navegador"); } };
    draw(); setTimeout(()=>{ ta.focus(); ta.select(); },50);
  });
}

/* ---------- edição manual por veículo (todas as informações) ---------- */
function painelVeiculo(placa, cnHint){
  const now=new Date();
  let cns=Object.values(state.follow).filter(f=>placa&&f.placa_cavalo===placa&&!(f.chegada&&/ENTREG/i.test(f.status||""))).map(f=>f.container);
  if(cnHint&&!cns.includes(cnHint)) cns.unshift(cnHint);
  if(!cns.length){ toast("Veículo sem containers no follow"); return; }
  const f0=state.follow[cns[0]]||{}, dt=s=>s?String(s).slice(0,16):"";
  const q=restante(f0,now), kmCalc=(()=>{ const x=Object.assign({},f0,{km_manual:null}); const k=kmRestante(x); return k; })();
  const manualAtivo=f0.km_manual!=null&&f0.km_manual!==""&&f0.km_loc===f0.localizacao;
  const corte=new Date(now); corte.setHours(CORTE_H,0,0,0);
  const folga=q&&q.eta?(corte-q.eta)/60000:null;
  const stSel=f0.status||"AGUARDANDO CARREGAMENTO"; const stOpts=[...new Set([...STATUS_OPTS, f0.status].filter(Boolean))].map(s=>`<option ${s===stSel?"selected":""}>${esc(s)}</option>`).join("");
  const destAtual=(f0.local_entrega||"SETE LAGOAS").toUpperCase(), destOpts=[...new Set(["SETE LAGOAS","BETIM",destAtual])].map(s=>`<option ${s===destAtual?"selected":""}>${esc(s)}</option>`).join("");
  const critOpts=c=>[...new Set(["","ITEM PARA LINHA","CRÍTICO",c||""])].map(s=>`<option value="${esc(s)}" ${s===(c||"")?"selected":""}>${s?esc(s):"—"}</option>`).join("");
  const info=(t,v)=>`<div><span class="sub">${t}</span><b>${v}</b></div>`;
  openPanel(`<h3>${placa?`Editar veículo <span class="mono">${esc(placa)}</span>`:`Alocar veículo · <span class="mono">${esc(cns[0])}</span>`}</h3>
    <p>Todas as informações usadas no painel, na lista de chegadas, no mapa e no resumo do WhatsApp. Altere só o que precisar e clique em Salvar; os campos em branco ficam sem valor.</p>
    <div class="ve-calc">${info("Faltam",q&&q.km!=null?q.km+" km"+(manualAtivo?" (manual)":""):"—")}${info(q&&q.est?"Chegada estimada":"Previsão de chegada",q&&q.eta?fmt(iso(q.eta)):f0.chegada?"chegou "+fmt(f0.chegada):"—")}${info("Folga até 23:00",folga==null?"—":folga>=0?dur(folga).slice(1):dur(-folga).slice(1)+" após o corte")}${info("Último follow",f0.atualizadoEm?fmt(f0.atualizadoEm):"—")}</div>
    <div class="sect">Veículo</div>
    <div class="fgrid">
      <label class="f">Placa cavalo<input id="v-pc" class="mono" value="${esc(f0.placa_cavalo||"")}"></label>
      <label class="f">Placa reboque<input id="v-pr" class="mono" value="${esc(f0.placa_reboque||"")}"></label>
      <label class="f">Motorista<input id="v-mot" value="${esc(f0.motorista||"")}"></label>
      <label class="f">Planta (local de entrega)<select id="v-le">${destOpts}</select></label>
      <label class="f">Status<select id="v-st">${stOpts}</select></label>
      <label class="f">Localização atual<input id="v-loc" value="${esc(f0.localizacao||"")}" placeholder="Ex.: NOVA LIMA - MG"></label>
      <label class="f">Km restantes até a planta<input id="v-km" type="number" min="0" step="1" value="${manualAtivo?esc(f0.km_manual):""}" placeholder="${kmCalc!=null?"calculado: "+kmCalc+" km":"cidade sem cálculo"}"><span class="sub" style="font-size:11.5px">Em branco = cálculo automático. O valor manual vale até a localização mudar.</span></label>
      <label class="f">Início de viagem<input id="v-ini" type="datetime-local" value="${dt(f0.inicio)}"></label>
      <label class="f">Previsão de chegada<input id="v-prev" type="datetime-local" value="${dt(f0.prev_chegada)}"></label>
      <label class="f">Chegada no cliente<input id="v-cheg" type="datetime-local" value="${dt(f0.chegada)}"></label>
      <label class="f full chk" style="flex-direction:row;align-items:center;gap:8px;color:var(--crit);font-weight:600"><input type="checkbox" id="v-manut" style="width:auto" ${emManut(f0)?"checked":""}> Veículo em manutenção (alerta para o cliente)</label>
      <label class="f">Motivo da manutenção<input id="v-mmot" value="${esc(f0.manut_motivo||"")}"></label>
      <label class="f">Previsão de liberação<input id="v-mlib" type="datetime-local" value="${dt(f0.manut_lib)}"></label>
    </div>
    ${cns.map((c,i)=>{ const p=state.prog[c], f=state.follow[c]||{}; return `<div class="sect">Container ${cns.length>1?(i+1)+" · ":""}<span class="mono">${esc(c)}</span></div>
    <div class="fgrid" data-cn="${esc(c)}">
      <label class="f">Expectativa na planta (programação Iveco)<input data-k="need" type="datetime-local" value="${dt(p&&p.necessidade)}" ${p?"":"disabled"}>${p?"":'<span class="sub" style="font-size:11.5px">não consta na programação</span>'}</label>
      <label class="f">Criticidade<select data-k="crit" ${p?"":"disabled"}>${critOpts(p&&p.criticidade)}</select></label>
      <label class="f">Data programada (follow)<input data-k="dp" type="datetime-local" value="${dt(f.data_prog)}"></label>
      <label class="f">Observação<input data-k="obs" value="${esc(f.obs||"")}"></label>
      <label class="f">Armador<input data-k="arm" list="dl-armadores" placeholder="${esc(ARMADOR_PREF[c.slice(0,4)]?ARMADOR_PREF[c.slice(0,4)]+" (pelo prefixo)":"ex.: MSC, MAERSK, COSCO")}" value="${esc(f.armador||(p&&p.armador)||"")}"></label>
    </div>`; }).join("")}
    <datalist id="dl-armadores">${ARMADORES_LISTA.map(a=>`<option value="${a}">`).join("")}</datalist>
    <div id="v-msg"></div>
    <div class="row"><button class="btn primary" id="v-save" type="button">Salvar alterações</button><button class="btn ghost" id="v-x" type="button">Cancelar</button>
      ${cns.map(c=>`<button class="btn ghost" type="button" data-full="${esc(c)}" style="margin-left:auto">Histórico ${esc(c)}</button>`).join("")}</div>`,
  el=>{
    el.classList.add("wide");
    const v=id=>{ const x=el.querySelector(id); return x?x.value.trim():""; };
    const msg=(t,ok)=>el.querySelector("#v-msg").innerHTML=`<div class="msg ${ok?"ok":"err"}">${esc(t)}</div>`;
    el.querySelector("#v-x").onclick=closePanel;
    el.querySelectorAll("[data-full]").forEach(b=>b.onclick=()=>painelEdit(b.dataset.full));
    el.querySelector("#v-save").onclick=async()=>{
      if(!state.db){ msg("Sem conexão com a base.",false); return; }
      const t=iso(new Date()), km=v("#v-km"), manut=el.querySelector("#v-manut").checked;
      const base={ placa_cavalo:v("#v-pc").toUpperCase(), placa_reboque:v("#v-pr").toUpperCase(), motorista:v("#v-mot"), local_entrega:v("#v-le"), status:v("#v-st"), localizacao:v("#v-loc"),
        inicio:v("#v-ini")||null, prev_chegada:v("#v-prev")||null, chegada:v("#v-cheg")||null, manut, manut_motivo:v("#v-mmot"), manut_lib:v("#v-mlib")||null,
        km_manual: km===""?null:Math.max(0,Math.round(+km)), km_loc: km===""?null:v("#v-loc"), editadoEm:t };
      if(manut && !MANUT_RE.test(base.status)) base.status="EM MANUTENÇÃO";
      if(!manut && MANUT_RE.test(base.status)) base.status="EM TRÂNSITO";
      try{
        for(const c of cns){ const old=state.follow[c], g=el.querySelector(`.fgrid[data-cn="${c}"]`), gv=k=>{ const x=g.querySelector(`[data-k="${k}"]`); return x?x.value.trim():""; };
          const nf=Object.assign({}, old||{}, base, { container:c, idOriginal:(old&&old.idOriginal)||c, data_prog:gv("dp")||null, obs:gv("obs"), armador:gv("arm").toUpperCase(), atualizadoEm:(old&&old.atualizadoEm)||null });
          if(manut && !(old&&emManut(old))) nf.manutDesde=t;
          await state.db.doc("follow/"+c).set(withHist(nf, old, t, "edição"));
          const p=state.prog[c]; if(p){ const np=Object.assign({},p,{necessidade:gv("need")||p.necessidade, criticidade:gv("crit")}); await state.db.doc("prog/"+c).set(np); } }
        closePanel(); toast(`Veículo ${base.placa_cavalo||placa} atualizado`);
      }catch(e){ msg("Falha ao salvar: "+(e.message||e.code),false); }
    };
  });
}
function painelEdit(cn){
  const p=state.prog[cn], f=state.follow[cn]||{}, novo=!cn;
  const dt=s=>s?String(s).slice(0,16):"";
  const stAtual=f.status||(state.follow[cn]?"EM TRÂNSITO":"EM PROGRAMAÇÃO"); const opts=[...new Set([...STATUS_OPTS, f.status].filter(Boolean))].map(s=>`<option ${s===stAtual?"selected":""}>${esc(s)}</option>`).join("");
  const a = p ? analisa(p, state.follow[cn], new Date()) : null;
  openPanel(`<h3>${novo?"Novo follow":`<span class="mono">${esc(cn)}</span>`}</h3>
    ${a?`<div><span class="pill ${a.tone}">${esc(a.label)}</span> ${a.gap!=null?`<span class="gap ${a.tone}">${dur(a.gap)}</span>`:""}</div>`:""}
    ${p?`<p>Necessidade Iveco <b>${fmt(p.necessidade)}</b>${isLinha(p)?" · item para linha":""} · ${esc(p.navio||"")} · ${esc(p.solicitante||"")}</p>`:""}
    <div class="sect">Follow-up</div>
    <div class="fgrid">
      ${novo?`<label class="f full">Container<input id="e-cn" class="mono" placeholder="ABCD1234567" autocomplete="off"></label>`:""}
      <label class="f">Status<select id="e-status">${opts}</select></label>
      <label class="f">Localização<input id="e-loc" value="${esc(f.localizacao||"")}"></label>
      <label class="f">Início de viagem<input id="e-ini" type="datetime-local" value="${dt(f.inicio)}"></label>
      <label class="f">Previsão de chegada<input id="e-prev" type="datetime-local" value="${dt(f.prev_chegada)}"></label>
      <label class="f">Data programada (follow)<input id="e-dp" type="datetime-local" value="${dt(f.data_prog)}"></label>
      <label class="f">Chegada no cliente<input id="e-cheg" type="datetime-local" value="${dt(f.chegada)}"></label>
      <label class="f">Placa cavalo<input id="e-pc" class="mono" value="${esc(f.placa_cavalo||"")}"></label>
      <label class="f">Placa reboque<input id="e-pr" class="mono" value="${esc(f.placa_reboque||"")}"></label>
      <label class="f">Motorista<input id="e-mot" value="${esc(f.motorista||"")}"></label>
      <label class="f">Local de entrega<input id="e-le" value="${esc(f.local_entrega||"SETE LAGOAS")}"></label>
      <label class="f full chk" style="flex-direction:row;align-items:center;gap:8px;color:var(--crit);font-weight:600"><input type="checkbox" id="e-manut" style="width:auto" ${emManut(f)?"checked":""}> Veículo em manutenção (alerta para o cliente)</label>
      <label class="f">Motivo da manutenção<input id="e-mmot" value="${esc(f.manut_motivo||"")}" placeholder="Ex.: pane elétrica, pneu, freio"></label>
      <label class="f">Previsão de liberação<input id="e-mlib" type="datetime-local" value="${String(f.manut_lib||"").slice(0,16)}"></label>
    </div>
    ${p?`<div class="sect">Programação Iveco</div><div class="fgrid">
      <label class="f">Necessidade na planta<input id="e-need" type="datetime-local" value="${dt(p.necessidade)}"></label>
      <label class="f">Criticidade<select id="e-crit"><option value="">—</option><option ${isLinha(p)?"selected":""}>ITEM PARA LINHA</option></select></label></div>`:""}
    <div id="e-msg"></div>
    <div class="row"><button class="btn primary" id="e-save" type="button">Salvar</button><button class="btn ghost" id="e-x" type="button">Cancelar</button>
      ${!novo&&state.follow[cn]?`<button class="btn danger" id="e-delf" type="button" style="margin-left:auto">Remover follow</button>`:""}
      ${!novo&&p?`<button class="btn danger" id="e-delp" type="button">Remover da programação</button>`:""}</div>
    ${f.hist&&f.hist.length?`<div class="sect">Histórico do follow</div><div class="hist">${f.hist.slice().reverse().map(h=>`<div><span class="num">${fmt(h.t)}</span><span>${h.orig==="edição"?"<b>edição</b> · ":""}${esc(h.status)} · ${esc(h.loc)}${h.prev?` · prev. ${fmt(h.prev)}`:""}${h.cheg?` · chegou ${fmt(h.cheg)}`:""}</span></div>`).join("")}</div>`:""}`,
  el=>{
    const v=id=>{ const x=el.querySelector(id); return x?x.value.trim():""; };
    const msg=(t,ok)=>el.querySelector("#e-msg").innerHTML=`<div class="msg ${ok?"ok":"err"}">${esc(t)}</div>`;
    el.querySelector("#e-x").onclick=closePanel;
    let armed=null;
    const confirmBtn=(btn,run)=>{ btn.onclick=async()=>{ if(armed!==btn){ armed=btn; btn.textContent="Confirmar remoção"; return; } try{ await run(); closePanel(); toast("Removido"); }catch(e){ msg("Falha: "+(e.message||e.code),false);} }; };
    const bf=el.querySelector("#e-delf"); bf&&confirmBtn(bf,()=>state.db.doc("follow/"+cn).delete());
    const bp=el.querySelector("#e-delp"); bp&&confirmBtn(bp,()=>state.db.doc("prog/"+cn).delete());
    el.querySelector("#e-save").onclick=async()=>{
      const c = novo ? (v("#e-cn").toUpperCase().match(/[A-Z]{4}\d{7}/)||[""])[0] : cn;
      if(!c){ msg("Informe um número de container válido (4 letras + 7 dígitos).",false); return; }
      if(!state.db){ msg("Sem conexão com a base.",false); return; }
      const now=iso(new Date()); const old=state.follow[c];
      const nf=Object.assign({}, old||{}, { container:c, idOriginal:(old&&old.idOriginal)||c, status:v("#e-status"), localizacao:v("#e-loc"), inicio:v("#e-ini")||null, prev_chegada:v("#e-prev")||null,
        data_prog:v("#e-dp")||null, chegada:v("#e-cheg")||null, placa_cavalo:v("#e-pc").toUpperCase(), placa_reboque:v("#e-pr").toUpperCase(), motorista:v("#e-mot"), local_entrega:v("#e-le"), atualizadoEm:(old&&old.atualizadoEm)||null, editadoEm:now,
        manut: el.querySelector("#e-manut").checked, manut_motivo:v("#e-mmot"), manut_lib:v("#e-mlib")||null });
      if(nf.manut && !MANUT_RE.test(nf.status)) nf.status="EM MANUTENÇÃO";
      if(nf.manut && !(old&&emManut(old))) nf.manutDesde=now;
      if(!nf.manut && MANUT_RE.test(nf.status)) nf.status="EM TRÂNSITO";
      try{
        await state.db.doc("follow/"+c).set(withHist(nf, old, now, "edição"));
        // o mesmo caminhão leva outro container: replica a situação de manutenção
        if(nf.placa_cavalo && (nf.manut || (old&&emManut(old)))){ for(const x of Object.values(state.follow)){ if(x.container===c || x.placa_cavalo!==nf.placa_cavalo || x.chegada) continue;
          const nx=Object.assign({},x,{status:nf.status, localizacao:nf.localizacao, manut:nf.manut, manut_motivo:nf.manut_motivo, manut_lib:nf.manut_lib, manutDesde:nf.manutDesde||x.manutDesde||null, prev_chegada:nf.prev_chegada, editadoEm:now});
          await state.db.doc("follow/"+x.container).set(withHist(nx, x, now, "edição")); } }
        if(p){ const np=Object.assign({},p,{necessidade:v("#e-need")||p.necessidade, criticidade:v("#e-crit")}); await state.db.doc("prog/"+c).set(np); }
        closePanel(); toast("Follow de "+c+" salvo");
      }catch(e){ msg("Falha ao salvar: "+(e.message||e.code),false); }
    };
  });
}

function textoResumo(){
  const now=new Date(); const rows=linhasComp().filter(r=>!state.dia||dia(r.p.necessidade)===state.dia)
    .sort((a,b)=>String(a.p.necessidade).localeCompare(String(b.p.necessidade)));
  const n=rows.length, com=rows.filter(r=>r.f).length;
  let t=`*IVECO – Necessidade x Posição dos veículos*\nAtualizado ${fmt(now)}\n\nProgramados: ${n} | Com veículo: ${com} | Sem veículo: ${n-com}\n`;
  const blocos=[["Em trânsito",r=>r.f&&r.a.eta&&!r.f.chegada],["Aguardando carregamento no porto",r=>r.f&&!r.a.eta],["Entregues",r=>r.f&&r.f.chegada],["Aguardando alocação de veículo",r=>!r.f]];
  blocos.forEach(([nome,fn])=>{ const b=rows.filter(fn); if(!b.length) return; t+=`\n*${nome} (${b.length})*\n`;
    b.forEach(r=>{ const f=r.f; t+=`• ${r.p.container}${isLinha(r.p)?" [LINHA]":""} – nec. ${fmt(r.p.necessidade)}`;
      if(f){ t+= f.chegada?` – chegou ${fmt(f.chegada)}`:(f.prev_chegada?` – ${f.localizacao} – prev. ${fmt(f.prev_chegada)}`:` – ${f.localizacao}`); }
      t+="\n"; }); });
  return t;
}
/* ---------- resumo visual para o cliente ---------- */
const CL = { bg:"#F2F6F8", card:"#FFFFFF", ink:"#13202A", muted:"#5F6F7B", line:"#DCE3E8", zebra:"#F7FAFB",
  band:"#0E3441", bandInk:"#FFFFFF", bandSub:"#9FC3CE", accent:"#0B6A84", late:"#B8322A", ontime:"#1C7F46",
  st:{ manut:["#B8322A","#FBE5E2"], betim:["#A8660A","#FBEFD8"], ok:["#1C7F46","#E1F2E7"], trans:["#2B5AA6","#E4EDFA"], desc:["#0B6A84","#DDF0F4"], porto:["#A8660A","#FBEFD8"], sem:["#56656F","#E9EEF1"] } };
const ORDEM_ST = ["manut","betim","trans","desc","porto","sem","ok"];
const NOME_ST = { manut:"Veículo em manutenção", betim:"Em Betim (aguarda envio à Iveco)", trans:"Em trânsito", desc:"Aguardando descarga", porto:"Aguardando carregamento", sem:"Aguardando veículo", ok:"Entregue" };
function stCliente(r){ const f=r.f; if(!f) return "sem"; if(enviarIveco(f)) return "betim"; if(f.chegada) return "ok"; if(emManut(f)) return "manut"; if(/DESCARGA/i.test(f.status||"")) return "desc"; if(!f.prev_chegada && !/AGUARDANDO CARREG|PORTO|PROGRAMA/i.test((f.localizacao||"")+" "+(f.status||""))) return "trans"; if(f.prev_chegada) return "trans"; return "porto"; }
function lugar(s){
  s=(s||"").replace(/\s*AGUARDANDO.*$/i,"").trim(); if(!s) return "—";
  return s.toLowerCase().replace(/(^|[\s\-\/(])(\S)/g,(m,a,b)=>a+b.toUpperCase())
    .replace(/\b(De|Do|Da|Dos|Das|E)\b/g,w=>w.toLowerCase()).replace(/(^|[\s\-])([a-z]{2})$/i,(m,a,b)=>a+b.toUpperCase());
}
function resumoRows(){
  return linhasComp().filter(r=>!state.dia||dia(r.p.necessidade)===state.dia)
    .map(r=>Object.assign(r,{st:stCliente(r)}))
    .sort((a,b)=>String(a.p.necessidade).localeCompare(String(b.p.necessidade)));
}
function desvioCliente(r){
  if(r.st==="sem"||r.st==="porto"||r.a.gap==null||!r.a.eta) return null;
  return r.a.gap<=0 ? {t:"No prazo", c:CL.ontime} : {t:dur(r.a.gap), c:CL.late};
}
function refDia(rows){ const ds=[...new Set(rows.map(r=>dia(r.p.necessidade)).filter(Boolean))].sort(); return ds.length===1? diaBR(ds[0]) : ds.length? diaBR(ds[0])+" a "+diaBR(ds[ds.length-1]) : ""; }

function rr(ctx,x,y,w,h,r){ ctx.beginPath(); ctx.moveTo(x+r,y); ctx.arcTo(x+w,y,x+w,y+h,r); ctx.arcTo(x+w,y+h,x,y+h,r); ctx.arcTo(x,y+h,x,y,r); ctx.arcTo(x,y,x+w,y,r); ctx.closePath(); }
function fit(ctx,t,max){ t=String(t??""); if(ctx.measureText(t).width<=max) return t; while(t.length>1 && ctx.measureText(t+"…").width>max) t=t.slice(0,-1); return t+"…"; }
const FNT=(w,s,f)=>`${w} ${s}px ${f==="m"?'"IBM Plex Mono",ui-monospace,Menlo,monospace':f==="c"?'"IBM Plex Sans Condensed","Arial Narrow",Arial,sans-serif':'"IBM Plex Sans",Arial,sans-serif'}`;
function pill(ctx,x,y,k,txt){ ctx.font=FNT(600,13); const w=ctx.measureText(txt).width+22; rr(ctx,x,y,w,26,13); ctx.fillStyle=CL.st[k][1]; ctx.fill(); ctx.fillStyle=CL.st[k][0]; ctx.textBaseline="middle"; ctx.fillText(txt,x+11,y+13.5); ctx.textBaseline="alphabetic"; return w; }
function tagLinha(ctx,x,y){ ctx.font=FNT(700,11,"c"); const t="ITEM P/ LINHA", w=ctx.measureText(t).width+12; rr(ctx,x,y,w,18,4); ctx.strokeStyle=CL.late; ctx.lineWidth=1.2; ctx.stroke(); ctx.fillStyle=CL.late; ctx.textBaseline="middle"; ctx.fillText(t,x+6,y+9.5); ctx.textBaseline="alphabetic"; return w; }

async function desenhaResumo(modo, comDesvio){
  try{ await document.fonts.ready; }catch(e){}
  const rows=resumoRows(), now=new Date();
  const S=2, W=1200, P=40, IW=W-2*P;
  const headH=132, kpiY=headH+24, kpiH=84;
  const bodyY=kpiY+kpiH+28;
  const grupos=ORDEM_ST.map(k=>({k,rows:rows.filter(r=>r.st===k)})).filter(g=>g.rows.length);
  const COLS=3, GAP=16, cardW=(IW-GAP*(COLS-1))/COLS, cardH=comDesvio?156:136, rowH=50;
  let bodyH = modo==="tabela" ? 46+rows.length*rowH : grupos.reduce((s,g)=>s+44+Math.ceil(g.rows.length/COLS)*(cardH+GAP),0);
  if(!rows.length) bodyH=80;
  const H=bodyY+bodyH+70;
  const cv=document.createElement("canvas"); cv.width=W*S; cv.height=H*S; const ctx=cv.getContext("2d"); ctx.scale(S,S);
  ctx.fillStyle=CL.bg; ctx.fillRect(0,0,W,H);

  // cabeçalho
  ctx.fillStyle=CL.band; ctx.fillRect(0,0,W,headH);
  ctx.fillStyle=CL.accent; ctx.fillRect(0,headH-5,W,5);
  ctx.fillStyle=CL.bandSub; ctx.font=FNT(600,13,"c"); if("letterSpacing" in ctx) ctx.letterSpacing="2px";
  ctx.fillText("TORRE DE CONTROLE · PORTOS RJ/SANTOS → IVECO SETE LAGOAS", P, 40);
  if("letterSpacing" in ctx) ctx.letterSpacing="0px";
  ctx.fillStyle=CL.bandInk; ctx.font=FNT(700,34,"c"); ctx.fillText("Posição dos containers Iveco", P, 82);
  ctx.fillStyle=CL.bandSub; ctx.font=FNT(400,16); ctx.fillText(`Necessidade de ${refDia(rows)}  ·  Atualizado em ${fmt(now)}`, P, 110);

  // KPIs
  const kp=[["Programados",rows.length,CL.accent]].concat(ORDEM_ST.filter(k=>(k!=="desc"&&k!=="manut"&&k!=="betim")||rows.some(r=>r.st===k)).map(k=>[NOME_ST[k],rows.filter(r=>r.st===k).length,CL.st[k][0]]));
  const kw=(IW-12*(kp.length-1))/kp.length;
  kp.forEach(([t,v,c],i)=>{ const x=P+i*(kw+12); rr(ctx,x,kpiY,kw,kpiH,10); ctx.fillStyle=CL.card; ctx.fill(); ctx.strokeStyle=CL.line; ctx.lineWidth=1; ctx.stroke();
    ctx.fillStyle=c; ctx.fillRect(x+14,kpiY+16,4,kpiH-32);
    ctx.font=FNT(700,34,"c"); ctx.fillText(String(v),x+28,kpiY+50); ctx.fillStyle=CL.muted; ctx.font=FNT(500,13); ctx.fillText(fit(ctx,t,kw-40),x+28,kpiY+70); });

  if(!rows.length){ ctx.fillStyle=CL.muted; ctx.font=FNT(400,16); ctx.fillText("Nenhum container programado para o período selecionado.",P,bodyY+40); }
  else if(modo==="tabela"){
    const cols = comDesvio
      ? [["Container",0,240],["Necessidade",240,130],["Situação",370,220],["Posição atual",590,220],["Previsão",810,150],["× Necessidade",960,140]]
      : [["Container",0,260],["Necessidade",260,140],["Situação",400,230],["Posição atual",630,290],["Previsão",920,180]];
    rr(ctx,P,bodyY,IW,bodyH,12); ctx.fillStyle=CL.card; ctx.fill(); ctx.strokeStyle=CL.line; ctx.stroke();
    ctx.save(); rr(ctx,P,bodyY,IW,bodyH,12); ctx.clip();
    ctx.fillStyle=CL.band; ctx.fillRect(P,bodyY,IW,46);
    ctx.fillStyle=CL.bandInk; ctx.font=FNT(600,13,"c"); if("letterSpacing" in ctx) ctx.letterSpacing="1px";
    cols.forEach(([t,x])=>ctx.fillText(t.toUpperCase(),P+18+x,bodyY+29)); if("letterSpacing" in ctx) ctx.letterSpacing="0px";
    rows.forEach((r,i)=>{ const y=bodyY+46+i*rowH, cy=y+rowH/2+5, X=c=>P+18+cols[c][1];
      if(i%2){ ctx.fillStyle=CL.zebra; ctx.fillRect(P,y,IW,rowH); }
      ctx.fillStyle=CL.st[r.st][0]; ctx.fillRect(P,y,5,rowH);
      ctx.strokeStyle=CL.line; ctx.beginPath(); ctx.moveTo(P,y); ctx.lineTo(P+IW,y); ctx.stroke();
      ctx.fillStyle=CL.ink; ctx.font=FNT(600,15,"m"); ctx.fillText(r.p.container,X(0),cy); const cw=ctx.measureText(r.p.container).width;
      if(isLinha(r.p)) tagLinha(ctx,X(0)+cw+10,cy-14);
      ctx.fillStyle=CL.ink; ctx.font=FNT(600,15); ctx.fillText(fmt(r.p.necessidade),X(1),cy);
      pill(ctx,X(2),y+(rowH-26)/2,r.st,NOME_ST[r.st]);
      ctx.fillStyle=r.f?CL.ink:CL.muted; ctx.font=FNT(400,14); ctx.fillText(fit(ctx,r.f?lugar(r.f.localizacao):"—",cols[3][2]-16),X(3),cy);
      ctx.font=FNT(500,15); ctx.fillStyle=CL.ink; const prev=r.f&&r.f.chegada?"chegou "+fmt(r.f.chegada):(r.f&&r.f.prev_chegada?fmt(r.f.prev_chegada):"—"); ctx.fillText(prev,X(4),cy);
      if(comDesvio){ const d=desvioCliente(r); ctx.font=FNT(600,15,"m"); ctx.fillStyle=d?d.c:CL.muted; ctx.fillText(d?d.t:"—",X(5),cy); }
    });
    ctx.restore();
  } else {
    let y=bodyY;
    grupos.forEach(g=>{
      const [c,soft]=CL.st[g.k];
      ctx.fillStyle=c; ctx.beginPath(); ctx.arc(P+7,y+17,7,0,Math.PI*2); ctx.fill();
      ctx.fillStyle=CL.ink; ctx.font=FNT(700,20,"c"); ctx.fillText(`${NOME_ST[g.k]}`,P+24,y+24);
      const tw=ctx.measureText(NOME_ST[g.k]).width; ctx.fillStyle=CL.muted; ctx.font=FNT(500,16,"c"); ctx.fillText(`(${g.rows.length})`,P+32+tw,y+24);
      y+=44;
      g.rows.forEach((r,i)=>{ const cx=P+(i%COLS)*(cardW+GAP), cy=y+Math.floor(i/COLS)*(cardH+GAP);
        rr(ctx,cx,cy,cardW,cardH,12); ctx.fillStyle=CL.card; ctx.fill(); ctx.strokeStyle=CL.line; ctx.lineWidth=1; ctx.stroke();
        ctx.save(); rr(ctx,cx,cy,cardW,cardH,12); ctx.clip(); ctx.fillStyle=c; ctx.fillRect(cx,cy,6,cardH); ctx.restore();
        const ix=cx+22, iw=cardW-40;
        ctx.fillStyle=CL.ink; ctx.font=FNT(600,18,"m"); ctx.fillText(r.p.container,ix,cy+34);
        if(isLinha(r.p)){ ctx.font=FNT(700,11,"c"); const w=ctx.measureText("ITEM P/ LINHA").width+12; tagLinha(ctx,cx+cardW-18-w,cy+20); }
        const linhaInfo=(lb,val,yy,bold)=>{ ctx.fillStyle=CL.muted; ctx.font=FNT(500,13); ctx.fillText(lb,ix,yy); ctx.fillStyle=CL.ink; ctx.font=FNT(bold?600:400,14); ctx.textAlign="right"; ctx.fillText(fit(ctx,val,iw-110),ix+iw,yy); ctx.textAlign="left"; };
        ctx.strokeStyle=CL.line; ctx.beginPath(); ctx.moveTo(ix,cy+50); ctx.lineTo(ix+iw,cy+50); ctx.stroke();
        linhaInfo("Necessidade",fmt(r.p.necessidade),cy+74,true);
        linhaInfo("Posição atual",r.f?lugar(r.f.localizacao):"—",cy+98);
        linhaInfo(r.f&&r.f.chegada?"Chegada":"Previsão",r.f&&r.f.chegada?fmt(r.f.chegada):(r.f&&r.f.prev_chegada?fmt(r.f.prev_chegada):"—"),cy+122,true);
        if(comDesvio){ const d=desvioCliente(r); ctx.fillStyle=CL.muted; ctx.font=FNT(500,13); ctx.fillText("Previsão × necessidade",ix,cy+144); ctx.font=FNT(600,14,"m"); ctx.fillStyle=d?d.c:CL.muted; ctx.textAlign="right"; ctx.fillText(d?d.t:"—",ix+iw,cy+144); ctx.textAlign="left"; }
      });
      y+=Math.ceil(g.rows.length/COLS)*(cardH+GAP);
    });
  }
  // rodapé
  ctx.fillStyle=CL.muted; ctx.font=FNT(400,13);
  ctx.fillText("Informações do monitoramento de hora em hora. Horários sujeitos a alteração conforme trânsito, carregamento e descarga.",P,H-30);
  return cv;
}

function htmlResumo(comDesvio){
  const rows=resumoRows(), now=new Date();
  const td='style="padding:8px 12px;border-bottom:1px solid #DCE3E8;font-family:Arial,sans-serif;font-size:13px;color:#13202A"';
  const th='style="padding:9px 12px;background:#0E3441;color:#FFFFFF;font-family:Arial,sans-serif;font-size:12px;text-align:left;text-transform:uppercase;letter-spacing:.5px"';
  const cont=ORDEM_ST.map(k=>[k,rows.filter(r=>r.st===k).length]).filter(x=>x[1]);
  let h=`<div style="font-family:Arial,sans-serif;color:#13202A"><div style="font-size:18px;font-weight:bold;color:#0E3441">Posição dos containers Iveco</div>
  <div style="font-size:13px;color:#5F6F7B;margin:2px 0 10px">Necessidade de ${refDia(rows)} · Atualizado em ${fmt(now)}</div>
  <div style="margin-bottom:10px;font-size:13px">${[`<b>${rows.length}</b> programados`].concat(cont.map(([k,n])=>`<span style="color:${CL.st[k][0]}"><b>${n}</b> ${NOME_ST[k].toLowerCase()}</span>`)).join(" &nbsp;·&nbsp; ")}</div>
  <table cellspacing="0" cellpadding="0" style="border-collapse:collapse;border:1px solid #DCE3E8"><tr><th ${th}>Container</th><th ${th}>Necessidade</th><th ${th}>Situação</th><th ${th}>Posição atual</th><th ${th}>Previsão chegada</th>${comDesvio?`<th ${th}>Previsão × necess.</th>`:""}</tr>`;
  rows.forEach((r,i)=>{ const [c,soft]=CL.st[r.st], d=desvioCliente(r), bg=i%2?"#F7FAFB":"#FFFFFF";
    h+=`<tr style="background:${bg}"><td ${td}><b style="font-family:Consolas,monospace">${esc(r.p.container)}</b>${isLinha(r.p)?' <span style="color:#B8322A;font-size:11px;font-weight:bold;border:1px solid #B8322A;padding:0 4px">ITEM P/ LINHA</span>':""}</td>
    <td ${td}><b>${fmt(r.p.necessidade)}</b></td><td ${td}><span style="background:${soft};color:${c};font-weight:bold;padding:3px 9px;border-radius:10px;white-space:nowrap">${NOME_ST[r.st]}</span></td>
    <td ${td}>${esc(r.f?lugar(r.f.localizacao):"—")}</td><td ${td}>${r.f&&r.f.chegada?"chegou "+fmt(r.f.chegada):(r.f&&r.f.prev_chegada?fmt(r.f.prev_chegada):"—")}</td>
    ${comDesvio?`<td ${td}><b style="color:${d?d.c:"#5F6F7B"}">${d?d.t:"—"}</b></td>`:""}</tr>`; });
  return h+`</table><div style="font-size:11px;color:#5F6F7B;margin-top:8px">Informações do monitoramento de hora em hora. Horários sujeitos a alteração conforme trânsito, carregamento e descarga.</div></div>`;
}

function painelResumo(){
  let modo="tabela", comDesvio=true, cv=null;
  try{ modo=localStorage.getItem("iveco.resumoModo")||"tabela"; comDesvio=localStorage.getItem("iveco.resumoDesvio")!=="0"; }catch(e){}
  openPanel(`<h3>Resumo para o cliente</h3>
    <p>Imagem pronta para o grupo de WhatsApp e tabela formatada para o corpo do e-mail, com os dados atuais${state.dia?` (necessidade de ${diaBR(state.dia)})`:""}.</p>
    <div class="row">
      <div class="seg" role="group" aria-label="Formato"><button type="button" data-m="tabela">Tabela</button><button type="button" data-m="cards">Cards</button></div>
      <label class="chk"><input type="checkbox" id="r-desvio"> Mostrar previsão × necessidade</label>
    </div>
    <div class="prev"><img id="r-img" alt="Prévia do resumo para o cliente"></div>
    <div class="row">
      <button class="btn primary" id="r-png" type="button">Baixar imagem (PNG)</button>
      <button class="btn" id="r-cimg" type="button">Copiar imagem</button>
      <button class="btn" id="r-mail" type="button">Copiar tabela p/ e-mail</button>
      <button class="btn ghost" id="r-txt" type="button">Copiar texto</button>
      <button class="btn ghost" id="r-x" type="button" style="margin-left:auto">Fechar</button>
    </div>
    <div id="r-msg"></div>`, async el=>{
    el.classList.add("wide");
    const msg=(t,ok)=>el.querySelector("#r-msg").innerHTML=`<div class="msg ${ok?"ok":"err"}">${esc(t)}</div>`;
    const img=el.querySelector("#r-img"), chk=el.querySelector("#r-desvio"); chk.checked=comDesvio;
    const segs=el.querySelectorAll(".seg button");
    const redraw=async()=>{ segs.forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.m===modo))); cv=await desenhaResumo(modo,comDesvio); img.src=cv.toDataURL("image/png");
      try{ localStorage.setItem("iveco.resumoModo",modo); localStorage.setItem("iveco.resumoDesvio",comDesvio?"1":"0"); }catch(e){} };
    segs.forEach(b=>b.onclick=()=>{ modo=b.dataset.m; redraw(); });
    chk.onchange=()=>{ comDesvio=chk.checked; redraw(); };
    el.querySelector("#r-x").onclick=closePanel;
    const blob=()=>new Promise(res=>cv.toBlob(res,"image/png"));
    const nome=()=>{ const d=new Date(); return `Iveco_posicao_${pad(d.getDate())}${pad(d.getMonth()+1)}_${pad(d.getHours())}${pad(d.getMinutes())}_${modo}.png`; };
    el.querySelector("#r-png").onclick=async()=>{ const dl=await window.APP_SERVICOS?.use?.("downloads"); if(!dl){ msg("Download indisponível nesta visualização. Use Copiar imagem.",false); return; }
      try{ await dl.save({filename:nome(), data:await blob()}); msg("Imagem salva. Anexe no grupo de WhatsApp.",true); }catch(e){ if(e.code!=="declined") msg("Não foi possível salvar ("+e.code+").",false); } };
    el.querySelector("#r-cimg").onclick=()=>{ try{ navigator.clipboard.write([new ClipboardItem({"image/png":blob()})]).then(()=>msg("Imagem copiada. Cole direto na conversa do WhatsApp Web ou no e-mail.",true),()=>msg("Este navegador não permite copiar imagem aqui. Use Baixar imagem.",false)); }catch(e){ msg("Este navegador não permite copiar imagem aqui. Use Baixar imagem.",false); } };
    el.querySelector("#r-mail").onclick=()=>{ const h=htmlResumo(comDesvio), t=textoResumo();
      try{ navigator.clipboard.write([new ClipboardItem({"text/html":new Blob([h],{type:"text/html"}),"text/plain":new Blob([t],{type:"text/plain"})})]).then(()=>msg("Tabela copiada. Cole no corpo do e-mail (Ctrl+V).",true),()=>msg("Não foi possível copiar a tabela neste navegador. Use Copiar imagem ou Baixar imagem.",false)); }
      catch(e){ msg("Não foi possível copiar a tabela neste navegador. Use Copiar imagem ou Baixar imagem.",false); } };
    el.querySelector("#r-txt").onclick=()=>{ navigator.clipboard.writeText(textoResumo()).then(()=>msg("Texto copiado.",true),()=>msg("Não foi possível copiar o texto.",false)); };
    await redraw();
  });
}

/* ---------- resumo para o gerente (WhatsApp) ---------- */
const GER_COR={crit:"#B8322A",warn:"#A8660A",ok:"#1C7F46",info:"#4755A0",desc:"#1E7F95",done:"#5A6A77"};
const GER_EMO={crit:"🔴",warn:"🟠",ok:"🟢",info:"⚪",desc:"🔵",done:"✅"};
const tomLinha=r=>r.carga==="descarga"?"desc":r.carga==="entregue"?"done":r.tone;
function biFiltrosTxt(){
  const b=state.bi, out=[];
  const dest=A(b.dest), dias=A(b.dia), crit=A(b.crit), sit=A(b.sit), cn=A(b.cn), carga=A(b.carga);
  if(dest.length) out.push("Planta "+dest.join(" / "));
  if(dias.length) out.push("Expectativa "+dias.map(d=>d==="__hoje__"?"hoje":diaBR(d).slice(0,5)).join(", "));
  if(crit.length) out.push(crit.map(c=>c==="__crit__"?"Críticos Iveco":c==="__sem__"?"Sem criticidade":c).join(", "));
  if(sit.length) out.push(sit.map(s=>BI_SIT[s]).join(", "));
  if(carga.length && !mesmo(carga,CARGA_PADRAO)) out.push(carga.map(c=>BI_CARGA[c]).join(", "));
  if(cn.length) out.push(cn.length<=3?cn.join(", "):cn.length+" containers selecionados");
  if(b.prog==="prog") out.push("Só programação Iveco");
  return out.join(" · ");
}
function gerDados(){
  const now=new Date(), b=state.bi, base=biLinhas(), hj=iso(now).slice(0,10), op=biFiltra(base);
  /* mesmos processos do Painel BI: em operação + entregues de hoje (ou das datas filtradas) */
  const rows=biFiltra(base,"carga").filter(r=>op.includes(r)||(r.carga==="entregue"&&((r.f&&r.f.chegada&&dia(r.f.chegada)===hj)||A(b.dia).length)));
  const mapa=rows;
  const RK={crit:0,warn:1,info:2,ok:3};
  const lista=rows.slice().sort((a,c)=>(RK[a.tone]-RK[c.tone])||(!!c.crit-!!a.crit)||String(a.need).localeCompare(String(c.need)));
  const cont=(fn)=>{ const m={}; rows.forEach(r=>{ const k=fn(r); m[k]=(m[k]||0)+1; }); return m; };
  const alertas=listaAlertas().filter(a=>statusAl(a,now).k==="ativo").concat(listaAlertas().filter(a=>statusAl(a,now).k==="prog"&&statusAl(a,now).ini-now<24*3600000)).slice(0,5)
    .map(a=>{ const s=statusAl(a,now); return {titulo:a.titulo, quando:s.t, tom:s.k==="prog"?"info":(a.tipo==="acidente"||a.tipo==="interdicao"||a.sev==="alta")?"crit":"warn"}; });
  const C=biChegadas(biFiltra(base,"carga").filter(r=>r.carga!=="semveic"), now);
  // agrupamento por posição (como no mapa), do mais perto ao mais longe da planta
  const grupos={}; mapa.filter(r=>r.f).forEach(r=>{ const ag=!r.placa&&r.carga!=="descarga"&&r.carga!=="entregue"&&!r.f.chegada&&!r.f.inicio; const k=(ag?"ag:":"")+(r.node||("?"+lugar(r.f.localizacao))); const nm=r.node&&NO[r.node]?NO[r.node].n:lugar(r.f.localizacao); const g=grupos[k]=grupos[k]||{k, nome:ag?((/SADA/i.test(r.f.localizacao||"")?"Sada ":"")+nm+" · aguardando veículo"):nm, veic:{}, km:null};
    const q=r.f.chegada?null:restante(r.f,now); const kk=r.f.chegada?0:(q&&q.km!=null?q.km:null); if(kk!=null) g.km=g.km==null?kk:Math.min(g.km,kk);
    const v=g.veic[r.placa||r.cn]=g.veic[r.placa||r.cn]||{placa:r.placa, reboque:r.f.placa_reboque||"", rs:[], f:r.f, q}; v.rs.push(r); });
  const posicoes=Object.values(grupos).map(g=>({...g, veic:Object.values(g.veic)})).sort((a,c)=>(a.km==null?1e9:a.km)-(c.km==null?1e9:c.km));
  const manut=[...new Set(rows.filter(r=>r.manut).map(r=>r.placa))];
  return {now, rows, mapa, lista, posicoes, alertas, C, manut,
    carga:cont(r=>r.carga), dest:cont(r=>r.dest), sit:cont(r=>r.tone),
    critRisco:rows.filter(r=>r.crit&&r.tone!=="ok"&&r.carga!=="entregue"),
    semVeic:rows.filter(r=>r.carga==="semveic"), filtros:biFiltrosTxt(), veics:new Set(mapa.filter(r=>r.f&&r.node&&r.carga!=="entregue").map(r=>r.placa)).size};
}
function textoGerente(d){
  const L=[], n=d.rows.length, now=d.now;
  L.push("*🚛 Torre de Controle · Carga Iveco*");
  L.push(`*Resumo da operação* – ${fmt(now)}`);
  L.push(`Último follow: ${state.meta.ultimoFollow?fmt(state.meta.ultimoFollow):"—"}`);
  if(d.filtros) L.push(`_Filtro: ${d.filtros}_`);
  L.push("");
  L.push(`*Processos: ${n}* · 🔴 Atrasados *${d.sit.crit||0}* · 🟠 Em risco *${d.sit.warn||0}* · 🟢 No prazo *${d.sit.ok||0}*`);
  const ordC=["transito","porto","betim","descarga","semveic","entregue"];
  if(d.critRisco.length) L.push(`⚠️ Críticos Iveco em risco: *${d.critRisco.length}* (${d.critRisco.map(r=>r.cn).join(", ")})`);
  if(d.manut.length) L.push(`🔧 Em manutenção: *${d.manut.length}* (${d.manut.join(", ")})`);
  const ate=d.C.ate.concat(d.C.limite);
  L.push(`🕚 Chegam hoje até 23h: *${ate.length}* veículo${ate.length===1?"":"s"}${ate.length?" ("+ate.map(v=>`${v.placa} ${fmtH(iso(v.eta))}`).join(", ")+")":""}${d.C.chegou.length?` · já chegaram hoje: *${d.C.chegou.length}*`:""}`);
  L.push("");
  L.push(`*📍 Posição dos veículos* (${d.veics} no corredor)`);
  if(!d.posicoes.length) L.push("Nenhum veículo em rota para o filtro atual.");
  d.posicoes.forEach(g=>{
    L.push(""); L.push(`*${g.nome}*${g.km===0?" – na planta":g.km!=null?` – ${g.km} km da planta`:""}`);
    g.veic.forEach(v=>{ const r0=v.rs.slice().sort((a,c)=>({crit:0,warn:1,info:2,ok:3}[a.tone]-{crit:0,warn:1,info:2,ok:3}[c.tone]))[0], t=tomLinha(r0);
      const cab=`${GER_EMO[t]} ${v.rs.map(r=>r.cn+(r.crit?` [${r.crit}]`:"")).join(" + ")} · ${v.placa||"sem placa"}`;
      if(r0.carga==="descarga"||r0.carga==="entregue"){ L.push(`${cab} – ${r0.carga==="descarga"?"aguardando descarga desde "+fmtH(v.f.chegada):"entregue "+fmt(v.f.chegada)}`); return; }
      L.push(cab);
      let det;
      if(r0.manut) det="🔧 "+manutTxt(v.f);
      else if(r0.carga==="descarga") det=`no cliente desde ${fmt(v.f.chegada)} · aguardando descarga`;
      else if(r0.carga==="entregue") det=`entregue ${fmt(v.f.chegada)}`;
      else if(v.q) det=v.q.txt; else det="posição sem distância cadastrada";
      const nec=v.rs.map(r=>r.need?fmt(r.need):"—").join(" / ");
      const des=r0.carga==="entregue"||r0.carga==="descarga"?"":(r0.gap!=null?` · ${dur(r0.gap)} (${BI_SIT[r0.tone].toLowerCase()})`:` · ${BI_SIT[r0.tone].toLowerCase()}`);
      L.push(`   ${det}`);
      L.push(`   Nec. ${nec}${des}`);
    });
  });
  if(d.semVeic.length){ L.push(""); L.push(`*⚪ Sem veículo alocado (${d.semVeic.length})*`);
    d.semVeic.sort((a,c)=>String(a.need).localeCompare(String(c.need))).forEach(r=>L.push(`• ${r.cn}${r.crit?` [${r.crit}]`:""} – nec. ${r.need?fmt(r.need):"—"}`)); }
  if(d.alertas.length){ L.push(""); L.push("*🛣️ Rodovias*"); d.alertas.forEach(a=>L.push(`${a.tom==="crit"?"🔴":a.tom==="warn"?"🟠":"🔵"} ${a.titulo} – ${a.quando.toLowerCase()}`)); }
  return L.join("\n");
}
/* mapa SVG do painel convertido em imagem (sempre no tema claro) */
async function mapaImagem(rowsMapa, now){
  const root=document.documentElement, prevT=root.getAttribute("data-theme"), sel=state.bi.sel;
  root.setAttribute("data-theme","light"); state.bi.sel="";
  const host=document.createElement("div"); host.style.cssText="position:fixed;left:-30000px;top:0;width:600px";
  let txt="", vw=560, vh=800;
  try{
    host.innerHTML=biMapa(rowsMapa,now); document.body.appendChild(host);
    const svg=host.querySelector("svg"), cs0=getComputedStyle(root);
    const rv=s=>s.replace(/var\((--[\w-]+)\)/g,(m,v)=>cs0.getPropertyValue(v).trim()||"#000");
    const PROPS=["fill","stroke","stroke-width","stroke-dasharray","stroke-linecap","opacity","font-family","font-size","font-weight","font-style","letter-spacing","paint-order","text-anchor"];
    svg.querySelectorAll("*").forEach(n=>{
      for(const a of [...n.attributes]) if(a.value.includes("var(")) n.setAttribute(a.name, rv(a.value));
      if(n.closest("defs")||!n.getAttribute("class")) return;
      const cs=getComputedStyle(n); let st="";
      PROPS.forEach(p=>{ const v=cs.getPropertyValue(p); if(v) st+=`${p}:${v.replace(/"/g,"'")};`; });
      n.setAttribute("style", st+(n.getAttribute("style")||""));
    });
    const vb=(svg.getAttribute("viewBox")||"0 0 560 800").split(/\s+/).map(Number); vw=vb[2]; vh=vb[3];
    svg.setAttribute("xmlns","http://www.w3.org/2000/svg"); svg.setAttribute("width",vw*3); svg.setAttribute("height",vh*3); svg.removeAttribute("class");
    svg.setAttribute("style","font-family:Arial,sans-serif");
    txt=new XMLSerializer().serializeToString(svg);
  } finally {
    host.remove(); prevT==null?root.removeAttribute("data-theme"):root.setAttribute("data-theme",prevT); state.bi.sel=sel;
  }
  const img=new Image(); img.src="data:image/svg+xml;charset=utf-8,"+encodeURIComponent(txt);
  await img.decode();
  return {img, vw, vh};
}
const TRUCK_P=["M1.5 3.5h19v11h-19z","M21.5 6.5h6l4.5 4.6v3.4h-10.5z"];
function truckCv(ctx,x,y,w,cor){ const s=w/34; ctx.save(); ctx.translate(x,y); ctx.scale(s,s); ctx.fillStyle=cor; ctx.strokeStyle="#fff"; ctx.lineWidth=1.1;
  TRUCK_P.forEach(d=>{ const p=new Path2D(d); ctx.fill(p); ctx.stroke(p); }); ctx.fillStyle="#ffffffcc"; ctx.fill(new Path2D("M23.3 7.8h3.6l2.8 2.9h-6.4z"));
  [7.5,26].forEach(cx=>{ ctx.beginPath(); ctx.arc(cx,17,2.9,0,Math.PI*2); ctx.fillStyle="#1c2a33"; ctx.fill(); ctx.strokeStyle="#fff"; ctx.lineWidth=1.2; ctx.stroke(); }); ctx.restore(); }
/* imagens verticais para celular (1080 × 1920, uma ou mais páginas) */
async function desenhaGerente(d,op){ op=Object.assign({mapa:true,det:true},op||{});
  try{ await document.fonts.ready; }catch(e){}
  const S=3, W=540, PH=960, P=18, INK="#13202A", MUT="#5A6A77", LINE="#D6DEE4", BG="#EEF2F4", G="#0B5B35", ROAD="#F2B43C";
  const IW=W-2*P, GUT=30, CX=P+GUT, CW=IW-GUT; // área dos cards da rota
  const itens=[]; const add=(h,draw,keep)=>itens.push({h,draw,keep:!!keep});
  const card=(ctx,x,y,w,h,top,bot,borda)=>{ const r=10; ctx.beginPath(); ctx.moveTo(x,y+(top?r:0)); if(top){ ctx.arcTo(x,y,x+r,y,r); ctx.lineTo(x+w-r,y); ctx.arcTo(x+w,y,x+w,y+r,r); } else { ctx.lineTo(x,y); ctx.lineTo(x+w,y); }
    if(bot){ ctx.lineTo(x+w,y+h-r); ctx.arcTo(x+w,y+h,x+w-r,y+h,r); ctx.lineTo(x+r,y+h); ctx.arcTo(x,y+h,x,y+h-r,r); } else { ctx.lineTo(x+w,y+h); ctx.lineTo(x,y+h); } ctx.closePath();
    ctx.fillStyle="#fff"; ctx.fill(); if(borda){ ctx.save(); ctx.clip(); ctx.fillStyle=borda; ctx.fillRect(x,y,5,h); ctx.restore(); } };
  const T=(txt,x,y,font,cor,al)=>{ ctx_.font=font; ctx_.fillStyle=cor; ctx_.textAlign=al||"left"; ctx_.fillText(txt,x,y); ctx_.textAlign="left"; };
  let ctx_=null;
  const secao=(t,sub)=>add(40,(ctx,y)=>{ T(t,P+2,y+28,FNT(700,19,"c"),INK); if(sub){ ctx.font=FNT(700,19,"c"); const w=ctx.measureText(t).width; T(sub,P+10+w,y+28,FNT(500,13),MUT); } },true);
  // KPIs
  const nT=d.carga.transito||0, nP=d.carga.porto||0, ate=d.C.ate.concat(d.C.limite), depois=d.C.depois;
  const kp=[["Processos",d.rows.length,G],["Em viagem",nT+nP,"#2B5AA6"],["Aguard. descarga",d.carga.descarga||0,GER_COR.desc],["Atrasados",d.sit.crit||0,GER_COR.crit],["Em risco",d.sit.warn||0,GER_COR.warn],["No prazo",d.sit.ok||0,GER_COR.ok],
    ["Sem veículo",d.carga.semveic||0,GER_COR.info],["Críticos em risco",d.critRisco.length,d.critRisco.length?GER_COR.crit:MUT],["Chegam até 23h",ate.length,GER_COR.ok]];
  const kw=(IW-2*10)/3, kh=70;
  // manutenção
  if(d.manut.length){ const fs=d.manut.map(pl=>d.rows.find(r=>r.placa===pl&&r.f)).filter(Boolean);
    add(34+fs.length*22+10,(ctx,y)=>{ rr(ctx,P,y,IW,34+fs.length*22,10); ctx.fillStyle="#FBE5E2"; ctx.fill(); ctx.strokeStyle=GER_COR.crit; ctx.lineWidth=1.5; ctx.stroke();
      T(`🔧 ${fs.length} veículo${fs.length>1?"s":""} em manutenção`,P+14,y+24,FNT(700,15),GER_COR.crit);
      fs.forEach((r,i)=>{ ctx.font=FNT(400,12.5); T(fit(ctx,`${r.placa} · ${d.rows.filter(x=>x.placa===r.placa).map(x=>x.cn).join(" + ")} · ${manutTxt(r.f)}`,IW-28),P+14,y+46+i*22,FNT(400,12.5),INK); }); }); }
  // resumo operacional
  const dims=[["Status da carga",["transito","porto","betim","descarga","semveic","entregue"].filter(k=>d.carga[k]).map(k=>[BI_CARGA[k]||k,d.carga[k],G])],
    ["Destino",Object.entries(d.dest).map(([k,v])=>[k,v,G])],
    ["Situação",["crit","warn","ok","info"].filter(k=>d.sit[k]).map(k=>[BI_SIT[k],d.sit[k],GER_COR[k]])]];
  // mapa do corredor (mesmo desenho do Painel BI)
  let mapa=null; if(op.mapa){ try{ mapa=await mapaImagem(d.mapa,d.now); }catch(e){ console.warn("mapa",e); } }
  if(mapa){ const mw=IW, mh=Math.round(mw*mapa.vh/mapa.vw);
    secao("Mapa · posição dos veículos",`${d.veics} no corredor`);
    add(mh+14,(ctx,y)=>{ ctx.save(); rr(ctx,P,y,mw,mh,10); ctx.clip(); ctx.imageSmoothingQuality="high"; ctx.drawImage(mapa.img,P,y,mw,mh); ctx.restore(); rr(ctx,P,y,mw,mh,10); ctx.strokeStyle=LINE; ctx.lineWidth=1; ctx.stroke(); }); }
  // posição dos veículos – rota vertical (planta no topo, porto embaixo)
  const iMap=itens.length;
  const i0=itens.length;
  secao("Detalhe por cidade",`${d.veics} veículo${d.veics===1?"":"s"} · BR-040 / BR-381`);
  add(62,(ctx,y)=>{ rr(ctx,P,y,IW,52,10); ctx.fillStyle="#fff"; ctx.fill();
    const L=[["crit","Atrasado"],["warn","Em risco"],["ok","No prazo"],["desc","Descarga"],["done","Entregue"],["info","Sem necessidade"],["!","Crítico Iveco"]], cw=(IW-20)/4;
    L.forEach(([k,t],i)=>{ const x=P+10+(i%4)*cw, yy=y+8+Math.floor(i/4)*22;
      if(k==="!"){ ctx.beginPath(); ctx.arc(x+11,yy+9,7,0,Math.PI*2); ctx.fillStyle=GER_COR.crit; ctx.fill(); T("!",x+11,yy+13.5,FNT(800,11),"#fff","center"); }
      else truckCv(ctx,x,yy+1,22,GER_COR[k]);
      T(t,x+27,yy+14,FNT(500,12),INK); }); },true);
  const estrada=(ctx,y,h,cor)=>{ ctx.fillStyle=cor||ROAD; ctx.fillRect(P+11,y,6,h); };
  const pos=d.posicoes;
  add(34,(ctx,y)=>{ estrada(ctx,y+20,14); ctx.beginPath(); ctx.arc(P+14,y+16,9,0,Math.PI*2); ctx.fillStyle=G; ctx.fill(); ctx.strokeStyle="#fff"; ctx.lineWidth=2.5; ctx.stroke();
    T("Iveco · planta",CX+6,y+21,FNT(700,14,"c"),G); },true);
  if(!pos.length) add(40,(ctx,y)=>{ estrada(ctx,y,40); T("Nenhum veículo em rota para o filtro atual.",CX+6,y+24,FNT(400,13),MUT); });
  pos.forEach((g,gi)=>{
    const tot=g.veic.length;
    add(38,(ctx,y)=>{ estrada(ctx,y,38); ctx.beginPath(); ctx.arc(P+14,y+22,7,0,Math.PI*2); ctx.fillStyle="#fff"; ctx.fill(); ctx.strokeStyle=INK; ctx.lineWidth=2.5; ctx.stroke();
      card(ctx,CX,y+6,CW,32,true,false); ctx.font=FNT(700,15,"c"); T(fit(ctx,g.nome,CW-150),CX+12,y+28,FNT(700,15,"c"),INK);
      T(g.km===0?"na planta":g.km!=null?`${g.km} km da planta`:"sem distância",CX+CW-12,y+28,FNT(600,12.5),MUT,"right"); },true);
    g.veic.forEach((v,i)=>{ const ult=i===tot-1;
      add(ult?58:50,(ctx,y)=>{ estrada(ctx,y,ult?58:50);
        const r0=v.rs.slice().sort((a,c)=>({crit:0,warn:1,info:2,ok:3}[a.tone]-{crit:0,warn:1,info:2,ok:3}[c.tone]))[0], t=tomLinha(r0), c=GER_COR[t];
        card(ctx,CX,y,CW,50,false,ult); ctx.strokeStyle=LINE; ctx.beginPath(); ctx.moveTo(CX+10,y); ctx.lineTo(CX+CW-10,y); ctx.stroke();
        truckCv(ctx,CX+10,y+9,28,c);
        const cns=v.rs.map(r=>r.cn).join(" + "); ctx.font=FNT(700,13.5,"m"); const cnTxt=fit(ctx,cns,CW-150); T(cnTxt,CX+46,y+20,FNT(700,13.5,"m"),INK);
        let xx=CX+46+ctx.measureText(cnTxt).width+6; if(v.rs.some(r=>r.crit)){ ctx.beginPath(); ctx.arc(xx+7,y+15,7,0,Math.PI*2); ctx.fillStyle=GER_COR.crit; ctx.fill(); T("!",xx+7,y+19.5,FNT(800,11),"#fff","center"); }
        let det; if(r0.manut) det="🔧 em manutenção"; else if(r0.carga==="descarga") det=`no cliente ${fmtH(v.f.chegada)} · aguard. descarga`; else if(r0.carga==="entregue") det=`entregue ${fmt(v.f.chegada)}`;
        else if(v.q){ det = v.q.vencida?`prev. ${fmtH(v.f.prev_chegada)} vencida`:`chega ${v.q.est?"≈ ":""}${fmtH(iso(v.q.eta))} (${dur(v.q.min).slice(1)})`; if(v.q.km!=null&&g.km!==v.q.km) det=v.q.km+" km · "+det; } else det="sem previsão";
        ctx.font=FNT(400,12.5); T(fit(ctx,`${v.placa||"—"} · ${det}`,CW-140),CX+46,y+39,FNT(400,12.5),MUT);
        const gap=r0.carga==="descarga"?"descarga":r0.carga==="entregue"?"entregue":r0.gap!=null?dur(r0.gap):"—";
        T(gap,CX+CW-12,y+21,FNT(700,15,"m"),c,"right");
        T("nec. "+(r0.need?fmt(r0.need):"—"),CX+CW-12,y+39,FNT(500,11.5),MUT,"right"); });
    });
  });
  add(34,(ctx,y)=>{ estrada(ctx,y,12); ctx.beginPath(); ctx.arc(P+14,y+17,8,0,Math.PI*2); ctx.fillStyle=INK; ctx.fill(); ctx.strokeStyle="#fff"; ctx.lineWidth=2.5; ctx.stroke();
    T("Portos · Rio de Janeiro / Santos",CX+6,y+22,FNT(700,14,"c"),INK); });
  if(!op.det) itens.splice(i0);
  // sem veículo
  const sv=d.semVeic.slice().sort((a,c)=>String(a.need).localeCompare(String(c.need)));
  if(sv.length&&!mapa){ secao("Sem veículo alocado",`(${sv.length})`); const pares=[]; for(let i=0;i<sv.length;i+=2) pares.push(sv.slice(i,i+2));
    pares.forEach((pr,i)=>{ const ult=i===pares.length-1; add(ult?36:26,(ctx,y)=>{ card(ctx,P,y,IW,ult?30:26,i===0,ult); const colW=(IW-28)/2;
      pr.forEach((r,j)=>{ const x=P+14+j*colW, c=GER_COR[r.tone]||GER_COR.info; ctx.beginPath(); ctx.arc(x+5,y+(i===0?17:13)-4,4.5,0,Math.PI*2); ctx.fillStyle=c; ctx.fill();
        const yy=y+(i===0?17:13); T(r.cn,x+15,yy,FNT(600,12.5,"m"),INK); ctx.font=FNT(600,12.5,"m"); const w=ctx.measureText(r.cn).width;
        T(r.need?fmt(r.need):"—",x+21+w,yy,FNT(400,12),MUT); if(r.crit){ ctx.font=FNT(400,12); T("!",x+27+w+ctx.measureText(r.need?fmt(r.need):"—").width,yy,FNT(800,13),GER_COR.crit); } }); }); }); }
  // rodovias
  if(d.alertas.length){ secao("Rodovias"); d.alertas.forEach(a=>add(52,(ctx,y)=>{ const c=a.tom==="crit"?GER_COR.crit:a.tom==="warn"?GER_COR.warn:GER_COR.info; card(ctx,P,y,IW,46,true,true,c);
    ctx.font=FNT(600,13); T(fit(ctx,a.titulo,IW-34),P+16,y+20,FNT(600,13),INK); ctx.font=FNT(400,12); T(fit(ctx,a.quando,IW-34),P+16,y+37,FNT(400,12),MUT); })); }
  // imagens: 1) mapa  2) detalhe por cidade (quando as duas opções estão marcadas)
  const H1=112, FOOT=40;
  const docs = (mapa&&op.det) ? [{its:itens.slice(0,iMap),tit:"Posição dos veículos"},{its:itens.slice(iMap),tit:"Detalhe por cidade"}] : [{its:itens,tit:"Posição dos veículos"}];
  return docs.filter(dc=>dc.its.length).map((dc,di,arr)=>{
    const PHt=Math.ceil(H1+dc.its.reduce((a,it)=>a+it.h,0)+FOOT+8);
    const cv=document.createElement("canvas"); cv.width=W*S; cv.height=PHt*S; const ctx=cv.getContext("2d"); ctx.scale(S,S); ctx_=ctx;
    ctx.fillStyle=BG; ctx.fillRect(0,0,W,PHt);
    ctx.fillStyle=G; ctx.fillRect(0,0,W,H1-12); truckCv(ctx,P,22,40,"#fff");
    T("CARGA IVECO · TORRE DE CONTROLE"+(arr.length>1?`  ·  IMAGEM ${di+1} DE ${arr.length}`:""),P+52,30,FNT(600,11.5,"c"),"#CFEBD8"); T(dc.tit,P+52,58,FNT(700,26,"c"),"#fff");
    T(`${fmt(d.now)}  ·  último follow ${state.meta.ultimoFollow?fmt(state.meta.ultimoFollow):"—"}`,P,82,FNT(500,13.5),"#E4F4EA");
    if(d.filtros){ ctx.font=FNT(400,12); T(fit(ctx,"Filtro: "+d.filtros,IW),P,98,FNT(400,12),"#CFEBD8"); }
    let y=H1; const cuts=[H1]; dc.its.forEach(it=>{ it.draw(ctx,y); y+=it.h; if(!it.keep) cuts.push(y); });
    cv.cuts=cuts; cv.lh=PHt; cv.lw=W; cv.S=S; cv.tit=dc.tit;
    ctx.fillStyle=LINE; ctx.fillRect(P,PHt-FOOT+6,IW,1);
    T("Km aproximados pela BR-040/BR-381 · ≈ estimado · ! crítico Iveco",P,PHt-14,FNT(400,11),MUT);
    return cv; });
}
let _jspdf=null;
function carregaJsPdf(){ if(window.jspdf) return Promise.resolve(window.jspdf); if(_jspdf) return _jspdf;
  _jspdf=new Promise((ok,er)=>{ const sc=document.createElement("script"); sc.src="jspdf.umd.min.js"; sc.onload=()=>window.jspdf?ok(window.jspdf):er(new Error("jsPDF indisponível")); sc.onerror=()=>{ _jspdf=null; er(new Error("não foi possível carregar o gerador de PDF")); }; document.head.appendChild(sc); });
  return _jspdf; }
async function gerPdf(lista){
  const {jsPDF}=await carregaJsPdf(); let pdf=null; const MAX=1000; const todas=[];
  for(const cv of [].concat(lista)){ const S=cv.S||3, W=cv.lw||540, H=cv.lh||cv.height/S, cuts=(cv.cuts||[]).concat([H]);
  const pags=[]; let y0=0;
  while(y0<H-1){ let y1=cuts.filter(c=>c>y0+MAX*0.55&&c<=y0+MAX).pop(); if(!y1) y1=Math.min(H,y0+MAX); if(H-y1<60) y1=H; pags.push([y0,y1]); y0=y1; }
  pags.forEach(pg=>todas.push({cv,S,W,pg})); }
  todas.forEach(({cv,S,W,pg},i)=>{ const [a,b]=pg; const h=b-a, c=document.createElement("canvas"); c.width=W*S; c.height=Math.round(h*S); const x=c.getContext("2d");
    x.fillStyle="#EEF2F4"; x.fillRect(0,0,c.width,c.height); x.drawImage(cv,0,Math.round(a*S),W*S,Math.round(h*S),0,0,W*S,Math.round(h*S));
    if(todas.length>1){ x.fillStyle="#5A6A77"; x.font=`600 ${11*S}px Arial`; x.textAlign="right"; x.fillText(`${i+1}/${todas.length}`,(W-8)*S,(h-6)*S); }
    const img=c.toDataURL("image/png");
    const ori=h>=W?"portrait":"landscape"; if(!pdf) pdf=new jsPDF({unit:"pt",format:[W,h],orientation:ori,compress:true}); else pdf.addPage([W,h],ori);
    pdf.addImage(img,"PNG",0,0,W,h,undefined,"FAST"); });
  return pdf.output("arraybuffer");
}
function painelGerente(){
  let cvs=[], d=null, fone="";
  try{ fone=localStorage.getItem("iveco.gerenteFone")||""; }catch(e){}
  openPanel(`<h3>Enviar resumo · WhatsApp</h3>
    <p>Com as duas opções marcadas, o resumo sai em <b>duas imagens</b>: 1) mapa da posição dos veículos e 2) detalhe por cidade, com os dados e filtros atuais do Painel BI. No celular, <b>Compartilhar imagens</b> envia as duas juntas para o WhatsApp.</p>
    <div class="msg info" style="font-size:13px">O WhatsApp reduz imagens compridas ao enviar como foto. Para o gerente ampliar sem perder nitidez, envie o <b>PDF</b> ou a imagem como <b>Documento</b> (📎 › Documento). O PDF vem dividido em páginas no tamanho da tela do celular.</div>
    <div class="row" style="gap:16px"><label class="chk"><input type="checkbox" id="g-omapa"> Incluir mapa da posição dos veículos</label><label class="chk"><input type="checkbox" id="g-odet"> Incluir detalhe por cidade</label></div>
    <div class="ger-pags" id="g-pags"></div>
    <div class="row">
      <button class="btn primary" id="g-share" type="button" hidden>Compartilhar imagem</button>
      <button class="btn primary" id="g-pdf" type="button">Baixar PDF (máxima qualidade)</button>
      <button class="btn" id="g-png" type="button">Baixar imagem</button>
      <button class="btn" id="g-cimg" type="button">Copiar imagem</button>
      <button class="btn ghost" id="g-ref" type="button">Atualizar</button>
    </div>
    <label style="display:block;margin-top:10px"><span class="sub">Mensagem de texto (pode editar antes de enviar)</span>
      <textarea id="g-txt" rows="10" style="width:100%;margin-top:4px"></textarea></label>
    <div class="row" style="align-items:flex-end">
      <label><span class="sub">WhatsApp do gerente (opcional, com DDD)</span><input id="g-fone" inputmode="tel" placeholder="(11) 99999-9999" style="display:block;margin-top:4px;background:var(--surface2);border:1px solid var(--line);border-radius:6px;padding:8px 10px;width:220px"></label>
      <a class="btn primary" id="g-wa" target="_blank" rel="noopener" style="text-decoration:none">Abrir no WhatsApp com o texto</a>
      <button class="btn" id="g-ctxt" type="button">Copiar texto</button>
      <button class="btn ghost" id="g-x" type="button" style="margin-left:auto">Fechar</button>
    </div>
    <div id="g-msg"></div>`, async el=>{
    el.classList.add("wide");
    const msg=(t,ok)=>el.querySelector("#g-msg").innerHTML=`<div class="msg ${ok?"ok":"err"}">${esc(t)}</div>`;
    const box=el.querySelector("#g-pags"), ta=el.querySelector("#g-txt"), fo=el.querySelector("#g-fone"), wa=el.querySelector("#g-wa");
    fo.value=fone;
    const link=()=>{ let n=(fo.value||"").replace(/\D/g,""); if(n&&n.length<=11) n="55"+n; wa.href=`https://wa.me/${n}?text=${encodeURIComponent(ta.value)}`; };
    const nome=i=>{ const t=new Date(); return `Iveco_resumo_${pad(t.getDate())}${pad(t.getMonth()+1)}_${pad(t.getHours())}${pad(t.getMinutes())}${cvs.length>1?"_"+(i+1)+"de"+cvs.length:""}.png`; };
    const blob=cv=>new Promise(res=>cv.toBlob(res,"image/png"));
    const arquivos=async()=>Promise.all(cvs.map(async(cv,i)=>new File([await blob(cv)],nome(i),{type:"image/png"})));
    const copiar=i=>{ try{ navigator.clipboard.write([new ClipboardItem({"image/png":blob(cvs[i])})]).then(()=>{ if(cvs.length<2) msg("Imagem copiada. Cole na conversa do WhatsApp (Ctrl+V).",true); },()=>msg("Este navegador não permite copiar imagem aqui. Use Baixar.",false)); }catch(e){ msg("Este navegador não permite copiar imagem aqui. Use Baixar.",false); } };
    const baixar=async i=>{ const dl=await window.APP_SERVICOS?.use?.("downloads"); if(!dl){ msg("Download indisponível nesta visualização. Use Copiar.",false); return false; }
      try{ await dl.save({filename:nome(i), data:await blob(cvs[i])}); return true; }catch(e){ if(e.code!=="declined") msg("Não foi possível salvar ("+e.code+").",false); return false; } };
    { let op={mapa:true,det:true}; try{ op=Object.assign(op,JSON.parse(localStorage.getItem("iveco.gerOp")||"{}")); }catch(e){} el.querySelector("#g-omapa").checked=op.mapa; el.querySelector("#g-odet").checked=op.det;
      ["#g-omapa","#g-odet"].forEach(id=>el.querySelector(id).onchange=()=>{ if(!el.querySelector("#g-omapa").checked&&!el.querySelector("#g-odet").checked){ el.querySelector(id).checked=true; return; } gera(); }); }
    const gera=async()=>{ if(!document.body.contains(el)){ if(window.__gerAtu===gera) window.__gerAtu=null; return; } d=gerDados(); ta.value=textoGerente(d); link(); const op={mapa:el.querySelector("#g-omapa").checked,det:el.querySelector("#g-odet").checked}; try{ localStorage.setItem("iveco.gerOp",JSON.stringify(op)); }catch(e){} cvs=await desenhaGerente(d,op);
      box.innerHTML=cvs.map((cv,i)=>`<figure class="ger-pg"><figcaption><b>${cvs.length>1?(i+1)+" · ":""}${esc(cv.tit||"Resumo")}</b><span><button class="btn sm" type="button" data-cp="${i}">Copiar</button> <button class="btn sm" type="button" data-dl="${i}">Baixar</button></span></figcaption><img src="${cv.toDataURL("image/png")}" alt="${esc(cv.tit||"Resumo")}"></figure>`).join(""); seqCp=0; atualizaCp(); el.querySelector("#g-png").textContent=cvs.length>1?`Baixar as ${cvs.length} imagens`:"Baixar imagem"; el.querySelector("#g-share").textContent=cvs.length>1?"Compartilhar as 2 imagens":"Compartilhar imagem";
      box.querySelectorAll("[data-cp]").forEach(b=>b.onclick=()=>{ const i=+b.dataset.cp; copiar(i); if(cvs.length>1) setTimeout(()=>msg(`Imagem ${i+1} (${cvs[i].tit}) copiada. Cole no WhatsApp (Ctrl+V).`,true),150); });
      box.querySelectorAll("[data-dl]").forEach(b=>b.onclick=async()=>{ if(await baixar(+b.dataset.dl)) msg("Imagem salva.",true); });
      
      try{ const fs=await arquivos(); el.querySelector("#g-share").hidden=!(navigator.canShare&&navigator.canShare({files:fs})); }catch(e){} };
    ta.oninput=link; fo.oninput=()=>{ link(); try{ localStorage.setItem("iveco.gerenteFone",fo.value); }catch(e){} };
    window.__gerAtu=gera; ta.addEventListener("input",()=>{ ta.dataset.editado="1"; });
    el.querySelector("#g-x").onclick=closePanel;
    let seqCp=0; const atualizaCp=()=>{ const b=el.querySelector("#g-cimg"); if(!b) return; b.textContent=cvs.length>1?`Copiar imagem ${seqCp+1} de ${cvs.length}`:"Copiar imagem"; };
    el.querySelector("#g-cimg").onclick=()=>{ const i=seqCp; copiar(i); if(cvs.length>1){ seqCp=(seqCp+1)%cvs.length; atualizaCp(); setTimeout(()=>msg(i===0?`Imagem 1 (${cvs[0].tit}) copiada. Cole no WhatsApp (Ctrl+V) e clique de novo para copiar a imagem 2.`:`Imagem 2 (${cvs[1].tit}) copiada. Cole no WhatsApp (Ctrl+V).`,true),150); } };
    el.querySelector("#g-pdf").onclick=async()=>{ const bt=el.querySelector("#g-pdf"); bt.disabled=true; const old=bt.textContent; bt.textContent="Gerando PDF…";
      try{ const buf=await gerPdf(cvs); const dl=await window.APP_SERVICOS?.use?.("downloads"); if(!dl){ msg("Download indisponível nesta visualização.",false); return; }
        await dl.save({filename:nome(0).replace(/\.png$/,".pdf"),data:new Uint8Array(buf)}); msg("PDF salvo. No WhatsApp, anexe como Documento.",true); }
      catch(e){ if(e&&e.code==="declined"){} else msg("Não foi possível gerar o PDF ("+((e&&(e.code||e.message))||"erro")+").",false); }
      finally{ bt.disabled=false; bt.textContent=old; } };
    el.querySelector("#g-ref").onclick=async()=>{ delete ta.dataset.editado; await gera(); msg("Resumo atualizado com os dados de agora.",true); };
    el.querySelector("#g-png").onclick=async()=>{ let n=0; for(let i=0;i<cvs.length;i++){ if(await baixar(i)) n++; else break; } if(n) msg(`${n} imagem${n>1?"ns":""} salva${n>1?"s":""}. Anexe na conversa do WhatsApp com o gerente.`,true); };
    el.querySelector("#g-share").onclick=async()=>{ try{ await navigator.share({files:await arquivos(), text:ta.value}); }catch(e){ if(e.name!=="AbortError") msg("Não foi possível compartilhar daqui. Use Copiar ou Baixar.",false); } };
    el.querySelector("#g-ctxt").onclick=()=>navigator.clipboard.writeText(ta.value).then(()=>msg("Texto copiado. Cole na conversa do WhatsApp.",true),()=>msg("Não foi possível copiar o texto.",false));
    await gera();
  });
}

async function exportar(){
  if(typeof XLSX==="undefined"){ toast("Leitor de planilha indisponível"); return; }
  const now=new Date();
  const comp=linhasComp().map(r=>({"Container":r.p.container,"Necessidade Iveco":fmt(r.p.necessidade),"Criticidade":r.p.criticidade||"","Situação":r.a.label,"Alertas":r.a.flags.map(f=>f.s).join(" | "),
    "Status follow":r.f?r.f.status:"","Localização":r.f?r.f.localizacao:"","Previsão":r.f?fmt(r.f.prev_chegada):"","Chegada":r.f?fmt(r.f.chegada):"","Desvio (h)":r.a.gap!=null?Math.round(r.a.gap/6)/10:"",
    "Placa":r.f?r.f.placa_cavalo:"","Motorista":r.f?r.f.motorista:"","Navio":r.p.navio,"Solicitante":r.p.solicitante,"Descarga":r.p.local_descarga}));
  const fol=Object.values(state.follow).map(f=>({"Container":f.container,"ID original":f.idOriginal,"Local de entrega":f.local_entrega,"Status":f.status,"Localização":f.localizacao,"Início":fmt(f.inicio),"Prev. chegada":fmt(f.prev_chegada),"Data programada":fmt(f.data_prog),"Chegada":fmt(f.chegada),"Placa cavalo":f.placa_cavalo,"Placa reboque":f.placa_reboque,"Motorista":f.motorista,"Atualizado":fmt(f.atualizadoEm)}));
  const wb=XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(comp),"Necessidade x Follow");
  XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(fol),"Follow");
  const I=calcInd(state.periodo), pct=v=>v==null?"":Math.round(v*1000)/10, hrs=v=>v==null?"":Math.round(v/6)/10;
  const indRows=[
    ["Período",PERIODOS[state.periodo]],["Programados",I.prog.length],["Cobertura de veículo (%)",pct(I.cobertura)],["Sem veículo com necessidade vencida",I.semVencidos.length],
    ["Entregues",I.entregues.length],["Pontualidade de entrega - OTD (%)",pct(I.otd)],["OTD itens para linha (%)",pct(I.otdLinha)],["Atraso médio das entregas atrasadas (h)",hrs(I.atrasoMedio)],
    ["Em trânsito",I.transito.length],["Em trânsito com previsão dentro da necessidade (%)",pct(I.transitoOk)],["Desvio médio previsto em trânsito (h)",hrs(I.desvioPrev)],["Aguardando carregamento no porto",I.porto.length],
    ["Tempo médio de viagem (h)",hrs(I.lead)],["Erro médio da 1ª previsão (h)",hrs(I.erroPrimeira)],["Erro médio da última previsão (h)",hrs(I.erroUltima)],
    ["Follows com horário programado divergente (%)",pct(I.divergencia)],["Follows enviados hoje",I.env.feitos],["Horas com follow hoje (%)",pct(I.env.aderencia)],["Maior intervalo sem follow hoje (h)",hrs(I.env.maiorGap)]
  ].map(([a,b])=>({"Indicador":a,"Valor":b}));
  XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(indRows),"Indicadores");
  XLSX.utils.book_append_sheet(wb,XLSX.utils.json_to_sheet(I.grupos.map(g=>({"Grupo":g.nome,"Containers":g.n,"Com veículo":g.comVeic,"Entregues":g.ent,"No prazo":g.ok,"OTD (%)":pct(g.otd),"Atraso médio entregas (h)":hrs(g.atraso),"Em trânsito":g.trans,"Desvio previsto médio (h)":hrs(g.prev)}))),"Indicadores por grupo");
  const buf=XLSX.write(wb,{type:"array",bookType:"xlsx"});
  const dl=await window.APP_SERVICOS?.use?.("downloads");
  if(!dl){ toast("Download indisponível nesta visualização"); return; }
  try{ await dl.save({filename:`Iveco_Necessidade_x_Follow_${now.getFullYear()}${pad(now.getMonth()+1)}${pad(now.getDate())}_${pad(now.getHours())}${pad(now.getMinutes())}.xlsx`, data:new Uint8Array(buf)}); }
  catch(e){ if(e.code!=="declined") toast("Não foi possível exportar ("+e.code+")"); }
}

/* ---------- eventos ---------- */
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{
  state.tab=b.dataset.tab; document.querySelectorAll(".tab").forEach(x=>x.setAttribute("aria-selected", String(x===b)));
  ["tab","fc","bi","anim","crit","comp","tl","fora","prog","rod","ind"].forEach(k=>$("#v-"+k).hidden = k!==state.tab);
  $("#f-sit").hidden = !(state.tab==="comp"||state.tab==="tl");
  $("#w-socrit").hidden = !(state.tab==="comp"||state.tab==="tl"||state.tab==="prog");
  document.querySelector(".legend").hidden = state.tab!=="tl";
  document.querySelector(".toolbar").hidden = state.tab==="ind"||state.tab==="rod"||state.tab==="bi"||state.tab==="anim"||state.tab==="tab"||state.tab==="fc";
  document.body.classList.toggle("bi-mode", state.tab==="bi");
  try{ localStorage.setItem("iveco.tab",state.tab);}catch(e){}
  render();
});
$("#q").oninput=e=>{ state.q=e.target.value; render(); };
$("#f-dia").onchange=e=>{ state.dia=e.target.value; render(); };
$("#f-sit").onchange=e=>{ state.sit=e.target.value; render(); };
$("#f-socrit").onchange=e=>{ state.soCrit=e.target.checked; render(); };
$("#b-import").onclick=painelImport;
$("#b-new").onclick=()=>painelEdit(null);
$("#b-resumo").onclick=painelResumo;
$("#b-export").onclick=exportar;
document.addEventListener("click",e=>{ const tr=e.target.closest("tbody tr[data-cn]"); if(tr) painelEdit(tr.dataset.cn); });
document.addEventListener("keydown",e=>{ if(e.key==="Enter"){ const tr=e.target.closest&&e.target.closest("tbody tr[data-cn]"); if(tr) painelEdit(tr.dataset.cn); } });
window.addEventListener("resize",()=>{ if(state.tab==="tl") renderTl(filtra(linhasComp(),()=>"")); });
setInterval(render, 60000);

/* ---------- conexão ---------- */
function setConn(on,t){ $("#conn-dot").className="dot "+(on?"on":"off"); $("#conn-txt").textContent=t; }
render();
(async()=>{
  const db = window.APP_SERVICOS && window.APP_SERVICOS.use ? await window.APP_SERVICOS.use("db") : null;
  if(!db){ setConn(false,"Base indisponível nesta visualização"); return; }
  state.db=db; setConn(true,(window.__modoNuvem&&window.__modoNuvem().nuvem)?"Conectando à nuvem…":"Salvo neste aparelho");
  const sub=(col,key)=>db.collection(col).onSnapshot(s=>{ const m={}; s.docs.forEach(d=>{ const x=d.data(); if(x){ if(col==="follow") limpaVazios(x); m[d.id]=x; } }); state[key]=m; render(); }, e=>setConn(false,"Conexão perdida ("+e.code+") · recarregue"));
  sub("prog","prog"); sub("follow","follow"); sub("envios","envios"); sub("alertas","alertas");
  let varreu=false;
  db.collection("cidades").onSnapshot(s=>{ s.docs.forEach(d=>{ const c=d.data(); if(c) registraCidade(c); }); render();
    if(!varreu){ varreu=true; setTimeout(()=>autoCidades(Object.values(state.follow)).then(r=>{ if(r.novas.length){ toast(`Cidades adicionadas à rota: ${r.novas.map(c=>c.nome).join(", ")}`); render(); } }),1500); } }, ()=>{});
  db.doc("meta/rodovias").onSnapshot(s=>{ state.rodMeta=s.exists?s.data():{}; render(); }, ()=>{});
  db.doc("meta/info").onSnapshot(s=>{ state.meta=s.exists? s.data() : {}; render(); }, ()=>{});
})();
try{ const bb=JSON.parse(localStorage.getItem("iveco.bi")||"null"); if(bb) state.bi=Object.assign(state.bi,bb);
  const b=state.bi; b.cn=Array.isArray(b.cn)?b.cn:[]; b.crit=Array.isArray(b.crit)?b.crit:(b.crit==="criticos"?["__crit__"]:A(b.crit)); b.dia=A(b.dia);
  b.carga=Array.isArray(b.carga)?b.carga.filter(v=>v!=="betim"):(b.carga==="ativos"?["transito","porto","descarga","semveic"]:A(b.carga).filter(v=>v!=="betim")); b.sit=A(b.sit); b.dest=A(b.dest).filter(v=>v==="Sete Lagoas"||v==="Betim"); }catch(e){}
document.body.classList.toggle("bi-mode", state.tab==="bi");
try{ const pp=localStorage.getItem("iveco.periodo"); if(pp&&PERIODOS[pp]) state.periodo=pp; }catch(e){}
try{ const t=localStorage.getItem("iveco.tab"); if(t){ const b=document.querySelector(`.tab[data-tab="${t}"]`); b&&b.click(); } }catch(e){}
})();
